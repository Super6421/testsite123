Thank you for purchase
Merci pour votre achat

------------------------------------
ShizuArt discord :
https://discord.gg/Fq8Bb7stC3
------------------------------------

EN(english) instructions:

!!! Make sure you have backed up your folders before adding a new model pack !!!

Open EN.zip

ItemsAdder :
   1. Open [EN.zip] and open [For ItemsAdder] folder
   2. Drag & Drop [shizuart_furnitures] folder in your [contents] folder

Oraxen :
   1. Open [EN.zip] folder and open [For Oraxen] folder
   2. Drag & Drop [items] and [pack] folders in your [Oraxen] folder


------------------------------------------------------------------------------

FR(français) instructions:

!!! Assurez-vous d'avoir fait une sauvegarde de vos dossiers avant d'ajouter un nouveau pack de models !!!

Ouvrez FR.zip

ItemsAdder :
   1. Ouvrez [FR.zip] et ouvrez le dossier [Pour ItemsAdder]
   2. Drag & Drop le dossier [shizuart_furnitures] dans votre dossier [contents]

Oraxen :
   1. Ouvrez le dossier [FR.zip] et ouvrez le dossier [Pour Oraxen]
   2. Drag & Drop le dossier [items] et [pack] dans votre dossier [Oraxen]
#d2bd06b1c2803fa391cfdb2047d23fdc