This assets are downloaded from:
    MCModels Marketplace
    Website:
        mcmodels.net

Models by:
    Akaleaf
    Contacts: 
        discord:
            akaleaf#4723
            discord.gg/jpbHGee <--- If you have any suggestions or ideas, questions or if you wanna see what the next product will be on the mcmodels, join our discord server! :pLove: :spinAkaleaf2:
        x:
            x.com/akaleafwastaken

Emissive 1.18.1 shaders (curseforge.com/minecraft/texture-packs/coredynamicemissives) by:
    Shock Micro
#6b607da587d66f198661f245b3793d23