Still have any questions?:
    1. Create a ticket help on mcmodels discord server
    2. Join my discord server here: https://discord.gg/jpbHGee
    3. DM me (Akaleaf) by the discord: akaleaf#4723
____________________________________________________________________________________________________________________________________________________________________________________
____________________________________________________________________________________________________________________________________________________________________________________

Installation:

    Installing via Nexo:
        1. According to your server version choose the folder.
            1.1) 1_21_1_and_below folder for 1.20 - 1.21.4
                Choose this, if you want to add: custom armors configuration with TRIMS implementation which works from 1.20 minecraft version (1.21.2+ too)

            1.2) 1_21_2_and_above folder for 1.21.2 - 1.21.4
                Choose this, if you want to add: custom armors configuration with COMPONENT implementation which works from 1.21.2 minecraft version

            For more informatoin about the differencies betwenn TRIMS and COMPONENT implementations check this Nexo custom armors wiki page:
                https://docs.nexomc.com/configuration/custom-armors

        2. To your "plugins" folder drop "Nexo" folder. This will add the necessary files.
        3. On the server or in the console of the server type "/n rl all"
        4. Restart your server and join
        5. Type "/n inv" to see added assets

    Installing via ItemsAdder:
        1. To your "plugins" folder drop "ItemsAdder" folder. This will add the necessary files.
        2. On the server type "/iazip" and apply generated resourcepack to your game if it doesn't applied automatically.
        3. Type "/ia" to see added assets

    Installing via Oraxen:
        1. To your "plugins" folder drop "Oraxen" folder. This will add the necessary files.
        2. On the server type "/o rl all" and apply generated resourcepack to your game if it doesn't applied automatically.
        3. Type "/o inv" to see added assets
____________________________________________________________________________________________________________________________________________________________________________________
____________________________________________________________________________________________________________________________________________________________________________________

Troubleshooting:

    Nexo:
        1. Armor doesn't display on a character:
            Restart your server and see if it is fixed.

        2. Armor doesn't display or has incorrect display on a character:
            Check again paragraph 1. of "Installing via Nexo"

    ItemsAdder:
        1. Armor doesn't display or has incorrect display on a character:
            If enabled shaders, OptiFine, Iris, Phosphor, Sodium, other similar mods - try to launch without them

    Oraxen:
        1. Armor doesn't display or has incorrect display on a character:
            If enabled shaders, OptiFine, Iris, Phosphor, Sodium, other similar mods - try to launch without them
____________________________________________________________________________________________________________________________________________________________________________________
____________________________________________________________________________________________________________________________________________________________________________________

Still have any questions?:
    1. Create a ticket help on mcmodels discord server
    2. Join my discord server here: https://discord.gg/jpbHGee
    3. DM me (Akaleaf) by the discord: akaleaf#4723
#6b607da587d66f198661f245b3793d23