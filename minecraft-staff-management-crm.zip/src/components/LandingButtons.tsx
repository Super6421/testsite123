"use client";

import Link from "next/link";
import { Button } from "@/components/ui/Button";

export function LandingButtons({ loggedIn, compact }: { loggedIn: boolean; compact?: boolean }) {
  if (loggedIn) {
    return (
      <Link href="/dashboard">
        <Button variant="primary" className={compact ? "px-4 py-2 text-xs" : "px-8 py-3.5 text-base"}>
          Перейти в панель →
        </Button>
      </Link>
    );
  }
  return (
    <Link href="/auth/signin">
      <Button variant="primary" className={compact ? "px-4 py-2 text-xs" : "px-8 py-3.5 text-base"}>
        {compact ? "Войти" : "🎮 Войти через Discord"}
      </Button>
    </Link>
  );
}
