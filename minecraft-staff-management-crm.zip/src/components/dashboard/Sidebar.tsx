"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import {
  LayoutDashboard,
  Users,
  MessageSquare,
  FileText,
  CalendarClock,
  Bell,
  ShieldCheck,
  User,
  Settings,
} from "lucide-react";
import Image from "next/image";

const nav = [
  { href: "/dashboard", label: "Дашборд", icon: LayoutDashboard, perm: null },
  { href: "/staff", label: "Персонал", icon: Users, perm: "staff.view" },
  { href: "/forum", label: "Форум", icon: MessageSquare, perm: "forum.view" },
  { href: "/reports", label: "Отчёты", icon: FileText, perm: null },
  { href: "/vacations", label: "Отпуска", icon: CalendarClock, perm: null },
  { href: "/notifications", label: "Уведомления", icon: Bell, perm: null },
  { href: "/profile", label: "Профиль", icon: User, perm: null },
];

export function Sidebar({
  permissions,
  logoUrl,
  siteName,
  canAdmin,
}: {
  permissions: string[];
  logoUrl: string;
  siteName: string;
  canAdmin: boolean;
}) {
  const pathname = usePathname();
  const can = (perm: string | null) => !perm || permissions.includes("*") || permissions.includes(perm);

  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-white/5 bg-[#1B1B1B]/95 lg:flex">
      <Link href="/dashboard" className="flex items-center gap-3 border-b border-white/5 px-5 py-5">
        <div className="relative h-10 w-10 overflow-hidden rounded-xl glow-honey">
          <Image src={logoUrl} alt={siteName} fill className="object-cover" />
        </div>
        <div>
          <p className="font-pixel text-[9px] leading-tight text-[#FFD54F]">AGE OF GLORY</p>
          <p className="text-[11px] text-white/40">STAFF PANEL</p>
        </div>
      </Link>

      <nav className="flex flex-1 flex-col gap-1 overflow-y-auto p-3 scrollbar-thin">
        {nav
          .filter((item) => can(item.perm))
          .map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={clsx(
                  "group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-all",
                  active
                    ? "bg-gradient-to-r from-[#FFD54F]/20 to-transparent text-[#FFD54F] shadow-[inset_0_0_0_1px_rgba(255,213,79,0.3)]"
                    : "text-white/60 hover:bg-white/5 hover:text-white",
                )}
              >
                <Icon size={18} />
                {item.label}
              </Link>
            );
          })}

        {canAdmin && (
          <>
            <div className="my-2 border-t border-white/5" />
            <Link
              href="/admin"
              className={clsx(
                "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-all",
                pathname.startsWith("/admin")
                  ? "bg-gradient-to-r from-[#4CAF50]/25 to-transparent text-[#8BEA8F]"
                  : "text-white/60 hover:bg-white/5 hover:text-white",
              )}
            >
              <ShieldCheck size={18} />
              Админ-панель
            </Link>
          </>
        )}
      </nav>

      <div className="border-t border-white/5 p-3">
        <Link href="/admin/settings" className="flex items-center gap-2 rounded-xl px-3 py-2 text-xs text-white/30 hover:text-white/60">
          <Settings size={14} /> v1.21.1 • Age Of Glory
        </Link>
      </div>
    </aside>
  );
}
