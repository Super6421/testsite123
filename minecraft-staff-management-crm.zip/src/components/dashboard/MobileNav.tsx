"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, ShieldCheck } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import * as Icons from "lucide-react";
import { NAV_ITEMS } from "@/lib/nav";
import Image from "next/image";

export function MobileNav({
  permissions,
  logoUrl,
  siteName,
  canAdmin,
}: {
  permissions: string[];
  logoUrl: string;
  siteName: string;
  canAdmin: boolean;
}) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const can = (perm: string | null) => !perm || permissions.includes("*") || permissions.includes(perm);

  return (
    <div className="lg:hidden">
      <button
        onClick={() => setOpen(true)}
        className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-[#FFD54F]"
      >
        <Menu size={18} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", damping: 24 }}
              className="glass-panel h-full w-72 p-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative h-9 w-9 overflow-hidden rounded-lg">
                    <Image src={logoUrl} alt={siteName} fill className="object-cover" />
                  </div>
                  <p className="font-pixel text-[9px] text-[#FFD54F]">AGE OF GLORY</p>
                </div>
                <button onClick={() => setOpen(false)} className="text-white/60">
                  <X size={20} />
                </button>
              </div>
              <nav className="flex flex-col gap-1">
                {NAV_ITEMS.filter((i) => can(i.perm)).map((item) => {
                  const Icon = Icons[item.icon as keyof typeof Icons] as typeof ShieldCheck;
                  const active = pathname === item.href;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setOpen(false)}
                      className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold ${
                        active ? "bg-[#FFD54F]/15 text-[#FFD54F]" : "text-white/70 hover:bg-white/5"
                      }`}
                    >
                      <Icon size={18} />
                      {item.label}
                    </Link>
                  );
                })}
                {canAdmin && (
                  <Link
                    href="/admin"
                    onClick={() => setOpen(false)}
                    className="mt-2 flex items-center gap-3 rounded-xl border-t border-white/10 px-3.5 py-2.5 pt-4 text-sm font-semibold text-[#8BEA8F]"
                  >
                    <ShieldCheck size={18} />
                    Админ-панель
                  </Link>
                )}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
