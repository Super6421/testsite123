"use client";

import { GlobalSearch } from "@/components/GlobalSearch";
import { NotificationBell } from "@/components/NotificationBell";
import { MobileNav } from "@/components/dashboard/MobileNav";
import { StatusBadge } from "@/components/StatusBadge";
import Link from "next/link";
import Image from "next/image";

export function Topbar({
  user,
  permissions,
  logoUrl,
  siteName,
  canAdmin,
}: {
  user: { discordUsername: string; discordAvatar: string | null; minecraftNick: string | null; status: string; lastSeenAt: string; roleName?: string; roleColor?: string };
  permissions: string[];
  logoUrl: string;
  siteName: string;
  canAdmin: boolean;
}) {
  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-white/5 bg-[#121212]/80 px-4 py-3 backdrop-blur-xl lg:px-6">
      <MobileNav permissions={permissions} logoUrl={logoUrl} siteName={siteName} canAdmin={canAdmin} />
      <div className="hidden md:block">
        <GlobalSearch />
      </div>
      <div className="ml-auto flex items-center gap-3">
        <NotificationBell />
        <Link href="/profile" className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 py-1.5 pl-1.5 pr-3 hover:bg-white/10">
          <div className="relative h-8 w-8 overflow-hidden rounded-lg">
            <Image src={user.discordAvatar ?? "/images/default-logo.png"} alt="avatar" fill className="object-cover" />
          </div>
          <div className="hidden text-left sm:block">
            <p className="text-xs font-bold leading-tight text-white">{user.minecraftNick || user.discordUsername}</p>
            <p className="text-[10px] font-bold leading-tight" style={{ color: user.roleColor ?? "#4CAF50" }}>
              {user.roleName ?? "Сотрудник"}
            </p>
          </div>
        </Link>
      </div>
    </header>
  );
}
