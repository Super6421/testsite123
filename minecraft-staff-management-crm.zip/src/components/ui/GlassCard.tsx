import clsx from "clsx";
import type { HTMLAttributes } from "react";

export function GlassCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx("glass-panel rounded-2xl p-5", className)} {...props} />;
}
