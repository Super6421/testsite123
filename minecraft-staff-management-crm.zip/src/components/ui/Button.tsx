"use client";

import { ButtonHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

type Variant = "primary" | "secondary" | "danger" | "ghost" | "outline";

const variants: Record<Variant, string> = {
  primary:
    "bg-gradient-to-r from-[#FFD54F] to-[#F7B500] text-[#1B1B1B] hover:brightness-110 shadow-[0_0_20px_rgba(255,213,79,0.35)]",
  secondary: "bg-gradient-to-r from-[#4CAF50] to-[#357A38] text-white hover:brightness-110 shadow-[0_0_20px_rgba(76,175,80,0.3)]",
  danger: "bg-red-600/90 text-white hover:bg-red-500",
  ghost: "bg-white/5 text-white hover:bg-white/10 border border-white/10",
  outline: "bg-transparent border border-[#FFD54F]/50 text-[#FFD54F] hover:bg-[#FFD54F]/10",
};

export const Button = forwardRef<HTMLButtonElement, ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }>(
  ({ className, variant = "primary", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx(
          "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-bold transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.97]",
          variants[variant],
          className,
        )}
        {...props}
      />
    );
  },
);
Button.displayName = "Button";
