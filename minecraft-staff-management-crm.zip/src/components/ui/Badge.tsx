import clsx from "clsx";
import type { ReactNode } from "react";

export function Badge({
  children,
  color = "#4CAF50",
  className,
}: {
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={clsx("inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold", className)}
      style={{
        backgroundColor: `${color}22`,
        color,
        border: `1px solid ${color}55`,
      }}
    >
      {children}
    </span>
  );
}
