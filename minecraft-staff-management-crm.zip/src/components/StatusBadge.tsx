import { statusLabel } from "@/lib/format";

export function StatusBadge({ status, lastSeenAt }: { status: string; lastSeenAt: string | Date }) {
  const label = statusLabel(status, lastSeenAt);
  const color = status === "vacation" ? "#FFD54F" : label === "Онлайн" ? "#4CAF50" : "#757575";
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold" style={{ color }}>
      <span
        className="h-2 w-2 rounded-full"
        style={{ backgroundColor: color, boxShadow: label === "Онлайн" ? `0 0 8px ${color}` : "none" }}
      />
      {label}
    </span>
  );
}

export function TwoFaBadge({ required, enabled }: { required: boolean; enabled: boolean }) {
  if (enabled) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-[#4CAF50]/50 bg-[#4CAF50]/15 px-2.5 py-1 text-[11px] font-bold text-[#4CAF50]">
        🔒 2FA ACTIVE
      </span>
    );
  }
  if (required) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-red-500/50 bg-red-500/15 px-2.5 py-1 text-[11px] font-bold text-red-400 animate-pulse-glow">
        ⚠ 2FA REQUIRED
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-white/20 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-white/50">
      2FA DISABLED
    </span>
  );
}
