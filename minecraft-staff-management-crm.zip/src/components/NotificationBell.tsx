"use client";

import { useEffect, useRef, useState } from "react";
import { Bell } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { timeAgo } from "@/lib/format";

type Notification = {
  id: string;
  type: string;
  title: string;
  message: string;
  link?: string | null;
  isRead: boolean;
  createdAt: string;
};

export function NotificationBell() {
  const [items, setItems] = useState<Notification[]>([]);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  async function load() {
    try {
      const res = await fetch("/api/notifications");
      if (!res.ok) return;
      const data = await res.json();
      setItems(data.notifications ?? []);
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    load();
    const es = new EventSource("/api/notifications/stream");
    es.onmessage = () => load();
    const poll = setInterval(load, 20000);
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("click", onClick);
    return () => {
      es.close();
      clearInterval(poll);
      document.removeEventListener("click", onClick);
    };
  }, []);

  const unread = items.filter((n) => !n.isRead).length;

  async function markAll() {
    await fetch("/api/notifications", { method: "PATCH", body: JSON.stringify({ all: true }) });
    load();
  }

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-[#FFD54F] transition hover:bg-white/10"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-[0_0_8px_rgba(239,68,68,0.8)]">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            className="glass-panel absolute right-0 z-50 mt-2 max-h-[26rem] w-80 overflow-y-auto rounded-2xl p-3 scrollbar-thin"
          >
            <div className="mb-2 flex items-center justify-between px-1">
              <p className="font-pixel text-[10px] text-[#FFD54F]">УВЕДОМЛЕНИЯ</p>
              {unread > 0 && (
                <button onClick={markAll} className="text-xs text-[#4CAF50] hover:underline">
                  Прочитать всё
                </button>
              )}
            </div>
            {items.length === 0 && <p className="p-4 text-center text-sm text-white/40">Пока пусто</p>}
            <div className="flex flex-col gap-1.5">
              {items.map((n) => (
                <Link
                  key={n.id}
                  href={n.link ?? "/notifications"}
                  className={`rounded-xl border p-2.5 text-sm transition hover:bg-white/5 ${
                    n.isRead ? "border-white/5 bg-white/[0.02]" : "border-[#FFD54F]/30 bg-[#FFD54F]/5"
                  }`}
                >
                  <p className="font-bold text-white">{n.title}</p>
                  <p className="mt-0.5 line-clamp-2 text-xs text-white/60">{n.message}</p>
                  <p className="mt-1 text-[10px] text-white/30">{timeAgo(n.createdAt)}</p>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
