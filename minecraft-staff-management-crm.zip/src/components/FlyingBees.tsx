"use client";

import { motion } from "framer-motion";
import { useMemo } from "react";

function Bee({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
      <ellipse cx="32" cy="34" rx="14" ry="12" fill="#FFD54F" />
      <path d="M20 27 a14 12 0 0 1 24 0" fill="none" />
      <rect x="19" y="27" width="26" height="5" rx="2.5" fill="#1B1B1B" />
      <rect x="19" y="36" width="26" height="5" rx="2.5" fill="#1B1B1B" />
      <circle cx="32" cy="18" r="8" fill="#3a2b1a" />
      <circle cx="29" cy="16" r="1.6" fill="#fff" />
      <circle cx="35" cy="16" r="1.6" fill="#fff" />
      <path d="M24 12 L20 6" stroke="#3a2b1a" strokeWidth="2" strokeLinecap="round" />
      <path d="M40 12 L44 6" stroke="#3a2b1a" strokeWidth="2" strokeLinecap="round" />
      <motion.ellipse
        cx="18"
        cy="28"
        rx="9"
        ry="5"
        fill="#FFFFFF"
        opacity="0.75"
        animate={{ rotate: [0, 25, 0] }}
        transition={{ duration: 0.35, repeat: Infinity }}
        style={{ transformOrigin: "26px 28px" }}
      />
      <motion.ellipse
        cx="46"
        cy="28"
        rx="9"
        ry="5"
        fill="#FFFFFF"
        opacity="0.75"
        animate={{ rotate: [0, -25, 0] }}
        transition={{ duration: 0.35, repeat: Infinity }}
        style={{ transformOrigin: "38px 28px" }}
      />
    </svg>
  );
}

export function FlyingBees({ count = 6 }: { count?: number }) {
  const bees = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        top: 8 + Math.random() * 75,
        left: 4 + Math.random() * 90,
        size: 20 + Math.random() * 20,
        duration: 7 + Math.random() * 6,
        delay: Math.random() * 4,
      })),
    [count],
  );

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {bees.map((bee) => (
        <div
          key={bee.id}
          className="absolute animate-float-bee"
          style={{
            top: `${bee.top}%`,
            left: `${bee.left}%`,
            animationDuration: `${bee.duration}s`,
            animationDelay: `${bee.delay}s`,
            filter: "drop-shadow(0 0 6px rgba(255,213,79,0.5))",
          }}
        >
          <Bee size={bee.size} />
        </div>
      ))}
    </div>
  );
}
