"use client";

import { useEffect, useRef, useState } from "react";
import { Search } from "lucide-react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";

export function GlobalSearch() {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState<{ staff: { id: string; discordUsername: string; minecraftNick?: string }[]; topics: { id: string; title: string }[] }>({
    staff: [],
    topics: [],
  });
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  useEffect(() => {
    if (q.trim().length < 2) {
      setResults({ staff: [], topics: [] });
      return;
    }
    const t = setTimeout(async () => {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      if (res.ok) setResults(await res.json());
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <div className="relative w-full max-w-sm" ref={ref}>
      <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2">
        <Search size={16} className="text-white/40" />
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Поиск по сотрудникам, темам..."
          className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/30"
        />
      </div>
      <AnimatePresence>
        {open && q.trim().length >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="glass-panel absolute z-50 mt-2 w-full rounded-2xl p-3"
          >
            {results.staff.length === 0 && results.topics.length === 0 && (
              <p className="p-2 text-center text-sm text-white/40">Ничего не найдено</p>
            )}
            {results.staff.length > 0 && (
              <div className="mb-2">
                <p className="mb-1 text-[10px] font-bold uppercase text-[#FFD54F]">Сотрудники</p>
                {results.staff.map((s) => (
                  <Link key={s.id} href={`/staff/${s.id}`} className="block rounded-lg px-2 py-1.5 text-sm hover:bg-white/5">
                    {s.minecraftNick || s.discordUsername}
                  </Link>
                ))}
              </div>
            )}
            {results.topics.length > 0 && (
              <div>
                <p className="mb-1 text-[10px] font-bold uppercase text-[#4CAF50]">Темы форума</p>
                {results.topics.map((t) => (
                  <Link key={t.id} href={`/forum/topic/${t.id}`} className="block rounded-lg px-2 py-1.5 text-sm hover:bg-white/5">
                    {t.title}
                  </Link>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
