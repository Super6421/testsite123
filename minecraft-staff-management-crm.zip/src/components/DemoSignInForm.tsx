"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/Button";

export function DemoSignInForm() {
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    if (username.trim().length < 2) {
      setError("Введите минимум 2 символа");
      return;
    }
    setLoading(true);
    setError("");
    const res = await signIn("demo", { username, redirect: false, callbackUrl: "/dashboard" });
    setLoading(false);
    if (res?.error) {
      setError("Не удалось войти");
    } else {
      window.location.href = "/dashboard";
    }
  }

  return (
    <div className="mt-8 space-y-3">
      <input
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Ваш игровой/демо-ник"
        className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none placeholder:text-white/30 focus:border-[#FFD54F]/50"
      />
      {error && <p className="text-xs text-red-400">{error}</p>}
      <Button onClick={submit} disabled={loading} className="w-full py-3.5 text-sm">
        {loading ? "Вход..." : "🐝 Войти в демо-режиме"}
      </Button>
      <p className="text-[11px] text-white/30">
        Первый вошедший пользователь автоматически становится Главным Администратором.
      </p>
    </div>
  );
}
