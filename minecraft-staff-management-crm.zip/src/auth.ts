import NextAuth from "next-auth";
import Discord from "next-auth/providers/discord";
import Credentials from "next-auth/providers/credentials";
import type { Provider } from "next-auth/providers";
import { db } from "@/db";
import { roles, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fetchGuildMemberRoles, isBotConfigured } from "@/lib/discord";
import { logAudit } from "@/lib/audit";
import { ensureSeeded } from "@/lib/seed";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      dbId: string;
      discordId: string;
      name?: string | null;
      email?: string | null;
      image?: string | null;
      twoFactorVerified?: boolean;
    };
  }
}

declare module "@auth/core/jwt" {
  interface JWT {
    dbId?: string;
    discordId?: string;
    twoFactorVerified?: boolean;
  }
}

export const DISCORD_CONFIGURED = Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET);

type NormalizedIdentity = {
  discordId: string;
  username: string;
  avatar: string | null;
  email: string | null;
};

function normalizeIdentity(provider: string | undefined, profile: unknown, user: unknown): NormalizedIdentity | null {
  if (provider === "discord" && profile) {
    const p = profile as { id: string; username?: string; global_name?: string; avatar?: string | null; email?: string };
    return { discordId: p.id, username: p.global_name ?? p.username ?? "Unknown", avatar: p.avatar ?? null, email: p.email ?? null };
  }
  if (provider === "demo" && user) {
    const u = user as { id: string; name?: string | null };
    return { discordId: u.id, username: u.name ?? "Demo User", avatar: null, email: null };
  }
  return null;
}

const providers: Provider[] = [
  Discord({
    clientId: process.env.DISCORD_CLIENT_ID ?? "",
    clientSecret: process.env.DISCORD_CLIENT_SECRET ?? "",
    authorization: { params: { scope: "identify email guilds" } },
  }),
];

// When no real Discord application has been configured yet, expose a clearly
// labelled "demo" identity provider so the whole staff panel remains fully
// explorable. It mimics the shape of a Discord profile (id/username/avatar)
// so every downstream permission/2FA/vacation check behaves identically to
// production. Remove automatically as soon as real Discord keys are set.
if (!DISCORD_CONFIGURED) {
  providers.push(
    Credentials({
      id: "demo",
      name: "Демо-вход (без Discord)",
      credentials: {
        username: { label: "Имя пользователя", type: "text" },
      },
      async authorize(credentials) {
        const username = String(credentials?.username ?? "").trim();
        if (!username || username.length < 2) return null;
        const slug = username.toLowerCase().replace(/[^a-z0-9]/g, "");
        const fakeId = `demo-${slug || "user"}`;
        return { id: fakeId, name: username };
      },
    }),
  );
}

export const { handlers, auth, signIn, signOut } = NextAuth({
  trustHost: true,
  session: { strategy: "jwt", maxAge: 30 * 24 * 60 * 60 },
  pages: {
    signIn: "/auth/signin",
  },
  providers,
  callbacks: {
    async signIn({ user, account, profile }) {
      const identity = normalizeIdentity(account?.provider, profile, user);
      if (!identity) return false;
      await ensureSeeded();
      const { discordId, username, avatar, email } = identity;

      const [existing] = await db.select().from(users).where(eq(users.discordId, discordId)).limit(1);

      if (!existing) {
        const totalUsers = await db.select({ id: users.id }).from(users);
        const isFirstUser = totalUsers.length === 0;

        let roleId: string | null = null;
        if (isFirstUser) {
          const [adminRole] = await db.select().from(roles).where(eq(roles.isSystem, true)).limit(1);
          roleId = adminRole?.id ?? null;
        }

        const [created] = await db
          .insert(users)
          .values({
            discordId,
            discordUsername: username,
            discordAvatar: avatar,
            email,
            roleId,
            isSuperAdmin: isFirstUser,
            loginsCount: 1,
            lastSeenAt: new Date(),
            status: "online",
          })
          .returning();

        await logAudit({
          actorId: created.id,
          action: "user.first_login",
          target: created.id,
          newValue: { discordId, isFirstUser },
        });
      } else {
        if (existing.isBanned) return false;

        await db
          .update(users)
          .set({
            discordUsername: username,
            discordAvatar: avatar,
            email: email ?? existing.email,
            loginsCount: existing.loginsCount + 1,
            lastSeenAt: new Date(),
            status: existing.status === "vacation" ? "vacation" : "online",
          })
          .where(eq(users.id, existing.id));

        // Two-way discord sync: if a bot token + guild are configured, pull
        // the member's live Discord roles and map them onto our role table.
        if (isBotConfigured()) {
          const discordRoles = await fetchGuildMemberRoles(discordId);
          if (discordRoles) {
            const mappable = await db.select().from(roles).where(eq(roles.isSystem, false));
            const matched = mappable
              .filter((r) => r.discordRoleId && discordRoles.includes(r.discordRoleId))
              .sort((a, b) => b.priority - a.priority)[0];
            if (matched && matched.id !== existing.roleId) {
              await db.update(users).set({ roleId: matched.id }).where(eq(users.id, existing.id));
              await logAudit({
                actorId: existing.id,
                action: "user.role_synced_from_discord",
                target: existing.id,
                oldValue: { roleId: existing.roleId },
                newValue: { roleId: matched.id },
              });
            } else if (!matched && existing.roleId && !existing.isSuperAdmin) {
              const [currentRole] = await db.select().from(roles).where(eq(roles.id, existing.roleId)).limit(1);
              if (currentRole?.discordRoleId) {
                await db.update(users).set({ roleId: null }).where(eq(users.id, existing.id));
              }
            }
          }
        }
      }

      user.id = discordId;
      return true;
    },
    async jwt({ token, account, profile, user, trigger, session }) {
      const identity = normalizeIdentity(account?.provider, profile, user);
      if (identity) {
        token.discordId = identity.discordId;
        const [dbUser] = await db.select().from(users).where(eq(users.discordId, identity.discordId)).limit(1);
        if (dbUser) {
          token.dbId = dbUser.id;
          let requires2fa = false;
          if (dbUser.roleId) {
            const [role] = await db.select().from(roles).where(eq(roles.id, dbUser.roleId)).limit(1);
            requires2fa = Boolean(role?.require2fa);
          }
          token.twoFactorVerified = !requires2fa;
        }
      }
      if (trigger === "update" && session?.twoFactorVerified) {
        token.twoFactorVerified = true;
      }
      return token;
    },
    async session({ session, token }) {
      session.user.id = token.discordId ?? "";
      session.user.discordId = token.discordId ?? "";
      session.user.dbId = token.dbId ?? "";
      session.user.twoFactorVerified = Boolean(token.twoFactorVerified);
      return session;
    },
  },
});
