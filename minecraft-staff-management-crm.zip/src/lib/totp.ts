import { authenticator } from "otplib";
import QRCode from "qrcode";

authenticator.options = { window: 1 };

export function generateTotpSecret() {
  return authenticator.generateSecret();
}

export function verifyTotpToken(secret: string, token: string) {
  try {
    return authenticator.verify({ token: token.replace(/\s/g, ""), secret });
  } catch {
    return false;
  }
}

export async function generateTotpQrCode(secret: string, account: string) {
  const otpauth = authenticator.keyuri(account, "Age Of Glory Staff", secret);
  const dataUrl = await QRCode.toDataURL(otpauth, {
    margin: 1,
    color: { dark: "#121212", light: "#FFD54F" },
  });
  return { otpauth, dataUrl };
}
