import "server-only";
import { db } from "@/db";
import { achievements, permissions, reportTypes, formFields, roles, rolePermissions, forumCategories, siteSettings } from "@/db/schema";
import { PERMISSION_CATALOG } from "@/lib/permissions";
import { eq } from "drizzle-orm";

let seeded = false;

export async function ensureSeeded() {
  if (seeded) return;

  const existingPerms = await db.select({ id: permissions.id }).from(permissions).limit(1);
  if (existingPerms.length === 0) {
    await db.insert(permissions).values(PERMISSION_CATALOG).onConflictDoNothing();
  }

  const existingRoles = await db.select().from(roles).limit(1);
  if (existingRoles.length === 0) {
    const allPerms = await db.select().from(permissions);
    const byKey = new Map(allPerms.map((p) => [p.key, p.id]));

    const [owner] = await db
      .insert(roles)
      .values({
        name: "Главный Администратор",
        color: "#FFD54F",
        priority: 1000,
        require2fa: true,
        isStaff: true,
        isSystem: true,
      })
      .returning();
    await db.insert(rolePermissions).values(allPerms.map((p) => ({ roleId: owner.id, permissionId: p.id })));

    const staffRolesData: Array<{ name: string; color: string; priority: number; require2fa: boolean; perms: string[] }> = [
      {
        name: "Куратор",
        color: "#FFB300",
        priority: 800,
        require2fa: true,
        perms: [
          "forum.view", "forum.create", "forum.reply", "forum.pin", "forum.close", "forum.edit",
          "reports.punishment.view", "reports.punishment.check", "reports.cheater.view", "reports.cheater.check",
          "reports.recruitment.view", "reports.recruitment.check",
          "staff.view", "staff.edit", "warn.give", "warn.remove", "vacation.give", "vacation.remove",
          "points.give", "points.remove", "promotion.give", "demotion.give", "role.edit",
          "admin.panel", "admin.audit", "admin.2fa",
        ],
      },
      {
        name: "Старший Модератор",
        color: "#66BB6A",
        priority: 600,
        require2fa: true,
        perms: [
          "forum.view", "forum.create", "forum.reply", "forum.pin",
          "reports.punishment.view", "reports.punishment.check",
          "reports.cheater.view", "reports.cheater.check",
          "staff.view", "warn.give", "vacation.give", "points.give",
        ],
      },
      {
        name: "Модератор",
        color: "#4CAF50",
        priority: 400,
        require2fa: false,
        perms: [
          "forum.view", "forum.create", "forum.reply",
          "reports.punishment.view", "reports.punishment.create",
          "reports.cheater.view", "reports.cheater.create",
          "staff.view",
        ],
      },
      {
        name: "Хелпер",
        color: "#81C784",
        priority: 200,
        require2fa: false,
        perms: ["forum.view", "forum.create", "forum.reply", "reports.punishment.view", "reports.punishment.create", "staff.view"],
      },
    ];

    for (const r of staffRolesData) {
      const [role] = await db
        .insert(roles)
        .values({ name: r.name, color: r.color, priority: r.priority, require2fa: r.require2fa, isStaff: true })
        .returning();
      const permIds = r.perms.map((k) => byKey.get(k)).filter(Boolean) as string[];
      if (permIds.length) {
        await db.insert(rolePermissions).values(permIds.map((permissionId) => ({ roleId: role.id, permissionId })));
      }
    }
  }

  const existingAch = await db.select().from(achievements).limit(1);
  if (existingAch.length === 0) {
    await db.insert(achievements).values([
      { key: "worker_bee", name: "Рабочая Пчела", description: "Выдан первый отчёт", icon: "🐝" },
      { key: "honey_bee", name: "Медовая Пчела", description: "10 принятых отчётов", icon: "🍯" },
      { key: "hive_keeper", name: "Хранитель Улья", description: "50 принятых отчётов", icon: "🛖" },
      { key: "queen_bee", name: "Королева Улья", description: "100 баллов набрано", icon: "👑" },
      { key: "legend", name: "Легенда Age Of Glory", description: "Год в составе персонала", icon: "🏆" },
    ]);
  }

  const existingCategories = await db.select().from(forumCategories).limit(1);
  if (existingCategories.length === 0) {
    await db.insert(forumCategories).values([
      { name: "Новости проекта", description: "Официальные новости и объявления", icon: "📰", order: 0 },
      { name: "Общение персонала", description: "Свободное общение сотрудников", icon: "💬", order: 1 },
      { name: "Гайды и обучение", description: "Инструкции для новых сотрудников", icon: "📚", order: 2 },
    ]);
  }

  const existingTypes = await db.select().from(reportTypes).limit(1);
  if (existingTypes.length === 0) {
    const [punishment] = await db
      .insert(reportTypes)
      .values({
        key: "punishment",
        name: "Отчёт по наказанию",
        description: "Отчёты о выданных банах, мутах и других наказаниях",
        icon: "⚖️",
        viewPermission: "reports.punishment.view",
        createPermission: "reports.punishment.create",
        reviewPermission: "reports.punishment.check",
        pointsConfig: { "Мут": 1, "Бан": 2, "Кик": 1, "Варн": 1 },
        order: 0,
      })
      .returning();

    await db.insert(formFields).values([
      { reportTypeId: punishment.id, label: "Ник нарушителя", fieldKey: "nickname", type: "text", required: true, order: 0 },
      {
        reportTypeId: punishment.id,
        label: "Тип наказания",
        fieldKey: "punishmentType",
        type: "select",
        required: true,
        options: ["Мут", "Бан", "Кик", "Варн"],
        order: 1,
      },
      { reportTypeId: punishment.id, label: "Причина", fieldKey: "reason", type: "textarea", required: true, order: 2 },
      { reportTypeId: punishment.id, label: "Скриншоты", fieldKey: "screenshots", type: "file", required: true, order: 3 },
      { reportTypeId: punishment.id, label: "Видео (ссылка)", fieldKey: "video", type: "text", required: false, order: 4 },
      { reportTypeId: punishment.id, label: "Комментарий", fieldKey: "comment", type: "textarea", required: false, order: 5 },
    ]);

    const [cheater] = await db
      .insert(reportTypes)
      .values({
        key: "cheater",
        name: "Отчёт по читерам",
        description: "Жалобы на использование чит-клиентов",
        icon: "🛡️",
        viewPermission: "reports.cheater.view",
        createPermission: "reports.cheater.create",
        reviewPermission: "reports.cheater.check",
        pointsConfig: { "Подтверждено": 3 },
        order: 1,
      })
      .returning();

    await db.insert(formFields).values([
      { reportTypeId: cheater.id, label: "Ник нарушителя", fieldKey: "nickname", type: "text", required: true, order: 0 },
      { reportTypeId: cheater.id, label: "Предполагаемый чит", fieldKey: "cheatType", type: "text", required: true, order: 1 },
      { reportTypeId: cheater.id, label: "Доказательства (видео/скрин)", fieldKey: "evidence", type: "file", required: true, order: 2 },
      { reportTypeId: cheater.id, label: "Комментарий", fieldKey: "comment", type: "textarea", required: false, order: 3 },
    ]);

    const [recruitment] = await db
      .insert(reportTypes)
      .values({
        key: "recruitment",
        name: "Отчёт по набору",
        description: "Отчёты о проведённых собеседованиях/наборах персонала",
        icon: "📋",
        viewPermission: "reports.recruitment.view",
        createPermission: "reports.recruitment.create",
        reviewPermission: "reports.recruitment.check",
        pointsConfig: { "Принят": 2, "Отклонён": 1 },
        order: 2,
      })
      .returning();

    await db.insert(formFields).values([
      { reportTypeId: recruitment.id, label: "Ник кандидата", fieldKey: "nickname", type: "text", required: true, order: 0 },
      {
        reportTypeId: recruitment.id,
        label: "Результат",
        fieldKey: "result",
        type: "select",
        required: true,
        options: ["Принят", "Отклонён"],
        order: 1,
      },
      { reportTypeId: recruitment.id, label: "Комментарий", fieldKey: "comment", type: "textarea", required: false, order: 2 },
    ]);
  }

  const existingSettings = await db.select().from(siteSettings).limit(1);
  if (existingSettings.length === 0) {
    await db.insert(siteSettings).values([
      { key: "siteName", value: "Age Of Glory Staff" },
      { key: "heroTitle", value: "AGE OF GLORY STAFF" },
      { key: "heroSubtitle", value: "Система управления персоналом проекта Age Of Glory" },
      { key: "logoUrl", value: "/images/default-logo.png" },
      { key: "discordInviteUrl", value: "https://discord.gg/" },
      { key: "discordGuildId", value: "" },
      { key: "minecraftVersion", value: "1.21.1" },
      {
        key: "aboutText",
        value:
          "Age Of Glory — проект нового поколения. Эта панель объединяет форум, отчёты, статистику и управление персоналом в одном месте.",
      },
    ]);
  }

  seeded = true;
}

export async function getOwnerRoleId() {
  const [role] = await db.select().from(roles).where(eq(roles.isSystem, true)).limit(1);
  return role?.id ?? null;
}
