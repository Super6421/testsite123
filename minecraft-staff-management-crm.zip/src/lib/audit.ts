import { db } from "@/db";
import { auditLogs } from "@/db/schema";

export async function logAudit(params: {
  actorId?: string | null;
  action: string;
  target?: string;
  oldValue?: unknown;
  newValue?: unknown;
}) {
  await db.insert(auditLogs).values({
    actorId: params.actorId ?? null,
    action: params.action,
    target: params.target,
    oldValue: (params.oldValue ?? null) as never,
    newValue: (params.newValue ?? null) as never,
  });
}
