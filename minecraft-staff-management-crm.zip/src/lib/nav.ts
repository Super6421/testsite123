export const NAV_ITEMS = [
  { href: "/dashboard", label: "Дашборд", icon: "LayoutDashboard", perm: null as string | null },
  { href: "/staff", label: "Персонал", icon: "Users", perm: "staff.view" },
  { href: "/forum", label: "Форум", icon: "MessageSquare", perm: "forum.view" },
  { href: "/reports", label: "Отчёты", icon: "FileText", perm: null },
  { href: "/vacations", label: "Отпуска", icon: "CalendarClock", perm: null },
  { href: "/notifications", label: "Уведомления", icon: "Bell", perm: null },
  { href: "/profile", label: "Профиль", icon: "User", perm: null },
];
