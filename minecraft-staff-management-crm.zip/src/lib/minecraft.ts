export function minecraftAvatarUrl(nickname: string | null | undefined, size = 100) {
  const nick = nickname?.trim() || "MHF_Steve";
  return `https://mc-heads.net/avatar/${encodeURIComponent(nick)}/${size}`;
}

export function minecraftBodyUrl(nickname: string | null | undefined, size = 200) {
  const nick = nickname?.trim() || "MHF_Steve";
  return `https://mc-heads.net/body/${encodeURIComponent(nick)}/${size}`;
}
