import "server-only";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { vacations } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export async function requireStaffAccess(pathname?: string) {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (!user) redirect("/auth/signin");

  if (!user.twoFactorVerified) redirect("/auth/2fa");

  if (!user.roleId || !user.role || !user.role.isStaff) {
    redirect("/access-denied");
  }

  if (user.role?.require2fa && !user.totpEnabled) {
    redirect("/auth/2fa");
  }

  if (user.status === "vacation") {
    const [activeVacation] = await db
      .select()
      .from(vacations)
      .where(and(eq(vacations.userId, user.id), eq(vacations.status, "active")))
      .orderBy(desc(vacations.createdAt))
      .limit(1);
    if (activeVacation) {
      const today = new Date().toISOString().slice(0, 10);
      if (activeVacation.endDate >= today) {
        redirect("/on-vacation");
      }
    }
  }

  if (!user.profileCompleted && pathname !== "/onboarding") {
    redirect("/onboarding");
  }

  return user;
}
