import { db } from "@/db";
import { notifications } from "@/db/schema";
import { emitToUser } from "@/lib/events";

export type NotificationType =
  | "report_accepted"
  | "report_rejected"
  | "report_revision"
  | "promotion"
  | "demotion"
  | "warn_given"
  | "warn_removed"
  | "vacation_given"
  | "vacation_removed"
  | "points_given"
  | "points_removed"
  | "role_changed"
  | "achievement"
  | "system";

export async function sendNotification(params: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  link?: string;
}) {
  const [row] = await db
    .insert(notifications)
    .values({
      userId: params.userId,
      type: params.type,
      title: params.title,
      message: params.message,
      link: params.link,
    })
    .returning();
  emitToUser(params.userId, { kind: "notification", payload: row });
  return row;
}
