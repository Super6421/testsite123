import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { eq } from "drizzle-orm";

export type SiteSettings = {
  siteName: string;
  heroTitle: string;
  heroSubtitle: string;
  logoUrl: string;
  discordInviteUrl: string;
  discordGuildId: string;
  minecraftVersion: string;
  aboutText: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: "Age Of Glory Staff",
  heroTitle: "AGE OF GLORY STAFF",
  heroSubtitle: "Система управления персоналом проекта Age Of Glory",
  logoUrl: "/images/default-logo.png",
  discordInviteUrl: "https://discord.gg/",
  discordGuildId: "",
  minecraftVersion: "1.21.1",
  aboutText:
    "Age Of Glory — проект нового поколения. Эта панель объединяет форум, отчёты, статистику и управление персоналом в одном месте.",
};

let cache: SiteSettings | null = null;
let cacheAt = 0;

export async function getSiteSettings(): Promise<SiteSettings> {
  if (cache && Date.now() - cacheAt < 5000) return cache;
  const rows = await db.select().from(siteSettings);
  const map: Record<string, unknown> = {};
  for (const row of rows) map[row.key] = row.value;
  const merged = { ...DEFAULT_SETTINGS, ...map } as SiteSettings;
  cache = merged;
  cacheAt = Date.now();
  return merged;
}

export async function setSiteSetting(key: keyof SiteSettings, value: unknown) {
  await db
    .insert(siteSettings)
    .values({ key, value: value as never })
    .onConflictDoUpdate({ target: siteSettings.key, set: { value: value as never } });
  cache = null;
}
