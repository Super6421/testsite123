export type PermissionDef = {
  key: string;
  label: string;
  category: string;
};

export const PERMISSION_CATALOG: PermissionDef[] = [
  // Forum
  { key: "forum.view", label: "Просмотр форума", category: "Форум" },
  { key: "forum.create", label: "Создание тем", category: "Форум" },
  { key: "forum.reply", label: "Ответы в темах", category: "Форум" },
  { key: "forum.edit", label: "Редактирование чужих сообщений", category: "Форум" },
  { key: "forum.pin", label: "Закрепление тем", category: "Форум" },
  { key: "forum.close", label: "Закрытие тем", category: "Форум" },
  { key: "forum.delete", label: "Удаление тем/сообщений", category: "Форум" },

  // Reports - punishment
  { key: "reports.punishment.view", label: "Просмотр отчётов по наказаниям", category: "Отчёты: Наказания" },
  { key: "reports.punishment.create", label: "Создание отчётов по наказаниям", category: "Отчёты: Наказания" },
  { key: "reports.punishment.check", label: "Проверка отчётов по наказаниям", category: "Отчёты: Наказания" },

  // Reports - cheaters
  { key: "reports.cheater.view", label: "Просмотр отчётов по читерам", category: "Отчёты: Читеры" },
  { key: "reports.cheater.create", label: "Создание отчётов по читерам", category: "Отчёты: Читеры" },
  { key: "reports.cheater.check", label: "Проверка отчётов по читерам", category: "Отчёты: Читеры" },

  // Reports - recruitment
  { key: "reports.recruitment.view", label: "Просмотр отчётов по наборам", category: "Отчёты: Наборы" },
  { key: "reports.recruitment.create", label: "Создание отчётов по наборам", category: "Отчёты: Наборы" },
  { key: "reports.recruitment.check", label: "Проверка отчётов по наборам", category: "Отчёты: Наборы" },

  // Staff
  { key: "staff.view", label: "Просмотр персонала", category: "Персонал" },
  { key: "staff.edit", label: "Редактирование персонала", category: "Персонал" },

  // Warns
  { key: "warn.give", label: "Выдача варнов", category: "Варны" },
  { key: "warn.remove", label: "Снятие варнов", category: "Варны" },

  // Vacations
  { key: "vacation.give", label: "Выдача отпусков", category: "Отпуска" },
  { key: "vacation.remove", label: "Снятие отпусков", category: "Отпуска" },

  // Points
  { key: "points.give", label: "Начисление баллов", category: "Баллы" },
  { key: "points.remove", label: "Списание баллов", category: "Баллы" },

  // Promotion / demotion / roles
  { key: "promotion.give", label: "Повышение сотрудников", category: "Кадры" },
  { key: "demotion.give", label: "Понижение сотрудников", category: "Кадры" },
  { key: "role.edit", label: "Изменение ролей сотрудников", category: "Кадры" },

  // Admin
  { key: "admin.panel", label: "Доступ к админ-панели", category: "Администрирование" },
  { key: "admin.settings", label: "Изменение настроек сайта", category: "Администрирование" },
  { key: "admin.audit", label: "Просмотр журнала аудита", category: "Администрирование" },
  { key: "admin.forms", label: "Конструктор форм отчётов", category: "Администрирование" },
  { key: "admin.forum", label: "Управление категориями форума", category: "Администрирование" },
  { key: "admin.2fa", label: "Управление 2FA сотрудников", category: "Администрирование" },
];

export const PERMISSION_KEYS = PERMISSION_CATALOG.map((p) => p.key);
