import "server-only";
import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";

export async function requireApiUser(permission?: string) {
  const user = await getCurrentUser();
  if (!user) {
    return { error: NextResponse.json({ error: "Не авторизован" }, { status: 401 }) } as const;
  }
  if (!user.twoFactorVerified) {
    return { error: NextResponse.json({ error: "Требуется 2FA" }, { status: 403 }) } as const;
  }
  if (!user.role?.isStaff) {
    return { error: NextResponse.json({ error: "Нет доступа" }, { status: 403 }) } as const;
  }
  if (permission && !can(user.permissions, permission)) {
    return { error: NextResponse.json({ error: "Недостаточно прав" }, { status: 403 }) } as const;
  }
  return { user } as const;
}
