import "server-only";
import { auth } from "@/auth";
import { db } from "@/db";
import { permissions, rolePermissions, roles, users } from "@/db/schema";
import { eq } from "drizzle-orm";

export type CurrentUser = Awaited<ReturnType<typeof getCurrentUser>>;

export async function getCurrentUser() {
  const session = await auth();
  if (!session?.user?.id) return null;
  const [user] = await db.select().from(users).where(eq(users.id, session.user.id)).limit(1);
  if (!user) return null;

  let role: typeof roles.$inferSelect | null = null;
  let perms: string[] = [];
  if (user.roleId) {
    const [r] = await db.select().from(roles).where(eq(roles.id, user.roleId)).limit(1);
    role = r ?? null;
    if (r) {
      const rows = await db
        .select({ key: permissions.key })
        .from(rolePermissions)
        .innerJoin(permissions, eq(permissions.id, rolePermissions.permissionId))
        .where(eq(rolePermissions.roleId, r.id));
      perms = rows.map((row) => row.key);
    }
  }
  if (user.isSuperAdmin) perms = ["*"];

  return {
    ...user,
    role,
    permissions: perms,
    twoFactorVerified: Boolean(session.user.twoFactorVerified),
  };
}

export function can(perms: string[], key: string) {
  return perms.includes("*") || perms.includes(key);
}
