import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { nanoid } from "nanoid";

// Local filesystem storage used as a drop-in stand-in for an S3 / MinIO
// bucket. Swap `saveUpload` for an S3 PutObject call to switch backends
// without touching call sites.
const UPLOAD_ROOT = path.join(process.cwd(), "public", "uploads");

export async function saveUpload(file: File, folder = "misc") {
  const bytes = Buffer.from(await file.arrayBuffer());
  const ext = path.extname(file.name) || "";
  const safeName = `${Date.now()}-${nanoid(8)}${ext}`;
  const dir = path.join(UPLOAD_ROOT, folder);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, safeName), bytes);
  return `/uploads/${folder}/${safeName}`;
}
