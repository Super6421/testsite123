// Lightweight in-process realtime event bus used to power Server-Sent
// Events (SSE) for the notification bell and live staff status updates.
// This avoids needing a separate Socket.IO process while still giving a
// realtime experience, since the app runs as a single long-lived Node
// process under `next start`.

type Listener = (data: unknown) => void;

const globalBus = globalThis as typeof globalThis & {
  __aogListeners?: Map<string, Set<Listener>>;
};

const listeners = globalBus.__aogListeners ?? new Map<string, Set<Listener>>();
globalBus.__aogListeners = listeners;

export function subscribe(userId: string, listener: Listener) {
  if (!listeners.has(userId)) listeners.set(userId, new Set());
  listeners.get(userId)!.add(listener);
  return () => {
    listeners.get(userId)?.delete(listener);
  };
}

export function subscribeAll(listener: Listener) {
  return subscribe("*", listener);
}

export function emitToUser(userId: string, data: unknown) {
  listeners.get(userId)?.forEach((l) => l(data));
  listeners.get("*")?.forEach((l) => l(data));
}

export function emitBroadcast(data: unknown) {
  for (const [, set] of listeners) set.forEach((l) => l(data));
}
