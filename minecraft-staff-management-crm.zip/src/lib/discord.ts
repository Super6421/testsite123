// Discord REST helpers used both by the OAuth callback (to read a member's
// guild roles) and by the admin panel (to push role changes back to
// Discord). All calls are guarded so the app keeps working in environments
// where a bot token / guild id has not been configured yet.

const API = "https://discord.com/api/v10";

export function isBotConfigured() {
  return Boolean(process.env.DISCORD_BOT_TOKEN && process.env.DISCORD_GUILD_ID);
}

async function botFetch(pathname: string, init?: RequestInit) {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error("DISCORD_BOT_TOKEN is not configured");
  const res = await fetch(`${API}${pathname}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });
  return res;
}

export async function fetchGuildMemberRoles(discordUserId: string): Promise<string[] | null> {
  if (!isBotConfigured()) return null;
  const guildId = process.env.DISCORD_GUILD_ID!;
  try {
    const res = await botFetch(`/guilds/${guildId}/members/${discordUserId}`);
    if (!res.ok) return null;
    const data = (await res.json()) as { roles: string[] };
    return data.roles;
  } catch {
    return null;
  }
}

export async function addGuildMemberRole(discordUserId: string, roleId: string) {
  if (!isBotConfigured()) return false;
  const guildId = process.env.DISCORD_GUILD_ID!;
  try {
    const res = await botFetch(`/guilds/${guildId}/members/${discordUserId}/roles/${roleId}`, {
      method: "PUT",
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function removeGuildMemberRole(discordUserId: string, roleId: string) {
  if (!isBotConfigured()) return false;
  const guildId = process.env.DISCORD_GUILD_ID!;
  try {
    const res = await botFetch(`/guilds/${guildId}/members/${discordUserId}/roles/${roleId}`, {
      method: "DELETE",
    });
    return res.ok;
  } catch {
    return false;
  }
}

export function discordAvatarUrl(discordId: string, avatarHash: string | null, discriminator = "0") {
  if (!avatarHash) {
    const last = Number(discordId.slice(-2)) || 0;
    const idx = discriminator === "0" ? last % 6 : Number(discriminator) % 5;
    return `https://cdn.discordapp.com/embed/avatars/${idx}.png`;
  }
  const ext = avatarHash.startsWith("a_") ? "gif" : "png";
  return `https://cdn.discordapp.com/avatars/${discordId}/${avatarHash}.${ext}?size=256`;
}
