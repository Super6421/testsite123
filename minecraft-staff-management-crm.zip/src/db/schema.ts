import {
  pgTable,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  primaryKey,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { nanoid } from "nanoid";

const id = () => text("id").primaryKey().$defaultFn(() => nanoid());

// ---------------------------------------------------------------------------
// ROLES & PERMISSIONS
// ---------------------------------------------------------------------------

export const roles = pgTable("roles", {
  id: id(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#4CAF50"),
  priority: integer("priority").notNull().default(0),
  discordRoleId: text("discord_role_id"),
  require2fa: boolean("require_2fa").notNull().default(false),
  isStaff: boolean("is_staff").notNull().default(true),
  isDefault: boolean("is_default").notNull().default(false),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const permissions = pgTable("permissions", {
  id: id(),
  key: text("key").notNull().unique(),
  label: text("label").notNull(),
  category: text("category").notNull(),
});

export const rolePermissions = pgTable(
  "role_permissions",
  {
    roleId: text("role_id").notNull().references(() => roles.id, { onDelete: "cascade" }),
    permissionId: text("permission_id").notNull().references(() => permissions.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.roleId, t.permissionId] })],
);

// ---------------------------------------------------------------------------
// USERS
// ---------------------------------------------------------------------------

export const users = pgTable(
  "users",
  {
    id: id(),
    discordId: text("discord_id").notNull().unique(),
    discordUsername: text("discord_username").notNull(),
    discordAvatar: text("discord_avatar"),
    email: text("email"),
    minecraftNick: text("minecraft_nick"),
    minecraftInfo: text("minecraft_info"),
    profileCompleted: boolean("profile_completed").notNull().default(false),
    roleId: text("role_id").references(() => roles.id, { onDelete: "set null" }),
    points: integer("points").notNull().default(0),
    status: text("status").notNull().default("offline"), // online | offline | vacation
    lastSeenAt: timestamp("last_seen_at").notNull().defaultNow(),
    totpSecret: text("totp_secret"),
    totpEnabled: boolean("totp_enabled").notNull().default(false),
    totpVerifiedAt: timestamp("totp_verified_at"),
    totalTimeSeconds: integer("total_time_seconds").notNull().default(0),
    loginsCount: integer("logins_count").notNull().default(0),
    isBanned: boolean("is_banned").notNull().default(false),
    isSuperAdmin: boolean("is_super_admin").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_discord_id_idx").on(t.discordId)],
);

export const dailyActivity = pgTable(
  "daily_activity",
  {
    id: id(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    date: text("date").notNull(), // YYYY-MM-DD
    seconds: integer("seconds").notNull().default(0),
  },
  (t) => [uniqueIndex("daily_activity_user_date_idx").on(t.userId, t.date)],
);

export const pointsHistory = pgTable("points_history", {
  id: id(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  delta: integer("delta").notNull(),
  reason: text("reason").notNull(),
  givenById: text("given_by_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const warns = pgTable("warns", {
  id: id(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  reason: text("reason").notNull(),
  givenById: text("given_by_id").references(() => users.id, { onDelete: "set null" }),
  active: boolean("active").notNull().default(true),
  removedById: text("removed_by_id").references(() => users.id, { onDelete: "set null" }),
  removedAt: timestamp("removed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const vacations = pgTable("vacations", {
  id: id(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  reason: text("reason").notNull(),
  givenById: text("given_by_id").references(() => users.id, { onDelete: "set null" }),
  status: text("status").notNull().default("active"), // active | ended | cancelled
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable(
  "notifications",
  {
    id: id(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    message: text("message").notNull(),
    link: text("link"),
    isRead: boolean("is_read").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("notifications_user_idx").on(t.userId)],
);

export const achievements = pgTable("achievements", {
  id: id(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull().default("🐝"),
});

export const userAchievements = pgTable(
  "user_achievements",
  {
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    achievementId: text("achievement_id").notNull().references(() => achievements.id, { onDelete: "cascade" }),
    earnedAt: timestamp("earned_at").notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.achievementId] })],
);

// ---------------------------------------------------------------------------
// FORUM
// ---------------------------------------------------------------------------

export const forumCategories = pgTable("forum_categories", {
  id: id(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  icon: text("icon").notNull().default("📁"),
  order: integer("order").notNull().default(0),
  viewPermission: text("view_permission").notNull().default("forum.view"),
  createPermission: text("create_permission").notNull().default("forum.create"),
});

export const forumTopics = pgTable("forum_topics", {
  id: id(),
  categoryId: text("category_id").notNull().references(() => forumCategories.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  authorId: text("author_id").references(() => users.id, { onDelete: "set null" }),
  pinned: boolean("pinned").notNull().default(false),
  closed: boolean("closed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const forumPosts = pgTable("forum_posts", {
  id: id(),
  topicId: text("topic_id").notNull().references(() => forumTopics.id, { onDelete: "cascade" }),
  authorId: text("author_id").references(() => users.id, { onDelete: "set null" }),
  content: text("content").notNull(),
  attachments: jsonb("attachments").$type<string[]>().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  editedAt: timestamp("edited_at"),
});

// ---------------------------------------------------------------------------
// REPORTS (constructor-based forms)
// ---------------------------------------------------------------------------

export type FormFieldType =
  | "text"
  | "textarea"
  | "number"
  | "date"
  | "file"
  | "select"
  | "checkbox"
  | "multiselect";

export const reportTypes = pgTable("report_types", {
  id: id(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  icon: text("icon").notNull().default("📄"),
  viewPermission: text("view_permission").notNull(),
  createPermission: text("create_permission").notNull(),
  reviewPermission: text("review_permission").notNull(),
  pointsConfig: jsonb("points_config").$type<Record<string, number>>().default({}),
  order: integer("order").notNull().default(0),
});

export const formFields = pgTable("form_fields", {
  id: id(),
  reportTypeId: text("report_type_id").notNull().references(() => reportTypes.id, { onDelete: "cascade" }),
  label: text("label").notNull(),
  fieldKey: text("field_key").notNull(),
  type: text("type").$type<FormFieldType>().notNull(),
  required: boolean("required").notNull().default(false),
  options: jsonb("options").$type<string[]>().default([]),
  order: integer("order").notNull().default(0),
});

export const reports = pgTable(
  "reports",
  {
    id: id(),
    reportTypeId: text("report_type_id").notNull().references(() => reportTypes.id, { onDelete: "cascade" }),
    authorId: text("author_id").references(() => users.id, { onDelete: "set null" }),
    data: jsonb("data").$type<Record<string, unknown>>().notNull().default({}),
    status: text("status").notNull().default("pending"), // pending | accepted | rejected | revision
    reviewerId: text("reviewer_id").references(() => users.id, { onDelete: "set null" }),
    reviewComment: text("review_comment"),
    pointsAwarded: integer("points_awarded").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("reports_author_idx").on(t.authorId)],
);

// ---------------------------------------------------------------------------
// AUDIT LOG
// ---------------------------------------------------------------------------

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: id(),
    actorId: text("actor_id").references(() => users.id, { onDelete: "set null" }),
    action: text("action").notNull(),
    target: text("target"),
    oldValue: jsonb("old_value"),
    newValue: jsonb("new_value"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("audit_logs_created_idx").on(t.createdAt)],
);

// ---------------------------------------------------------------------------
// SITE SETTINGS (key-value, editable from admin panel)
// ---------------------------------------------------------------------------

export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});

// ---------------------------------------------------------------------------
// RELATIONS
// ---------------------------------------------------------------------------

export const usersRelations = relations(users, ({ one, many }) => ({
  role: one(roles, { fields: [users.roleId], references: [roles.id] }),
  pointsHistory: many(pointsHistory),
  warns: many(warns),
  vacations: many(vacations),
  notifications: many(notifications),
}));

export const rolesRelations = relations(roles, ({ many }) => ({
  users: many(users),
  rolePermissions: many(rolePermissions),
}));

export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({
  role: one(roles, { fields: [rolePermissions.roleId], references: [roles.id] }),
  permission: one(permissions, { fields: [rolePermissions.permissionId], references: [permissions.id] }),
}));

export const forumCategoriesRelations = relations(forumCategories, ({ many }) => ({
  topics: many(forumTopics),
}));

export const forumTopicsRelations = relations(forumTopics, ({ one, many }) => ({
  category: one(forumCategories, { fields: [forumTopics.categoryId], references: [forumCategories.id] }),
  author: one(users, { fields: [forumTopics.authorId], references: [users.id] }),
  posts: many(forumPosts),
}));

export const forumPostsRelations = relations(forumPosts, ({ one }) => ({
  topic: one(forumTopics, { fields: [forumPosts.topicId], references: [forumTopics.id] }),
  author: one(users, { fields: [forumPosts.authorId], references: [users.id] }),
}));

export const reportTypesRelations = relations(reportTypes, ({ many }) => ({
  fields: many(formFields),
  reports: many(reports),
}));

export const formFieldsRelations = relations(formFields, ({ one }) => ({
  reportType: one(reportTypes, { fields: [formFields.reportTypeId], references: [reportTypes.id] }),
}));

export const reportsRelations = relations(reports, ({ one }) => ({
  reportType: one(reportTypes, { fields: [reports.reportTypeId], references: [reportTypes.id] }),
  author: one(users, { fields: [reports.authorId], references: [users.id] }),
  reviewer: one(users, { fields: [reports.reviewerId], references: [users.id] }),
}));
