import { NextResponse } from "next/server";
import { auth } from "@/auth";

const PUBLIC_PATHS = [
  "/",
  "/auth/signin",
  "/access-denied",
  "/on-vacation",
];

export default auth((req) => {
  const { pathname } = req.nextUrl;

  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/uploads") ||
    pathname.startsWith("/images") ||
    /\.(png|jpg|jpeg|svg|ico|webp|css|js)$/.test(pathname)
  ) {
    return NextResponse.next();
  }

  const isPublic = PUBLIC_PATHS.includes(pathname);
  const session = req.auth;

  if (!session?.user?.id) {
    if (isPublic) return NextResponse.next();
    const url = req.nextUrl.clone();
    url.pathname = "/auth/signin";
    return NextResponse.redirect(url);
  }

  // Logged in but no verified 2FA yet (role requires it) -> force 2FA gate.
  if (!session.user.twoFactorVerified && pathname !== "/auth/2fa") {
    const url = req.nextUrl.clone();
    url.pathname = "/auth/2fa";
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|uploads|images).*)"],
};
