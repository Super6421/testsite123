import type { ReactNode } from "react";
import { requireStaffAccess } from "@/lib/access";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Topbar } from "@/components/dashboard/Topbar";
import { HeartbeatPing } from "@/components/HeartbeatPing";
import { getSiteSettings } from "@/lib/settings";
import { can } from "@/lib/current-user";
import { discordAvatarUrl } from "@/lib/discord";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await requireStaffAccess();
  const settings = await getSiteSettings();
  const canAdmin = can(user.permissions, "admin.panel");

  return (
    <div className="min-h-screen bg-[#121212] bg-honeycomb">
      <HeartbeatPing />
      <Sidebar permissions={user.permissions} logoUrl={settings.logoUrl} siteName={settings.siteName} canAdmin={canAdmin} />
      <div className="lg:pl-64">
        <Topbar
          user={{
            discordUsername: user.discordUsername,
            discordAvatar: discordAvatarUrl(user.discordId, user.discordAvatar),
            minecraftNick: user.minecraftNick,
            status: user.status,
            lastSeenAt: user.lastSeenAt.toISOString(),
            roleName: user.role?.name,
            roleColor: user.role?.color,
          }}
          permissions={user.permissions}
          logoUrl={settings.logoUrl}
          siteName={settings.siteName}
          canAdmin={canAdmin}
        />
        <main className="mx-auto max-w-[1500px] px-4 py-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
