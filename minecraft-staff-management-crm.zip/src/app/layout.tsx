import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Nunito, Press_Start_2P } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";

const nunito = Nunito({ subsets: ["latin", "cyrillic"], variable: "--font-body-var", weight: ["400", "600", "700", "800"] });
const pressStart = Press_Start_2P({ subsets: ["latin"], weight: "400", variable: "--font-display-var" });

export const metadata: Metadata = {
  title: "Age Of Glory Staff",
  description: "Система управления персоналом проекта Age Of Glory",
  icons: { icon: "/images/default-logo.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${nunito.variable} ${pressStart.variable}`}>
      <body className="bg-[#121212] text-[#f5f5f0] antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
