import Link from "next/link";
import Image from "next/image";
import { auth } from "@/auth";
import { getSiteSettings } from "@/lib/settings";
import { FlyingBees } from "@/components/FlyingBees";
import { PollenParticles } from "@/components/PollenParticles";
import { LandingButtons } from "@/components/LandingButtons";

export const dynamic = "force-dynamic";

const FEATURES = [
  { icon: "🛡️", title: "Ролевая система", text: "Гибкие роли и права: forum, reports, staff, admin — всё настраивается без кода." },
  { icon: "🔐", title: "2FA для персонала", text: "Обязательная двухфакторная авторизация для выбранных ролей через Google Authenticator." },
  { icon: "📋", title: "Конструктор отчётов", text: "Отчёты по наказаниям, читерам и наборам с гибкими формами и проверкой." },
  { icon: "💬", title: "Форум персонала", text: "Категории, темы, вложения, закрепление и модерация обсуждений." },
  { icon: "🐝", title: "Discord-синхронизация", text: "Роли синхронизируются между сайтом и Discord в реальном времени." },
  { icon: "📊", title: "Статистика и рейтинги", text: "Баллы, варны, время в сети, топ недели и месяца, достижения." },
];

export default async function HomePage() {
  const session = await auth();
  const settings = await getSiteSettings();

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#121212] text-white">
      <div className="absolute inset-0">
        <Image src="/images/hero-bg.jpg" alt="" fill priority className="object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#121212]/40 via-[#121212]/70 to-[#121212]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-[#121212]/40" />
      </div>
      <PollenParticles count={40} />
      <FlyingBees count={8} />

      <div className="relative z-10 flex flex-col items-center px-4 pb-16 pt-10 sm:pt-16">
        <nav className="mb-16 flex w-full max-w-6xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-11 w-11 overflow-hidden rounded-xl glow-honey">
              <Image src={settings.logoUrl} alt={settings.siteName} fill className="object-cover" />
            </div>
            <span className="font-pixel text-[10px] text-[#FFD54F]">AGE OF GLORY</span>
          </div>
          <LandingButtons loggedIn={Boolean(session?.user)} compact />
        </nav>

        <div className="flex max-w-4xl flex-col items-center text-center">
          <span className="glass-panel-light mb-6 rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-widest text-[#FFD54F]">
            🍯 Minecraft {settings.minecraftVersion} • CRM для персонала
          </span>
          <h1 className="font-pixel glow-honey-text text-gradient-honey text-[7vw] leading-tight sm:text-[3.4rem] lg:text-[4.2rem]">
            {settings.heroTitle}
          </h1>
          <p className="mt-6 max-w-2xl text-base text-white/70 sm:text-lg">{settings.heroSubtitle}</p>
          <p className="mt-3 max-w-3xl text-sm text-white/40">{settings.aboutText}</p>

          <div className="mt-10">
            <LandingButtons loggedIn={Boolean(session?.user)} />
          </div>
        </div>

        <div className="mt-24 grid w-full max-w-6xl grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="glass-panel group rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1 hover:glow-honey"
            >
              <div className="mb-3 text-3xl">{f.icon}</div>
              <h3 className="mb-2 text-lg font-extrabold text-[#FFD54F]">{f.title}</h3>
              <p className="text-sm text-white/60">{f.text}</p>
            </div>
          ))}
        </div>

        <div className="glass-panel mt-24 flex w-full max-w-4xl flex-col items-center gap-4 rounded-3xl p-10 text-center">
          <h2 className="font-pixel text-xl text-white">🐝 ГОТОВЫ ПРИСОЕДИНИТЬСЯ?</h2>
          <p className="max-w-xl text-sm text-white/60">
            Доступ на панель предоставляется только сотрудникам проекта с необходимой ролью в Discord.
          </p>
          <LandingButtons loggedIn={Boolean(session?.user)} />
        </div>

        <footer className="mt-16 text-xs text-white/30">© {new Date().getFullYear()} {settings.siteName}. Все права защищены.</footer>
      </div>
    </main>
  );
}
