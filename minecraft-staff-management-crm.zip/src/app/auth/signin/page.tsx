import Image from "next/image";
import { auth, signIn } from "@/auth";
import { redirect } from "next/navigation";
import { getSiteSettings } from "@/lib/settings";
import { FlyingBees } from "@/components/FlyingBees";
import { PollenParticles } from "@/components/PollenParticles";

export default async function SignInPage() {
  const session = await auth();
  if (session?.user) redirect("/dashboard");
  const settings = await getSiteSettings();
  const discordConfigured = Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET);

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#121212] px-4">
      <div className="absolute inset-0">
        <Image src="/images/hero-bg.jpg" alt="" fill className="object-cover opacity-40" />
        <div className="absolute inset-0 bg-[#121212]/75" />
      </div>
      <PollenParticles count={24} />
      <FlyingBees count={4} />

      <div className="glass-panel relative z-10 w-full max-w-md rounded-3xl p-8 text-center glow-honey">
        <div className="relative mx-auto mb-4 h-16 w-16 overflow-hidden rounded-2xl glow-honey">
          <Image src={settings.logoUrl} alt={settings.siteName} fill className="object-cover" />
        </div>
        <h1 className="font-pixel text-lg text-[#FFD54F]">ВХОД В ПАНЕЛЬ</h1>
        <p className="mt-3 text-sm text-white/60">
          Доступ предоставляется только сотрудникам проекта Age Of Glory, обладающим необходимой ролью в Discord.
        </p>

        <form
          action={async () => {
            "use server";
            await signIn("discord", { redirectTo: "/dashboard" });
          }}
          className="mt-8"
        >
          <button
            type="submit"
            className="flex w-full items-center justify-center gap-3 rounded-xl bg-[#5865F2] px-6 py-3.5 text-sm font-bold text-white transition hover:brightness-110"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.099.246.198.373.292a.077.077 0 0 1-.006.127c-.598.35-1.22.645-1.873.893a.076.076 0 0 0-.04.106c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.838 19.838 0 0 0 6.002-3.03.077.077 0 0 0 .032-.055c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.418 2.157-2.418 1.21 0 2.176 1.094 2.157 2.418 0 1.334-.955 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.418 2.157-2.418 1.21 0 2.176 1.094 2.157 2.418 0 1.334-.946 2.419-2.157 2.419z" />
            </svg>
            {discordConfigured ? "Войти через Discord" : "Войти через Discord (демо-режим)"}
          </button>
        </form>

        {!discordConfigured && (
          <p className="mt-4 rounded-xl border border-[#FFD54F]/30 bg-[#FFD54F]/5 p-3 text-xs text-[#FFD54F]/80">
            ⚠ DISCORD_CLIENT_ID / DISCORD_CLIENT_SECRET не заданы в .env — вход настроен в демонстрационном режиме
            через тестовое Discord-приложение. Добавьте реальные ключи для боевого запуска.
          </p>
        )}

        <p className="mt-6 text-[11px] text-white/30">Age Of Glory Staff • Minecraft 1.21.1</p>
      </div>
    </main>
  );
}
