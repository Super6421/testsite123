import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const { minecraftNick, minecraftInfo } = (await req.json()) as {
    minecraftNick: string;
    minecraftInfo?: string;
  };
  if (!minecraftNick?.trim()) return NextResponse.json({ error: "Укажите ник Minecraft" }, { status: 400 });

  const [updated] = await db
    .update(users)
    .set({ minecraftNick: minecraftNick.trim(), minecraftInfo: minecraftInfo ?? "", profileCompleted: true })
    .where(eq(users.id, user.id))
    .returning();

  return NextResponse.json({ user: updated });
}
