import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { generateTotpQrCode, generateTotpSecret } from "@/lib/totp";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  if (user.totpEnabled) return NextResponse.json({ error: "2FA уже подключена" }, { status: 400 });

  const secret = generateTotpSecret();
  await db.update(users).set({ totpSecret: secret }).where(eq(users.id, user.id));
  const { dataUrl, otpauth } = await generateTotpQrCode(secret, user.discordUsername);
  return NextResponse.json({ qr: dataUrl, otpauth, secret });
}
