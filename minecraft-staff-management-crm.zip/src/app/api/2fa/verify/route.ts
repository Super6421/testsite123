import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { verifyTotpToken } from "@/lib/totp";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  if (!user.totpEnabled || !user.totpSecret) {
    return NextResponse.json({ error: "2FA не подключена" }, { status: 400 });
  }
  const { code } = (await req.json()) as { code: string };
  const valid = verifyTotpToken(user.totpSecret, code ?? "");
  if (!valid) return NextResponse.json({ error: "Неверный код" }, { status: 400 });
  return NextResponse.json({ ok: true });
}
