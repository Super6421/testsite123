import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request) {
  const guard = await requireApiUser("admin.2fa");
  if ("error" in guard) return guard.error;

  const { userId } = (await req.json()) as { userId: string };
  await db
    .update(users)
    .set({ totpEnabled: false, totpSecret: null, totpVerifiedAt: null })
    .where(eq(users.id, userId));

  await logAudit({ actorId: guard.user.id, action: "2fa.reset", target: userId });
  await sendNotification({
    userId,
    type: "system",
    title: "2FA сброшена",
    message: "Администратор сбросил вашу двухфакторную аутентификацию. Настройте её заново при следующем входе.",
  });

  return NextResponse.json({ ok: true });
}
