import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { verifyTotpToken } from "@/lib/totp";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  if (!user.totpSecret) return NextResponse.json({ error: "Сначала получите QR-код" }, { status: 400 });

  const { code } = (await req.json()) as { code: string };
  const valid = verifyTotpToken(user.totpSecret, code ?? "");
  if (!valid) return NextResponse.json({ error: "Неверный код" }, { status: 400 });

  await db
    .update(users)
    .set({ totpEnabled: true, totpVerifiedAt: new Date() })
    .where(eq(users.id, user.id));

  await logAudit({ actorId: user.id, action: "2fa.enabled", target: user.id });

  return NextResponse.json({ ok: true });
}
