import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { formFields, reportTypes } from "@/db/schema";
import { asc } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const types = await db.select().from(reportTypes).orderBy(asc(reportTypes.order));
  const fields = await db.select().from(formFields).orderBy(asc(formFields.order));

  const withFields = types.map((t) => ({
    ...t,
    fields: fields.filter((f) => f.reportTypeId === t.id),
    canView: can(user.permissions, t.viewPermission),
    canCreate: can(user.permissions, t.createPermission),
    canReview: can(user.permissions, t.reviewPermission),
  }));

  return NextResponse.json({ reportTypes: withFields });
}

export async function POST(req: Request) {
  const guard = await requireApiUser("admin.forms");
  if ("error" in guard) return guard.error;
  const body = (await req.json()) as {
    key: string;
    name: string;
    description?: string;
    icon?: string;
    viewPermission: string;
    createPermission: string;
    reviewPermission: string;
    pointsConfig?: Record<string, number>;
  };

  const [created] = await db
    .insert(reportTypes)
    .values({
      key: body.key,
      name: body.name,
      description: body.description ?? "",
      icon: body.icon ?? "📄",
      viewPermission: body.viewPermission,
      createPermission: body.createPermission,
      reviewPermission: body.reviewPermission,
      pointsConfig: body.pointsConfig ?? {},
      order: 99,
    })
    .returning();

  await logAudit({ actorId: guard.user.id, action: "reportType.create", target: created.id, newValue: body });
  return NextResponse.json({ reportType: created });
}
