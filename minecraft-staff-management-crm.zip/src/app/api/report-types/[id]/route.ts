import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { reportTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("admin.forms");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const body = await req.json();

  const [updated] = await db.update(reportTypes).set(body).where(eq(reportTypes.id, id)).returning();
  await logAudit({ actorId: guard.user.id, action: "reportType.update", target: id, newValue: body });
  return NextResponse.json({ reportType: updated });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("admin.forms");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  await db.delete(reportTypes).where(eq(reportTypes.id, id));
  await logAudit({ actorId: guard.user.id, action: "reportType.delete", target: id });
  return NextResponse.json({ ok: true });
}
