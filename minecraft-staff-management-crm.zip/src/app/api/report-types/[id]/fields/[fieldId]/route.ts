import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { formFields } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string; fieldId: string }> }) {
  const guard = await requireApiUser("admin.forms");
  if ("error" in guard) return guard.error;
  const { fieldId } = await ctx.params;
  await db.delete(formFields).where(eq(formFields.id, fieldId));
  await logAudit({ actorId: guard.user.id, action: "formField.delete", target: fieldId });
  return NextResponse.json({ ok: true });
}
