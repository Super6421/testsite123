import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { formFields } from "@/db/schema";
import { logAudit } from "@/lib/audit";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("admin.forms");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const body = (await req.json()) as {
    label: string;
    fieldKey: string;
    type: string;
    required?: boolean;
    options?: string[];
    order?: number;
  };

  const [created] = await db
    .insert(formFields)
    .values({
      reportTypeId: id,
      label: body.label,
      fieldKey: body.fieldKey,
      type: body.type as never,
      required: body.required ?? false,
      options: body.options ?? [],
      order: body.order ?? 99,
    })
    .returning();

  await logAudit({ actorId: guard.user.id, action: "formField.create", target: id, newValue: body });
  return NextResponse.json({ field: created });
}
