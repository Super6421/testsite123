import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { forumTopics } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as { pinned?: boolean; closed?: boolean };
  const permission = body.pinned !== undefined ? "forum.pin" : "forum.close";
  const guard = await requireApiUser(permission);
  if ("error" in guard) return guard.error;

  const [updated] = await db.update(forumTopics).set(body).where(eq(forumTopics.id, id)).returning();
  await logAudit({ actorId: guard.user.id, action: "forum.topic.state", target: id, newValue: body });
  return NextResponse.json({ topic: updated });
}
