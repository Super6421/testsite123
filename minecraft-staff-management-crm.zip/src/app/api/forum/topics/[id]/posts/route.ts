import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { forumCategories, forumPosts, forumTopics } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [topic] = await db.select().from(forumTopics).where(eq(forumTopics.id, id)).limit(1);
  if (!topic) return NextResponse.json({ error: "Не найдено" }, { status: 404 });
  if (topic.closed) return NextResponse.json({ error: "Тема закрыта" }, { status: 400 });

  const [category] = await db.select().from(forumCategories).where(eq(forumCategories.id, topic.categoryId)).limit(1);
  if (!category || !can(user.permissions, "forum.reply")) return NextResponse.json({ error: "Нет прав" }, { status: 403 });

  const { content, attachments } = (await req.json()) as { content: string; attachments?: string[] };
  if (!content?.trim()) return NextResponse.json({ error: "Пустое сообщение" }, { status: 400 });

  const [post] = await db
    .insert(forumPosts)
    .values({ topicId: id, authorId: user.id, content, attachments: attachments ?? [] })
    .returning();

  return NextResponse.json({ post });
}
