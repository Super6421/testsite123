import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { forumCategories, forumPosts, forumTopics, users } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [topic] = await db.select().from(forumTopics).where(eq(forumTopics.id, id)).limit(1);
  if (!topic) return NextResponse.json({ error: "Не найдено" }, { status: 404 });

  const [category] = await db.select().from(forumCategories).where(eq(forumCategories.id, topic.categoryId)).limit(1);
  if (!category || !can(user.permissions, category.viewPermission)) {
    return NextResponse.json({ error: "Нет доступа" }, { status: 403 });
  }

  const posts = await db
    .select({
      post: forumPosts,
      author: { id: users.id, discordUsername: users.discordUsername, discordAvatar: users.discordAvatar, minecraftNick: users.minecraftNick },
    })
    .from(forumPosts)
    .leftJoin(users, eq(forumPosts.authorId, users.id))
    .where(eq(forumPosts.topicId, id))
    .orderBy(asc(forumPosts.createdAt));

  return NextResponse.json({ topic, category, posts, canModerate: can(user.permissions, "forum.pin") || can(user.permissions, "forum.close") });
}
