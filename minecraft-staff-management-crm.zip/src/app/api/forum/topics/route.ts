import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { forumCategories, forumPosts, forumTopics } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const { categoryId, title, content, attachments } = (await req.json()) as {
    categoryId: string;
    title: string;
    content: string;
    attachments?: string[];
  };

  const [category] = await db.select().from(forumCategories).where(eq(forumCategories.id, categoryId)).limit(1);
  if (!category) return NextResponse.json({ error: "Раздел не найден" }, { status: 404 });
  if (!can(user.permissions, category.createPermission)) return NextResponse.json({ error: "Нет прав" }, { status: 403 });
  if (!title?.trim() || !content?.trim()) return NextResponse.json({ error: "Заполните все поля" }, { status: 400 });

  const [topic] = await db.insert(forumTopics).values({ categoryId, title, authorId: user.id }).returning();
  await db.insert(forumPosts).values({ topicId: topic.id, authorId: user.id, content, attachments: attachments ?? [] });

  await logAudit({ actorId: user.id, action: "forum.topic.create", target: topic.id, newValue: { title } });

  return NextResponse.json({ topic });
}
