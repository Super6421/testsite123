import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { forumCategories, forumTopics } from "@/db/schema";
import { asc, eq, sql } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const categories = await db.select().from(forumCategories).orderBy(asc(forumCategories.order));
  const counts = await db
    .select({ categoryId: forumTopics.categoryId, count: sql<number>`count(*)::int` })
    .from(forumTopics)
    .groupBy(forumTopics.categoryId);
  const countMap = new Map(counts.map((c) => [c.categoryId, c.count]));

  const visible = categories
    .filter((c) => can(user.permissions, c.viewPermission))
    .map((c) => ({ ...c, canCreate: can(user.permissions, c.createPermission), topicsCount: countMap.get(c.id) ?? 0 }));

  return NextResponse.json({ categories: visible });
}

export async function POST(req: Request) {
  const guard = await requireApiUser("admin.forum");
  if ("error" in guard) return guard.error;
  const body = (await req.json()) as {
    name: string;
    description?: string;
    icon?: string;
    viewPermission?: string;
    createPermission?: string;
  };

  const [created] = await db
    .insert(forumCategories)
    .values({
      name: body.name,
      description: body.description ?? "",
      icon: body.icon ?? "📁",
      viewPermission: body.viewPermission ?? "forum.view",
      createPermission: body.createPermission ?? "forum.create",
      order: 99,
    })
    .returning();

  await logAudit({ actorId: guard.user.id, action: "forumCategory.create", target: created.id, newValue: body });
  return NextResponse.json({ category: created });
}
