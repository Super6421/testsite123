import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { forumCategories, forumTopics, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [category] = await db.select().from(forumCategories).where(eq(forumCategories.id, id)).limit(1);
  if (!category) return NextResponse.json({ error: "Не найдено" }, { status: 404 });
  if (!can(user.permissions, category.viewPermission)) return NextResponse.json({ error: "Нет доступа" }, { status: 403 });

  const topics = await db
    .select({
      topic: forumTopics,
      author: { id: users.id, discordUsername: users.discordUsername, discordAvatar: users.discordAvatar, minecraftNick: users.minecraftNick },
    })
    .from(forumTopics)
    .leftJoin(users, eq(forumTopics.authorId, users.id))
    .where(eq(forumTopics.categoryId, id))
    .orderBy(desc(forumTopics.pinned), desc(forumTopics.createdAt));

  return NextResponse.json({ category, topics, canCreate: can(user.permissions, category.createPermission) });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("admin.forum");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const body = await req.json();
  const [updated] = await db.update(forumCategories).set(body).where(eq(forumCategories.id, id)).returning();
  await logAudit({ actorId: guard.user.id, action: "forumCategory.update", target: id, newValue: body });
  return NextResponse.json({ category: updated });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("admin.forum");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  await db.delete(forumCategories).where(eq(forumCategories.id, id));
  await logAudit({ actorId: guard.user.id, action: "forumCategory.delete", target: id });
  return NextResponse.json({ ok: true });
}
