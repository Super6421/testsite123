import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { auditLogs, notifications, pointsHistory, reports, roles, users } from "@/db/schema";
import { and, desc, eq, gte, isNotNull, sql } from "drizzle-orm";
import { isOnline } from "@/lib/format";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const allStaff = await db
    .select({ id: users.id, lastSeenAt: users.lastSeenAt, status: users.status })
    .from(users)
    .where(and(isNotNull(users.roleId), eq(users.isBanned, false)));

  const onlineCount = allStaff.filter((s) => s.status !== "vacation" && isOnline(s.lastSeenAt)).length;

  const allReports = await db.select().from(reports);
  const pendingReports = allReports.filter((r) => r.status === "pending").length;
  const newToday = allReports.filter((r) => {
    const d = new Date(r.createdAt);
    const today = new Date();
    return d.toDateString() === today.toDateString();
  }).length;

  const recentAudit = await db
    .select({ log: auditLogs, actor: { id: users.id, discordUsername: users.discordUsername, discordAvatar: users.discordAvatar } })
    .from(auditLogs)
    .leftJoin(users, eq(auditLogs.actorId, users.id))
    .orderBy(desc(auditLogs.createdAt))
    .limit(10);

  const recentNotifications = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(8);

  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const monthAgo = new Date();
  monthAgo.setDate(monthAgo.getDate() - 30);

  const weekTop = await db
    .select({
      userId: pointsHistory.userId,
      total: sql<number>`sum(${pointsHistory.delta})::int`,
    })
    .from(pointsHistory)
    .where(gte(pointsHistory.createdAt, weekAgo))
    .groupBy(pointsHistory.userId)
    .orderBy(desc(sql`sum(${pointsHistory.delta})`))
    .limit(5);

  const monthTop = await db
    .select({
      userId: pointsHistory.userId,
      total: sql<number>`sum(${pointsHistory.delta})::int`,
    })
    .from(pointsHistory)
    .where(gte(pointsHistory.createdAt, monthAgo))
    .groupBy(pointsHistory.userId)
    .orderBy(desc(sql`sum(${pointsHistory.delta})`))
    .limit(5);

  const allTimeTop = await db
    .select({
      id: users.id,
      discordUsername: users.discordUsername,
      discordAvatar: users.discordAvatar,
      minecraftNick: users.minecraftNick,
      points: users.points,
      roleName: roles.name,
      roleColor: roles.color,
    })
    .from(users)
    .leftJoin(roles, eq(users.roleId, roles.id))
    .orderBy(desc(users.points))
    .limit(5);

  async function attachUsers(rows: { userId: string; total: number }[]) {
    const ids = rows.map((r) => r.userId);
    if (!ids.length) return [];
    const staffUsers = await db.select().from(users).where(sql`${users.id} = ANY(${ids})`);
    return rows.map((r) => ({ ...r, user: staffUsers.find((u) => u.id === r.userId) }));
  }

  return NextResponse.json({
    onlineCount,
    staffCount: allStaff.length,
    pendingReports,
    newReportsToday: newToday,
    recentAudit,
    recentNotifications,
    topWeek: await attachUsers(weekTop),
    topMonth: await attachUsers(monthTop),
    topAllTime: allTimeTop,
  });
}
