import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { saveUpload } from "@/lib/uploads";

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const formData = await req.formData();
  const file = formData.get("file");
  const folder = (formData.get("folder") as string) || "misc";

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Файл не найден" }, { status: 400 });
  }
  if (file.size > 15 * 1024 * 1024) {
    return NextResponse.json({ error: "Файл слишком большой (макс. 15 МБ)" }, { status: 400 });
  }

  const url = await saveUpload(file, folder);
  return NextResponse.json({ url });
}
