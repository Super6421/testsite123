import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { permissions } from "@/db/schema";

export async function GET() {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;
  const rows = await db.select().from(permissions);
  return NextResponse.json({ permissions: rows });
}
