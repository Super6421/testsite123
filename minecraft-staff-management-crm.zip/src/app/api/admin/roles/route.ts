import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { permissions, rolePermissions, roles } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;

  const allRoles = await db.select().from(roles).orderBy(desc(roles.priority));
  const links = await db
    .select({ roleId: rolePermissions.roleId, key: permissions.key })
    .from(rolePermissions)
    .innerJoin(permissions, eq(permissions.id, rolePermissions.permissionId));

  const withPerms = allRoles.map((r) => ({
    ...r,
    permissions: links.filter((l) => l.roleId === r.id).map((l) => l.key),
  }));

  return NextResponse.json({ roles: withPerms });
}

export async function POST(req: Request) {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;
  const body = (await req.json()) as { name: string; color?: string; priority?: number; require2fa?: boolean };
  if (!body.name?.trim()) return NextResponse.json({ error: "Укажите название" }, { status: 400 });

  const [created] = await db
    .insert(roles)
    .values({ name: body.name.trim(), color: body.color ?? "#4CAF50", priority: body.priority ?? 100, require2fa: body.require2fa ?? false })
    .returning();

  await logAudit({ actorId: guard.user.id, action: "role.create", target: created.id, newValue: body });
  return NextResponse.json({ role: created });
}
