import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { permissions, rolePermissions } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const { keys } = (await req.json()) as { keys: string[] };

  await db.delete(rolePermissions).where(eq(rolePermissions.roleId, id));
  if (keys.length) {
    const perms = await db.select().from(permissions).where(inArray(permissions.key, keys));
    if (perms.length) {
      await db.insert(rolePermissions).values(perms.map((p) => ({ roleId: id, permissionId: p.id })));
    }
  }

  await logAudit({ actorId: guard.user.id, action: "role.permissions.update", target: id, newValue: { keys } });
  return NextResponse.json({ ok: true });
}
