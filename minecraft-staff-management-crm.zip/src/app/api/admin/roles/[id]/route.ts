import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { roles, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const body = (await req.json()) as Partial<{
    name: string;
    color: string;
    priority: number;
    require2fa: boolean;
    discordRoleId: string | null;
  }>;

  const [before] = await db.select().from(roles).where(eq(roles.id, id)).limit(1);
  const [updated] = await db.update(roles).set(body).where(eq(roles.id, id)).returning();

  await logAudit({ actorId: guard.user.id, action: "role.update", target: id, oldValue: before, newValue: body });
  return NextResponse.json({ role: updated });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("role.edit");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;

  const [role] = await db.select().from(roles).where(eq(roles.id, id)).limit(1);
  if (role?.isSystem) return NextResponse.json({ error: "Системную роль удалить нельзя" }, { status: 400 });

  await db.update(users).set({ roleId: null }).where(eq(users.roleId, id));
  await db.delete(roles).where(eq(roles.id, id));

  await logAudit({ actorId: guard.user.id, action: "role.delete", target: id });
  return NextResponse.json({ ok: true });
}
