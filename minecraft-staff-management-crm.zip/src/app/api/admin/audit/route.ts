import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const guard = await requireApiUser("admin.audit");
  if ("error" in guard) return guard.error;

  const rows = await db
    .select({
      log: auditLogs,
      actor: { id: users.id, discordUsername: users.discordUsername, discordAvatar: users.discordAvatar },
    })
    .from(auditLogs)
    .leftJoin(users, eq(auditLogs.actorId, users.id))
    .orderBy(desc(auditLogs.createdAt))
    .limit(200);

  return NextResponse.json({ logs: rows });
}
