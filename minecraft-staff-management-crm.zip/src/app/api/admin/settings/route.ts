import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { getSiteSettings, setSiteSetting } from "@/lib/settings";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const settings = await getSiteSettings();
  return NextResponse.json({ settings });
}

export async function PATCH(req: Request) {
  const guard = await requireApiUser("admin.settings");
  if ("error" in guard) return guard.error;
  const body = (await req.json()) as Record<string, unknown>;

  for (const [key, value] of Object.entries(body)) {
    await setSiteSetting(key as never, value);
  }

  await logAudit({ actorId: guard.user.id, action: "settings.update", newValue: body });
  return NextResponse.json({ ok: true });
}
