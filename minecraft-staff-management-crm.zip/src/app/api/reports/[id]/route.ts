import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { reportTypes, reports, users } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db
    .select({
      report: reports,
      type: reportTypes,
      author: { id: users.id, discordUsername: users.discordUsername, minecraftNick: users.minecraftNick, discordAvatar: users.discordAvatar },
    })
    .from(reports)
    .innerJoin(reportTypes, eq(reports.reportTypeId, reportTypes.id))
    .leftJoin(users, eq(reports.authorId, users.id))
    .where(eq(reports.id, id))
    .limit(1);

  if (!row) return NextResponse.json({ error: "Не найден" }, { status: 404 });

  const allowed =
    row.author?.id === user.id || can(user.permissions, row.type.viewPermission) || can(user.permissions, row.type.reviewPermission);
  if (!allowed) return NextResponse.json({ error: "Нет доступа" }, { status: 403 });

  return NextResponse.json(row);
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db.select().from(reports).where(eq(reports.id, id)).limit(1);
  if (!row) return NextResponse.json({ error: "Не найден" }, { status: 404 });
  if (row.authorId !== user.id) return NextResponse.json({ error: "Нет доступа" }, { status: 403 });
  if (row.status !== "revision") return NextResponse.json({ error: "Отчёт нельзя редактировать" }, { status: 400 });

  const { data } = (await req.json()) as { data: Record<string, unknown> };
  const [updated] = await db
    .update(reports)
    .set({ data, status: "pending", updatedAt: new Date() })
    .where(eq(reports.id, id))
    .returning();

  return NextResponse.json({ report: updated });
}
