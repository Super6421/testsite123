import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { pointsHistory, reportTypes, reports, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [row] = await db
    .select({ report: reports, type: reportTypes })
    .from(reports)
    .innerJoin(reportTypes, eq(reports.reportTypeId, reportTypes.id))
    .where(eq(reports.id, id))
    .limit(1);
  if (!row) return NextResponse.json({ error: "Не найден" }, { status: 404 });
  if (!can(user.permissions, row.type.reviewPermission)) {
    return NextResponse.json({ error: "Нет прав на проверку" }, { status: 403 });
  }

  const { status, comment } = (await req.json()) as {
    status: "accepted" | "rejected" | "revision";
    comment?: string;
  };

  let pointsAwarded = 0;
  if (status === "accepted" && row.report.authorId) {
    const pointsConfig = (row.type.pointsConfig ?? {}) as Record<string, number>;
    const data = row.report.data as Record<string, unknown>;
    const key = (data.punishmentType as string) || (data.result as string) || "Подтверждено";
    pointsAwarded = pointsConfig[key] ?? Object.values(pointsConfig)[0] ?? 1;
    await db
      .update(users)
      .set({ points: sql`${users.points} + ${pointsAwarded}` })
      .where(eq(users.id, row.report.authorId));
    await db.insert(pointsHistory).values({
      userId: row.report.authorId,
      delta: pointsAwarded,
      reason: `Принятый отчёт: ${row.type.name}`,
      givenById: user.id,
    });
  }

  await db
    .update(reports)
    .set({ status, reviewComment: comment, reviewerId: user.id, pointsAwarded, updatedAt: new Date() })
    .where(eq(reports.id, id));

  await logAudit({ actorId: user.id, action: `report.${status}`, target: id, newValue: { comment } });

  if (row.report.authorId) {
    const typeMap = { accepted: "report_accepted", rejected: "report_rejected", revision: "report_revision" } as const;
    const titleMap = { accepted: "Отчёт принят ✅", rejected: "Отчёт отклонён ❌", revision: "Отчёт на доработку ✏️" };
    await sendNotification({
      userId: row.report.authorId,
      type: typeMap[status],
      title: titleMap[status],
      message: comment || `Ваш отчёт «${row.type.name}» обработан.`,
      link: `/reports/view/${id}`,
    });
  }

  return NextResponse.json({ ok: true, pointsAwarded });
}
