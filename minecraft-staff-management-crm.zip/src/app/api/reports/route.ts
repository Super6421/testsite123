import { NextResponse } from "next/server";
import { getCurrentUser, can } from "@/lib/current-user";
import { db } from "@/db";
import { reportTypes, reports, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const typeKey = searchParams.get("type");
  const mine = searchParams.get("mine") === "1";

  let typeRow;
  if (typeKey) {
    [typeRow] = await db.select().from(reportTypes).where(eq(reportTypes.key, typeKey)).limit(1);
    if (!typeRow) return NextResponse.json({ error: "Тип отчёта не найден" }, { status: 404 });
    if (!mine && !can(user.permissions, typeRow.viewPermission) && !can(user.permissions, typeRow.reviewPermission)) {
      return NextResponse.json({ error: "Нет доступа" }, { status: 403 });
    }
  }

  const rows = await db
    .select({
      report: reports,
      type: reportTypes,
      author: { id: users.id, discordUsername: users.discordUsername, minecraftNick: users.minecraftNick, discordAvatar: users.discordAvatar },
    })
    .from(reports)
    .innerJoin(reportTypes, eq(reports.reportTypeId, reportTypes.id))
    .leftJoin(users, eq(reports.authorId, users.id))
    .orderBy(desc(reports.createdAt));

  let filtered = rows;
  if (typeRow) filtered = filtered.filter((r) => r.type.id === typeRow!.id);
  if (mine) filtered = filtered.filter((r) => r.author?.id === user.id);
  else
    filtered = filtered.filter(
      (r) => r.author?.id === user.id || can(user.permissions, r.type.viewPermission) || can(user.permissions, r.type.reviewPermission),
    );

  return NextResponse.json({ reports: filtered });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const { typeKey, data } = (await req.json()) as { typeKey: string; data: Record<string, unknown> };
  const [type] = await db.select().from(reportTypes).where(eq(reportTypes.key, typeKey)).limit(1);
  if (!type) return NextResponse.json({ error: "Тип отчёта не найден" }, { status: 404 });
  if (!can(user.permissions, type.createPermission)) {
    return NextResponse.json({ error: "Нет прав на создание этого отчёта" }, { status: 403 });
  }

  const [created] = await db
    .insert(reports)
    .values({ reportTypeId: type.id, authorId: user.id, data, status: "pending" })
    .returning();

  await logAudit({ actorId: user.id, action: "report.create", target: created.id, newValue: { typeKey } });

  return NextResponse.json({ report: created });
}
