import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { warns } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string; warnId: string }> }) {
  const guard = await requireApiUser("warn.remove");
  if ("error" in guard) return guard.error;
  const { id, warnId } = await ctx.params;

  await db
    .update(warns)
    .set({ active: false, removedById: guard.user.id, removedAt: new Date() })
    .where(eq(warns.id, warnId));

  await logAudit({ actorId: guard.user.id, action: "warn.remove", target: id, oldValue: { warnId } });
  await sendNotification({ userId: id, type: "warn_removed", title: "Предупреждение снято", message: "Одно из ваших предупреждений было снято администрацией." });

  return NextResponse.json({ ok: true });
}
