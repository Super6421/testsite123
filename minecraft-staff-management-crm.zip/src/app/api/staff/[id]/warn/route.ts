import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { warns } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("warn.give");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const { reason } = (await req.json()) as { reason: string };
  if (!reason) return NextResponse.json({ error: "Укажите причину" }, { status: 400 });

  const active = await db.select().from(warns).where(and(eq(warns.userId, id), eq(warns.active, true)));
  if (active.length >= 3) {
    return NextResponse.json({ error: "У сотрудника уже максимум предупреждений (3)" }, { status: 400 });
  }

  await db.insert(warns).values({ userId: id, reason, givenById: guard.user.id });
  await logAudit({ actorId: guard.user.id, action: "warn.give", target: id, newValue: { reason } });
  await sendNotification({ userId: id, type: "warn_given", title: "Выдано предупреждение", message: reason });

  return NextResponse.json({ ok: true });
}
