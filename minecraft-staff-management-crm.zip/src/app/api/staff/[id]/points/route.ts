import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { pointsHistory, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const { delta, reason } = (await req.json()) as { delta: number; reason: string };
  const guard = await requireApiUser(delta >= 0 ? "points.give" : "points.remove");
  if ("error" in guard) return guard.error;
  if (!reason || !delta) return NextResponse.json({ error: "Некорректные данные" }, { status: 400 });

  await db.update(users).set({ points: sql`${users.points} + ${delta}` }).where(eq(users.id, id));
  await db.insert(pointsHistory).values({ userId: id, delta, reason, givenById: guard.user.id });

  await logAudit({ actorId: guard.user.id, action: "points.change", target: id, newValue: { delta, reason } });
  await sendNotification({
    userId: id,
    type: delta >= 0 ? "points_given" : "points_removed",
    title: delta >= 0 ? `Начислено ${delta} баллов` : `Списано ${Math.abs(delta)} баллов`,
    message: reason,
  });

  return NextResponse.json({ ok: true });
}
