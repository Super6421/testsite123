import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { dailyActivity, pointsHistory, reports, users, vacations, warns, userAchievements, achievements, roles } from "@/db/schema";
import { and, desc, eq, gte } from "drizzle-orm";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const viewer = await getCurrentUser();
  if (!viewer) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await ctx.params;

  const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!user) return NextResponse.json({ error: "Не найден" }, { status: 404 });

  const canViewFull = viewer.id === id || viewer.permissions.includes("*") || viewer.permissions.includes("staff.view");
  if (!canViewFull) return NextResponse.json({ error: "Нет доступа" }, { status: 403 });

  const [role] = user.roleId ? await db.select().from(roles).where(eq(roles.id, user.roleId)).limit(1) : [null];

  const pointsHist = await db
    .select()
    .from(pointsHistory)
    .where(eq(pointsHistory.userId, id))
    .orderBy(desc(pointsHistory.createdAt))
    .limit(50);

  const warnList = await db.select().from(warns).where(eq(warns.userId, id)).orderBy(desc(warns.createdAt));
  const vacationList = await db.select().from(vacations).where(eq(vacations.userId, id)).orderBy(desc(vacations.createdAt));
  const userReports = await db.select().from(reports).where(eq(reports.authorId, id));

  const since = new Date();
  since.setDate(since.getDate() - 30);
  const activity = await db
    .select()
    .from(dailyActivity)
    .where(and(eq(dailyActivity.userId, id), gte(dailyActivity.date, since.toISOString().slice(0, 10))))
    .orderBy(dailyActivity.date);

  const achievementRows = await db
    .select({ achievement: achievements, earnedAt: userAchievements.earnedAt })
    .from(userAchievements)
    .innerJoin(achievements, eq(achievements.id, userAchievements.achievementId))
    .where(eq(userAchievements.userId, id));

  const todayStr = new Date().toISOString().slice(0, 10);
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const monthAgo = new Date();
  monthAgo.setDate(monthAgo.getDate() - 30);

  const timeToday = activity.filter((a) => a.date === todayStr).reduce((s, a) => s + a.seconds, 0);
  const timeWeek = activity.filter((a) => a.date >= weekAgo.toISOString().slice(0, 10)).reduce((s, a) => s + a.seconds, 0);
  const timeMonth = activity.filter((a) => a.date >= monthAgo.toISOString().slice(0, 10)).reduce((s, a) => s + a.seconds, 0);

  return NextResponse.json({
    user: { ...user, totpSecret: undefined },
    role,
    pointsHistory: pointsHist,
    warns: warnList,
    vacations: vacationList,
    reports: {
      total: userReports.length,
      accepted: userReports.filter((r) => r.status === "accepted").length,
      rejected: userReports.filter((r) => r.status === "rejected").length,
      pending: userReports.filter((r) => r.status === "pending").length,
    },
    activity,
    stats: { timeToday, timeWeek, timeMonth },
    achievements: achievementRows,
  });
}
