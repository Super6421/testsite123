import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { roles, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";
import { addGuildMemberRole, removeGuildMemberRole } from "@/lib/discord";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const { roleId, mode } = (await req.json()) as { roleId: string; mode: "promotion" | "demotion" | "edit" };
  const permKey = mode === "promotion" ? "promotion.give" : mode === "demotion" ? "demotion.give" : "role.edit";
  const guard = await requireApiUser(permKey);
  if ("error" in guard) return guard.error;

  const [target] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!target) return NextResponse.json({ error: "Не найден" }, { status: 404 });

  const [newRole] = await db.select().from(roles).where(eq(roles.id, roleId)).limit(1);
  if (!newRole) return NextResponse.json({ error: "Роль не найдена" }, { status: 404 });

  const [oldRole] = target.roleId ? await db.select().from(roles).where(eq(roles.id, target.roleId)).limit(1) : [null];

  await db.update(users).set({ roleId }).where(eq(users.id, id));

  if (oldRole?.discordRoleId) await removeGuildMemberRole(target.discordId, oldRole.discordRoleId);
  if (newRole.discordRoleId) await addGuildMemberRole(target.discordId, newRole.discordRoleId);

  await logAudit({
    actorId: guard.user.id,
    action: `role.${mode}`,
    target: id,
    oldValue: { role: oldRole?.name },
    newValue: { role: newRole.name },
  });

  const typeMap = { promotion: "promotion", demotion: "demotion", edit: "role_changed" } as const;
  await sendNotification({
    userId: id,
    type: typeMap[mode],
    title: mode === "promotion" ? "Повышение!" : mode === "demotion" ? "Понижение" : "Роль изменена",
    message: `Ваша новая роль: ${newRole.name}`,
  });

  return NextResponse.json({ ok: true });
}
