import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { users, vacations } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("vacation.give");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const { startDate, endDate, reason } = (await req.json()) as {
    startDate: string;
    endDate: string;
    reason: string;
  };
  if (!startDate || !endDate || !reason) {
    return NextResponse.json({ error: "Заполните все поля" }, { status: 400 });
  }

  await db.insert(vacations).values({ userId: id, startDate, endDate, reason, givenById: guard.user.id });
  await db.update(users).set({ status: "vacation" }).where(eq(users.id, id));

  await logAudit({ actorId: guard.user.id, action: "vacation.give", target: id, newValue: { startDate, endDate, reason } });
  await sendNotification({
    userId: id,
    type: "vacation_given",
    title: "Вам выдан отпуск",
    message: `С ${startDate} по ${endDate}. Причина: ${reason}`,
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("vacation.remove");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;

  await db
    .update(vacations)
    .set({ status: "cancelled" })
    .where(and(eq(vacations.userId, id), eq(vacations.status, "active")));
  await db.update(users).set({ status: "online" }).where(eq(users.id, id));

  await logAudit({ actorId: guard.user.id, action: "vacation.remove", target: id });
  await sendNotification({ userId: id, type: "vacation_removed", title: "Отпуск снят", message: "Ваш доступ к панели восстановлен." });

  return NextResponse.json({ ok: true });
}
