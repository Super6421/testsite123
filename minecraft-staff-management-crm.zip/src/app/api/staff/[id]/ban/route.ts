import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";
import { sendNotification } from "@/lib/notify";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireApiUser("staff.edit");
  if ("error" in guard) return guard.error;
  const { id } = await ctx.params;
  const { banned } = (await req.json()) as { banned: boolean };

  await db
    .update(users)
    .set({ isBanned: banned, roleId: banned ? null : undefined })
    .where(eq(users.id, id));

  await logAudit({ actorId: guard.user.id, action: banned ? "staff.remove" : "staff.restore", target: id });
  if (!banned) {
    await sendNotification({ userId: id, type: "system", title: "Доступ восстановлен", message: "Ваш доступ к панели персонала восстановлен." });
  }

  return NextResponse.json({ ok: true });
}
