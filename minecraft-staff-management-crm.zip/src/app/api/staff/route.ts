import { NextResponse } from "next/server";
import { requireApiUser } from "@/lib/api-guard";
import { db } from "@/db";
import { roles, users } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const guard = await requireApiUser("staff.view");
  if ("error" in guard) return guard.error;

  const rows = await db
    .select({
      id: users.id,
      discordId: users.discordId,
      discordUsername: users.discordUsername,
      discordAvatar: users.discordAvatar,
      minecraftNick: users.minecraftNick,
      points: users.points,
      status: users.status,
      lastSeenAt: users.lastSeenAt,
      isBanned: users.isBanned,
      isSuperAdmin: users.isSuperAdmin,
      totpEnabled: users.totpEnabled,
      createdAt: users.createdAt,
      role: {
        id: roles.id,
        name: roles.name,
        color: roles.color,
        priority: roles.priority,
        require2fa: roles.require2fa,
      },
    })
    .from(users)
    .leftJoin(roles, eq(users.roleId, roles.id))
    .orderBy(desc(roles.priority), desc(users.points));

  return NextResponse.json({ staff: rows });
}
