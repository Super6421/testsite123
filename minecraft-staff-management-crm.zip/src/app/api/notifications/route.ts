import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(50);
  return NextResponse.json({ notifications: rows });
}

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id, all } = (await req.json()) as { id?: string; all?: boolean };
  if (all) {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, user.id));
  } else if (id) {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }
  return NextResponse.json({ ok: true });
}
