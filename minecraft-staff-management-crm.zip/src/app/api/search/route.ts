import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { forumTopics, users } from "@/db/schema";
import { ilike, or } from "drizzle-orm";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") ?? "").trim();
  if (q.length < 2) return NextResponse.json({ staff: [], topics: [] });

  const staff = await db
    .select({ id: users.id, discordUsername: users.discordUsername, minecraftNick: users.minecraftNick, discordAvatar: users.discordAvatar })
    .from(users)
    .where(or(ilike(users.discordUsername, `%${q}%`), ilike(users.minecraftNick, `%${q}%`)))
    .limit(8);

  const topics = await db
    .select({ id: forumTopics.id, title: forumTopics.title })
    .from(forumTopics)
    .where(ilike(forumTopics.title, `%${q}%`))
    .limit(8);

  return NextResponse.json({ staff, topics });
}
