import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/current-user";
import { db } from "@/db";
import { dailyActivity, users } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";

const HEARTBEAT_SECONDS = 20;

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  if (user.status === "vacation") return NextResponse.json({ ok: true, skipped: true });

  const today = new Date().toISOString().slice(0, 10);

  await db
    .update(users)
    .set({
      lastSeenAt: new Date(),
      status: "online",
      totalTimeSeconds: sql`${users.totalTimeSeconds} + ${HEARTBEAT_SECONDS}`,
    })
    .where(eq(users.id, user.id));

  const [existing] = await db
    .select()
    .from(dailyActivity)
    .where(and(eq(dailyActivity.userId, user.id), eq(dailyActivity.date, today)))
    .limit(1);

  if (existing) {
    await db
      .update(dailyActivity)
      .set({ seconds: sql`${dailyActivity.seconds} + ${HEARTBEAT_SECONDS}` })
      .where(eq(dailyActivity.id, existing.id));
  } else {
    await db.insert(dailyActivity).values({ userId: user.id, date: today, seconds: HEARTBEAT_SECONDS });
  }

  return NextResponse.json({ ok: true });
}
