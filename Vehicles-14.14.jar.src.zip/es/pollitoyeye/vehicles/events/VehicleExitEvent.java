/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.interfaces.Vehicle;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class VehicleExitEvent
/*    */   extends Event implements Cancellable {
/* 11 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private boolean cancelled;
/*    */   private boolean removeOnDismount;
/*    */   private Player player;
/*    */   private Vehicle vehicle;
/*    */   
/*    */   public VehicleExitEvent(Player paramPlayer, Vehicle paramVehicle) {
/* 18 */     this.player = paramPlayer;
/* 19 */     this.vehicle = paramVehicle;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 24 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 27 */     return handlerList;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean paramBoolean) {
/* 31 */     this.cancelled = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 35 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 39 */     return this.player;
/*    */   }
/*    */   
/*    */   public Vehicle getVehicle() {
/* 43 */     return this.vehicle;
/*    */   }
/*    */   
/*    */   public boolean removeOnDismountSet() {
/* 47 */     return this.removeOnDismount;
/*    */   }
/*    */   
/*    */   public void setRemoveOnDismount(boolean paramBoolean) {
/* 51 */     this.removeOnDismount = paramBoolean;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehicleExitEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */