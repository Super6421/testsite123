/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.interfaces.Vehicle;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class VehicleCollideEvent
/*    */   extends Event {
/*  9 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private Vehicle vehicle;
/*    */   
/*    */   public VehicleCollideEvent(Vehicle paramVehicle) {
/* 13 */     this.vehicle = paramVehicle;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 18 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 21 */     return handlerList;
/*    */   }
/*    */   
/*    */   public Vehicle getVehicle() {
/* 25 */     return this.vehicle;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehicleCollideEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */