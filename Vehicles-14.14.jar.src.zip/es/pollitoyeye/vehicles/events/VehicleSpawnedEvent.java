/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class VehicleSpawnedEvent
/*    */   extends Event
/*    */ {
/* 14 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private String owner;
/*    */   private Location blockLoc;
/*    */   private String vehicleSubType;
/*    */   private VehicleType vehicleType;
/*    */   private ArrayList<ArmorStand> vehicleParts;
/*    */   
/*    */   public VehicleSpawnedEvent(String paramString1, Location paramLocation, ArrayList<ArmorStand> paramArrayList, String paramString2, VehicleType paramVehicleType) {
/* 22 */     this.owner = paramString1;
/* 23 */     this.blockLoc = paramLocation;
/* 24 */     this.vehicleSubType = paramString2;
/* 25 */     this.vehicleType = paramVehicleType;
/* 26 */     this.vehicleParts = paramArrayList;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 30 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 33 */     return handlerList;
/*    */   }
/*    */   public String getOwner() {
/* 36 */     return this.owner;
/*    */   }
/*    */   public Location getBlockLocation() {
/* 39 */     return this.blockLoc;
/*    */   }
/*    */   public VehicleType getVehicleType() {
/* 42 */     return this.vehicleType;
/*    */   }
/*    */   public String getVehicleSubType() {
/* 45 */     return this.vehicleSubType;
/*    */   }
/*    */   public ArrayList<ArmorStand> getVehicleParts() {
/* 48 */     return this.vehicleParts;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehicleSpawnedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */