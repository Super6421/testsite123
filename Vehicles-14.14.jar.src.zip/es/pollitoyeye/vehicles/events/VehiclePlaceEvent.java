/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class VehiclePlaceEvent
/*    */   extends Event implements Cancellable {
/* 12 */   private static final HandlerList handlerList = new HandlerList();
/*    */   
/*    */   private Location to;
/*    */   private VehicleType type;
/*    */   private boolean cancelled;
/*    */   private Player own;
/*    */   private String subType;
/*    */   
/*    */   public VehiclePlaceEvent(Player paramPlayer, Location paramLocation, VehicleType paramVehicleType, String paramString) {
/* 21 */     this.own = paramPlayer;
/* 22 */     this.to = paramLocation;
/* 23 */     this.type = paramVehicleType;
/* 24 */     this.subType = paramString;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 28 */     return handlerList;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 32 */     return handlerList;
/*    */   }
/*    */   
/*    */   public Location getLocation() {
/* 36 */     return this.to;
/*    */   }
/*    */   
/*    */   public Player getOwner() {
/* 40 */     return this.own;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean paramBoolean) {
/* 44 */     this.cancelled = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 48 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public VehicleType getType() {
/* 52 */     return this.type;
/*    */   }
/*    */   
/*    */   public String getSubType() {
/* 56 */     return this.subType;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehiclePlaceEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */