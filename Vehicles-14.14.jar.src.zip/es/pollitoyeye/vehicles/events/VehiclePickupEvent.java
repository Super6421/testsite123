/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class VehiclePickupEvent
/*    */   extends Event
/*    */ {
/* 13 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private String owner;
/*    */   private Location blockLoc;
/*    */   private Player player;
/*    */   private String vehicleSubType;
/*    */   private VehicleType vehicleType;
/*    */   private boolean cancelled;
/*    */   private boolean overridePermission;
/*    */   
/*    */   public VehiclePickupEvent(Player paramPlayer, String paramString1, Location paramLocation, String paramString2, VehicleType paramVehicleType) {
/* 23 */     this.owner = paramString1;
/* 24 */     setPlayer(paramPlayer);
/* 25 */     this.blockLoc = paramLocation;
/* 26 */     this.vehicleSubType = paramString2;
/* 27 */     this.vehicleType = paramVehicleType;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 31 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 34 */     return handlerList;
/*    */   }
/*    */   public String getOwner() {
/* 37 */     return this.owner;
/*    */   }
/*    */   public Location getBlockLocation() {
/* 40 */     return this.blockLoc;
/*    */   }
/*    */   public VehicleType getVehicleType() {
/* 43 */     return this.vehicleType;
/*    */   }
/*    */   public String getVehicleSubType() {
/* 46 */     return this.vehicleSubType;
/*    */   }
/*    */   public boolean isCancelled() {
/* 49 */     return this.cancelled;
/*    */   }
/*    */   public void setCancelled(boolean paramBoolean) {
/* 52 */     this.cancelled = paramBoolean;
/*    */   }
/*    */   public boolean isOverridePermissionEnabled() {
/* 55 */     return this.overridePermission;
/*    */   }
/*    */   public void setOverridePermission(boolean paramBoolean) {
/* 58 */     this.overridePermission = paramBoolean;
/*    */   }
/*    */   public Player getPlayer() {
/* 61 */     return this.player;
/*    */   }
/*    */   public void setPlayer(Player paramPlayer) {
/* 64 */     this.player = paramPlayer;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehiclePickupEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */