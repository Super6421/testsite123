/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class VehicleEnterEvent
/*    */   extends Event implements Cancellable {
/* 13 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private boolean cancelled;
/*    */   private Player player;
/*    */   private VehicleSubType vehicleSubType;
/*    */   private VehicleType vehicleType;
/*    */   private ArmorStand mainArmorStand;
/*    */   
/*    */   public VehicleEnterEvent(Player paramPlayer, VehicleSubType paramVehicleSubType, VehicleType paramVehicleType, ArmorStand paramArmorStand) {
/* 21 */     this.player = paramPlayer;
/* 22 */     this.vehicleSubType = paramVehicleSubType;
/* 23 */     this.vehicleType = paramVehicleType;
/* 24 */     this.mainArmorStand = paramArmorStand;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 29 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 32 */     return handlerList;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean paramBoolean) {
/* 36 */     this.cancelled = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 40 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public ArmorStand getMainArmorStand() {
/* 44 */     return this.mainArmorStand;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 48 */     return this.player;
/*    */   }
/*    */   
/*    */   public VehicleSubType getVehicleSubType() {
/* 52 */     return this.vehicleSubType;
/*    */   }
/*    */   
/*    */   public VehicleType getVehicleType() {
/* 56 */     return this.vehicleType;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehicleEnterEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */