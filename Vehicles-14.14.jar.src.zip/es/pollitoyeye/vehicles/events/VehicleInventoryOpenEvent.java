/*    */ package es.pollitoyeye.vehicles.events;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.interfaces.Vehicle;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class VehicleInventoryOpenEvent
/*    */   extends Event
/*    */   implements Cancellable {
/* 12 */   private static final HandlerList handlerList = new HandlerList();
/*    */   private boolean cancelled;
/*    */   private Player player;
/*    */   private Vehicle vehicle;
/*    */   
/*    */   public VehicleInventoryOpenEvent(Player paramPlayer, Vehicle paramVehicle) {
/* 18 */     this.player = paramPlayer;
/* 19 */     this.vehicle = paramVehicle;
/*    */   }
/*    */ 
/*    */   
/*    */   public HandlerList getHandlers() {
/* 24 */     return handlerList;
/*    */   }
/*    */   public static HandlerList getHandlerList() {
/* 27 */     return handlerList;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean paramBoolean) {
/* 31 */     this.cancelled = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 35 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public Vehicle getVehicle() {
/* 39 */     return this.vehicle;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 43 */     return this.player;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\events\VehicleInventoryOpenEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */