/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class HelicopterType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack material;
/*    */   private ItemStack helixMaterial;
/*    */   private double avalue;
/*    */   private double rModifier;
/*    */   private float missilePower;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private int fuelCapacity;
/*    */   private double fuelWasteSpeed;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public HelicopterType(ItemStack paramItemStack1, ItemStack paramItemStack2, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, float paramFloat, double paramDouble4, String paramString3, int paramInt, double paramDouble5, ItemStack paramItemStack3) {
/* 24 */     this.maxSpeed = paramDouble1;
/* 25 */     this.name = paramString1;
/* 26 */     this.displayName = paramString2;
/* 27 */     this.avalue = paramDouble2;
/* 28 */     this.rModifier = paramDouble3;
/* 29 */     this.material = paramItemStack1;
/* 30 */     this.helixMaterial = paramItemStack2;
/* 31 */     this.missilePower = paramFloat;
/* 32 */     this.mHealth = paramDouble4;
/* 33 */     this.permission = paramString3;
/* 34 */     this.fuelCapacity = paramInt;
/* 35 */     this.fuelWasteSpeed = paramDouble5;
/* 36 */     this.modelItem = paramItemStack3;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 39 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 42 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 45 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 48 */     return this.name;
/*    */   }
/*    */   public ItemStack getMaterial() {
/* 51 */     return this.material.clone();
/*    */   }
/*    */   public ItemStack getHelixMaterial() {
/* 54 */     return this.helixMaterial.clone();
/*    */   }
/*    */   public double getAcelerationValue() {
/* 57 */     return this.avalue;
/*    */   }
/*    */   public double getRotorSpeedValue() {
/* 60 */     return this.rModifier;
/*    */   }
/*    */   public float getMissilePower() {
/* 63 */     return this.missilePower;
/*    */   }
/*    */   public double getMaxHealth() {
/* 66 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 69 */     return this.permission;
/*    */   }
/*    */   public static HelicopterType valueOf(String paramString) {
/* 72 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.HELICOPTER, paramString);
/* 73 */     if (vehicleSubType != null) {
/* 74 */       return (HelicopterType)vehicleSubType;
/*    */     }
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 82 */     return this.fuelCapacity;
/*    */   }
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 86 */     return this.fuelWasteSpeed;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 90 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\HelicopterType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */