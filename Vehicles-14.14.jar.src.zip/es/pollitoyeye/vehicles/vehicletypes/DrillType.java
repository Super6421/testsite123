/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class DrillType
/*     */   implements VehicleSubType
/*     */ {
/*     */   private double maxSpeed;
/*     */   private double maxBackwardsSpeed;
/*     */   private ItemStack material;
/*     */   private ItemStack wheelMaterial;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private int hardness;
/*     */   private int fortuneLevel;
/*     */   private int silkTouchLevel;
/*     */   private double blockBreakDamage;
/*     */   private int animationDelay;
/*     */   private int miningSpeed;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public DrillType(ItemStack paramItemStack1, ItemStack paramItemStack2, double paramDouble1, double paramDouble2, String paramString1, String paramString2, double paramDouble3, double paramDouble4, String paramString3, int paramInt1, double paramDouble5, int paramInt2, int paramInt3, int paramInt4, double paramDouble6, int paramInt5, int paramInt6, ItemStack paramItemStack3) {
/*  31 */     this.maxSpeed = paramDouble1;
/*  32 */     this.maxBackwardsSpeed = paramDouble2;
/*  33 */     this.material = paramItemStack1;
/*  34 */     this.name = paramString1;
/*  35 */     this.displayName = paramString2;
/*  36 */     this.wheelMaterial = paramItemStack2;
/*  37 */     this.avalue = paramDouble3;
/*  38 */     this.mHealth = paramDouble4;
/*  39 */     this.permission = paramString3;
/*  40 */     this.fuelCapacity = paramInt1;
/*  41 */     this.fuelWasteSpeed = paramDouble5;
/*  42 */     this.hardness = paramInt2;
/*  43 */     this.fortuneLevel = paramInt3;
/*  44 */     this.silkTouchLevel = paramInt4;
/*  45 */     this.blockBreakDamage = paramDouble6;
/*  46 */     this.animationDelay = paramInt5;
/*  47 */     this.miningSpeed = paramInt6;
/*  48 */     this.modelItem = paramItemStack3;
/*     */   }
/*     */   public ItemStack getMaterial() {
/*  51 */     return this.material.clone();
/*     */   }
/*     */   public double getMaxSpeed() {
/*  54 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  57 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  60 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  63 */     return this.name;
/*     */   }
/*     */   public ItemStack getWheelMaterial() {
/*  66 */     return this.wheelMaterial.clone();
/*     */   }
/*     */   public double getAcelerationValue() {
/*  69 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/*  72 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  75 */     return this.permission;
/*     */   }
/*     */   public static DrillType valueOf(String paramString) {
/*  78 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.DRILL, paramString);
/*  79 */     if (vehicleSubType != null) {
/*  80 */       return (DrillType)vehicleSubType;
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/*  87 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/*  91 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   public int getHardness() {
/*  94 */     return this.hardness;
/*     */   }
/*     */   public void setHardness(int paramInt) {
/*  97 */     this.hardness = paramInt;
/*     */   }
/*     */   public int getFortuneLevel() {
/* 100 */     return this.fortuneLevel;
/*     */   }
/*     */   public void setFortuneLevel(int paramInt) {
/* 103 */     this.fortuneLevel = paramInt;
/*     */   }
/*     */   public int getSilkTouchLevel() {
/* 106 */     return this.silkTouchLevel;
/*     */   }
/*     */   public void setSilkTouchLevel(int paramInt) {
/* 109 */     this.silkTouchLevel = paramInt;
/*     */   }
/*     */   public double getBlockBreakDamage() {
/* 112 */     return this.blockBreakDamage;
/*     */   }
/*     */   public void setBlockBreakDamage(double paramDouble) {
/* 115 */     this.blockBreakDamage = paramDouble;
/*     */   }
/*     */   public int getAnimationDelay() {
/* 118 */     return this.animationDelay;
/*     */   }
/*     */   public void setAnimationDelay(int paramInt) {
/* 121 */     this.animationDelay = paramInt;
/*     */   }
/*     */   public int getMiningSpeed() {
/* 124 */     return this.miningSpeed;
/*     */   }
/*     */   public void setMiningSpeed(int paramInt) {
/* 127 */     this.miningSpeed = paramInt;
/*     */   }
/*     */   public double getMaxBackwardsSpeed() {
/* 130 */     return this.maxBackwardsSpeed;
/*     */   }
/*     */   public void setMaxBackwardsSpeed(double paramDouble) {
/* 133 */     this.maxBackwardsSpeed = paramDouble;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 137 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\DrillType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */