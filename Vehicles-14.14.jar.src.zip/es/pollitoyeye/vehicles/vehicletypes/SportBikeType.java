/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class SportBikeType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private ItemStack wheelMaterial;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private double avalue;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private int fuelCapacity;
/*    */   private double fuelWasteSpeed;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public SportBikeType(ItemStack paramItemStack1, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, String paramString3, int paramInt, double paramDouble4, ItemStack paramItemStack2) {
/* 21 */     this.maxSpeed = paramDouble1;
/* 22 */     this.name = paramString1;
/* 23 */     this.displayName = paramString2;
/* 24 */     this.wheelMaterial = paramItemStack1;
/* 25 */     this.avalue = paramDouble2;
/* 26 */     this.mHealth = paramDouble3;
/* 27 */     this.permission = paramString3;
/* 28 */     this.fuelCapacity = paramInt;
/* 29 */     this.fuelWasteSpeed = paramDouble4;
/* 30 */     this.modelItem = paramItemStack2;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 33 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 36 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 39 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 42 */     return this.name;
/*    */   }
/*    */   public ItemStack getWheelMaterial() {
/* 45 */     return this.wheelMaterial.clone();
/*    */   }
/*    */   public double getAcelerationValue() {
/* 48 */     return this.avalue;
/*    */   }
/*    */   public double getMaxHealth() {
/* 51 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 54 */     return this.permission;
/*    */   }
/*    */   public static SportBikeType valueOf(String paramString) {
/* 57 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.SPORT_BIKE, paramString);
/* 58 */     if (vehicleSubType != null) {
/* 59 */       return (SportBikeType)vehicleSubType;
/*    */     }
/* 61 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 66 */     return this.fuelCapacity;
/*    */   }
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 70 */     return this.fuelWasteSpeed;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 74 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\SportBikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */