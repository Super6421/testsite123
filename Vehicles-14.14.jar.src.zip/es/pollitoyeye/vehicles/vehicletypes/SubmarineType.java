/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class SubmarineType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack material;
/*    */   private ItemStack helixMaterial;
/*    */   private ItemStack port1;
/*    */   private ItemStack port2;
/*    */   private ItemStack port3;
/*    */   private double avalue;
/*    */   private double rModifier;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private int fuelCapacity;
/*    */   private double fuelWasteSpeed;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public SubmarineType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, double paramDouble4, String paramString3, int paramInt, double paramDouble5, ItemStack paramItemStack6) {
/* 26 */     this.maxSpeed = paramDouble1;
/* 27 */     this.name = paramString1;
/* 28 */     this.displayName = paramString2;
/* 29 */     this.avalue = paramDouble2;
/* 30 */     this.rModifier = paramDouble3;
/* 31 */     this.material = paramItemStack1;
/* 32 */     this.helixMaterial = paramItemStack2;
/* 33 */     this.port1 = paramItemStack3;
/* 34 */     this.port2 = paramItemStack4;
/* 35 */     this.port3 = paramItemStack5;
/* 36 */     this.mHealth = paramDouble4;
/* 37 */     this.permission = paramString3;
/* 38 */     this.fuelCapacity = paramInt;
/* 39 */     this.fuelWasteSpeed = paramDouble5;
/* 40 */     this.modelItem = paramItemStack6;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 43 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 46 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 49 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 52 */     return this.name;
/*    */   }
/*    */   public ItemStack getMaterial() {
/* 55 */     return this.material.clone();
/*    */   }
/*    */   public ItemStack getHelixMaterial() {
/* 58 */     return this.helixMaterial.clone();
/*    */   }
/*    */   public ItemStack getViewPort1() {
/* 61 */     return this.port1.clone();
/*    */   }
/*    */   public ItemStack getViewPort2() {
/* 64 */     return this.port2.clone();
/*    */   }
/*    */   public ItemStack getViewPort3() {
/* 67 */     return this.port3.clone();
/*    */   }
/*    */   public double getAcelerationValue() {
/* 70 */     return this.avalue;
/*    */   }
/*    */   public double getRotorSpeedValue() {
/* 73 */     return this.rModifier;
/*    */   }
/*    */   public double getMaxHealth() {
/* 76 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 79 */     return this.permission;
/*    */   }
/*    */   public static SubmarineType valueOf(String paramString) {
/* 82 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.SUBMARINE, paramString);
/* 83 */     if (vehicleSubType != null) {
/* 84 */       return (SubmarineType)vehicleSubType;
/*    */     }
/* 86 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 91 */     return this.fuelCapacity;
/*    */   }
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 95 */     return this.fuelWasteSpeed;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 99 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\SubmarineType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */