/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class TractorType
/*     */   implements VehicleSubType {
/*     */   private double maxSpeed;
/*     */   private double maxBackwardsSpeed;
/*     */   private ItemStack material;
/*     */   private ItemStack wheelMaterial;
/*     */   private ItemStack wheelCoverMaterial;
/*     */   private ItemStack motorMaterial;
/*     */   private ItemStack bottomMaterial;
/*     */   private ItemStack steeringWheelMaterial;
/*     */   private ItemStack bigWheelOutsideMaterial;
/*     */   private ItemStack bigWheelInsideMaterial;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private int harvestSpeed;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public TractorType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, ItemStack paramItemStack6, ItemStack paramItemStack7, ItemStack paramItemStack8, double paramDouble1, double paramDouble2, String paramString1, String paramString2, double paramDouble3, double paramDouble4, String paramString3, int paramInt1, double paramDouble5, int paramInt2, ItemStack paramItemStack9) {
/*  31 */     this.maxSpeed = paramDouble1;
/*  32 */     this.maxBackwardsSpeed = paramDouble2;
/*  33 */     this.material = paramItemStack1;
/*  34 */     this.name = paramString1;
/*  35 */     this.displayName = paramString2;
/*  36 */     this.wheelMaterial = paramItemStack2;
/*  37 */     this.wheelCoverMaterial = paramItemStack3;
/*  38 */     this.avalue = paramDouble3;
/*  39 */     this.mHealth = paramDouble4;
/*  40 */     this.permission = paramString3;
/*  41 */     this.fuelCapacity = paramInt1;
/*  42 */     this.fuelWasteSpeed = paramDouble5;
/*  43 */     this.motorMaterial = paramItemStack4;
/*  44 */     this.bottomMaterial = paramItemStack5;
/*  45 */     this.steeringWheelMaterial = paramItemStack6;
/*  46 */     this.bigWheelInsideMaterial = paramItemStack8;
/*  47 */     this.bigWheelOutsideMaterial = paramItemStack7;
/*  48 */     this.harvestSpeed = paramInt2;
/*  49 */     this.modelItem = paramItemStack9;
/*     */   }
/*     */   public ItemStack getMaterial() {
/*  52 */     return this.material.clone();
/*     */   }
/*     */   public double getMaxSpeed() {
/*  55 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  58 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  61 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  64 */     return this.name;
/*     */   }
/*     */   public ItemStack getWheelMaterial() {
/*  67 */     return this.wheelMaterial.clone();
/*     */   }
/*     */   public double getAcelerationValue() {
/*  70 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/*  73 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  76 */     return this.permission;
/*     */   }
/*     */   public static TractorType valueOf(String paramString) {
/*  79 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.TRACTOR, paramString);
/*  80 */     if (vehicleSubType != null) {
/*  81 */       return (TractorType)vehicleSubType;
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/*  88 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/*  92 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   public double getMaxBackwardsSpeed() {
/*  95 */     return this.maxBackwardsSpeed;
/*     */   }
/*     */   public void setMaxBackwardsSpeed(double paramDouble) {
/*  98 */     this.maxBackwardsSpeed = paramDouble;
/*     */   }
/*     */   public ItemStack getWheelCoverMaterial() {
/* 101 */     return this.wheelCoverMaterial;
/*     */   }
/*     */   public void setWheelCoverMaterial(ItemStack paramItemStack) {
/* 104 */     this.wheelCoverMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getMotorMaterial() {
/* 107 */     return this.motorMaterial;
/*     */   }
/*     */   public void setMotorMaterial(ItemStack paramItemStack) {
/* 110 */     this.motorMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getBottomMaterial() {
/* 113 */     return this.bottomMaterial;
/*     */   }
/*     */   public void setBottomMaterial(ItemStack paramItemStack) {
/* 116 */     this.bottomMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getSteeringWheelMaterial() {
/* 119 */     return this.steeringWheelMaterial;
/*     */   }
/*     */   public void setSteeringWheelMaterial(ItemStack paramItemStack) {
/* 122 */     this.steeringWheelMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getBigWheelOutsideMaterial() {
/* 125 */     return this.bigWheelOutsideMaterial;
/*     */   }
/*     */   public void setBigWheelOutsideMaterial(ItemStack paramItemStack) {
/* 128 */     this.bigWheelOutsideMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getBigWheelInsideMaterial() {
/* 131 */     return this.bigWheelInsideMaterial;
/*     */   }
/*     */   public void setBigWheelInsideMaterial(ItemStack paramItemStack) {
/* 134 */     this.bigWheelInsideMaterial = paramItemStack;
/*     */   }
/*     */   public int getHarvestSpeed() {
/* 137 */     return this.harvestSpeed;
/*     */   }
/*     */   public void setHarvestSpeed(int paramInt) {
/* 140 */     this.harvestSpeed = paramInt;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 144 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\TractorType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */