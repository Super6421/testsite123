/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class PlaneType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack material;
/*    */   private ItemStack wheelsMaterial;
/*    */   private ItemStack wingsMaterial;
/*    */   private double avalue;
/*    */   private double tSpeed;
/*    */   private float bombPower;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private int fuelCapacity;
/*    */   private double fuelWasteSpeed;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public PlaneType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, float paramFloat, double paramDouble4, String paramString3, int paramInt, double paramDouble5, ItemStack paramItemStack4) {
/* 25 */     this.maxSpeed = paramDouble1;
/* 26 */     this.name = paramString1;
/* 27 */     this.displayName = paramString2;
/* 28 */     this.avalue = paramDouble2;
/* 29 */     this.tSpeed = paramDouble3;
/* 30 */     this.material = paramItemStack1;
/* 31 */     this.wheelsMaterial = paramItemStack2;
/* 32 */     this.wingsMaterial = paramItemStack3;
/* 33 */     this.bombPower = paramFloat;
/* 34 */     this.mHealth = paramDouble4;
/* 35 */     this.permission = paramString3;
/* 36 */     this.fuelCapacity = paramInt;
/* 37 */     this.fuelWasteSpeed = paramDouble5;
/* 38 */     this.modelItem = paramItemStack4;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 41 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 44 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 47 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 50 */     return this.name;
/*    */   }
/*    */   public ItemStack getMaterial() {
/* 53 */     return this.material.clone();
/*    */   }
/*    */   public ItemStack getWingsMaterial() {
/* 56 */     return this.wingsMaterial.clone();
/*    */   }
/*    */   public ItemStack getWheelsMaterial() {
/* 59 */     return this.wheelsMaterial.clone();
/*    */   }
/*    */   public double getAcelerationValue() {
/* 62 */     return this.avalue;
/*    */   }
/*    */   public double getTakeOffSpeed() {
/* 65 */     return this.tSpeed;
/*    */   }
/*    */   public float getBombPower() {
/* 68 */     return this.bombPower;
/*    */   }
/*    */   public double getMaxHealth() {
/* 71 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 74 */     return this.permission;
/*    */   }
/*    */   public static PlaneType valueOf(String paramString) {
/* 77 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.PLANE, paramString);
/* 78 */     if (vehicleSubType != null) {
/* 79 */       return (PlaneType)vehicleSubType;
/*    */     }
/* 81 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 86 */     return this.fuelCapacity;
/*    */   }
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 90 */     return this.fuelWasteSpeed;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 94 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\PlaneType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */