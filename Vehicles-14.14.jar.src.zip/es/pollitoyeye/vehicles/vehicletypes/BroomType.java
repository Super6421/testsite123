/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BroomType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private double avalue;
/*    */   private double rModifier;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public BroomType(double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, double paramDouble4, String paramString3, ItemStack paramItemStack) {
/* 19 */     this.maxSpeed = paramDouble1;
/* 20 */     this.name = paramString1;
/* 21 */     this.displayName = paramString2;
/* 22 */     this.avalue = paramDouble2;
/* 23 */     this.rModifier = paramDouble3;
/* 24 */     this.mHealth = paramDouble4;
/* 25 */     this.permission = paramString3;
/* 26 */     this.modelItem = paramItemStack;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 29 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 32 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 38 */     return this.name;
/*    */   }
/*    */   public double getAcelerationValue() {
/* 41 */     return this.avalue;
/*    */   }
/*    */   public double getUpSpeedValue() {
/* 44 */     return this.rModifier;
/*    */   }
/*    */   public double getMaxHealth() {
/* 47 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 50 */     return this.permission;
/*    */   }
/*    */   public static BroomType valueOf(String paramString) {
/* 53 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.BROOM, paramString);
/* 54 */     if (vehicleSubType != null) {
/* 55 */       return (BroomType)vehicleSubType;
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 63 */     return 100;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 68 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 72 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\BroomType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */