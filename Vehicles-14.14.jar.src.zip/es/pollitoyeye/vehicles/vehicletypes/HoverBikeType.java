/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class HoverBikeType
/*     */   implements VehicleSubType
/*     */ {
/*     */   private double maxSpeed;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private ItemStack material1;
/*     */   private ItemStack material2;
/*     */   private ItemStack material3;
/*     */   private ItemStack material4;
/*     */   private ItemStack material5;
/*     */   private ItemStack material6;
/*     */   private ItemStack material7;
/*     */   private ItemStack carpetMaterial;
/*     */   private ItemStack spadeMaterial;
/*     */   private ItemStack hoeMaterial;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public HoverBikeType(double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, String paramString3, int paramInt, double paramDouble4, ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, ItemStack paramItemStack6, ItemStack paramItemStack7, ItemStack paramItemStack8, ItemStack paramItemStack9, ItemStack paramItemStack10, ItemStack paramItemStack11) {
/*  33 */     this.maxSpeed = paramDouble1;
/*  34 */     this.name = paramString1;
/*  35 */     this.displayName = paramString2;
/*  36 */     this.avalue = paramDouble2;
/*  37 */     this.mHealth = paramDouble3;
/*  38 */     this.permission = paramString3;
/*  39 */     this.fuelCapacity = paramInt;
/*  40 */     this.fuelWasteSpeed = paramDouble4;
/*  41 */     this.material1 = paramItemStack1;
/*  42 */     this.material2 = paramItemStack2;
/*  43 */     this.material3 = paramItemStack3;
/*  44 */     this.material4 = paramItemStack4;
/*  45 */     this.material5 = paramItemStack5;
/*  46 */     this.material6 = paramItemStack6;
/*  47 */     this.material7 = paramItemStack7;
/*  48 */     this.carpetMaterial = paramItemStack8;
/*  49 */     this.spadeMaterial = paramItemStack9;
/*  50 */     this.hoeMaterial = paramItemStack10;
/*  51 */     this.modelItem = paramItemStack11;
/*     */   }
/*     */   public double getMaxSpeed() {
/*  54 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  57 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  60 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  63 */     return this.name;
/*     */   }
/*     */   public double getAcelerationValue() {
/*  66 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/*  69 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  72 */     return this.permission;
/*     */   }
/*     */   public static HoverBikeType valueOf(String paramString) {
/*  75 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.HOVER_BIKE, paramString);
/*  76 */     if (vehicleSubType != null) {
/*  77 */       return (HoverBikeType)vehicleSubType;
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/*  84 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/*  88 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   public ItemStack getMaterial1() {
/*  91 */     return this.material1;
/*     */   }
/*     */   public ItemStack getMaterial2() {
/*  94 */     return this.material2;
/*     */   }
/*     */   public ItemStack getMaterial3() {
/*  97 */     return this.material3;
/*     */   }
/*     */   public ItemStack getMaterial4() {
/* 100 */     return this.material4;
/*     */   }
/*     */   public ItemStack getMaterial5() {
/* 103 */     return this.material5;
/*     */   }
/*     */   public ItemStack getMaterial6() {
/* 106 */     return this.material6;
/*     */   }
/*     */   public ItemStack getMaterial7() {
/* 109 */     return this.material7;
/*     */   }
/*     */   public ItemStack getCarpetMaterial() {
/* 112 */     return this.carpetMaterial;
/*     */   }
/*     */   public ItemStack getSpadeMaterial() {
/* 115 */     return this.spadeMaterial;
/*     */   }
/*     */   public ItemStack getHoeMaterial() {
/* 118 */     return this.hoeMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 122 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\HoverBikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */