/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TankType
/*     */   implements VehicleSubType
/*     */ {
/*     */   private double maxSpeed;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private ItemStack material;
/*     */   private ItemStack material2;
/*     */   private ItemStack firstChains;
/*     */   private ItemStack secondChains;
/*     */   private ItemStack thirdChains;
/*     */   private ItemStack holeMaterial;
/*     */   private double avalue;
/*     */   private float missilePower;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public TankType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, ItemStack paramItemStack6, double paramDouble1, String paramString1, String paramString2, double paramDouble2, float paramFloat, double paramDouble3, String paramString3, int paramInt, double paramDouble4, ItemStack paramItemStack7) {
/*  38 */     this.maxSpeed = paramDouble1;
/*  39 */     this.name = paramString1;
/*  40 */     this.displayName = paramString2;
/*  41 */     this.avalue = paramDouble2;
/*  42 */     this.material = paramItemStack1;
/*  43 */     this.material2 = paramItemStack2;
/*  44 */     this.firstChains = paramItemStack3;
/*  45 */     this.secondChains = paramItemStack4;
/*  46 */     this.thirdChains = paramItemStack5;
/*  47 */     this.holeMaterial = paramItemStack6;
/*  48 */     this.missilePower = paramFloat;
/*  49 */     this.mHealth = paramDouble3;
/*  50 */     this.permission = paramString3;
/*  51 */     this.fuelCapacity = paramInt;
/*  52 */     this.fuelWasteSpeed = paramDouble4;
/*  53 */     this.modelItem = paramItemStack7;
/*     */   }
/*     */   public double getMaxSpeed() {
/*  56 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  59 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  65 */     return this.name;
/*     */   }
/*     */   public ItemStack getMaterial() {
/*  68 */     return this.material.clone();
/*     */   }
/*     */   public ItemStack getMaterial2() {
/*  71 */     return this.material2.clone();
/*     */   }
/*     */   public ItemStack getFirstChains() {
/*  74 */     return this.firstChains.clone();
/*     */   }
/*     */   public ItemStack getSecondChains() {
/*  77 */     return this.secondChains.clone();
/*     */   }
/*     */   public ItemStack getThirdChains() {
/*  80 */     return this.thirdChains.clone();
/*     */   }
/*     */   public ItemStack getHoleMaterial() {
/*  83 */     return this.holeMaterial.clone();
/*     */   }
/*     */   public double getAcelerationValue() {
/*  86 */     return this.avalue;
/*     */   }
/*     */   public float getMissilePower() {
/*  89 */     return this.missilePower;
/*     */   }
/*     */   public double getMaxHealth() {
/*  92 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  95 */     return this.permission;
/*     */   }
/*     */   public static TankType valueOf(String paramString) {
/*  98 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.TANK, paramString);
/*  99 */     if (vehicleSubType != null) {
/* 100 */       return (TankType)vehicleSubType;
/*     */     }
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/* 107 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/* 111 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 115 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\TankType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */