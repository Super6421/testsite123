/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class RacingCarType
/*     */   implements VehicleSubType {
/*     */   private double maxSpeed;
/*     */   private double maxBackwardsSpeed;
/*     */   private ItemStack material;
/*     */   private ItemStack wheelMaterial;
/*     */   private ItemStack glassMaterial;
/*     */   private ItemStack wingMaterial;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public RacingCarType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, double paramDouble1, double paramDouble2, String paramString1, String paramString2, double paramDouble3, double paramDouble4, String paramString3, int paramInt, double paramDouble5, ItemStack paramItemStack5) {
/*  26 */     this.maxSpeed = paramDouble1;
/*  27 */     this.material = paramItemStack1;
/*  28 */     this.name = paramString1;
/*  29 */     this.displayName = paramString2;
/*  30 */     this.wheelMaterial = paramItemStack2;
/*  31 */     this.glassMaterial = paramItemStack3;
/*  32 */     this.wingMaterial = paramItemStack4;
/*  33 */     this.avalue = paramDouble3;
/*  34 */     this.mHealth = paramDouble4;
/*  35 */     this.permission = paramString3;
/*  36 */     this.fuelCapacity = paramInt;
/*  37 */     this.fuelWasteSpeed = paramDouble5;
/*  38 */     this.maxBackwardsSpeed = paramDouble2;
/*  39 */     this.modelItem = paramItemStack5;
/*     */   }
/*     */   public ItemStack getMaterial() {
/*  42 */     return this.material.clone();
/*     */   }
/*     */   public double getMaxSpeed() {
/*  45 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  48 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  51 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  54 */     return this.name;
/*     */   }
/*     */   public ItemStack getWheelMaterial() {
/*  57 */     return this.wheelMaterial.clone();
/*     */   }
/*     */   public double getAcelerationValue() {
/*  60 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/*  63 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  66 */     return this.permission;
/*     */   }
/*     */   public static RacingCarType valueOf(String paramString) {
/*  69 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.RACING_CAR, paramString);
/*  70 */     if (vehicleSubType != null) {
/*  71 */       return (RacingCarType)vehicleSubType;
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/*  78 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/*  82 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   public ItemStack getGlassMaterial() {
/*  85 */     return this.glassMaterial;
/*     */   }
/*     */   public void setGlassMaterial(ItemStack paramItemStack) {
/*  88 */     this.glassMaterial = paramItemStack;
/*     */   }
/*     */   public ItemStack getWingMaterial() {
/*  91 */     return this.wingMaterial;
/*     */   }
/*     */   public void setWingMaterial(ItemStack paramItemStack) {
/*  94 */     this.wingMaterial = paramItemStack;
/*     */   }
/*     */   public double getMaxBackwardsSpeed() {
/*  97 */     return this.maxBackwardsSpeed;
/*     */   }
/*     */   public void setMaxBackwardsSpeed(double paramDouble) {
/* 100 */     this.maxBackwardsSpeed = paramDouble;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 104 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\RacingCarType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */