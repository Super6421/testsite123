/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class RaftType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack banner;
/*    */   private double avalue;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public RaftType(ItemStack paramItemStack1, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, String paramString3, ItemStack paramItemStack2) {
/* 19 */     this.maxSpeed = paramDouble1;
/* 20 */     this.name = paramString1;
/* 21 */     this.displayName = paramString2;
/* 22 */     this.avalue = paramDouble2;
/* 23 */     this.banner = paramItemStack1;
/* 24 */     this.mHealth = paramDouble3;
/* 25 */     this.permission = paramString3;
/* 26 */     this.modelItem = paramItemStack2;
/*    */   }
/*    */   public double getMaxSpeed() {
/* 29 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 32 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 38 */     return this.name;
/*    */   }
/*    */   public ItemStack getSailMaterial() {
/* 41 */     return this.banner;
/*    */   }
/*    */   public double getAcelerationValue() {
/* 44 */     return this.avalue;
/*    */   }
/*    */   public double getMaxHealth() {
/* 47 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 50 */     return this.permission;
/*    */   }
/*    */   public static RaftType valueOf(String paramString) {
/* 53 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.RAFT, paramString);
/* 54 */     if (vehicleSubType != null) {
/* 55 */       return (RaftType)vehicleSubType;
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 63 */     return 100;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 68 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 72 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\RaftType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */