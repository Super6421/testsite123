/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class CarType implements VehicleSubType {
/*     */   private double maxSpeed;
/*     */   private double maxBackwardsSpeed;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private ItemStack material;
/*     */   private ItemStack wheelMaterial;
/*     */   private ItemStack frontLights;
/*     */   private ItemStack backLights;
/*     */   private ItemStack steelMaterial;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public CarType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, double paramDouble1, double paramDouble2, String paramString1, String paramString2, double paramDouble3, double paramDouble4, String paramString3, int paramInt, double paramDouble5, ItemStack paramItemStack6) {
/*  26 */     this.maxSpeed = paramDouble1;
/*  27 */     this.maxBackwardsSpeed = paramDouble2;
/*  28 */     this.material = paramItemStack1;
/*  29 */     this.name = paramString1;
/*  30 */     this.displayName = paramString2;
/*  31 */     this.wheelMaterial = paramItemStack2;
/*  32 */     this.avalue = paramDouble3;
/*  33 */     this.frontLights = paramItemStack3;
/*  34 */     this.backLights = paramItemStack4;
/*  35 */     this.steelMaterial = paramItemStack5;
/*  36 */     this.mHealth = paramDouble4;
/*  37 */     this.permission = paramString3;
/*  38 */     this.fuelCapacity = paramInt;
/*  39 */     this.fuelWasteSpeed = paramDouble5;
/*  40 */     this.modelItem = paramItemStack6;
/*     */   }
/*     */   public ItemStack getMaterial() {
/*  43 */     return this.material.clone();
/*     */   }
/*     */   public double getMaxSpeed() {
/*  46 */     return this.maxSpeed;
/*     */   }
/*     */   public double getMaxBackwardsSpeed() {
/*  49 */     return this.maxBackwardsSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/*  52 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/*  55 */     return this.name;
/*     */   }
/*     */   public String toString() {
/*  58 */     return this.name;
/*     */   }
/*     */   public ItemStack getBackLightsMaterial() {
/*  61 */     return this.backLights;
/*     */   }
/*     */   public ItemStack getFrontLightsMaterial() {
/*  64 */     return this.frontLights;
/*     */   }
/*     */   public ItemStack getSteelMaterial() {
/*  67 */     return this.steelMaterial;
/*     */   }
/*     */   public ItemStack getWheelsMaterial() {
/*  70 */     return this.wheelMaterial.clone();
/*     */   }
/*     */   public double getAcelerationValue() {
/*  73 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/*  76 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/*  79 */     return this.permission;
/*     */   }
/*     */   public static CarType valueOf(String paramString) {
/*  82 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.CAR, paramString);
/*  83 */     if (vehicleSubType != null) {
/*  84 */       return (CarType)vehicleSubType;
/*     */     }
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/*  92 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/*  96 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 100 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\CarType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */