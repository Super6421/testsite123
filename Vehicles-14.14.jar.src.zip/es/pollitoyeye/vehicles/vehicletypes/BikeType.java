/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class BikeType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private ItemStack material;
/*    */   private ItemStack wheelMaterial;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack seatMaterial;
/*    */   private double avalue;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private int fuelCapacity;
/*    */   private double fuelWasteSpeed;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public BikeType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, String paramString3, int paramInt, double paramDouble4, ItemStack paramItemStack4) {
/* 23 */     this.maxSpeed = paramDouble1;
/* 24 */     this.material = paramItemStack1;
/* 25 */     this.name = paramString1;
/* 26 */     this.displayName = paramString2;
/* 27 */     this.wheelMaterial = paramItemStack2;
/* 28 */     this.seatMaterial = paramItemStack3;
/* 29 */     this.avalue = paramDouble2;
/* 30 */     this.mHealth = paramDouble3;
/* 31 */     this.permission = paramString3;
/* 32 */     this.fuelCapacity = paramInt;
/* 33 */     this.fuelWasteSpeed = paramDouble4;
/* 34 */     this.modelItem = paramItemStack4;
/*    */   }
/*    */   public ItemStack getMaterial() {
/* 37 */     return this.material.clone();
/*    */   }
/*    */   public double getMaxSpeed() {
/* 40 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 43 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 46 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 49 */     return this.name;
/*    */   }
/*    */   public ItemStack getWheelMaterial() {
/* 52 */     return this.wheelMaterial.clone();
/*    */   }
/*    */   public ItemStack getSeatMaterial() {
/* 55 */     return this.seatMaterial.clone();
/*    */   }
/*    */   public double getAcelerationValue() {
/* 58 */     return this.avalue;
/*    */   }
/*    */   public double getMaxHealth() {
/* 61 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 64 */     return this.permission;
/*    */   }
/*    */   public static BikeType valueOf(String paramString) {
/* 67 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.BIKE, paramString);
/* 68 */     if (vehicleSubType != null) {
/* 69 */       return (BikeType)vehicleSubType;
/*    */     }
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 76 */     return this.fuelCapacity;
/*    */   }
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 80 */     return this.fuelWasteSpeed;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 84 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\BikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */