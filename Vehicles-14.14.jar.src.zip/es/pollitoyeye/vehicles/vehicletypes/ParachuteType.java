/*    */ package es.pollitoyeye.vehicles.vehicletypes;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class ParachuteType implements VehicleSubType {
/*    */   private double maxSpeed;
/*    */   private String name;
/*    */   private String displayName;
/*    */   private ItemStack banner1Material;
/*    */   private ItemStack banner2Material;
/*    */   private double avalue;
/*    */   private double mHealth;
/*    */   private String permission;
/*    */   private ItemStack modelItem;
/*    */   
/*    */   public ParachuteType(ItemStack paramItemStack1, ItemStack paramItemStack2, double paramDouble1, String paramString1, String paramString2, double paramDouble2, double paramDouble3, String paramString3, ItemStack paramItemStack3) {
/* 20 */     this.maxSpeed = paramDouble1;
/* 21 */     this.banner1Material = paramItemStack1;
/* 22 */     this.banner2Material = paramItemStack2;
/* 23 */     this.name = paramString1;
/* 24 */     this.displayName = paramString2;
/* 25 */     this.avalue = paramDouble2;
/* 26 */     this.mHealth = paramDouble3;
/* 27 */     this.permission = paramString3;
/* 28 */     this.modelItem = paramItemStack3;
/*    */   }
/*    */   public ItemStack getFirstBannerMaterial() {
/* 31 */     return this.banner1Material.clone();
/*    */   }
/*    */   public ItemStack getSecondBannerMaterial() {
/* 34 */     return this.banner2Material.clone();
/*    */   }
/*    */   public double getMaxSpeed() {
/* 37 */     return this.maxSpeed;
/*    */   }
/*    */   public String getDisplayName() {
/* 40 */     return this.displayName;
/*    */   }
/*    */   public String getName() {
/* 43 */     return this.name;
/*    */   }
/*    */   public String toString() {
/* 46 */     return this.name;
/*    */   }
/*    */   public double getAcelerationValue() {
/* 49 */     return this.avalue;
/*    */   }
/*    */   public double getMaxHealth() {
/* 52 */     return this.mHealth;
/*    */   }
/*    */   public String getPermission() {
/* 55 */     return this.permission;
/*    */   }
/*    */   public static ParachuteType valueOf(String paramString) {
/* 58 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.PARACHUTE, paramString);
/* 59 */     if (vehicleSubType != null) {
/* 60 */       return (ParachuteType)vehicleSubType;
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getFuelCapacity() {
/* 68 */     return 100;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getFuelWasteSpeed() {
/* 73 */     return 0.0D;
/*    */   }
/*    */   
/*    */   public ItemStack getModelItem() {
/* 77 */     return this.modelItem;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\ParachuteType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */