/*     */ package es.pollitoyeye.vehicles.vehicletypes;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MechaType
/*     */   implements VehicleSubType
/*     */ {
/*     */   private double maxSpeed;
/*     */   private double maxBackwardsSpeed;
/*     */   private ItemStack bodyMaterial1;
/*     */   private ItemStack bodyMaterial2;
/*     */   private ItemStack wheelMaterial1;
/*     */   private ItemStack wheelMaterial2;
/*     */   private ItemStack joinsMaterial;
/*     */   private ItemStack leftHandMaterial;
/*     */   private ItemStack seatMaterial;
/*     */   private ItemStack armsMaterial;
/*     */   private ItemStack gunMaterial1;
/*     */   private ItemStack gunMaterial2;
/*     */   private ItemStack headLampMaterial;
/*     */   private ItemStack shoulderMaterial;
/*     */   private ItemStack wheelJoinsMaterial1;
/*     */   private ItemStack wheelJoinsMaterial2;
/*     */   private String name;
/*     */   private String displayName;
/*     */   private double avalue;
/*     */   private double mHealth;
/*     */   private String permission;
/*     */   private int fuelCapacity;
/*     */   private double fuelWasteSpeed;
/*     */   private double thrustAcceleration;
/*     */   private double thrustTime;
/*     */   private double thrustRecoverSpeed;
/*     */   private boolean gunEnabled;
/*     */   private double gunRange;
/*     */   private double gunProjectileSpeed;
/*     */   private double gunDamage;
/*     */   private double gunFuelWaste;
/*     */   private Color gunColor;
/*     */   private double gunShootDelay;
/*     */   private boolean hookEnabled;
/*     */   private double hookRange;
/*     */   private double hookProjectileSpeed;
/*     */   private double hookShootDelay;
/*     */   private double hookDamage;
/*     */   private double hookFuelWaste;
/*     */   private ItemStack modelItem;
/*     */   
/*     */   public MechaType(ItemStack paramItemStack1, ItemStack paramItemStack2, ItemStack paramItemStack3, ItemStack paramItemStack4, ItemStack paramItemStack5, ItemStack paramItemStack6, ItemStack paramItemStack7, ItemStack paramItemStack8, ItemStack paramItemStack9, ItemStack paramItemStack10, ItemStack paramItemStack11, ItemStack paramItemStack12, ItemStack paramItemStack13, ItemStack paramItemStack14, double paramDouble1, double paramDouble2, String paramString1, String paramString2, double paramDouble3, double paramDouble4, String paramString3, int paramInt, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, boolean paramBoolean1, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, Color paramColor, double paramDouble13, boolean paramBoolean2, double paramDouble14, double paramDouble15, double paramDouble16, double paramDouble17, double paramDouble18, ItemStack paramItemStack15) {
/*  63 */     this.maxSpeed = paramDouble1;
/*  64 */     this.maxBackwardsSpeed = paramDouble2;
/*  65 */     this.bodyMaterial1 = paramItemStack1;
/*  66 */     this.bodyMaterial2 = paramItemStack2;
/*  67 */     this.wheelMaterial1 = paramItemStack3;
/*  68 */     this.wheelMaterial2 = paramItemStack4;
/*  69 */     this.joinsMaterial = paramItemStack5;
/*  70 */     this.leftHandMaterial = paramItemStack6;
/*  71 */     this.seatMaterial = paramItemStack7;
/*  72 */     this.armsMaterial = paramItemStack8;
/*  73 */     this.gunMaterial1 = paramItemStack9;
/*  74 */     this.gunMaterial2 = paramItemStack10;
/*  75 */     this.headLampMaterial = paramItemStack11;
/*  76 */     this.shoulderMaterial = paramItemStack12;
/*  77 */     this.wheelJoinsMaterial1 = paramItemStack13;
/*  78 */     this.wheelJoinsMaterial2 = paramItemStack14;
/*  79 */     this.name = paramString1;
/*  80 */     this.displayName = paramString2;
/*  81 */     this.avalue = paramDouble3;
/*  82 */     this.mHealth = paramDouble4;
/*  83 */     this.permission = paramString3;
/*  84 */     this.fuelCapacity = paramInt;
/*  85 */     this.fuelWasteSpeed = paramDouble5;
/*  86 */     this.thrustAcceleration = paramDouble6;
/*  87 */     this.thrustTime = paramDouble7;
/*  88 */     this.thrustRecoverSpeed = paramDouble8;
/*  89 */     this.gunEnabled = paramBoolean1;
/*  90 */     this.gunRange = paramDouble9;
/*  91 */     this.gunProjectileSpeed = paramDouble10;
/*  92 */     this.gunDamage = paramDouble11;
/*  93 */     this.gunFuelWaste = paramDouble12;
/*  94 */     this.gunColor = paramColor;
/*  95 */     this.gunShootDelay = paramDouble13;
/*  96 */     this.hookEnabled = paramBoolean2;
/*  97 */     this.hookRange = paramDouble14;
/*  98 */     this.hookProjectileSpeed = paramDouble15;
/*  99 */     this.hookShootDelay = paramDouble16;
/* 100 */     this.hookDamage = paramDouble17;
/* 101 */     this.hookFuelWaste = paramDouble18;
/* 102 */     this.modelItem = paramItemStack15;
/*     */   }
/*     */   
/*     */   public double getMaxSpeed() {
/* 106 */     return this.maxSpeed;
/*     */   }
/*     */   public String getDisplayName() {
/* 109 */     return this.displayName;
/*     */   }
/*     */   public String getName() {
/* 112 */     return this.name;
/*     */   }
/*     */   public String toString() {
/* 115 */     return this.name;
/*     */   }
/*     */   public double getAcelerationValue() {
/* 118 */     return this.avalue;
/*     */   }
/*     */   public double getMaxHealth() {
/* 121 */     return this.mHealth;
/*     */   }
/*     */   public String getPermission() {
/* 124 */     return this.permission;
/*     */   }
/*     */   public static MechaType valueOf(String paramString) {
/* 127 */     VehicleSubType vehicleSubType = VehiclesMain.getPlugin().vehicleSubTypeFromString(VehicleType.MECHA, paramString);
/* 128 */     if (vehicleSubType != null) {
/* 129 */       return (MechaType)vehicleSubType;
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFuelCapacity() {
/* 136 */     return this.fuelCapacity;
/*     */   }
/*     */   
/*     */   public double getFuelWasteSpeed() {
/* 140 */     return this.fuelWasteSpeed;
/*     */   }
/*     */   public double getMaxBackwardsSpeed() {
/* 143 */     return this.maxBackwardsSpeed;
/*     */   }
/*     */   public void setMaxBackwardsSpeed(double paramDouble) {
/* 146 */     this.maxBackwardsSpeed = paramDouble;
/*     */   }
/*     */   public double getThrustAcceleration() {
/* 149 */     return this.thrustAcceleration;
/*     */   }
/*     */   public double getThrustTime() {
/* 152 */     return this.thrustTime;
/*     */   }
/*     */   public double getThrustRecoverSpeed() {
/* 155 */     return this.thrustRecoverSpeed;
/*     */   }
/*     */   
/*     */   public ItemStack getBodyMaterial1() {
/* 159 */     return this.bodyMaterial1;
/*     */   }
/*     */   
/*     */   public ItemStack getBodyMaterial2() {
/* 163 */     return this.bodyMaterial2;
/*     */   }
/*     */   
/*     */   public ItemStack getWheelMaterial1() {
/* 167 */     return this.wheelMaterial1;
/*     */   }
/*     */   
/*     */   public ItemStack getWheelMaterial2() {
/* 171 */     return this.wheelMaterial2;
/*     */   }
/*     */   
/*     */   public ItemStack getJoinsMaterial() {
/* 175 */     return this.joinsMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getLeftHandMaterial() {
/* 179 */     return this.leftHandMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getSeatMaterial() {
/* 183 */     return this.seatMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getArmsMaterial() {
/* 187 */     return this.armsMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getGunMaterial1() {
/* 191 */     return this.gunMaterial1;
/*     */   }
/*     */   
/*     */   public ItemStack getGunMaterial2() {
/* 195 */     return this.gunMaterial2;
/*     */   }
/*     */   
/*     */   public ItemStack getHeadLampMaterial() {
/* 199 */     return this.headLampMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getShoulderMaterial() {
/* 203 */     return this.shoulderMaterial;
/*     */   }
/*     */   
/*     */   public ItemStack getWheelJoinsMaterial1() {
/* 207 */     return this.wheelJoinsMaterial1;
/*     */   }
/*     */   
/*     */   public ItemStack getWheelJoinsMaterial2() {
/* 211 */     return this.wheelJoinsMaterial2;
/*     */   }
/*     */   
/*     */   public boolean isGunEnabled() {
/* 215 */     return this.gunEnabled;
/*     */   }
/*     */   
/*     */   public double getGunRange() {
/* 219 */     return this.gunRange;
/*     */   }
/*     */   
/*     */   public double getGunProjectileSpeed() {
/* 223 */     return this.gunProjectileSpeed;
/*     */   }
/*     */   
/*     */   public double getGunDamage() {
/* 227 */     return this.gunDamage;
/*     */   }
/*     */   
/*     */   public double getGunFuelWaste() {
/* 231 */     return this.gunFuelWaste;
/*     */   }
/*     */   
/*     */   public Color getGunColor() {
/* 235 */     return this.gunColor;
/*     */   }
/*     */   
/*     */   public double getGunShootDelay() {
/* 239 */     return this.gunShootDelay;
/*     */   }
/*     */   
/*     */   public boolean isHookEnabled() {
/* 243 */     return this.hookEnabled;
/*     */   }
/*     */   
/*     */   public double getHookRange() {
/* 247 */     return this.hookRange;
/*     */   }
/*     */   
/*     */   public double getHookProjectileSpeed() {
/* 251 */     return this.hookProjectileSpeed;
/*     */   }
/*     */   
/*     */   public double getHookShootDelay() {
/* 255 */     return this.hookShootDelay;
/*     */   }
/*     */   
/*     */   public double getHookDamage() {
/* 259 */     return this.hookDamage;
/*     */   }
/*     */   
/*     */   public double getHookFuelWaste() {
/* 263 */     return this.hookFuelWaste;
/*     */   }
/*     */   
/*     */   public ItemStack getModelItem() {
/* 267 */     return this.modelItem;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehicletypes\MechaType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */