/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NbtApiException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -993309714559452334L;
/* 23 */   public static Boolean confirmedBroken = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NbtApiException() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NbtApiException(String paramString, Throwable paramThrowable) {
/* 37 */     super(generateMessage(paramString), paramThrowable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NbtApiException(String paramString) {
/* 44 */     super(generateMessage(paramString));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NbtApiException(Throwable paramThrowable) {
/* 51 */     super(generateMessage((paramThrowable == null) ? null : paramThrowable.toString()), paramThrowable);
/*    */   }
/*    */   
/*    */   private static String generateMessage(String paramString) {
/* 55 */     if (paramString == null)
/* 56 */       return null; 
/* 57 */     if (confirmedBroken == null)
/* 58 */       return "[?][" + MinecraftVersion.getNBTAPIVersion() + "]" + paramString; 
/* 59 */     if (!confirmedBroken.booleanValue()) {
/* 60 */       return "[Selfchecked][" + MinecraftVersion.getNBTAPIVersion() + "]" + paramString;
/*    */     }
/*    */     
/* 63 */     return "[" + MinecraftVersion.getVersion() + "][" + MinecraftVersion.getNBTAPIVersion() + "]There were errors detected during the server self-check! Please, make sure that NBT-API is up to date. Error message: " + paramString;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NbtApiException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */