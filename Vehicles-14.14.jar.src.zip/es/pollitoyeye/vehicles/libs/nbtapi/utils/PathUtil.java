/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public final class PathUtil
/*    */ {
/* 10 */   private static final Pattern pattern = Pattern.compile("[^\\\\](\\.)");
/* 11 */   private static final Pattern indexPattern = Pattern.compile(".*\\[(-?[0-9]+)\\]");
/*    */   
/*    */   public static List<PathSegment> splitPath(String paramString) {
/* 14 */     ArrayList<PathSegment> arrayList = new ArrayList();
/* 15 */     Matcher matcher = pattern.matcher(paramString);
/* 16 */     int i = 0;
/* 17 */     while (matcher.find(i)) {
/* 18 */       arrayList.add(new PathSegment(paramString.substring(i, matcher.end() - 1).replace("\\.", ".")));
/* 19 */       i = matcher.end();
/*    */     } 
/* 21 */     arrayList.add(new PathSegment(paramString.substring(i).replace("\\.", ".")));
/* 22 */     return arrayList;
/*    */   }
/*    */   
/*    */   public static class PathSegment
/*    */   {
/*    */     private final String path;
/*    */     private final Integer index;
/*    */     
/*    */     private PathSegment(String param1String) {
/* 31 */       Matcher matcher = PathUtil.indexPattern.matcher(param1String);
/* 32 */       if (matcher.find()) {
/* 33 */         this.path = param1String.substring(0, param1String.indexOf("["));
/* 34 */         this.index = Integer.valueOf(Integer.parseInt(matcher.group(1)));
/*    */       } else {
/* 36 */         this.path = param1String;
/* 37 */         this.index = null;
/*    */       } 
/*    */     }
/*    */     
/*    */     public String getPath() {
/* 42 */       return this.path;
/*    */     }
/*    */     
/*    */     public int getIndex() {
/* 46 */       return this.index.intValue();
/*    */     }
/*    */     
/*    */     public boolean hasIndex() {
/* 50 */       return (this.index != null);
/*    */     }
/*    */ 
/*    */     
/*    */     public String toString() {
/* 55 */       return "PathSegment [path=" + this.path + ", index=" + this.index + "]";
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\PathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */