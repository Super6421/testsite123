/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckUtil
/*    */ {
/*    */   public static void assertAvailable(MinecraftVersion paramMinecraftVersion) {
/* 12 */     if (!MinecraftVersion.isAtLeastVersion(paramMinecraftVersion))
/* 13 */       throw new NbtApiException("This Method is only avaliable for the version " + paramMinecraftVersion
/* 14 */           .name() + " and above!"); 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\CheckUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */