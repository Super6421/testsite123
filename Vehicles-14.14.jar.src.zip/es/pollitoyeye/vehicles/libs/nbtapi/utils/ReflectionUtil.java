/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.MojangToMapping;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ 
/*    */ public final class ReflectionUtil
/*    */ {
/*    */   public static Field getMappedField(Class<?> paramClass, String paramString) {
/* 11 */     String str = paramString.split("#")[1];
/*    */     try {
/* 13 */       return paramClass.getField(str);
/* 14 */     } catch (NoSuchFieldException|SecurityException noSuchFieldException) {
/*    */ 
/*    */       
/*    */       try {
/* 18 */         return paramClass.getDeclaredField((String)MojangToMapping.getMapping().get(paramString));
/* 19 */       } catch (Exception exception) {
/* 20 */         throw new NbtApiException("Unable to find field " + paramString + " in class " + paramClass.getName(), exception);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\ReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */