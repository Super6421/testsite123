/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DataResult;
/*    */ import com.mojang.serialization.DynamicOps;
/*    */ import com.mojang.serialization.JsonOps;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.MojangToMapping;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.util.Optional;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTJsonUtil
/*    */ {
/*    */   public static JsonElement itemStackToJson(ItemStack paramItemStack) {
/*    */     try {
/* 30 */       Codec codec = (Codec)ClassWrapper.NMS_ITEMSTACK.getClazz().getField((String)MojangToMapping.getMapping().get("net.minecraft.world.item.ItemStack#CODEC")).get(null);
/* 31 */       Object object = ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { paramItemStack });
/* 32 */       DataResult dataResult = codec.encode(object, (DynamicOps)JsonOps.INSTANCE, JsonOps.INSTANCE
/* 33 */           .emptyMap());
/* 34 */       Optional<JsonElement> optional = (Optional)dataResult.getClass().getMethod("result", new Class[0]).invoke(dataResult, new Object[0]);
/* 35 */       return optional.orElse(null);
/* 36 */     } catch (Exception exception) {
/* 37 */       throw new NbtApiException("Error trying to get Json of an ItemStack.", exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\NBTJsonUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */