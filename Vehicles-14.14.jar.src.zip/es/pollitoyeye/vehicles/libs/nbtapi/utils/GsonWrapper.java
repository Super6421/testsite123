/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class GsonWrapper
/*    */ {
/* 26 */   private static Gson gson = new Gson();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getString(Object paramObject) {
/* 35 */     return gson.toJson(paramObject);
/*    */   }
/*    */   
/*    */   public static void overwriteGsonInstance(Gson paramGson) {
/* 39 */     gson = paramGson;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T deserializeJson(String paramString, Class<T> paramClass) {
/*    */     try {
/* 51 */       if (paramString == null) {
/* 52 */         return null;
/*    */       }
/*    */       
/* 55 */       Object object = gson.fromJson(paramString, paramClass);
/* 56 */       return paramClass.cast(object);
/* 57 */     } catch (Exception exception) {
/* 58 */       throw new NbtApiException("Error while converting json to " + paramClass.getName(), exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\GsonWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */