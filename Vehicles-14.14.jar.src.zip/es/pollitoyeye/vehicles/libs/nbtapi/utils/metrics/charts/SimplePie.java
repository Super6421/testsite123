/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.json.JsonObjectBuilder;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimplePie
/*    */   extends CustomChart
/*    */ {
/*    */   private final Callable<String> callable;
/*    */   
/*    */   public SimplePie(String paramString, Callable<String> paramCallable) {
/* 18 */     super(paramString);
/* 19 */     this.callable = paramCallable;
/*    */   }
/*    */ 
/*    */   
/*    */   protected JsonObjectBuilder.JsonObject getChartData() {
/* 24 */     String str = this.callable.call();
/* 25 */     if (str == null || str.isEmpty())
/*    */     {
/* 27 */       return null;
/*    */     }
/* 29 */     return (new JsonObjectBuilder())
/* 30 */       .appendField("value", str)
/* 31 */       .build();
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\metrics\charts\SimplePie.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */