/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.json.JsonObjectBuilder;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleLineChart
/*    */   extends CustomChart
/*    */ {
/*    */   private final Callable<Integer> callable;
/*    */   
/*    */   public SingleLineChart(String paramString, Callable<Integer> paramCallable) {
/* 18 */     super(paramString);
/* 19 */     this.callable = paramCallable;
/*    */   }
/*    */ 
/*    */   
/*    */   protected JsonObjectBuilder.JsonObject getChartData() {
/* 24 */     int i = ((Integer)this.callable.call()).intValue();
/* 25 */     if (i == 0)
/*    */     {
/* 27 */       return null;
/*    */     }
/* 29 */     return (new JsonObjectBuilder())
/* 30 */       .appendField("value", i)
/* 31 */       .build();
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\metrics\charts\SingleLineChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */