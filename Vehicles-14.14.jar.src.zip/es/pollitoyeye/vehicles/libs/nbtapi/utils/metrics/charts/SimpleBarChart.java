/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.json.JsonObjectBuilder;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleBarChart
/*    */   extends CustomChart
/*    */ {
/*    */   private final Callable<Map<String, Integer>> callable;
/*    */   
/*    */   public SimpleBarChart(String paramString, Callable<Map<String, Integer>> paramCallable) {
/* 19 */     super(paramString);
/* 20 */     this.callable = paramCallable;
/*    */   }
/*    */ 
/*    */   
/*    */   protected JsonObjectBuilder.JsonObject getChartData() {
/* 25 */     JsonObjectBuilder jsonObjectBuilder = new JsonObjectBuilder();
/*    */     
/* 27 */     Map map = this.callable.call();
/* 28 */     if (map == null || map.isEmpty())
/*    */     {
/* 30 */       return null;
/*    */     }
/* 32 */     for (Map.Entry entry : map.entrySet()) {
/* 33 */       jsonObjectBuilder.appendField((String)entry.getKey(), new int[] { ((Integer)entry.getValue()).intValue() });
/*    */     } 
/*    */     
/* 36 */     return (new JsonObjectBuilder())
/* 37 */       .appendField("values", jsonObjectBuilder.build())
/* 38 */       .build();
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\metrics\charts\SimpleBarChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */