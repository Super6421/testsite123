/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.json.JsonObjectBuilder;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdvancedBarChart
/*    */   extends CustomChart
/*    */ {
/*    */   private final Callable<Map<String, int[]>> callable;
/*    */   
/*    */   public AdvancedBarChart(String paramString, Callable<Map<String, int[]>> paramCallable) {
/* 19 */     super(paramString);
/* 20 */     this.callable = paramCallable;
/*    */   }
/*    */ 
/*    */   
/*    */   protected JsonObjectBuilder.JsonObject getChartData() {
/* 25 */     JsonObjectBuilder jsonObjectBuilder = new JsonObjectBuilder();
/* 26 */     Map map = this.callable.call();
/* 27 */     if (map == null || map.isEmpty())
/*    */     {
/* 29 */       return null;
/*    */     }
/* 31 */     boolean bool = true;
/* 32 */     for (Map.Entry entry : map.entrySet()) {
/* 33 */       if (((int[])entry.getValue()).length == 0) {
/*    */         continue;
/*    */       }
/* 36 */       bool = false;
/* 37 */       jsonObjectBuilder.appendField((String)entry.getKey(), (int[])entry.getValue());
/*    */     } 
/* 39 */     if (bool)
/*    */     {
/* 41 */       return null;
/*    */     }
/*    */     
/* 44 */     return (new JsonObjectBuilder())
/* 45 */       .appendField("values", jsonObjectBuilder.build())
/* 46 */       .build();
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\metrics\charts\AdvancedBarChart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */