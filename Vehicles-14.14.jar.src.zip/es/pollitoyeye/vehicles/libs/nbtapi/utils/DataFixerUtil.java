/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*     */ 
/*     */ import com.mojang.datafixers.DSL;
/*     */ import com.mojang.datafixers.DataFixer;
/*     */ import com.mojang.serialization.Dynamic;
/*     */ import com.mojang.serialization.DynamicOps;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTCompound;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTReflectionUtil;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFixerUtil
/*     */ {
/*     */   public static final int VERSION1_12R1 = 1343;
/*     */   public static final int VERSION1_16R1 = 2586;
/*     */   public static final int VERSION1_17R1 = 2730;
/*     */   public static final int VERSION1_18R1 = 2975;
/*     */   public static final int VERSION1_19R1 = 3120;
/*     */   public static final int VERSION1_19R3 = 3337;
/*     */   public static final int VERSION1_20R1 = 3465;
/*     */   public static final int VERSION1_20R2 = 3578;
/*     */   public static final int VERSION1_20R3 = 3700;
/*     */   public static final int VERSION1_20R4 = 3837;
/*     */   public static final int VERSION1_21R1 = 3953;
/*     */   public static final int VERSION1_21R2 = 4080;
/*     */   public static final int VERSION1_21R3 = 4189;
/*     */   public static final int VERSION1_21R4 = 4323;
/*     */   public static final int VERSION1_21R5 = 4435;
/*     */   public static final int VERSION1_21R6 = 4554;
/*     */   public static final int VERSION1_21R7 = 4671;
/*     */   public static final int VERSION_26_1 = 4786;
/*     */   @Deprecated
/*     */   public static final int VERSION1_12_2 = 1343;
/*     */   @Deprecated
/*     */   public static final int VERSION1_16_5 = 2586;
/*     */   @Deprecated
/*     */   public static final int VERSION1_17_1 = 2730;
/*     */   @Deprecated
/*     */   public static final int VERSION1_18_2 = 2975;
/*     */   @Deprecated
/*     */   public static final int VERSION1_19_2 = 3120;
/*     */   @Deprecated
/*     */   public static final int VERSION1_19_4 = 3337;
/*     */   @Deprecated
/*     */   public static final int VERSION1_20_1 = 3465;
/*     */   @Deprecated
/*     */   public static final int VERSION1_20_2 = 3578;
/*     */   @Deprecated
/*     */   public static final int VERSION1_20_4 = 3700;
/*     */   @Deprecated
/*     */   public static final int VERSION1_20_5 = 3837;
/*     */   @Deprecated
/*     */   public static final int VERSION1_21 = 3953;
/*     */   @Deprecated
/*     */   public static final int VERSION1_21_2 = 4080;
/*     */   @Deprecated
/*     */   public static final int VERSION1_21_3 = 4189;
/*     */   @Deprecated
/*     */   public static final int VERSION1_21_4 = 4323;
/*     */   @Deprecated
/*     */   public static final int VERSION1_21_5 = 4435;
/*     */   
/*     */   public static Object fixUpRawItemData(Object paramObject, int paramInt1, int paramInt2) {
/*  73 */     DataFixer dataFixer = (DataFixer)ReflectionMethod.GET_DATAFIXER.run(null, new Object[0]);
/*  74 */     DSL.TypeReference typeReference = (DSL.TypeReference)ReflectionUtil.getMappedField(ClassWrapper.NMS_REFERENCES.getClazz(), "net.minecraft.util.datafix.fixes.References#ITEM_STACK").get(null);
/*  75 */     DynamicOps dynamicOps = (DynamicOps)ReflectionUtil.getMappedField(ClassWrapper.NMS_NBTOPS.getClazz(), "net.minecraft.nbt.NbtOps#INSTANCE").get(null);
/*  76 */     Dynamic dynamic = dataFixer.update(typeReference, new Dynamic(dynamicOps, paramObject), paramInt1, paramInt2);
/*     */     
/*  78 */     return dynamic.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT fixUpItemData(ReadWriteNBT paramReadWriteNBT, int paramInt1, int paramInt2) {
/*  83 */     ReadWriteNBT readWriteNBT = NBT.wrapNMSTag(fixUpRawItemData(
/*  84 */           NBTReflectionUtil.getToCompount(((NBTCompound)paramReadWriteNBT).getCompound(), (NBTCompound)paramReadWriteNBT), paramInt1, paramInt2));
/*     */     
/*  86 */     readWriteNBT.setInteger("DataVersion", Integer.valueOf(paramInt2));
/*  87 */     return readWriteNBT;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT fixUpItemData(ReadWriteNBT paramReadWriteNBT, int paramInt) {
/*  92 */     return fixUpItemData(paramReadWriteNBT, paramInt, getCurrentVersion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getCurrentVersion() {
/* 105 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC26_1))
/* 106 */       return 4786; 
/* 107 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R7))
/* 108 */       return 4671; 
/* 109 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6))
/* 110 */       return 4554; 
/* 111 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5))
/* 112 */       return 4435; 
/* 113 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4))
/* 114 */       return 4323; 
/* 115 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R3))
/* 116 */       return 4189; 
/* 117 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R2))
/* 118 */       return 4080; 
/* 119 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R1))
/* 120 */       return 3953; 
/* 121 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4))
/* 122 */       return 3837; 
/* 123 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R3))
/* 124 */       return 3700; 
/* 125 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R1))
/* 126 */       return 3465; 
/* 127 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_19_R3))
/* 128 */       return 3337; 
/* 129 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_19_R1))
/* 130 */       return 3120; 
/* 131 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_18_R1))
/* 132 */       return 2975; 
/* 133 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_17_R1))
/* 134 */       return 2730; 
/* 135 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_16_R1))
/* 136 */       return 2586; 
/* 137 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_12_R1)) {
/* 138 */       return 1343;
/*     */     }
/* 140 */     throw new NbtApiException("Trying to update data *to* a version before 1.12.2? Something is probably going wrong, contact the plugin author.");
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\DataFixerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */