/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.logging.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ObjectCreator
/*    */ {
/* 19 */   NMS_NBTTAGCOMPOUND(null, null, ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz(), new Class[0]),
/* 20 */   NMS_CUSTOMDATA(MinecraftVersion.MC1_20_R4, null, ClassWrapper.NMS_CUSTOMDATA.getClazz(), new Class[] { ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz() }),
/* 21 */   NMS_BLOCKPOSITION(null, null, ClassWrapper.NMS_BLOCKPOSITION.getClazz(), new Class[] { int.class, int.class, int.class }),
/* 22 */   NMS_COMPOUNDFROMITEM(MinecraftVersion.MC1_11_R1, MinecraftVersion.MC1_20_R3, ClassWrapper.NMS_ITEMSTACK.getClazz(), new Class[] { ClassWrapper.NMS_NBTTAGCOMPOUND
/* 23 */       .getClazz() });
/*    */   
/*    */   private Constructor<?> construct;
/*    */   private Class<?> targetClass;
/*    */   
/*    */   ObjectCreator(MinecraftVersion paramMinecraftVersion1, MinecraftVersion paramMinecraftVersion2, Class<?> paramClass, Class<?>... paramVarArgs) {
/* 29 */     if (paramClass == null)
/*    */       return; 
/* 31 */     if (paramMinecraftVersion1 != null && MinecraftVersion.getVersion().getVersionId() < paramMinecraftVersion1.getVersionId())
/*    */       return; 
/* 33 */     if (paramMinecraftVersion2 != null && MinecraftVersion.getVersion().getVersionId() > paramMinecraftVersion2.getVersionId())
/*    */       return; 
/*    */     try {
/* 36 */       this.targetClass = paramClass;
/* 37 */       this.construct = paramClass.getDeclaredConstructor(paramVarArgs);
/* 38 */       this.construct.setAccessible(true);
/* 39 */     } catch (Exception exception) {
/* 40 */       MinecraftVersion.getLogger().log(Level.SEVERE, "Unable to find the constructor for the class '" + paramClass.getName() + "'", exception);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getInstance(Object... paramVarArgs) {
/*    */     try {
/* 52 */       return this.construct.newInstance(paramVarArgs);
/* 53 */     } catch (Exception exception) {
/* 54 */       throw new NbtApiException("Exception while creating a new instance of '" + this.targetClass + "'", exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\nmsmappings\ObjectCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */