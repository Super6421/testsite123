/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings;
/*    */ 
/*    */ import com.mojang.serialization.DataResult;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTReflectionUtil;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ import java.util.Objects;
/*    */ import java.util.Optional;
/*    */ 
/*    */ public class CodecHelper
/*    */ {
/*    */   public static Object convertItemStackToNbt(Object paramObject) {
/* 12 */     DataResult dataResult = null;
/*    */     
/*    */     try {
/* 15 */       dataResult = NBTReflectionUtil.itemstack_codec.encodeStart(NBTReflectionUtil.nbtRegistryOps, paramObject);
/* 16 */       Objects.requireNonNull(dataResult);
/* 17 */       return ((Optional)dataResult.getClass().getMethod("result", new Class[0]).invoke(dataResult, new Object[0])).get();
/* 18 */     } catch (Exception exception) {
/* 19 */       throw new NbtApiException("Failed to convert ItemStack to NBT. " + dataResult + " " + paramObject, exception);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Object convertNbtToItemStack(Object paramObject) {
/* 24 */     DataResult dataResult = null;
/*    */     
/*    */     try {
/* 27 */       dataResult = NBTReflectionUtil.itemstack_codec.parse(NBTReflectionUtil.nbtRegistryOps, paramObject);
/* 28 */       Objects.requireNonNull(dataResult);
/* 29 */       return ((Optional)dataResult.getClass().getMethod("result", new Class[0]).invoke(dataResult, new Object[0])).get();
/* 30 */     } catch (Exception exception) {
/* 31 */       throw new NbtApiException("Failed to convert NBT to ItemStack. " + dataResult + " " + paramObject, exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\nmsmappings\CodecHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */