/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MojangToMapping
/*     */ {
/*  20 */   private static Map<String, String> MC1_18R1 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static Map<String, String> MC1_18R2 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static Map<String, String> MC1_19R1 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static Map<String, String> MC1_19R2 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private static Map<String, String> MC1_20R1 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   private static Map<String, String> MC1_20R2 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private static Map<String, String> MC1_20R3 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   private static Map<String, String> MC1_20R4 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   private static Map<String, String> MC1_21R1 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private static Map<String, String> MC1_21R2 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   private static Map<String, String> MC1_21R3 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   private static Map<String, String> MC1_21R4 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   private static Map<String, String> MC1_21R5 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   private static Map<String, String> MC1_21R6 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   private static Map<String, String> MC1_21R7 = new HashMap<String, String>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, String> getMapping() {
/* 323 */     if (MinecraftVersion.getVersion() != MinecraftVersion.UNKNOWN) { MinecraftVersion.getVersion(); if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC26_1))
/* 324 */         return Collections.EMPTY_MAP;  }
/*     */     
/* 326 */     switch (MinecraftVersion.getVersion()) {
/*     */       case MC1_21_R7:
/* 328 */         return MC1_21R7;
/*     */       case MC1_21_R6:
/* 330 */         return MC1_21R6;
/*     */       case MC1_21_R5:
/* 332 */         return MC1_21R5;
/*     */       case MC1_21_R4:
/* 334 */         return MC1_21R4;
/*     */       case MC1_21_R3:
/* 336 */         return MC1_21R3;
/*     */       case MC1_21_R2:
/* 338 */         return MC1_21R2;
/*     */       case MC1_21_R1:
/* 340 */         return MC1_21R1;
/*     */       case MC1_20_R4:
/* 342 */         return MC1_20R4;
/*     */       case MC1_20_R3:
/* 344 */         return MC1_20R3;
/*     */       case MC1_20_R2:
/* 346 */         return MC1_20R2;
/*     */       case MC1_20_R1:
/* 348 */         return MC1_20R1;
/*     */       case MC1_19_R3:
/* 350 */         return MC1_19R2;
/*     */       case MC1_19_R2:
/* 352 */         return MC1_19R2;
/*     */       case MC1_19_R1:
/* 354 */         return MC1_19R1;
/*     */       case MC1_18_R2:
/* 356 */         return MC1_18R2;
/*     */       case MC1_18_R1:
/* 358 */         return MC1_18R1;
/*     */       case UNKNOWN:
/* 360 */         return MC1_21R7;
/*     */     } 
/*     */     
/* 363 */     throw new NbtApiException("No fitting mapping found for version " + MinecraftVersion.getVersion() + ". This is a bug!");
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\nmsmappings\MojangToMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */