/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum PackageWrapper
/*    */ {
/* 11 */   NMS(new String(new byte[] { 110, 101, 116, 46, 109, 105, 110, 101, 99, 114, 97, 102, 116, 46, 115, 101, 114, 118, 101, 114
/*    */       })),
/* 13 */   CRAFTBUKKIT(new String(new byte[] { 111, 114, 103, 46, 98, 117, 107, 107, 105, 116, 46, 99, 114, 97, 102, 116, 98, 117, 107, 107, 105, 116
/*    */       })),
/* 15 */   NONE("");
/*    */   
/*    */   private final String uri;
/*    */   
/*    */   PackageWrapper(String paramString1) {
/* 20 */     this.uri = paramString1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUri() {
/* 27 */     return this.uri;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\nmsmappings\PackageWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */