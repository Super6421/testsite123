/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.bukkit.Metrics;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts.CustomChart;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts.DrilldownPie;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.metrics.charts.SimplePie;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MinecraftVersion
/*     */ {
/*  29 */   UNKNOWN(2147483647),
/*  30 */   MC1_7_R4(174), MC1_8_R3(183), MC1_9_R1(191), MC1_9_R2(192), MC1_10_R1(1101), MC1_11_R1(1111), MC1_12_R1(1121),
/*  31 */   MC1_13_R1(1131), MC1_13_R2(1132), MC1_14_R1(1141), MC1_15_R1(1151), MC1_16_R1(1161), MC1_16_R2(1162),
/*  32 */   MC1_16_R3(1163), MC1_17_R1(1171), MC1_18_R1(1181, true), MC1_18_R2(1182, true), MC1_19_R1(1191, true),
/*  33 */   MC1_19_R2(1192, true), MC1_19_R3(1193, true), MC1_20_R1(1201, true), MC1_20_R2(1202, true), MC1_20_R3(1203, true),
/*  34 */   MC1_20_R4(1204, true), MC1_21_R1(1211, true), MC1_21_R2(1212, true), MC1_21_R3(1213, true), MC1_21_R4(1214, true),
/*  35 */   MC1_21_R5(1215, true), MC1_21_R6(1216, true), MC1_21_R7(1217, true), MC26_1(2601, true);
/*     */   
/*     */   private static MinecraftVersion version;
/*     */   
/*     */   private static Boolean hasGsonSupport;
/*     */   private static Boolean isForgePresent;
/*     */   
/*     */   static {
/*  43 */     bStatsDisabled = false;
/*  44 */     disablePackageWarning = false;
/*  45 */     updateCheckDisabled = true;
/*     */ 
/*     */ 
/*     */     
/*  49 */     logger = Logger.getLogger("NBTAPI");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     VERSION_TO_REVISION = new HashMap<String, MinecraftVersion>()
/*     */       {
/*     */       
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private static Boolean isNeoForgePresent;
/*     */   
/*     */   private static Boolean isFabricPresent;
/*     */   
/*     */   private static Boolean isFoliaPresent;
/*     */   
/*     */   private static boolean bStatsDisabled;
/*     */   
/*     */   private static boolean disablePackageWarning;
/*     */   
/*     */   private static boolean updateCheckDisabled;
/*     */   
/*     */   private static Logger logger;
/*     */   
/*     */   protected static final String VERSION = "2.15.7";
/*     */   
/*     */   private final int versionId;
/*     */   
/*     */   private final boolean mojangMapping;
/*     */   
/*     */   private static final Map<String, MinecraftVersion> VERSION_TO_REVISION;
/*     */   
/*     */   MinecraftVersion(int paramInt1, boolean paramBoolean) {
/*  88 */     this.versionId = paramInt1;
/*  89 */     this.mojangMapping = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVersionId() {
/*  96 */     return this.versionId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMojangMapping() {
/* 104 */     return this.mojangMapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPackageName() {
/* 114 */     if (this == UNKNOWN) {
/*     */       try {
/* 116 */         return Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
/* 117 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 121 */     return name().replace("MC", "v");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAtLeastVersion(MinecraftVersion paramMinecraftVersion) {
/* 131 */     return (getVersion().getVersionId() >= paramMinecraftVersion.getVersionId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNewerThan(MinecraftVersion paramMinecraftVersion) {
/* 141 */     return (getVersion().getVersionId() > paramMinecraftVersion.getVersionId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MinecraftVersion getVersion() {
/* 151 */     if (version != null) {
/* 152 */       return version;
/*     */     }
/*     */     try {
/* 155 */       String str = Bukkit.getServer().getClass().getPackage().getName().split("\\.")[3];
/* 156 */       logger.info("[NBTAPI] Found Minecraft: " + str + "! Trying to find NMS support");
/* 157 */       version = valueOf(str.replace("v", "MC"));
/* 158 */     } catch (Exception exception) {
/* 159 */       logger.info("[NBTAPI] Found Minecraft: " + Bukkit.getServer().getBukkitVersion().split("-")[0] + "! Trying to find NMS support");
/*     */       
/* 161 */       version = VERSION_TO_REVISION.get(Bukkit.getServer().getBukkitVersion().split("-")[0]);
/* 162 */       if (version == null) {
/*     */         
/* 164 */         String str = Bukkit.getServer().getBukkitVersion().split("-")[0].split(".build")[0];
/* 165 */         for (Map.Entry<String, MinecraftVersion> entry : VERSION_TO_REVISION.entrySet()) {
/* 166 */           if (str.startsWith((String)entry.getKey()) && version == null) {
/* 167 */             version = (MinecraftVersion)entry.getValue(); continue;
/*     */           } 
/* 169 */           if (str.startsWith((String)entry.getKey()) && ((MinecraftVersion)entry.getValue()).getVersionId() > version.getVersionId()) {
/* 170 */             version = (MinecraftVersion)entry.getValue();
/*     */           }
/*     */         } 
/*     */       } 
/* 174 */       if (version == null) {
/* 175 */         version = UNKNOWN;
/*     */       }
/*     */     } 
/* 178 */     if (version != UNKNOWN) {
/* 179 */       logger.info("[NBTAPI] NMS support '" + version.name() + "' loaded!");
/*     */     } else {
/* 181 */       logger.warning("[NBTAPI] This Server-Version(" + Bukkit.getServer().getBukkitVersion() + ") is not supported by this NBT-API Version(" + "2.15.7" + ") located in " + 
/*     */           
/* 183 */           VersionChecker.getPlugin() + ". The NBT-API will try to work as good as it can! Some functions may not work!");
/*     */     } 
/*     */     
/* 186 */     init();
/* 187 */     return version;
/*     */   }
/*     */   
/*     */   public static String getNBTAPIVersion() {
/* 191 */     return "2.15.7";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void init() {
/* 197 */     String str1 = new String(new byte[] { 100, 101, 46, 116, 114, 55, 122, 119, 46, 99, 104, 97, 110, 103, 101, 109, 101, 46, 110, 98, 116, 97, 112, 105, 46, 117, 116, 105, 108, 115 });
/*     */     
/* 199 */     String str2 = new String(new byte[] { 100, 101, 46, 116, 114, 55, 122, 119, 46, 110, 98, 116, 97, 112, 105, 46, 117, 116, 105, 108, 115 });
/*     */     
/*     */     try {
/* 202 */       if (hasGsonSupport() && !bStatsDisabled) {
/* 203 */         Plugin plugin = Bukkit.getPluginManager().getPlugin(VersionChecker.getPlugin());
/* 204 */         if (plugin != null && plugin instanceof org.bukkit.plugin.java.JavaPlugin) {
/* 205 */           getLogger()
/* 206 */             .info("[NBTAPI] Using the plugin '" + plugin.getName() + "' to create a bStats instance!");
/* 207 */           Metrics metrics = new Metrics(plugin, 1058);
/* 208 */           metrics.addCustomChart((CustomChart)new SimplePie("nbtapi_version", () -> "2.15.7"));
/*     */ 
/*     */           
/* 211 */           metrics.addCustomChart((CustomChart)new DrilldownPie("nms_version", () -> {
/*     */                   HashMap<Object, Object> hashMap1 = new HashMap<>();
/*     */                   HashMap<Object, Object> hashMap2 = new HashMap<>();
/*     */                   hashMap2.put(Bukkit.getName(), Integer.valueOf(1));
/*     */                   hashMap1.put(getVersion().name(), hashMap2);
/*     */                   return hashMap1;
/*     */                 }));
/* 218 */           metrics.addCustomChart((CustomChart)new SimplePie("shaded", () -> Boolean.toString(!"NBTAPI".equals(VersionChecker.getPlugin()))));
/*     */ 
/*     */           
/* 221 */           metrics.addCustomChart((CustomChart)new SimplePie("server_software", () -> Bukkit.getName()));
/*     */ 
/*     */           
/* 224 */           metrics.addCustomChart((CustomChart)new SimplePie("parent_plugin", () -> VersionChecker.getPluginforBStats()));
/*     */ 
/*     */           
/* 227 */           metrics.addCustomChart((CustomChart)new SimplePie("parent_plugin_type", () -> VersionChecker.getPluginType()));
/*     */ 
/*     */           
/* 230 */           metrics.addCustomChart((CustomChart)new SimplePie("special_environment", () -> isFoliaPresent() ? "Folia" : (isForgePresent() ? "Forge" : (isFabricPresent() ? "Fabric" : (isNeoForgePresent() ? "NeoForge" : "None")))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 243 */           metrics.addCustomChart((CustomChart)new SimplePie("bindings_check", () -> {
/*     */                   boolean bool = false;
/*     */                   
/*     */                   for (ClassWrapper classWrapper : ClassWrapper.values()) {
/*     */                     if (classWrapper.isEnabled() && classWrapper.getClazz() == null) {
/*     */                       bool = true;
/*     */                     }
/*     */                   } 
/*     */                   
/*     */                   for (ReflectionMethod reflectionMethod : ReflectionMethod.values()) {
/*     */                     if (reflectionMethod.isCompatible() && !reflectionMethod.isLoaded()) {
/*     */                       bool = true;
/*     */                     }
/*     */                   } 
/*     */                   return bool ? "Failed" : "Pass";
/*     */                 }));
/* 259 */         } else if (plugin == null) {
/* 260 */           getLogger().info("[NBTAPI] Unable to create a bStats instance!!");
/*     */         } 
/*     */       } 
/* 263 */     } catch (Exception exception) {
/* 264 */       logger.log(Level.WARNING, "[NBTAPI] Error enabling Metrics!", exception);
/*     */     } 
/*     */     
/* 267 */     if (hasGsonSupport() && !updateCheckDisabled)
/* 268 */       (new Thread(() -> {
/*     */             try {
/*     */               VersionChecker.checkForUpdates();
/* 271 */             } catch (Exception exception) {
/*     */               logger.log(Level.WARNING, "[NBTAPI] Error while checking for updates! Error: " + exception.getMessage());
/*     */             } 
/* 274 */           })).start(); 
/* 275 */     if (!disablePackageWarning && MinecraftVersion.class.getPackage().getName().equals(str1)) {
/* 276 */       logger.warning("#########################################- NBTAPI -#########################################");
/*     */       
/* 278 */       logger.warning("The NBT-API package has not been moved! This *will* cause problems with other plugins containing");
/*     */       
/* 280 */       logger.warning("a different version of the api! Please read the guide on the plugin page on how to get the");
/*     */       
/* 282 */       logger.warning("Maven Shade plugin to relocate the api to your personal location! If you are not the developer,");
/*     */       
/* 284 */       logger.warning("please check your plugins and contact their developer, so they can fix this issue.");
/* 285 */       logger.warning("#########################################- NBTAPI -#########################################");
/*     */     } 
/*     */     
/* 288 */     if (!disablePackageWarning && !"NBTAPI".equals(VersionChecker.getPlugin())) {
/*     */       
/* 290 */       if (!"de.tr7zw.nbtapi.utils".equals(str2)) {
/* 291 */         logger.warning("#########################################- NBTAPI -#########################################");
/*     */         
/* 293 */         logger.warning("The NBT-API inside " + 
/* 294 */             VersionChecker.getPlugin() + " is the plugin version, not the API!");
/* 295 */         logger.warning("The plugin itself should never be shaded! Remove the `-plugin` from the dependency and fix your shading setup.");
/*     */         
/* 297 */         logger.warning("For more info check: https://github.com/tr7zw/Item-NBT-API/wiki/Using-Maven#option-2-shading-the-nbt-api-into-your-plugin");
/*     */         
/* 299 */         logger.warning("#########################################- NBTAPI -#########################################");
/*     */         
/*     */         return;
/*     */       } 
/* 303 */       if (MinecraftVersion.class.getPackage().getName().equals("de.tr7zw.nbtapi.utils")) {
/* 304 */         logger.warning("#########################################- NBTAPI -#########################################");
/*     */         
/* 306 */         logger.warning("The NBT-API inside " + 
/* 307 */             VersionChecker.getPlugin() + " is located at 'de.tr7zw.nbtapi.utils'!");
/* 308 */         logger.warning("This package name is reserved for the official NBTAPI plugin, and not intended to be used for shading!");
/*     */         
/* 310 */         logger.warning("Please change the relocate to something else. For example: com.example.util.nbtapi");
/* 311 */         logger.warning("#########################################- NBTAPI -#########################################");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasGsonSupport() {
/* 321 */     if (hasGsonSupport != null) {
/* 322 */       return hasGsonSupport.booleanValue();
/*     */     }
/*     */     try {
/* 325 */       Class.forName("com.google.gson.Gson");
/* 326 */       hasGsonSupport = Boolean.valueOf(true);
/* 327 */     } catch (Exception exception) {
/* 328 */       logger.info("[NBTAPI] Gson not found! This will not allow the usage of some methods!");
/* 329 */       hasGsonSupport = Boolean.valueOf(false);
/*     */     } 
/* 331 */     return hasGsonSupport.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFabricPresent() {
/* 338 */     if (isFabricPresent != null) {
/* 339 */       return isFabricPresent.booleanValue();
/*     */     }
/*     */     try {
/* 342 */       logger.info("[NBTAPI] Found Fabric: " + Class.forName("net.fabricmc.api.ModInitializer"));
/* 343 */       isFabricPresent = Boolean.valueOf(true);
/* 344 */     } catch (Exception exception) {
/* 345 */       isFabricPresent = Boolean.valueOf(false);
/*     */     } 
/* 347 */     return isFabricPresent.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isForgePresent() {
/* 354 */     if (isForgePresent != null) {
/* 355 */       return isForgePresent.booleanValue();
/*     */     }
/*     */     try {
/* 358 */       logger.info("[NBTAPI] Found Forge: " + (
/* 359 */           (getVersion() == MC1_7_R4) ? (String)Class.forName("cpw.mods.fml.common.Loader") : 
/* 360 */           (String)Class.forName("net.minecraftforge.fml.common.Loader")));
/* 361 */       isForgePresent = Boolean.valueOf(true);
/* 362 */     } catch (Exception exception) {
/* 363 */       isForgePresent = Boolean.valueOf(false);
/*     */     } 
/* 365 */     return isForgePresent.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNeoForgePresent() {
/* 372 */     if (isNeoForgePresent != null) {
/* 373 */       return isNeoForgePresent.booleanValue();
/*     */     }
/*     */     try {
/* 376 */       logger.info("[NBTAPI] Found NeoForge: " + Class.forName("net.neoforged.neoforge.common.NeoForge"));
/* 377 */       isNeoForgePresent = Boolean.valueOf(true);
/* 378 */     } catch (Exception exception) {
/* 379 */       isNeoForgePresent = Boolean.valueOf(false);
/*     */     } 
/* 381 */     return isNeoForgePresent.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFoliaPresent() {
/* 388 */     if (isFoliaPresent != null) {
/* 389 */       return isFoliaPresent.booleanValue();
/*     */     }
/*     */     try {
/* 392 */       logger.info("[NBTAPI] Found Folia: " + Class.forName("io.papermc.paper.threadedregions.RegionizedServer"));
/* 393 */       isFoliaPresent = Boolean.valueOf(true);
/* 394 */     } catch (Exception exception) {
/* 395 */       isFoliaPresent = Boolean.valueOf(false);
/*     */     } 
/* 397 */     return isFoliaPresent.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void disableBStats() {
/* 406 */     bStatsDisabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void disableUpdateCheck() {
/* 414 */     updateCheckDisabled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void enableUpdateCheck() {
/* 422 */     updateCheckDisabled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void disablePackageWarning() {
/* 432 */     disablePackageWarning = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Logger getLogger() {
/* 439 */     return logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void replaceLogger(Logger paramLogger) {
/* 448 */     if (paramLogger == null)
/* 449 */       throw new NullPointerException("Logger can not be null!"); 
/* 450 */     logger = paramLogger;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\MinecraftVersion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */