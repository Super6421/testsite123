/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*     */ 
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTItem;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.logging.Level;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionChecker
/*     */ {
/*     */   private static final String USER_AGENT = "nbt-api Version check";
/*     */   private static final String REQUEST_URL = "https://api.spiget.org/v2/resources/7939/versions?size=100";
/*     */   public static boolean hideOk = false;
/*     */   
/*     */   protected static void checkForUpdates() {
/*  29 */     URL uRL = new URL("https://api.spiget.org/v2/resources/7939/versions?size=100");
/*  30 */     HttpURLConnection httpURLConnection = (HttpURLConnection)uRL.openConnection();
/*  31 */     httpURLConnection.addRequestProperty("User-Agent", "nbt-api Version check");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  37 */     InputStream inputStream = httpURLConnection.getInputStream();
/*  38 */     InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
/*     */ 
/*     */     
/*  41 */     JsonElement jsonElement = (new JsonParser()).parse(inputStreamReader);
/*  42 */     if (jsonElement.isJsonArray()) {
/*     */       
/*  44 */       JsonArray jsonArray = (JsonArray)jsonElement;
/*  45 */       JsonObject jsonObject = (JsonObject)jsonArray.get(jsonArray.size() - 1);
/*  46 */       int i = getVersionDifference(jsonObject.get("name").getAsString());
/*  47 */       if (i == -1) {
/*  48 */         MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] The NBT-API in '" + 
/*  49 */             getPlugin() + "' seems to be outdated!");
/*  50 */         MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Current Version: '2.15.7' Newest Version: " + jsonObject
/*  51 */             .get("name").getAsString() + "'");
/*  52 */         MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Please update the NBTAPI or the plugin that contains the api(nag the mod author when the newest release has an old version, not the NBTAPI dev)!");
/*     */       
/*     */       }
/*  55 */       else if (i == 0) {
/*  56 */         if (!hideOk)
/*  57 */           MinecraftVersion.getLogger().log(Level.INFO, "[NBTAPI] The NBT-API seems to be up-to-date!"); 
/*  58 */       } else if (i == 1) {
/*  59 */         MinecraftVersion.getLogger().log(Level.INFO, "[NBTAPI] The NBT-API in '" + getPlugin() + "' seems to be a future Version, not yet released on Spigot/CurseForge! This is not an error!");
/*     */         
/*  61 */         MinecraftVersion.getLogger().log(Level.INFO, "[NBTAPI] Current Version: '2.15.7' Newest Version: " + jsonObject
/*  62 */             .get("name").getAsString() + "'");
/*     */       } 
/*     */     } else {
/*     */       
/*  66 */       MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error when looking for Updates! Got non Json Array: '" + jsonElement
/*  67 */           .toString() + "'");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getVersionDifference(String paramString) {
/*  76 */     String str1 = "2.15.7";
/*  77 */     if (str1.equals(paramString))
/*  78 */       return 0; 
/*  79 */     String str2 = "\\.";
/*  80 */     if ((str1.split(str2)).length != 3 || (paramString.split(str2)).length != 3)
/*  81 */       return -1; 
/*  82 */     int i = Integer.parseInt(str1.split(str2)[0]);
/*  83 */     int j = Integer.parseInt(str1.split(str2)[1]);
/*  84 */     String str3 = str1.split(str2)[2];
/*  85 */     int k = Integer.parseInt(paramString.split(str2)[0]);
/*  86 */     int m = Integer.parseInt(paramString.split(str2)[1]);
/*  87 */     String str4 = paramString.split(str2)[2];
/*  88 */     if (i < k)
/*  89 */       return -1; 
/*  90 */     if (i > k)
/*  91 */       return 1; 
/*  92 */     if (j < m)
/*  93 */       return -1; 
/*  94 */     if (j > m)
/*  95 */       return 1; 
/*  96 */     int n = Integer.parseInt(str3.split("-")[0]);
/*  97 */     int i1 = Integer.parseInt(str4.split("-")[0]);
/*  98 */     if (n < i1)
/*  99 */       return -1; 
/* 100 */     if (n > i1)
/* 101 */       return 1; 
/* 102 */     if (!str4.contains("-") && str3.contains("-")) {
/* 103 */       return -1;
/*     */     }
/* 105 */     if (str4.contains("-") && str3.contains("-"))
/* 106 */       return 0; 
/* 107 */     return 1;
/*     */   }
/*     */   
/*     */   protected static String getPlugin() {
/* 111 */     ClassLoader classLoader = VersionChecker.class.getClassLoader();
/* 112 */     InputStream inputStream = classLoader.getResourceAsStream("paper-plugin.yml");
/* 113 */     if (inputStream != null) {
/* 114 */       try { InputStreamReader inputStreamReader = new InputStreamReader(inputStream); 
/* 115 */         try { YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(inputStreamReader);
/* 116 */           String str = yamlConfiguration.getString("name");
/* 117 */           inputStreamReader.close(); return str; } catch (Throwable throwable) { try { inputStreamReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException)
/*     */       {  }
/* 119 */       catch (IllegalArgumentException illegalArgumentException)
/*     */       
/* 121 */       { MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error reading paper-plugin.yml: " + illegalArgumentException.getMessage()); }
/*     */     
/*     */     }
/*     */     
/* 125 */     inputStream = classLoader.getResourceAsStream("plugin.yml");
/*     */     
/* 127 */     if (inputStream != null) {
/* 128 */       try { InputStreamReader inputStreamReader = new InputStreamReader(inputStream); 
/* 129 */         try { YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(inputStreamReader);
/* 130 */           String str = yamlConfiguration.getString("name");
/* 131 */           inputStreamReader.close(); return str; } catch (Throwable throwable) { try { inputStreamReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException)
/*     */       {  }
/* 133 */       catch (IllegalArgumentException illegalArgumentException)
/*     */       
/* 135 */       { MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error reading plugin.yml: " + illegalArgumentException.getMessage()); }
/*     */     
/*     */     }
/* 138 */     return NBTItem.class.getPackage().getName();
/*     */   }
/*     */   
/*     */   protected static String getPluginforBStats() {
/* 142 */     ClassLoader classLoader = VersionChecker.class.getClassLoader();
/* 143 */     InputStream inputStream = classLoader.getResourceAsStream("paper-plugin.yml");
/* 144 */     if (inputStream != null) {
/* 145 */       try { InputStreamReader inputStreamReader = new InputStreamReader(inputStream); 
/* 146 */         try { YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(inputStreamReader);
/* 147 */           String str = yamlConfiguration.getString("name");
/* 148 */           inputStreamReader.close(); return str; } catch (Throwable throwable) { try { inputStreamReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException)
/*     */       {  }
/* 150 */       catch (IllegalArgumentException illegalArgumentException)
/*     */       
/* 152 */       { MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error reading paper-plugin.yml: " + illegalArgumentException.getMessage()); }
/*     */     
/*     */     }
/*     */     
/* 156 */     inputStream = classLoader.getResourceAsStream("plugin.yml");
/*     */     
/* 158 */     if (inputStream != null) {
/* 159 */       try { InputStreamReader inputStreamReader = new InputStreamReader(inputStream); 
/* 160 */         try { YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(inputStreamReader);
/* 161 */           String str = yamlConfiguration.getString("name");
/* 162 */           inputStreamReader.close(); return str; } catch (Throwable throwable) { try { inputStreamReader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (IOException iOException)
/*     */       {  }
/* 164 */       catch (IllegalArgumentException illegalArgumentException)
/*     */       
/* 166 */       { MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error reading plugin.yml: " + illegalArgumentException.getMessage()); }
/*     */     
/*     */     }
/* 169 */     return "UnknownPlugin";
/*     */   }
/*     */   
/*     */   protected static String getPluginType() {
/* 173 */     ClassLoader classLoader = VersionChecker.class.getClassLoader();
/* 174 */     InputStream inputStream = classLoader.getResourceAsStream("paper-plugin.yml");
/* 175 */     if (inputStream != null) {
/*     */       try {
/* 177 */         inputStream.close();
/* 178 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/* 181 */       return "PaperPlugin";
/*     */     } 
/*     */     
/* 184 */     inputStream = classLoader.getResourceAsStream("plugin.yml");
/* 185 */     if (inputStream != null) {
/*     */       try {
/* 187 */         inputStream.close();
/* 188 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/* 191 */       return "SpigotPlugin";
/*     */     } 
/* 193 */     return "UnknownPlugin";
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\VersionChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */