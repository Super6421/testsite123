/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*    */ 
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class UUIDUtil
/*    */ {
/*    */   public static UUID uuidFromIntArray(int[] paramArrayOfint) {
/*  8 */     return new UUID(paramArrayOfint[0] << 32L | paramArrayOfint[1] & 0xFFFFFFFFL, paramArrayOfint[2] << 32L | paramArrayOfint[3] & 0xFFFFFFFFL);
/*    */   }
/*    */ 
/*    */   
/*    */   public static int[] uuidToIntArray(UUID paramUUID) {
/* 13 */     long l1 = paramUUID.getMostSignificantBits();
/* 14 */     long l2 = paramUUID.getLeastSignificantBits();
/* 15 */     return leastMostToIntArray(l1, l2);
/*    */   }
/*    */   
/*    */   private static int[] leastMostToIntArray(long paramLong1, long paramLong2) {
/* 19 */     return new int[] { (int)(paramLong1 >> 32L), (int)paramLong1, (int)(paramLong2 >> 32L), (int)paramLong2 };
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\UUIDUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */