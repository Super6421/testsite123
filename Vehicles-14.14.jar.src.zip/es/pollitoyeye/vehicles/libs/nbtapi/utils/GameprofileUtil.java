/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.utils;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.properties.Property;
/*     */ import com.mojang.authlib.properties.PropertyMap;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTType;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTCompoundList;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GameprofileUtil
/*     */ {
/*  21 */   private static Method GET_NAME = null;
/*  22 */   private static Method GET_ID = null;
/*  23 */   private static Method GET_VALUE = null;
/*  24 */   private static Method GET_SIGNATURE = null;
/*  25 */   private static Method GET_PROPERTY_NAME = null;
/*  26 */   private static Method GET_PROPERTIES = null;
/*     */   
/*     */   static {
/*  29 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/*  31 */         GET_NAME = GameProfile.class.getDeclaredMethod("name", new Class[0]);
/*  32 */         GET_ID = GameProfile.class.getDeclaredMethod("id", new Class[0]);
/*  33 */         GET_VALUE = Property.class.getDeclaredMethod("value", new Class[0]);
/*  34 */         GET_SIGNATURE = Property.class.getDeclaredMethod("signature", new Class[0]);
/*  35 */         GET_PROPERTY_NAME = Property.class.getDeclaredMethod("name", new Class[0]);
/*  36 */         GET_PROPERTIES = GameProfile.class.getDeclaredMethod("properties", new Class[0]);
/*  37 */       } catch (NoSuchMethodException noSuchMethodException) {
/*  38 */         noSuchMethodException.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static GameProfile readGameProfile(ReadableNBT paramReadableNBT) {
/*  45 */     String str = null;
/*  46 */     UUID uUID = null;
/*  47 */     if (paramReadableNBT.hasTag("Name") && paramReadableNBT.getType("Name") == NBTType.NBTTagString) {
/*  48 */       str = paramReadableNBT.getString("Name");
/*  49 */     } else if (paramReadableNBT.hasTag("name") && paramReadableNBT.getType("name") == NBTType.NBTTagString) {
/*  50 */       str = paramReadableNBT.getString("name");
/*     */     } 
/*  52 */     if (paramReadableNBT.hasTag("Id") && paramReadableNBT.getType("Id") == NBTType.NBTTagIntArray && (paramReadableNBT.getIntArray("Id")).length == 4) {
/*  53 */       uUID = paramReadableNBT.getUUID("Id");
/*  54 */     } else if (paramReadableNBT.hasTag("id") && paramReadableNBT.getType("id") == NBTType.NBTTagIntArray && (paramReadableNBT
/*  55 */       .getIntArray("id")).length == 4) {
/*  56 */       uUID = paramReadableNBT.getUUID("id");
/*     */     } 
/*     */     try {
/*  59 */       GameProfile gameProfile = new GameProfile(uUID, str);
/*  60 */       if (paramReadableNBT.hasTag("Properties") && paramReadableNBT.getType("Properties") == NBTType.NBTTagCompound) {
/*  61 */         ReadableNBT readableNBT = paramReadableNBT.getCompound("Properties");
/*  62 */         for (String str1 : readableNBT.getKeys()) {
/*  63 */           ReadableNBTList readableNBTList = readableNBT.getCompoundList(str);
/*  64 */           for (byte b = 0; b < readableNBTList.size(); b++) {
/*  65 */             ReadableNBT readableNBT1 = (ReadableNBT)readableNBTList.get(b);
/*  66 */             String str2 = readableNBT1.getString("Value");
/*  67 */             if (readableNBT1.hasTag("Signature") && readableNBT1
/*  68 */               .getType("Signature") == NBTType.NBTTagString) {
/*  69 */               gameProfile.getProperties().put(str1, new Property(str1, str2, readableNBT1
/*  70 */                     .getString("Signature")));
/*     */             } else {
/*  72 */               gameProfile.getProperties().put(str1, new Property(str1, str2));
/*     */             }
/*     */           
/*     */           } 
/*     */         } 
/*  77 */       } else if (paramReadableNBT.getType("properties") == NBTType.NBTTagList) {
/*  78 */         ReadableNBTList readableNBTList = paramReadableNBT.getCompoundList("properties");
/*  79 */         for (byte b = 0; b < readableNBTList.size(); b++) {
/*  80 */           ReadableNBT readableNBT = (ReadableNBT)readableNBTList.get(b);
/*  81 */           String str1 = readableNBT.getString("name");
/*  82 */           String str2 = readableNBT.getString("value");
/*  83 */           if (readableNBT.hasTag("signature") && readableNBT
/*  84 */             .getType("signature") == NBTType.NBTTagString) {
/*  85 */             gameProfile.getProperties().put(str1, new Property(str1, str2, readableNBT
/*  86 */                   .getString("signature")));
/*     */           } else {
/*  88 */             gameProfile.getProperties().put(str1, new Property(str1, str2));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  93 */       return gameProfile;
/*  94 */     } catch (Throwable throwable) {
/*  95 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ReadWriteNBT writeGameProfile(ReadWriteNBT paramReadWriteNBT, GameProfile paramGameProfile) {
/* 100 */     String str = getName(paramGameProfile);
/* 101 */     if (str != null && !str.isEmpty()) {
/* 102 */       String str1 = MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4) ? "name" : "Name";
/* 103 */       paramReadWriteNBT.setString(str1, getName(paramGameProfile));
/*     */     } 
/* 105 */     UUID uUID = getId(paramGameProfile);
/* 106 */     if (uUID != null) {
/* 107 */       String str1 = MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4) ? "id" : "Id";
/* 108 */       paramReadWriteNBT.setUUID(str1, uUID);
/*     */     } 
/* 110 */     PropertyMap propertyMap = getProperties(paramGameProfile);
/* 111 */     if (!propertyMap.isEmpty()) {
/* 112 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 113 */         ReadWriteNBTCompoundList readWriteNBTCompoundList = paramReadWriteNBT.getCompoundList("properties");
/* 114 */         for (Property property : propertyMap.values()) {
/* 115 */           ReadWriteNBT readWriteNBT = readWriteNBTCompoundList.addCompound();
/* 116 */           readWriteNBT.setString("name", getPropertyName(property));
/* 117 */           readWriteNBT.setString("value", getValue(property));
/* 118 */           if (property.hasSignature()) {
/* 119 */             readWriteNBT.setString("signature", getSignature(property));
/*     */           }
/*     */         } 
/*     */       } else {
/* 123 */         ReadWriteNBT readWriteNBT = paramReadWriteNBT.getOrCreateCompound("Properties");
/* 124 */         for (String str1 : paramGameProfile.getProperties().keySet()) {
/* 125 */           ReadWriteNBTCompoundList readWriteNBTCompoundList = readWriteNBT.getCompoundList(str1);
/* 126 */           for (Property property : propertyMap.get(str1)) {
/* 127 */             ReadWriteNBT readWriteNBT1 = readWriteNBTCompoundList.addCompound();
/* 128 */             readWriteNBT1.setString("Value", getValue(property));
/* 129 */             if (property.hasSignature()) {
/* 130 */               readWriteNBT1.setString("Signature", getSignature(property));
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 136 */     return paramReadWriteNBT;
/*     */   }
/*     */   
/*     */   private static String getName(GameProfile paramGameProfile) {
/* 140 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 142 */         return GET_NAME.invoke(paramGameProfile, new Object[0]).toString();
/* 143 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 144 */         throw new NbtApiException("Failed to get GameProfile name via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 147 */     return paramGameProfile.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private static UUID getId(GameProfile paramGameProfile) {
/* 152 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 154 */         return (UUID)GET_ID.invoke(paramGameProfile, new Object[0]);
/* 155 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 156 */         throw new NbtApiException("Failed to get GameProfile id via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 159 */     return paramGameProfile.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getValue(Property paramProperty) {
/* 164 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 166 */         return GET_VALUE.invoke(paramProperty, new Object[0]).toString();
/* 167 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 168 */         throw new NbtApiException("Failed to get Property value via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 171 */     return paramProperty.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getSignature(Property paramProperty) {
/* 176 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 178 */         return GET_SIGNATURE.invoke(paramProperty, new Object[0]).toString();
/* 179 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 180 */         throw new NbtApiException("Failed to get Property signature via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 183 */     return paramProperty.getSignature();
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getPropertyName(Property paramProperty) {
/* 188 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 190 */         return GET_PROPERTY_NAME.invoke(paramProperty, new Object[0]).toString();
/* 191 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 192 */         throw new NbtApiException("Failed to get Property name via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 195 */     return paramProperty.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private static PropertyMap getProperties(GameProfile paramGameProfile) {
/* 200 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R6)) {
/*     */       try {
/* 202 */         return (PropertyMap)GET_PROPERTIES.invoke(paramGameProfile, new Object[0]);
/* 203 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 204 */         throw new NbtApiException("Failed to get GameProfile properties via reflection", illegalAccessException);
/*     */       } 
/*     */     }
/* 207 */     return paramGameProfile.getProperties();
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtap\\utils\GameprofileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */