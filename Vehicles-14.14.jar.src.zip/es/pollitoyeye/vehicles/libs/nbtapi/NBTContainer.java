/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ObjectCreator;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTContainer
/*     */   extends NBTCompound
/*     */ {
/*     */   private Object nbt;
/*     */   private boolean closed;
/*     */   private boolean readOnly;
/*     */   
/*     */   @Deprecated
/*     */   public NBTContainer() {
/*  29 */     super(null, null);
/*  30 */     this.nbt = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTContainer(Object paramObject) {
/*  41 */     super(null, null);
/*  42 */     if (paramObject == null) {
/*  43 */       paramObject = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/*  45 */     if (!ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().isAssignableFrom(paramObject.getClass())) {
/*  46 */       throw new NbtApiException("The object '" + paramObject.getClass() + "' is not a valid NBT-Object!");
/*     */     }
/*  48 */     this.nbt = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTContainer(InputStream paramInputStream) {
/*  59 */     super(null, null);
/*  60 */     this.nbt = NBTReflectionUtil.readNBT(paramInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTContainer(String paramString) {
/*  72 */     super(null, null);
/*  73 */     if (paramString == null) {
/*  74 */       throw new NullPointerException("The String can't be null!");
/*     */     }
/*     */     try {
/*  77 */       this.nbt = ReflectionMethod.PARSE_NBT.run(null, new Object[] { paramString });
/*  78 */     } catch (Exception exception) {
/*  79 */       throw new NbtApiException("Unable to parse Malformed Json!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCompound() {
/*  85 */     return this.nbt;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCompound(Object paramObject) {
/*  90 */     this.nbt = paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setClosed() {
/*  95 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isClosed() {
/* 100 */     return this.closed;
/*     */   }
/*     */   
/*     */   protected boolean isReadOnly() {
/* 104 */     return this.readOnly;
/*     */   }
/*     */   
/*     */   protected NBTContainer setReadOnly(boolean paramBoolean) {
/* 108 */     this.readOnly = true;
/* 109 */     return this;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */