/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.handler;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NBT;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTHandler;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class NBTHandlers
/*    */ {
/* 12 */   public static final NBTHandler<ItemStack> ITEM_STACK = new NBTHandler<ItemStack>()
/*    */     {
/*    */       public boolean fuzzyMatch(Object param1Object)
/*    */       {
/* 16 */         return param1Object instanceof ItemStack;
/*    */       }
/*    */ 
/*    */       
/*    */       public void set(ReadWriteNBT param1ReadWriteNBT, String param1String, ItemStack param1ItemStack) {
/* 21 */         param1ReadWriteNBT.removeKey(param1String);
/* 22 */         ReadWriteNBT readWriteNBT = param1ReadWriteNBT.getOrCreateCompound(param1String);
/* 23 */         readWriteNBT.mergeCompound((ReadableNBT)NBT.itemStackToNBT(param1ItemStack));
/*    */       }
/*    */ 
/*    */       
/*    */       public ItemStack get(ReadableNBT param1ReadableNBT, String param1String) {
/* 28 */         ReadableNBT readableNBT = param1ReadableNBT.getCompound(param1String);
/* 29 */         if (readableNBT != null) {
/* 30 */           return NBT.itemStackFromNBT(readableNBT);
/*    */         }
/* 32 */         return null;
/*    */       }
/*    */     };
/*    */ 
/*    */   
/* 37 */   public static final NBTHandler<ReadableNBT> STORE_READABLE_TAG = new NBTHandler<ReadableNBT>()
/*    */     {
/*    */       public boolean fuzzyMatch(Object param1Object)
/*    */       {
/* 41 */         return param1Object instanceof ReadableNBT;
/*    */       }
/*    */ 
/*    */       
/*    */       public void set(ReadWriteNBT param1ReadWriteNBT, String param1String, ReadableNBT param1ReadableNBT) {
/* 46 */         param1ReadWriteNBT.removeKey(param1String);
/* 47 */         param1ReadWriteNBT.getOrCreateCompound(param1String).mergeCompound(param1ReadableNBT);
/*    */       }
/*    */ 
/*    */       
/*    */       public ReadableNBT get(ReadableNBT param1ReadableNBT, String param1String) {
/* 52 */         ReadableNBT readableNBT = param1ReadableNBT.getCompound(param1String);
/* 53 */         if (readableNBT != null) {
/* 54 */           ReadWriteNBT readWriteNBT = NBT.createNBTObject();
/* 55 */           readWriteNBT.mergeCompound(readableNBT);
/* 56 */           return (ReadableNBT)readWriteNBT;
/*    */         } 
/* 58 */         return null;
/*    */       }
/*    */     };
/*    */ 
/*    */   
/* 63 */   public static final NBTHandler<ReadWriteNBT> STORE_READWRITE_TAG = new NBTHandler<ReadWriteNBT>()
/*    */     {
/*    */       public boolean fuzzyMatch(Object param1Object)
/*    */       {
/* 67 */         return param1Object instanceof ReadWriteNBT;
/*    */       }
/*    */ 
/*    */       
/*    */       public void set(ReadWriteNBT param1ReadWriteNBT1, String param1String, ReadWriteNBT param1ReadWriteNBT2) {
/* 72 */         param1ReadWriteNBT1.removeKey(param1String);
/* 73 */         param1ReadWriteNBT1.getOrCreateCompound(param1String).mergeCompound((ReadableNBT)param1ReadWriteNBT2);
/*    */       }
/*    */ 
/*    */       
/*    */       public ReadWriteNBT get(ReadableNBT param1ReadableNBT, String param1String) {
/* 78 */         ReadableNBT readableNBT = param1ReadableNBT.getCompound(param1String);
/* 79 */         if (readableNBT != null) {
/* 80 */           ReadWriteNBT readWriteNBT = NBT.createNBTObject();
/* 81 */           readWriteNBT.mergeCompound(readableNBT);
/* 82 */           return readWriteNBT;
/*    */         } 
/* 84 */         return null;
/*    */       }
/*    */     };
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\handler\NBTHandlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */