/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTFileHandle;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ObjectCreator;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTFile
/*     */   extends NBTCompound
/*     */   implements NBTFileHandle
/*     */ {
/*     */   private final File file;
/*     */   private Object nbt;
/*     */   
/*     */   @Deprecated
/*     */   public NBTFile(File paramFile) {
/*  31 */     super(null, null);
/*  32 */     if (paramFile == null) {
/*  33 */       throw new NullPointerException("File can't be null!");
/*     */     }
/*  35 */     this.file = paramFile;
/*  36 */     if (paramFile.exists()) {
/*  37 */       this.nbt = NBTReflectionUtil.readNBT(Files.newInputStream(paramFile.toPath(), new java.nio.file.OpenOption[0]));
/*     */     } else {
/*  39 */       this.nbt = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*  40 */       save();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() {
/*     */     try {
/*  52 */       getWriteLock().lock();
/*  53 */       saveTo(this.file, this);
/*     */     } finally {
/*  55 */       getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile() {
/*  64 */     return this.file;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCompound() {
/*  69 */     return this.nbt;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setCompound(Object paramObject) {
/*  74 */     this.nbt = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static NBTCompound readFrom(File paramFile) {
/*  89 */     if (!paramFile.exists())
/*  90 */       return new NBTContainer(); 
/*  91 */     return new NBTContainer(NBTReflectionUtil.readNBT(Files.newInputStream(paramFile.toPath(), new java.nio.file.OpenOption[0])));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void saveTo(File paramFile, NBTCompound paramNBTCompound) {
/* 106 */     if (!paramFile.exists()) {
/* 107 */       paramFile.getParentFile().mkdirs();
/* 108 */       if (!paramFile.createNewFile())
/* 109 */         throw new IOException("Unable to create file at " + paramFile.getAbsolutePath()); 
/*     */     } 
/* 111 */     paramNBTCompound.writeCompound(Files.newOutputStream(paramFile.toPath(), new java.nio.file.OpenOption[0]));
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */