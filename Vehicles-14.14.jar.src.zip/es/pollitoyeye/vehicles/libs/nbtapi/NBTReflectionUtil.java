/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import com.mojang.serialization.Codec;
/*     */ import com.mojang.serialization.DynamicOps;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.DataFixerUtil;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.GsonWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.ReflectionUtil;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.CodecHelper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ObjectCreator;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTReflectionUtil
/*     */ {
/*  45 */   private static Field field_unhandledTags = null;
/*  46 */   private static Field field_handle = null;
/*  47 */   private static Object type_custom_data = null;
/*  48 */   private static Object registry_access = null;
/*  49 */   public static Codec<Object> itemstack_codec = null;
/*  50 */   public static DynamicOps<Object> nbtOps = null;
/*  51 */   public static DynamicOps<Object> nbtRegistryOps = null;
/*  52 */   public static Object problemReporter = null;
/*     */   
/*     */   static {
/*     */     try {
/*  56 */       field_unhandledTags = ClassWrapper.CRAFT_METAITEM.getClazz().getDeclaredField("unhandledTags");
/*  57 */       field_unhandledTags.setAccessible(true);
/*  58 */     } catch (NoSuchFieldException noSuchFieldException) {}
/*     */ 
/*     */     
/*     */     try {
/*  62 */       field_handle = ClassWrapper.CRAFT_ITEMSTACK.getClazz().getDeclaredField("handle");
/*  63 */       field_handle.setAccessible(true);
/*  64 */     } catch (NoSuchFieldException noSuchFieldException) {}
/*     */ 
/*     */     
/*  67 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/*     */       try {
/*  69 */         Field field = ReflectionUtil.getMappedField(ClassWrapper.NMS_DATACOMPONENTS.getClazz(), "net.minecraft.core.component.DataComponents#CUSTOM_DATA");
/*  70 */         type_custom_data = field.get(null);
/*  71 */       } catch (Exception exception) {
/*  72 */         MinecraftVersion.getLogger().log(Level.WARNING, "Unable to find DataComponents#CUSTOM_DATA, NBTApi will not be able to read/write custom data on 1.20+", exception);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/*  77 */         Object object = ReflectionMethod.NMSSERVER_GETSERVER.run(Bukkit.getServer(), new Object[0]);
/*  78 */         registry_access = ReflectionMethod.NMSSERVER_GETREGISTRYACCESS.run(object, new Object[0]);
/*  79 */         itemstack_codec = (Codec<Object>)ReflectionUtil.getMappedField(ClassWrapper.NMS_ITEMSTACK.getClazz(), "net.minecraft.world.item.ItemStack#CODEC").get(null);
/*  80 */         nbtOps = (DynamicOps<Object>)ReflectionUtil.getMappedField(ClassWrapper.NMS_NBTOPS.getClazz(), "net.minecraft.nbt.NbtOps#INSTANCE").get(null);
/*  81 */         if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/*  82 */           nbtRegistryOps = (DynamicOps<Object>)ReflectionMethod.GET_SERIALIZATION_CONTEXT.run(registry_access, new Object[] { nbtOps });
/*  83 */           problemReporter = ReflectionUtil.getMappedField(ClassWrapper.NMS_PROBLEM_REPORTER.getClazz(), "net.minecraft.util.ProblemReporter#DISCARDING").get(null);
/*     */         } 
/*  85 */       } catch (Exception exception) {
/*  86 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getNMSEntity(Entity paramEntity) {
/*     */     try {
/* 106 */       return ReflectionMethod.CRAFT_ENTITY_GET_HANDLE.run(ClassWrapper.CRAFT_ENTITY.getClazz().cast(paramEntity), new Object[0]);
/* 107 */     } catch (Exception exception) {
/* 108 */       throw new NbtApiException("Exception while getting the NMS Entity from a Bukkit Entity!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object readNBT(InputStream paramInputStream) {
/*     */     try {
/* 120 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R3)) {
/* 121 */         return ReflectionMethod.NBTFILE_READV2.run(null, new Object[] { paramInputStream, ReflectionMethod.NBTACCOUNTER_CREATE_UNLIMITED
/* 122 */               .run(null, new Object[0]) });
/*     */       }
/* 124 */       return ReflectionMethod.NBTFILE_READ.run(null, new Object[] { paramInputStream });
/*     */     }
/* 126 */     catch (Exception exception) {
/*     */       try {
/* 128 */         paramInputStream.close();
/* 129 */       } catch (IOException iOException) {}
/*     */       
/* 131 */       throw new NbtApiException("Exception while reading a NBT File!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object writeNBT(Object paramObject, OutputStream paramOutputStream) {
/*     */     try {
/* 144 */       return ReflectionMethod.NBTFILE_WRITE.run(null, new Object[] { paramObject, paramOutputStream });
/* 145 */     } catch (Exception exception) {
/* 146 */       throw new NbtApiException("Exception while writing NBT!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getCraftItemHandle(ItemStack paramItemStack) {
/*     */     try {
/* 159 */       return field_handle.get(paramItemStack);
/* 160 */     } catch (IllegalArgumentException|IllegalAccessException illegalArgumentException) {
/* 161 */       throw new NbtApiException("Error getting handle from " + paramItemStack.getClass(), illegalArgumentException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeApiNBT(NBTCompound paramNBTCompound, OutputStream paramOutputStream) {
/*     */     try {
/* 173 */       Object object = paramNBTCompound.getResolvedObject();
/* 174 */       if (object == null) {
/* 175 */         object = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
/*     */       }
/* 177 */       ReflectionMethod.NBTFILE_WRITE.run(null, new Object[] { object, paramOutputStream });
/* 178 */     } catch (Exception exception) {
/* 179 */       throw new NbtApiException("Exception while writing NBT!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getItemRootNBTTagCompound(Object paramObject) {
/*     */     try {
/* 192 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 193 */         Object object = ReflectionMethod.NMSDATACOMPONENTHOLDER_GET.run(paramObject, new Object[] { type_custom_data });
/* 194 */         if (object == null) {
/* 195 */           return null;
/*     */         }
/* 197 */         return ReflectionMethod.NMSCUSTOMDATA_GETCOPY.run(object, new Object[0]);
/*     */       } 
/* 199 */       return ReflectionMethod.NMSITEM_GETTAG.run(paramObject, new Object[0]);
/*     */     
/*     */     }
/* 202 */     catch (Exception exception) {
/* 203 */       throw new NbtApiException("Exception while getting an Itemstack's NBTCompound!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setItemStackCompound(Object paramObject1, Object paramObject2) {
/* 214 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 215 */       if (paramObject2 == null) {
/* 216 */         ReflectionMethod.NMSITEM_SET.run(paramObject1, new Object[] { type_custom_data, null });
/*     */       } else {
/* 218 */         ReflectionMethod.NMSITEM_SET.run(paramObject1, new Object[] { type_custom_data, ObjectCreator.NMS_CUSTOMDATA
/* 219 */               .getInstance(new Object[] { paramObject2 }) });
/*     */       } 
/*     */     } else {
/* 222 */       ReflectionMethod.ITEMSTACK_SET_TAG.run(paramObject1, new Object[] { paramObject2 });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object convertNBTCompoundtoNMSItem(NBTCompound paramNBTCompound) {
/* 233 */     Object object = null;
/*     */     try {
/* 235 */       object = getToCompount(paramNBTCompound.getCompound(), paramNBTCompound);
/* 236 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 237 */         if (paramNBTCompound.hasTag("DataVersion", NBTType.NBTTagInt)) {
/* 238 */           int i = paramNBTCompound.getInteger("DataVersion").intValue();
/* 239 */           int j = DataFixerUtil.getCurrentVersion();
/* 240 */           if (i < j) {
/* 241 */             object = DataFixerUtil.fixUpRawItemData(object, i, j);
/*     */           }
/* 243 */         } else if (paramNBTCompound.hasTag("tag") || paramNBTCompound.hasTag("Count")) {
/* 244 */           object = DataFixerUtil.fixUpRawItemData(object, 3700, DataFixerUtil.getCurrentVersion());
/*     */         } 
/* 246 */         if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5))
/* 247 */           return CodecHelper.convertNbtToItemStack(object); 
/* 248 */         if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4)) {
/* 249 */           Optional optional = (Optional)ReflectionMethod.NMSITEM_LOAD_MODERN.run(null, new Object[] { registry_access, object });
/*     */           
/* 251 */           return optional.orElse(null);
/*     */         } 
/* 253 */         return ReflectionMethod.NMSITEM_LOAD.run(null, new Object[] { registry_access, object });
/*     */       } 
/* 255 */       if (MinecraftVersion.getVersion().getVersionId() >= MinecraftVersion.MC1_11_R1.getVersionId()) {
/* 256 */         return ObjectCreator.NMS_COMPOUNDFROMITEM.getInstance(new Object[] { object });
/*     */       }
/* 258 */       return ReflectionMethod.NMSITEM_CREATESTACK.run(null, new Object[] { object });
/*     */     }
/* 260 */     catch (Exception exception) {
/* 261 */       throw new NbtApiException("Exception while converting NBTCompound to NMS ItemStack! " + object, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NBTContainer convertNMSItemtoNBTCompound(Object paramObject) {
/*     */     try {
/*     */       NBTContainer nBTContainer;
/* 274 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/* 275 */         nBTContainer = new NBTContainer(CodecHelper.convertItemStackToNbt(paramObject));
/* 276 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 277 */         nBTContainer = new NBTContainer(ReflectionMethod.NMSITEM_SAVE_MODERN.run(paramObject, new Object[] { registry_access }));
/*     */       } else {
/* 279 */         Object object = ReflectionMethod.NMSITEM_SAVE.run(paramObject, new Object[] { ObjectCreator.NMS_NBTTAGCOMPOUND
/* 280 */               .getInstance(new Object[0]) });
/* 281 */         nBTContainer = new NBTContainer(object);
/*     */       } 
/* 283 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_12_R1)) {
/* 284 */         nBTContainer.setInteger("DataVersion", Integer.valueOf(DataFixerUtil.getCurrentVersion()));
/*     */       }
/* 286 */       return nBTContainer;
/* 287 */     } catch (Exception exception) {
/* 288 */       throw new NbtApiException("Exception while converting NMS ItemStack to NBTCompound!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Map<String, Object> getUnhandledNBTTags(ItemMeta paramItemMeta) {
/*     */     try {
/* 302 */       return (Map<String, Object>)field_unhandledTags.get(paramItemMeta);
/* 303 */     } catch (Exception exception) {
/* 304 */       throw new NbtApiException("Exception while getting unhandled tags from ItemMeta!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getEntityNBTTagCompound(Object paramObject) {
/*     */     try {
/*     */       Object object1;
/* 316 */       Object object = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
/*     */       
/* 318 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/* 319 */         Object object2 = ReflectionMethod.NMS_GET_TAG_VALUE_OUTPUT.run(null, new Object[] { problemReporter, registry_access });
/*     */         
/* 321 */         ReflectionMethod.NMS_ENTITY_GET_NBT_1216.run(paramObject, new Object[] { object2 });
/*     */         
/* 323 */         object1 = ReflectionMethod.NMS_TAG_VALUE_OUTPUT_TO_TAG_COMPOUND.run(object2, new Object[0]);
/*     */       } else {
/* 325 */         object1 = ReflectionMethod.NMS_ENTITY_GET_NBT.run(paramObject, new Object[] { object });
/*     */       } 
/* 327 */       if (object1 == null)
/* 328 */         object1 = object; 
/* 329 */       return object1;
/* 330 */     } catch (Exception exception) {
/* 331 */       throw new NbtApiException("Exception while getting NBTCompound from NMS Entity!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object setEntityNBTTag(Object paramObject1, Object paramObject2) {
/*     */     try {
/* 344 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/* 345 */         Object object = ReflectionMethod.NMS_GET_TAG_VALUE_INPUT.run(null, new Object[] { problemReporter, registry_access, paramObject1 });
/*     */         
/* 347 */         ReflectionMethod.NMS_ENTITY_SET_NBT_1216.run(paramObject2, new Object[] { object });
/*     */       } else {
/* 349 */         ReflectionMethod.NMS_ENTITY_SET_NBT.run(paramObject2, new Object[] { paramObject1 });
/*     */       } 
/*     */       
/* 352 */       return paramObject2;
/* 353 */     } catch (Exception exception) {
/* 354 */       throw new NbtApiException("Exception while setting the NBTCompound of an Entity", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getTileEntityNBTTagCompound(BlockState paramBlockState) {
/*     */     try {
/* 366 */       Object object = ClassWrapper.CRAFT_WORLD.getClazz().cast(paramBlockState.getWorld());
/* 367 */       Object object1 = ReflectionMethod.CRAFT_WORLD_GET_HANDLE.run(object, new Object[0]);
/* 368 */       Object object2 = null;
/* 369 */       if (MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4) {
/* 370 */         object2 = ReflectionMethod.NMS_WORLD_GET_TILEENTITY_1_7_10.run(object1, new Object[] { Integer.valueOf(paramBlockState.getX()), Integer.valueOf(paramBlockState.getY()), 
/* 371 */               Integer.valueOf(paramBlockState.getZ()) });
/*     */       } else {
/* 373 */         Object object4 = ObjectCreator.NMS_BLOCKPOSITION.getInstance(new Object[] { Integer.valueOf(paramBlockState.getX()), Integer.valueOf(paramBlockState.getY()), Integer.valueOf(paramBlockState.getZ()) });
/* 374 */         object2 = ReflectionMethod.NMS_WORLD_GET_TILEENTITY.run(object1, new Object[] { object4 });
/*     */       } 
/*     */       
/* 377 */       if (object2 == null) {
/* 378 */         throw new NbtApiException("The passed BlockState(" + paramBlockState.getType() + ") doesn't point to a BlockEntity. Only BlockEntities like Chest/Signs/Furnance/etc have NBT.");
/*     */       }
/*     */ 
/*     */       
/* 382 */       Object object3 = null;
/* 383 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/* 384 */         Object object4 = ReflectionMethod.NMS_GET_TAG_VALUE_OUTPUT.run(null, new Object[] { problemReporter, registry_access });
/*     */         
/* 386 */         ReflectionMethod.TILEENTITY_GET_NBT_1216.run(object2, new Object[] { object4 });
/*     */         
/* 388 */         object3 = ReflectionMethod.NMS_TAG_VALUE_OUTPUT_TO_TAG_COMPOUND.run(object4, new Object[0]);
/* 389 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 390 */         object3 = ReflectionMethod.TILEENTITY_GET_NBT_1205.run(object2, new Object[] { registry_access });
/* 391 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_18_R1)) {
/* 392 */         object3 = ReflectionMethod.TILEENTITY_GET_NBT_1181.run(object2, new Object[0]);
/*     */       } else {
/* 394 */         object3 = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
/* 395 */         ReflectionMethod.TILEENTITY_GET_NBT.run(object2, new Object[] { object3 });
/*     */       } 
/* 397 */       if (object3 == null) {
/* 398 */         throw new NbtApiException("Unable to get NBTCompound from TileEntity! " + paramBlockState + " " + object2);
/*     */       }
/* 400 */       return object3;
/* 401 */     } catch (Exception exception) {
/* 402 */       throw new NbtApiException("Exception while getting NBTCompound from TileEntity!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTileEntityNBTTagCompound(BlockState paramBlockState, Object paramObject) {
/*     */     try {
/* 414 */       Object object = ClassWrapper.CRAFT_WORLD.getClazz().cast(paramBlockState.getWorld());
/* 415 */       Object object1 = ReflectionMethod.CRAFT_WORLD_GET_HANDLE.run(object, new Object[0]);
/* 416 */       Object object2 = null;
/* 417 */       if (MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4) {
/* 418 */         object2 = ReflectionMethod.NMS_WORLD_GET_TILEENTITY_1_7_10.run(object1, new Object[] { Integer.valueOf(paramBlockState.getX()), Integer.valueOf(paramBlockState.getY()), 
/* 419 */               Integer.valueOf(paramBlockState.getZ()) });
/*     */       } else {
/* 421 */         Object object3 = ObjectCreator.NMS_BLOCKPOSITION.getInstance(new Object[] { Integer.valueOf(paramBlockState.getX()), Integer.valueOf(paramBlockState.getY()), Integer.valueOf(paramBlockState.getZ()) });
/* 422 */         object2 = ReflectionMethod.NMS_WORLD_GET_TILEENTITY.run(object1, new Object[] { object3 });
/*     */       } 
/* 424 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R5)) {
/* 425 */         Object object3 = ReflectionMethod.NMS_GET_TAG_VALUE_INPUT.run(null, new Object[] { problemReporter, registry_access, paramObject });
/*     */         
/* 427 */         ReflectionMethod.TILEENTITY_SET_NBT_1216.run(object2, new Object[] { object3 });
/* 428 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 429 */         ReflectionMethod.TILEENTITY_SET_NBT_1205.run(object2, new Object[] { paramObject, registry_access });
/* 430 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_17_R1)) {
/* 431 */         ReflectionMethod.TILEENTITY_SET_NBT.run(object2, new Object[] { paramObject });
/* 432 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_16_R1)) {
/* 433 */         Object object3 = ReflectionMethod.TILEENTITY_GET_BLOCKDATA.run(object2, new Object[0]);
/* 434 */         ReflectionMethod.TILEENTITY_SET_NBT_LEGACY1161.run(object2, new Object[] { object3, paramObject });
/*     */       } else {
/* 436 */         ReflectionMethod.TILEENTITY_SET_NBT_LEGACY1151.run(object2, new Object[] { paramObject });
/*     */       } 
/* 438 */     } catch (Exception exception) {
/* 439 */       throw new NbtApiException("Exception while setting NBTData for a TileEntity!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getSubNBTTagCompound(Object paramObject, String paramString) {
/*     */     try {
/* 452 */       if (((Boolean)ReflectionMethod.COMPOUND_HAS_KEY.run(paramObject, new Object[] { paramString })).booleanValue()) {
/* 453 */         Object object = ReflectionMethod.COMPOUND_GET_COMPOUND.run(paramObject, new Object[] { paramString });
/* 454 */         if (object instanceof Optional) {
/* 455 */           return ((Optional)object).orElse(null);
/*     */         }
/* 457 */         return object;
/*     */       } 
/* 459 */       throw new NbtApiException("Tried getting invalid compound '" + paramString + "' from '" + paramObject + "'!");
/*     */     }
/* 461 */     catch (Exception exception) {
/* 462 */       throw new NbtApiException("Exception while getting NBT subcompounds!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addNBTTagCompound(NBTCompound paramNBTCompound, String paramString) {
/* 473 */     if (paramString == null) {
/* 474 */       remove(paramNBTCompound, paramString);
/*     */       return;
/*     */     } 
/* 477 */     Object object1 = paramNBTCompound.getCompound();
/* 478 */     if (object1 == null) {
/* 479 */       object1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/* 481 */     if (!validCompound(paramNBTCompound)) {
/*     */       return;
/*     */     }
/* 484 */     Object object2 = getToCompount(object1, paramNBTCompound);
/*     */     try {
/* 486 */       ReflectionMethod.COMPOUND_SET.run(object2, new Object[] { paramString, ClassWrapper.NMS_NBTTAGCOMPOUND
/* 487 */             .getClazz().newInstance() });
/* 488 */       paramNBTCompound.setCompound(object1);
/* 489 */     } catch (Exception exception) {
/* 490 */       throw new NbtApiException("Exception while adding a Compound!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validCompound(NBTCompound paramNBTCompound) {
/* 501 */     Object object1 = paramNBTCompound.getCompound();
/* 502 */     if (object1 instanceof Optional) {
/* 503 */       object1 = ((Optional)object1).orElse(null);
/*     */     }
/* 505 */     if (object1 == null) {
/* 506 */       object1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/* 508 */     Object object2 = getToCompount(object1, paramNBTCompound);
/* 509 */     paramNBTCompound.setResolvedObject(object2);
/* 510 */     return (object2 != null);
/*     */   }
/*     */   
/*     */   public static Object getToCompount(Object paramObject, NBTCompound paramNBTCompound) {
/* 514 */     ArrayDeque<String> arrayDeque = new ArrayDeque();
/* 515 */     while (paramNBTCompound.getParent() != null) {
/* 516 */       arrayDeque.add(paramNBTCompound.getName());
/* 517 */       paramNBTCompound = paramNBTCompound.getParent();
/*     */     } 
/* 519 */     if (paramObject instanceof Optional) {
/* 520 */       paramObject = ((Optional)paramObject).orElse(null);
/*     */     }
/* 522 */     while (!arrayDeque.isEmpty()) {
/* 523 */       String str = arrayDeque.pollLast();
/* 524 */       paramObject = getSubNBTTagCompound(paramObject, str);
/* 525 */       if (paramObject instanceof Optional) {
/* 526 */         paramObject = ((Optional)paramObject).orElse(null);
/*     */       }
/* 528 */       if (paramObject == null) {
/* 529 */         throw new NbtApiException("Unable to find tag '" + str + "' in " + paramObject);
/*     */       }
/*     */     } 
/* 532 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void mergeOtherNBTCompound(NBTCompound paramNBTCompound1, NBTCompound paramNBTCompound2) {
/* 542 */     Object object1 = paramNBTCompound2.getResolvedObject();
/* 543 */     if (object1 == null) {
/*     */       return;
/*     */     }
/* 546 */     Object object2 = paramNBTCompound1.getCompound();
/* 547 */     if (object2 == null) {
/* 548 */       object2 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/* 550 */     if (!validCompound(paramNBTCompound1))
/* 551 */       throw new NbtApiException("The Compound wasn't able to be linked back to the root!"); 
/* 552 */     Object object3 = getToCompount(object2, paramNBTCompound1);
/*     */     try {
/* 554 */       ReflectionMethod.COMPOUND_MERGE.run(object3, new Object[] { object1 });
/* 555 */       paramNBTCompound1.setCompound(object2);
/* 556 */     } catch (Exception exception) {
/* 557 */       throw new NbtApiException("Exception while merging two NBTCompounds!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void set(NBTCompound paramNBTCompound, String paramString, Object paramObject) {
/* 569 */     if (paramObject == null) {
/* 570 */       remove(paramNBTCompound, paramString);
/*     */       return;
/*     */     } 
/* 573 */     Object object1 = paramNBTCompound.getCompound();
/* 574 */     if (object1 == null) {
/* 575 */       object1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/* 577 */     if (!validCompound(paramNBTCompound)) {
/* 578 */       throw new NbtApiException("The Compound wasn't able to be linked back to the root!");
/*     */     }
/* 580 */     Object object2 = getToCompount(object1, paramNBTCompound);
/*     */     try {
/* 582 */       ReflectionMethod.COMPOUND_SET.run(object2, new Object[] { paramString, paramObject });
/* 583 */       paramNBTCompound.setCompound(object1);
/* 584 */     } catch (Exception exception) {
/* 585 */       throw new NbtApiException("Exception while setting key '" + paramString + "' to '" + paramObject + "'!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> NBTList<T> getList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Class<T> paramClass) {
/* 600 */     Object object = paramNBTCompound.getResolvedObject();
/* 601 */     if (object == null) {
/* 602 */       object = dummyNBT.getCompound();
/*     */     }
/*     */     try {
/* 605 */       Object object1 = null;
/* 606 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4)) {
/* 607 */         object1 = ReflectionMethod.COMPOUND_GET_LIST.run(object, new Object[] { paramString });
/* 608 */         if (object1 instanceof Optional) {
/* 609 */           object1 = ((Optional)object1).orElse(null);
/*     */         }
/* 611 */         if (object1 == null) {
/* 612 */           object1 = ClassWrapper.NMS_NBTTAGLIST.getClazz().newInstance();
/*     */         }
/*     */       } else {
/* 615 */         object1 = ReflectionMethod.COMPOUND_GET_LIST_LEGACY.run(object, new Object[] { paramString, Integer.valueOf(paramNBTType.getId()) });
/*     */       } 
/* 617 */       if (paramClass == String.class)
/* 618 */         return new NBTStringList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 619 */       if (paramClass == NBTListCompound.class)
/* 620 */         return new NBTCompoundList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 621 */       if (paramClass == Integer.class)
/* 622 */         return new NBTIntegerList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 623 */       if (paramClass == Float.class)
/* 624 */         return new NBTFloatList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 625 */       if (paramClass == Double.class)
/* 626 */         return new NBTDoubleList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 627 */       if (paramClass == Long.class)
/* 628 */         return new NBTLongList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 629 */       if (paramClass == int[].class)
/* 630 */         return new NBTIntArrayList(paramNBTCompound, paramString, paramNBTType, object1); 
/* 631 */       if (paramClass == UUID.class) {
/* 632 */         return new NBTUUIDList(paramNBTCompound, paramString, paramNBTType, object1);
/*     */       }
/* 634 */       return null;
/*     */     }
/* 636 */     catch (Exception exception) {
/* 637 */       throw new NbtApiException("Exception while getting a list with the type '" + paramNBTType + "'!", exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static NBTType getListType(NBTCompound paramNBTCompound, String paramString) {
/* 642 */     Object object = paramNBTCompound.getResolvedObject();
/* 643 */     if (object == null)
/* 644 */       object = dummyNBT.getCompound(); 
/*     */     try {
/*     */       Field field;
/* 647 */       Object object1 = ReflectionMethod.COMPOUND_GET.run(object, new Object[] { paramString });
/* 648 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4)) {
/* 649 */         if (object1 instanceof Optional) {
/* 650 */           object1 = ((Optional)object1).orElse(null);
/*     */         }
/* 652 */         if (object1 == null) {
/* 653 */           return NBTType.NBTTagEnd;
/*     */         }
/* 655 */         if ((new NBTStringList(paramNBTCompound, paramString, NBTType.NBTTagString, object1)).isEmpty()) {
/* 656 */           return NBTType.NBTTagEnd;
/*     */         }
/* 658 */         Object object2 = ReflectionMethod.LIST_GET.run(object1, new Object[] { Integer.valueOf(0) });
/* 659 */         if (object2 instanceof Optional) {
/* 660 */           object2 = ((Optional)object2).orElse(null);
/*     */         }
/* 662 */         if (object2 == null) {
/* 663 */           return NBTType.NBTTagEnd;
/*     */         }
/* 665 */         return NBTType.fromName((String)ReflectionMethod.TAGTYPE_GET_NAME
/* 666 */             .run(ReflectionMethod.TAGTYPE_OWN_TYPE.run(object2, new Object[0]), new Object[0]));
/*     */       } 
/* 668 */       String str = "type";
/* 669 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_17_R1)) {
/* 670 */         str = "w";
/*     */       }
/*     */       
/*     */       try {
/* 674 */         field = object1.getClass().getDeclaredField(str);
/* 675 */       } catch (NoSuchFieldException noSuchFieldException) {
/*     */         
/* 677 */         field = object1.getClass().getDeclaredField("type");
/*     */       } 
/* 679 */       field.setAccessible(true);
/* 680 */       return NBTType.valueOf(field.getByte(object1));
/* 681 */     } catch (Exception exception) {
/* 682 */       throw new NbtApiException("Exception while getting the list type!", exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Object getEntry(NBTCompound paramNBTCompound, String paramString) {
/* 687 */     Object object = paramNBTCompound.getResolvedObject();
/*     */     try {
/* 689 */       return ReflectionMethod.COMPOUND_GET.run(object, new Object[] { paramString });
/* 690 */     } catch (Exception exception) {
/* 691 */       throw new NbtApiException("Exception while getting an Entry!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setObject(NBTCompound paramNBTCompound, String paramString, Object paramObject) {
/* 703 */     if (!MinecraftVersion.hasGsonSupport())
/*     */       return; 
/*     */     try {
/* 706 */       String str = GsonWrapper.getString(paramObject);
/* 707 */       setData(paramNBTCompound, ReflectionMethod.COMPOUND_SET_STRING, paramString, str);
/* 708 */     } catch (Exception exception) {
/* 709 */       throw new NbtApiException("Exception while setting the Object '" + paramObject + "'!", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getObject(NBTCompound paramNBTCompound, String paramString, Class<T> paramClass) {
/* 722 */     if (!MinecraftVersion.hasGsonSupport())
/* 723 */       return null; 
/* 724 */     String str = (String)getData(paramNBTCompound, ReflectionMethod.COMPOUND_GET_STRING, paramString);
/* 725 */     if (str == null) {
/* 726 */       return null;
/*     */     }
/* 728 */     return (T)GsonWrapper.deserializeJson(str, paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(NBTCompound paramNBTCompound, String paramString) {
/* 738 */     Object object1 = paramNBTCompound.getCompound();
/* 739 */     if (object1 == null) {
/*     */       return;
/*     */     }
/* 742 */     if (!validCompound(paramNBTCompound))
/*     */       return; 
/* 744 */     Object object2 = getToCompount(object1, paramNBTCompound);
/* 745 */     ReflectionMethod.COMPOUND_REMOVE_KEY.run(object2, new Object[] { paramString });
/* 746 */     paramNBTCompound.setCompound(object1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<String> getKeys(NBTCompound paramNBTCompound) {
/* 757 */     Object object = paramNBTCompound.getResolvedObject();
/* 758 */     if (object == null) {
/* 759 */       return Collections.emptySet();
/*     */     }
/* 761 */     return (Set<String>)ReflectionMethod.COMPOUND_GET_KEYS.run(object, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setData(NBTCompound paramNBTCompound, ReflectionMethod paramReflectionMethod, String paramString, Object paramObject) {
/* 773 */     if (paramObject == null) {
/* 774 */       remove(paramNBTCompound, paramString);
/*     */       return;
/*     */     } 
/* 777 */     Object object1 = paramNBTCompound.getCompound();
/* 778 */     if (object1 == null) {
/* 779 */       object1 = ObjectCreator.NMS_NBTTAGCOMPOUND.getInstance(new Object[0]);
/*     */     }
/* 781 */     if (!validCompound(paramNBTCompound))
/* 782 */       throw new NbtApiException("The Compound wasn't able to be linked back to the root!"); 
/* 783 */     Object object2 = getToCompount(object1, paramNBTCompound);
/* 784 */     paramReflectionMethod.run(object2, new Object[] { paramString, paramObject });
/* 785 */     paramNBTCompound.setCompound(object1);
/*     */   }
/*     */   
/* 788 */   private static final NBTContainer dummyNBT = new NBTContainer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getData(NBTCompound paramNBTCompound, ReflectionMethod paramReflectionMethod, String paramString) {
/* 799 */     Object object1 = paramNBTCompound.getResolvedObject();
/*     */     
/* 801 */     if (object1 == null) {
/* 802 */       object1 = dummyNBT.getCompound();
/*     */     }
/* 804 */     if (object1 instanceof Optional) {
/* 805 */       object1 = ((Optional)object1).orElseGet(() -> dummyNBT.getCompound());
/*     */     }
/* 807 */     Object object2 = paramReflectionMethod.run(object1, new Object[] { paramString });
/* 808 */     if (object2 instanceof Optional) {
/* 809 */       return ((Optional)object2).orElseGet(() -> getDefaultValue(paramReflectionMethod));
/*     */     }
/* 811 */     return object2;
/*     */   }
/*     */   
/*     */   private static Object getDefaultValue(ReflectionMethod paramReflectionMethod) {
/* 815 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_STRING)
/* 816 */       return ""; 
/* 817 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_BYTE)
/* 818 */       return Byte.valueOf((byte)0); 
/* 819 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_SHORT)
/* 820 */       return Short.valueOf((short)0); 
/* 821 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_BOOLEAN)
/* 822 */       return Boolean.valueOf(false); 
/* 823 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_INT)
/* 824 */       return Integer.valueOf(0); 
/* 825 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_LONG)
/* 826 */       return Long.valueOf(0L); 
/* 827 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_FLOAT)
/* 828 */       return Float.valueOf(0.0F); 
/* 829 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_DOUBLE)
/* 830 */       return Double.valueOf(0.0D); 
/* 831 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_BYTEARRAY)
/* 832 */       return new byte[0]; 
/* 833 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_INTARRAY)
/* 834 */       return new int[0]; 
/* 835 */     if (paramReflectionMethod == ReflectionMethod.COMPOUND_GET_LONGARRAY) {
/* 836 */       return new long[0];
/*     */     }
/* 838 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTReflectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */