/*      */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*      */ 
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTHandler;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTCompoundList;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTList;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.CheckUtil;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.PathUtil;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.UUIDUtil;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.Forge1710Mappings;
/*      */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*      */ import java.io.OutputStream;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.locks.Lock;
/*      */ import java.util.concurrent.locks.ReadWriteLock;
/*      */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NBTCompound
/*      */   implements ReadWriteNBT
/*      */ {
/*   37 */   private final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
/*   38 */   private final Lock readLock = this.readWriteLock.readLock();
/*   39 */   private final Lock writeLock = this.readWriteLock.writeLock();
/*      */   
/*      */   private String compundName;
/*      */   private NBTCompound parent;
/*      */   private final boolean readOnly;
/*      */   private Object readOnlyCache;
/*      */   
/*      */   protected NBTCompound(NBTCompound paramNBTCompound, String paramString) {
/*   47 */     this(paramNBTCompound, paramString, false);
/*      */   }
/*      */   
/*      */   protected NBTCompound(NBTCompound paramNBTCompound, String paramString, boolean paramBoolean) {
/*   51 */     this.compundName = paramString;
/*   52 */     this.parent = paramNBTCompound;
/*   53 */     this.readOnly = paramBoolean;
/*      */   }
/*      */   
/*      */   protected Lock getReadLock() {
/*   57 */     return this.readLock;
/*      */   }
/*      */   
/*      */   protected Lock getWriteLock() {
/*   61 */     return this.writeLock;
/*      */   }
/*      */   
/*      */   protected void saveCompound() {
/*   65 */     if (this.parent != null)
/*   66 */       this.parent.saveCompound(); 
/*      */   }
/*      */   
/*      */   protected void setResolvedObject(Object paramObject) {
/*   70 */     if (isClosed()) {
/*   71 */       throw new NbtApiException("Tried using closed NBT data!");
/*      */     }
/*   73 */     if (this.readOnly) {
/*   74 */       this.readOnlyCache = paramObject;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setClosed() {
/*   79 */     if (this.parent != null) {
/*   80 */       this.parent.setClosed();
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean isClosed() {
/*   85 */     if (this.parent != null) {
/*   86 */       return this.parent.isClosed();
/*      */     }
/*   88 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean isReadOnly() {
/*   92 */     return this.readOnly;
/*      */   }
/*      */   
/*      */   protected Object getResolvedObject() {
/*   96 */     if (isClosed()) {
/*   97 */       throw new NbtApiException("Tried using closed NBT data!");
/*      */     }
/*   99 */     if (this.readOnlyCache != null) {
/*  100 */       return this.readOnlyCache;
/*      */     }
/*  102 */     Object object1 = getCompound();
/*  103 */     if (object1 instanceof Optional) {
/*  104 */       object1 = ((Optional)object1).orElse(null);
/*      */     }
/*  106 */     if (object1 == null) {
/*  107 */       return null;
/*      */     }
/*  109 */     if (!NBTReflectionUtil.validCompound(this))
/*  110 */       throw new NbtApiException("The Compound wasn't able to be linked back to the root!"); 
/*  111 */     Object object2 = NBTReflectionUtil.getToCompount(object1, this);
/*  112 */     if (this.readOnly) {
/*  113 */       this.readOnlyCache = object2;
/*      */     }
/*  115 */     return object2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  122 */     return this.compundName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCompound() {
/*  129 */     return this.parent.getCompound();
/*      */   }
/*      */   
/*      */   protected void setCompound(Object paramObject) {
/*  133 */     this.parent.setCompound(paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTCompound getParent() {
/*  140 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mergeCompound(NBTCompound paramNBTCompound) {
/*  150 */     if (paramNBTCompound == null) {
/*      */       return;
/*      */     }
/*      */     try {
/*  154 */       this.writeLock.lock();
/*  155 */       NBTReflectionUtil.mergeOtherNBTCompound(this, paramNBTCompound);
/*  156 */       saveCompound();
/*      */     } finally {
/*  158 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void mergeCompound(ReadableNBT paramReadableNBT) {
/*  164 */     if (paramReadableNBT instanceof NBTCompound) {
/*  165 */       mergeCompound((NBTCompound)paramReadableNBT);
/*      */     } else {
/*  167 */       throw new NbtApiException("Unknown NBT object: " + paramReadableNBT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) {
/*      */     try {
/*  180 */       this.writeLock.lock();
/*  181 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_STRING, paramString1, paramString2);
/*  182 */       saveCompound();
/*      */     } finally {
/*  184 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) {
/*      */     try {
/*  197 */       this.readLock.lock();
/*  198 */       return (String)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_STRING, paramString);
/*      */     } finally {
/*  200 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInteger(String paramString, Integer paramInteger) {
/*      */     try {
/*  213 */       this.writeLock.lock();
/*  214 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_INT, paramString, paramInteger);
/*  215 */       saveCompound();
/*      */     } finally {
/*  217 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer getInteger(String paramString) {
/*      */     try {
/*  230 */       this.readLock.lock();
/*  231 */       return (Integer)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_INT, paramString);
/*      */     } finally {
/*  233 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, Double paramDouble) {
/*      */     try {
/*  246 */       this.writeLock.lock();
/*  247 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_DOUBLE, paramString, paramDouble);
/*  248 */       saveCompound();
/*      */     } finally {
/*  250 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Double getDouble(String paramString) {
/*      */     try {
/*  263 */       this.readLock.lock();
/*  264 */       return (Double)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_DOUBLE, paramString);
/*      */     } finally {
/*  266 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, Byte paramByte) {
/*      */     try {
/*  279 */       this.writeLock.lock();
/*  280 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BYTE, paramString, paramByte);
/*  281 */       saveCompound();
/*      */     } finally {
/*  283 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Byte getByte(String paramString) {
/*      */     try {
/*  296 */       this.readLock.lock();
/*  297 */       return (Byte)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BYTE, paramString);
/*      */     } finally {
/*  299 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, Short paramShort) {
/*      */     try {
/*  312 */       this.writeLock.lock();
/*  313 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_SHORT, paramString, paramShort);
/*  314 */       saveCompound();
/*      */     } finally {
/*  316 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Short getShort(String paramString) {
/*      */     try {
/*  329 */       this.readLock.lock();
/*  330 */       return (Short)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_SHORT, paramString);
/*      */     } finally {
/*  332 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, Long paramLong) {
/*      */     try {
/*  345 */       this.writeLock.lock();
/*  346 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_LONG, paramString, paramLong);
/*  347 */       saveCompound();
/*      */     } finally {
/*  349 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Long getLong(String paramString) {
/*      */     try {
/*  362 */       this.readLock.lock();
/*  363 */       return (Long)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_LONG, paramString);
/*      */     } finally {
/*  365 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, Float paramFloat) {
/*      */     try {
/*  378 */       this.writeLock.lock();
/*  379 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_FLOAT, paramString, paramFloat);
/*  380 */       saveCompound();
/*      */     } finally {
/*  382 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Float getFloat(String paramString) {
/*      */     try {
/*  395 */       this.readLock.lock();
/*  396 */       return (Float)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_FLOAT, paramString);
/*      */     } finally {
/*  398 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByteArray(String paramString, byte[] paramArrayOfbyte) {
/*      */     try {
/*  411 */       this.writeLock.lock();
/*  412 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BYTEARRAY, paramString, paramArrayOfbyte);
/*  413 */       saveCompound();
/*      */     } finally {
/*  415 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getByteArray(String paramString) {
/*      */     try {
/*  428 */       this.readLock.lock();
/*  429 */       return (byte[])NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BYTEARRAY, paramString);
/*      */     } finally {
/*  431 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIntArray(String paramString, int[] paramArrayOfint) {
/*      */     try {
/*  444 */       this.writeLock.lock();
/*  445 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_INTARRAY, paramString, paramArrayOfint);
/*  446 */       saveCompound();
/*      */     } finally {
/*  448 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getIntArray(String paramString) {
/*      */     try {
/*  461 */       this.readLock.lock();
/*  462 */       return (int[])NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_INTARRAY, paramString);
/*      */     } finally {
/*  464 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLongArray(String paramString, long[] paramArrayOflong) {
/*  478 */     CheckUtil.assertAvailable(MinecraftVersion.MC1_16_R1);
/*      */     try {
/*  480 */       this.writeLock.lock();
/*  481 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_LONGARRAY, paramString, paramArrayOflong);
/*  482 */       saveCompound();
/*      */     } finally {
/*  484 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long[] getLongArray(String paramString) {
/*  498 */     CheckUtil.assertAvailable(MinecraftVersion.MC1_16_R1);
/*      */     try {
/*  500 */       this.readLock.lock();
/*  501 */       return (long[])NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_LONGARRAY, paramString);
/*      */     } finally {
/*  503 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, Boolean paramBoolean) {
/*      */     try {
/*  516 */       this.writeLock.lock();
/*  517 */       NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_BOOLEAN, paramString, paramBoolean);
/*  518 */       saveCompound();
/*      */     } finally {
/*  520 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void set(String paramString, Object paramObject) {
/*  525 */     NBTReflectionUtil.set(this, paramString, paramObject);
/*  526 */     saveCompound();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean getBoolean(String paramString) {
/*      */     try {
/*  538 */       this.readLock.lock();
/*  539 */       return (Boolean)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_BOOLEAN, paramString);
/*      */     } finally {
/*  541 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setObject(String paramString, Object paramObject) {
/*      */     try {
/*  555 */       this.writeLock.lock();
/*  556 */       NBTReflectionUtil.setObject(this, paramString, paramObject);
/*  557 */       saveCompound();
/*      */     } finally {
/*  559 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public <T> T getObject(String paramString, Class<T> paramClass) {
/*      */     try {
/*  574 */       this.readLock.lock();
/*  575 */       return (T)NBTReflectionUtil.getObject(this, paramString, (Class)paramClass);
/*      */     } finally {
/*  577 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemStack(String paramString, ItemStack paramItemStack) {
/*      */     try {
/*  590 */       this.writeLock.lock();
/*  591 */       removeKey(paramString);
/*  592 */       addCompound(paramString).mergeCompound(NBTItem.convertItemtoNBT(paramItemStack));
/*      */     } finally {
/*  594 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ItemStack getItemStack(String paramString) {
/*      */     try {
/*  607 */       this.readLock.lock();
/*  608 */       NBTCompound nBTCompound = getCompound(paramString);
/*  609 */       if (nBTCompound == null)
/*  610 */         return null; 
/*  611 */       return NBTItem.convertNBTtoItem(nBTCompound);
/*      */     } finally {
/*  613 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setItemStackArray(String paramString, ItemStack[] paramArrayOfItemStack) {
/*      */     try {
/*  626 */       this.writeLock.lock();
/*  627 */       removeKey(paramString);
/*  628 */       addCompound(paramString).mergeCompound(NBTItem.convertItemArraytoNBT(paramArrayOfItemStack));
/*      */     } finally {
/*  630 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ItemStack[] getItemStackArray(String paramString) {
/*      */     try {
/*  645 */       this.readLock.lock();
/*  646 */       NBTCompound nBTCompound = getCompound(paramString);
/*  647 */       if (nBTCompound == null)
/*  648 */         return null; 
/*  649 */       return NBTItem.convertNBTtoItemArray(nBTCompound);
/*      */     } finally {
/*  651 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUUID(String paramString, UUID paramUUID) {
/*      */     try {
/*  664 */       this.writeLock.lock();
/*  665 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4)) {
/*  666 */         setIntArray(paramString, UUIDUtil.uuidToIntArray(paramUUID));
/*  667 */       } else if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_16_R1)) {
/*  668 */         NBTReflectionUtil.setData(this, ReflectionMethod.COMPOUND_SET_UUID, paramString, paramUUID);
/*      */       } else {
/*  670 */         setString(paramString, paramUUID.toString());
/*      */       } 
/*  672 */       saveCompound();
/*      */     } finally {
/*  674 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UUID getUUID(String paramString) {
/*      */     try {
/*  687 */       this.readLock.lock();
/*  688 */       NBTType nBTType = getType(paramString);
/*  689 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4) && nBTType == NBTType.NBTTagIntArray)
/*  690 */         return UUIDUtil.uuidFromIntArray(getIntArray(paramString)); 
/*  691 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_16_R1) && nBTType == NBTType.NBTTagIntArray)
/*      */       {
/*  693 */         return (UUID)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_UUID, paramString); } 
/*  694 */       if (nBTType == NBTType.NBTTagString) {
/*      */         try {
/*  696 */           return UUID.fromString(getString(paramString));
/*  697 */         } catch (IllegalArgumentException illegalArgumentException) {
/*  698 */           return null;
/*      */         } 
/*      */       }
/*  701 */       return null;
/*      */     } finally {
/*      */       
/*  704 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Boolean hasKey(String paramString) {
/*  717 */     return Boolean.valueOf(hasTag(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTag(String paramString) {
/*      */     try {
/*  729 */       this.readLock.lock();
/*  730 */       Boolean bool = (Boolean)NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_HAS_KEY, paramString);
/*  731 */       if (bool == null)
/*  732 */         return false; 
/*  733 */       return bool.booleanValue();
/*      */     } finally {
/*  735 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeKey(String paramString) {
/*      */     try {
/*  745 */       this.writeLock.lock();
/*  746 */       NBTReflectionUtil.remove(this, paramString);
/*  747 */       saveCompound();
/*      */     } finally {
/*  749 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getKeys() {
/*      */     try {
/*  759 */       this.readLock.lock();
/*  760 */       return new HashSet<>(NBTReflectionUtil.getKeys(this));
/*      */     } finally {
/*  762 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTCompound addCompound(String paramString) {
/*      */     try {
/*  774 */       this.writeLock.lock();
/*  775 */       if (getType(paramString) == NBTType.NBTTagCompound)
/*  776 */         return getCompound(paramString); 
/*  777 */       NBTReflectionUtil.addNBTTagCompound(this, paramString);
/*  778 */       NBTCompound nBTCompound = getCompound(paramString);
/*  779 */       if (nBTCompound == null)
/*  780 */         throw new NbtApiException("Error while adding Compound, got null!"); 
/*  781 */       saveCompound();
/*  782 */       return nBTCompound;
/*      */     } finally {
/*  784 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTCompound getCompound(String paramString) {
/*      */     try {
/*  795 */       this.readLock.lock();
/*  796 */       if (getType(paramString) != NBTType.NBTTagCompound)
/*  797 */         return null; 
/*  798 */       NBTCompound nBTCompound = new NBTCompound(this, paramString, this.readOnly);
/*  799 */       if (NBTReflectionUtil.validCompound(nBTCompound))
/*  800 */         return nBTCompound; 
/*  801 */       return null;
/*      */     } finally {
/*  803 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTCompound getOrCreateCompound(String paramString) {
/*  815 */     return addCompound(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<String> getStringList(String paramString) {
/*      */     try {
/*  825 */       this.writeLock.lock();
/*  826 */       NBTList<String> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagString, String.class);
/*  827 */       saveCompound();
/*  828 */       return nBTList;
/*      */     } finally {
/*  830 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<Integer> getIntegerList(String paramString) {
/*      */     try {
/*  841 */       this.writeLock.lock();
/*  842 */       NBTList<Integer> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagInt, Integer.class);
/*  843 */       saveCompound();
/*  844 */       return nBTList;
/*      */     } finally {
/*  846 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<int[]> getIntArrayList(String paramString) {
/*      */     try {
/*  857 */       this.writeLock.lock();
/*  858 */       NBTList<int> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagIntArray, (Class)int[].class);
/*  859 */       saveCompound();
/*  860 */       return (NBTList)nBTList;
/*      */     } finally {
/*  862 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<UUID> getUUIDList(String paramString) {
/*      */     try {
/*  873 */       this.writeLock.lock();
/*  874 */       NBTList<UUID> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagIntArray, UUID.class);
/*  875 */       saveCompound();
/*  876 */       return nBTList;
/*      */     } finally {
/*  878 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<Float> getFloatList(String paramString) {
/*      */     try {
/*  889 */       this.writeLock.lock();
/*  890 */       NBTList<Float> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagFloat, Float.class);
/*  891 */       saveCompound();
/*  892 */       return nBTList;
/*      */     } finally {
/*  894 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<Double> getDoubleList(String paramString) {
/*      */     try {
/*  905 */       this.writeLock.lock();
/*  906 */       NBTList<Double> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagDouble, Double.class);
/*  907 */       saveCompound();
/*  908 */       return nBTList;
/*      */     } finally {
/*  910 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTList<Long> getLongList(String paramString) {
/*      */     try {
/*  921 */       this.writeLock.lock();
/*  922 */       NBTList<Long> nBTList = NBTReflectionUtil.getList(this, paramString, NBTType.NBTTagLong, Long.class);
/*  923 */       saveCompound();
/*  924 */       return nBTList;
/*      */     } finally {
/*  926 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTType getListType(String paramString) {
/*      */     try {
/*  939 */       this.readLock.lock();
/*  940 */       if (getType(paramString) != NBTType.NBTTagList)
/*  941 */         return null; 
/*  942 */       return NBTReflectionUtil.getListType(this, paramString);
/*      */     } finally {
/*  944 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTCompoundList getCompoundList(String paramString) {
/*      */     try {
/*  955 */       this.writeLock.lock();
/*  956 */       NBTCompoundList nBTCompoundList = (NBTCompoundList)NBTReflectionUtil.<NBTListCompound>getList(this, paramString, NBTType.NBTTagCompound, NBTListCompound.class);
/*      */       
/*  958 */       saveCompound();
/*  959 */       return nBTCompoundList;
/*      */     } finally {
/*  961 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getOrDefault(String paramString, T paramT) {
/*  980 */     if (paramT == null)
/*  981 */       throw new NullPointerException("Default type in getOrDefault can't be null!"); 
/*  982 */     if (!hasTag(paramString)) {
/*  983 */       return paramT;
/*      */     }
/*  985 */     Class<?> clazz = paramT.getClass();
/*  986 */     if (clazz == Boolean.class || clazz == boolean.class)
/*  987 */       return (T)getBoolean(paramString); 
/*  988 */     if (clazz == Byte.class || clazz == byte.class)
/*  989 */       return (T)getByte(paramString); 
/*  990 */     if (clazz == Short.class || clazz == short.class)
/*  991 */       return (T)getShort(paramString); 
/*  992 */     if (clazz == Integer.class || clazz == int.class)
/*  993 */       return (T)getInteger(paramString); 
/*  994 */     if (clazz == Long.class || clazz == long.class)
/*  995 */       return (T)getLong(paramString); 
/*  996 */     if (clazz == Float.class || clazz == float.class)
/*  997 */       return (T)getFloat(paramString); 
/*  998 */     if (clazz == Double.class || clazz == double.class)
/*  999 */       return (T)getDouble(paramString); 
/* 1000 */     if (clazz == byte[].class)
/* 1001 */       return (T)getByteArray(paramString); 
/* 1002 */     if (clazz == int[].class)
/* 1003 */       return (T)getIntArray(paramString); 
/* 1004 */     if (clazz == long[].class)
/* 1005 */       return (T)getLongArray(paramString); 
/* 1006 */     if (clazz == String.class)
/* 1007 */       return (T)getString(paramString); 
/* 1008 */     if (clazz == UUID.class) {
/* 1009 */       UUID uUID = getUUID(paramString);
/* 1010 */       return (uUID == null) ? paramT : (T)uUID;
/*      */     } 
/* 1012 */     if (clazz.isEnum()) {
/*      */       
/* 1014 */       T t = (T)getEnum(paramString, (Class)paramT.getClass());
/* 1015 */       return (t == null) ? paramT : t;
/*      */     } 
/*      */     
/* 1018 */     throw new NbtApiException("Unsupported type for getOrDefault: " + clazz.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T getOrNull(String paramString, Class<?> paramClass) {
/* 1036 */     if (paramClass == null)
/* 1037 */       throw new NullPointerException("Default type in getOrNull can't be null!"); 
/* 1038 */     if (!hasTag(paramString)) {
/* 1039 */       return null;
/*      */     }
/* 1041 */     if (paramClass == Boolean.class || paramClass == boolean.class)
/* 1042 */       return (T)getBoolean(paramString); 
/* 1043 */     if (paramClass == Byte.class || paramClass == byte.class)
/* 1044 */       return (T)getByte(paramString); 
/* 1045 */     if (paramClass == Short.class || paramClass == short.class)
/* 1046 */       return (T)getShort(paramString); 
/* 1047 */     if (paramClass == Integer.class || paramClass == int.class)
/* 1048 */       return (T)getInteger(paramString); 
/* 1049 */     if (paramClass == Long.class || paramClass == long.class)
/* 1050 */       return (T)getLong(paramString); 
/* 1051 */     if (paramClass == Float.class || paramClass == float.class)
/* 1052 */       return (T)getFloat(paramString); 
/* 1053 */     if (paramClass == Double.class || paramClass == double.class)
/* 1054 */       return (T)getDouble(paramString); 
/* 1055 */     if (paramClass == byte[].class)
/* 1056 */       return (T)getByteArray(paramString); 
/* 1057 */     if (paramClass == int[].class)
/* 1058 */       return (T)getIntArray(paramString); 
/* 1059 */     if (paramClass == long[].class)
/* 1060 */       return (T)getLongArray(paramString); 
/* 1061 */     if (paramClass == String.class)
/* 1062 */       return (T)getString(paramString); 
/* 1063 */     if (paramClass == UUID.class)
/* 1064 */       return (T)getUUID(paramString); 
/* 1065 */     if (paramClass.isEnum()) {
/* 1066 */       return getEnum(paramString, (Class)paramClass);
/*      */     }
/* 1068 */     throw new NbtApiException("Unsupported type for getOrNull: " + paramClass.getName());
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T resolveOrNull(String paramString, Class<?> paramClass) {
/* 1073 */     List<PathUtil.PathSegment> list = PathUtil.splitPath(paramString);
/* 1074 */     NBTCompound nBTCompound = this;
/* 1075 */     for (byte b = 0; b < list.size() - 1; b++) {
/* 1076 */       PathUtil.PathSegment pathSegment1 = list.get(b);
/* 1077 */       if (!pathSegment1.hasIndex()) {
/* 1078 */         nBTCompound = nBTCompound.getCompound(pathSegment1.getPath());
/* 1079 */         if (nBTCompound == null) {
/* 1080 */           return null;
/*      */         }
/*      */       }
/* 1083 */       else if (nBTCompound.getType(pathSegment1.getPath()) == NBTType.NBTTagList && nBTCompound
/* 1084 */         .getListType(pathSegment1.getPath()) == NBTType.NBTTagCompound) {
/* 1085 */         NBTCompoundList nBTCompoundList = nBTCompound.getCompoundList(pathSegment1.getPath());
/* 1086 */         if (pathSegment1.getIndex() >= 0) {
/* 1087 */           nBTCompound = nBTCompoundList.get(pathSegment1.getIndex());
/*      */         } else {
/* 1089 */           nBTCompound = nBTCompoundList.get(nBTCompoundList.size() + pathSegment1.getIndex());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1094 */     PathUtil.PathSegment pathSegment = list.get(list.size() - 1);
/* 1095 */     if (!pathSegment.hasIndex()) {
/* 1096 */       return nBTCompound.getOrNull(pathSegment.getPath(), paramClass);
/*      */     }
/* 1098 */     return getIndexedValue(nBTCompound, pathSegment, (Class)paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T resolveOrDefault(String paramString, T paramT) {
/* 1104 */     List<PathUtil.PathSegment> list = PathUtil.splitPath(paramString);
/* 1105 */     NBTCompound nBTCompound = this;
/* 1106 */     for (byte b = 0; b < list.size() - 1; b++) {
/* 1107 */       PathUtil.PathSegment pathSegment1 = list.get(b);
/* 1108 */       if (!pathSegment1.hasIndex()) {
/* 1109 */         nBTCompound = nBTCompound.getCompound(pathSegment1.getPath());
/* 1110 */         if (nBTCompound == null) {
/* 1111 */           return paramT;
/*      */         }
/*      */       }
/* 1114 */       else if (nBTCompound.getType(pathSegment1.getPath()) == NBTType.NBTTagList && nBTCompound
/* 1115 */         .getListType(pathSegment1.getPath()) == NBTType.NBTTagCompound) {
/* 1116 */         NBTCompoundList nBTCompoundList = nBTCompound.getCompoundList(pathSegment1.getPath());
/* 1117 */         if (pathSegment1.getIndex() >= 0) {
/* 1118 */           nBTCompound = nBTCompoundList.get(pathSegment1.getIndex());
/*      */         } else {
/* 1120 */           nBTCompound = nBTCompoundList.get(nBTCompoundList.size() + pathSegment1.getIndex());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1125 */     PathUtil.PathSegment pathSegment = list.get(list.size() - 1);
/* 1126 */     if (!pathSegment.hasIndex()) {
/* 1127 */       return nBTCompound.getOrDefault(pathSegment.getPath(), paramT);
/*      */     }
/* 1129 */     return getIndexedValue(nBTCompound, pathSegment, (Class)paramT.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> T getIndexedValue(NBTCompound paramNBTCompound, PathUtil.PathSegment paramPathSegment, Class<T> paramClass) {
/* 1136 */     if (paramClass == String.class) {
/* 1137 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1138 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagString) {
/* 1139 */         if (paramPathSegment.getIndex() >= 0) {
/* 1140 */           return (T)paramNBTCompound.getStringList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1142 */         NBTList<String> nBTList = paramNBTCompound.getStringList(paramPathSegment.getPath());
/* 1143 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/*      */       
/* 1146 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1148 */     if (paramClass == int.class || paramClass == Integer.class) {
/* 1149 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1150 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagInt) {
/* 1151 */         if (paramPathSegment.getIndex() >= 0) {
/* 1152 */           return (T)paramNBTCompound.getIntegerList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1154 */         NBTList<Integer> nBTList = paramNBTCompound.getIntegerList(paramPathSegment.getPath());
/* 1155 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/* 1157 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagIntArray) {
/* 1158 */         if (paramPathSegment.getIndex() >= 0) {
/* 1159 */           int[] arrayOfInt = paramNBTCompound.getIntArray(paramPathSegment.getPath());
/* 1160 */           if (arrayOfInt != null) {
/* 1161 */             return (T)Integer.valueOf(arrayOfInt[paramPathSegment.getIndex()]);
/*      */           }
/*      */         } else {
/* 1164 */           int[] arrayOfInt = paramNBTCompound.getIntArray(paramPathSegment.getPath());
/* 1165 */           if (arrayOfInt != null) {
/* 1166 */             return (T)Integer.valueOf(arrayOfInt[arrayOfInt.length + paramPathSegment.getIndex()]);
/*      */           }
/*      */         } 
/*      */       }
/* 1170 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1172 */     if (paramClass == long.class || paramClass == Long.class) {
/* 1173 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1174 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagLong) {
/* 1175 */         if (paramPathSegment.getIndex() >= 0) {
/* 1176 */           return (T)paramNBTCompound.getLongList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1178 */         NBTList<Long> nBTList = paramNBTCompound.getLongList(paramPathSegment.getPath());
/* 1179 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/* 1181 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagLongArray) {
/* 1182 */         if (paramPathSegment.getIndex() >= 0) {
/* 1183 */           long[] arrayOfLong = paramNBTCompound.getLongArray(paramPathSegment.getPath());
/* 1184 */           if (arrayOfLong != null) {
/* 1185 */             return (T)Long.valueOf(arrayOfLong[paramPathSegment.getIndex()]);
/*      */           }
/*      */         } else {
/* 1188 */           long[] arrayOfLong = paramNBTCompound.getLongArray(paramPathSegment.getPath());
/* 1189 */           if (arrayOfLong != null) {
/* 1190 */             return (T)Long.valueOf(arrayOfLong[arrayOfLong.length + paramPathSegment.getIndex()]);
/*      */           }
/*      */         } 
/*      */       }
/* 1194 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1196 */     if (paramClass == float.class || paramClass == Float.class) {
/* 1197 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1198 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagFloat) {
/* 1199 */         if (paramPathSegment.getIndex() >= 0) {
/* 1200 */           return (T)paramNBTCompound.getFloatList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1202 */         NBTList<Float> nBTList = paramNBTCompound.getFloatList(paramPathSegment.getPath());
/* 1203 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/*      */       
/* 1206 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1208 */     if (paramClass == double.class || paramClass == Double.class) {
/* 1209 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1210 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagDouble) {
/* 1211 */         if (paramPathSegment.getIndex() >= 0) {
/* 1212 */           return (T)paramNBTCompound.getDoubleList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1214 */         NBTList<Double> nBTList = paramNBTCompound.getDoubleList(paramPathSegment.getPath());
/* 1215 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/*      */       
/* 1218 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1220 */     if (paramClass == int[].class) {
/* 1221 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagList && paramNBTCompound
/* 1222 */         .getListType(paramPathSegment.getPath()) == NBTType.NBTTagIntArray) {
/* 1223 */         if (paramPathSegment.getIndex() >= 0) {
/* 1224 */           return (T)paramNBTCompound.getIntArrayList(paramPathSegment.getPath()).get(paramPathSegment.getIndex());
/*      */         }
/* 1226 */         NBTList<int[]> nBTList = paramNBTCompound.getIntArrayList(paramPathSegment.getPath());
/* 1227 */         return (T)nBTList.get(nBTList.size() + paramPathSegment.getIndex());
/*      */       } 
/*      */       
/* 1230 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1232 */     if (paramClass == byte.class || paramClass == Byte.class) {
/* 1233 */       if (paramNBTCompound.getType(paramPathSegment.getPath()) == NBTType.NBTTagByteArray) {
/* 1234 */         if (paramPathSegment.getIndex() >= 0) {
/* 1235 */           byte[] arrayOfByte = paramNBTCompound.getByteArray(paramPathSegment.getPath());
/* 1236 */           if (arrayOfByte != null) {
/* 1237 */             return (T)Byte.valueOf(arrayOfByte[paramPathSegment.getIndex()]);
/*      */           }
/*      */         } else {
/* 1240 */           byte[] arrayOfByte = paramNBTCompound.getByteArray(paramPathSegment.getPath());
/* 1241 */           if (arrayOfByte != null) {
/* 1242 */             return (T)Byte.valueOf(arrayOfByte[arrayOfByte.length + paramPathSegment.getIndex()]);
/*      */           }
/*      */         } 
/*      */       }
/* 1246 */       throw new NbtApiException("No fitting list/array found for " + paramPathSegment.getPath() + " of type " + paramClass);
/*      */     } 
/* 1248 */     throw new NbtApiException("Unable to get indexed value for type " + paramClass);
/*      */   }
/*      */ 
/*      */   
/*      */   public ReadWriteNBT resolveCompound(String paramString) {
/* 1253 */     List<PathUtil.PathSegment> list = PathUtil.splitPath(paramString);
/* 1254 */     NBTCompound nBTCompound = this;
/* 1255 */     for (byte b = 0; b < list.size(); b++) {
/* 1256 */       PathUtil.PathSegment pathSegment = list.get(b);
/* 1257 */       if (!pathSegment.hasIndex()) {
/* 1258 */         nBTCompound = nBTCompound.getCompound(pathSegment.getPath());
/* 1259 */         if (nBTCompound == null) {
/* 1260 */           return null;
/*      */         }
/*      */       }
/* 1263 */       else if (nBTCompound.getType(pathSegment.getPath()) == NBTType.NBTTagList && nBTCompound
/* 1264 */         .getListType(pathSegment.getPath()) == NBTType.NBTTagCompound) {
/* 1265 */         NBTCompoundList nBTCompoundList = nBTCompound.getCompoundList(pathSegment.getPath());
/* 1266 */         if (pathSegment.getIndex() >= 0) {
/* 1267 */           nBTCompound = nBTCompoundList.get(pathSegment.getIndex());
/*      */         } else {
/* 1269 */           nBTCompound = nBTCompoundList.get(nBTCompoundList.size() + pathSegment.getIndex());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1274 */     return nBTCompound;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReadWriteNBT resolveOrCreateCompound(String paramString) {
/* 1279 */     List<PathUtil.PathSegment> list = PathUtil.splitPath(paramString);
/* 1280 */     NBTCompound nBTCompound = this;
/* 1281 */     for (byte b = 0; b < list.size(); b++) {
/* 1282 */       PathUtil.PathSegment pathSegment = list.get(b);
/* 1283 */       if (!pathSegment.hasIndex()) {
/* 1284 */         nBTCompound = nBTCompound.getOrCreateCompound(pathSegment.getPath());
/* 1285 */         if (nBTCompound == null) {
/* 1286 */           return null;
/*      */         }
/*      */       }
/* 1289 */       else if (nBTCompound.getType(pathSegment.getPath()) == NBTType.NBTTagList && nBTCompound
/* 1290 */         .getListType(pathSegment.getPath()) == NBTType.NBTTagCompound) {
/* 1291 */         NBTCompoundList nBTCompoundList = nBTCompound.getCompoundList(pathSegment.getPath());
/* 1292 */         if (pathSegment.getIndex() >= 0) {
/* 1293 */           nBTCompound = nBTCompoundList.get(pathSegment.getIndex());
/*      */         } else {
/* 1295 */           nBTCompound = nBTCompoundList.get(nBTCompoundList.size() + pathSegment.getIndex());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1300 */     return nBTCompound;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Enum<?>> void setEnum(String paramString, E paramE) {
/* 1313 */     if (paramE == null) {
/* 1314 */       removeKey(paramString);
/*      */       return;
/*      */     } 
/* 1317 */     setString(paramString, paramE.name());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <E extends Enum<E>> E getEnum(String paramString, Class<E> paramClass) {
/* 1331 */     if (paramString == null || paramClass == null) {
/* 1332 */       return null;
/*      */     }
/* 1334 */     String str = getString(paramString);
/* 1335 */     if (str == null)
/* 1336 */       return null; 
/*      */     try {
/* 1338 */       return Enum.valueOf(paramClass, str);
/* 1339 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1340 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NBTType getType(String paramString) {
/*      */     try {
/* 1351 */       this.readLock.lock();
/* 1352 */       if (MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4) {
/* 1353 */         Object object1 = NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET, paramString);
/* 1354 */         if (object1 == null)
/* 1355 */           return null; 
/* 1356 */         return NBTType.valueOf(((Byte)ReflectionMethod.COMPOUND_OWN_TYPE_LEGACY.run(object1, new Object[0])).byteValue());
/*      */       } 
/* 1358 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_21_R4)) {
/* 1359 */         Object object1 = NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET, paramString);
/* 1360 */         if (object1 == null)
/* 1361 */           return null; 
/* 1362 */         return NBTType.fromName((String)ReflectionMethod.TAGTYPE_GET_NAME.run(ReflectionMethod.TAGTYPE_OWN_TYPE.run(object1, new Object[0]), new Object[0]));
/*      */       } 
/* 1364 */       Object object = NBTReflectionUtil.getData(this, ReflectionMethod.COMPOUND_GET_TYPE, paramString);
/* 1365 */       if (object == null)
/* 1366 */         return null; 
/* 1367 */       return NBTType.valueOf(((Byte)object).byteValue());
/*      */     } finally {
/* 1369 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeCompound(OutputStream paramOutputStream) {
/*      */     try {
/* 1376 */       this.writeLock.lock();
/* 1377 */       NBTReflectionUtil.writeApiNBT(this, paramOutputStream);
/*      */     } finally {
/* 1379 */       this.writeLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T get(String paramString, NBTHandler<T> paramNBTHandler) {
/* 1385 */     return (T)paramNBTHandler.get((ReadableNBT)this, paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> void set(String paramString, T paramT, NBTHandler<T> paramNBTHandler) {
/* 1390 */     paramNBTHandler.set(this, paramString, paramT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1399 */     return asNBTString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String toString(String paramString) {
/* 1416 */     return asNBTString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearNBT() {
/* 1424 */     for (String str : getKeys()) {
/* 1425 */       removeKey(str);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String asNBTString() {
/*      */     try {
/* 1437 */       this.readLock.lock();
/* 1438 */       Object object = getResolvedObject();
/* 1439 */       if (object == null)
/* 1440 */         return "{}"; 
/* 1441 */       if (MinecraftVersion.isForgePresent() && MinecraftVersion.getVersion() == MinecraftVersion.MC1_7_R4) {
/* 1442 */         return Forge1710Mappings.toString(object);
/*      */       }
/* 1444 */       return object.toString();
/*      */     } finally {
/*      */       
/* 1447 */       this.readLock.unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1453 */     return toString().hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object paramObject) {
/* 1461 */     if (this == paramObject)
/* 1462 */       return true; 
/* 1463 */     if (paramObject == null)
/* 1464 */       return false; 
/* 1465 */     if (paramObject instanceof NBTCompound) {
/* 1466 */       NBTCompound nBTCompound = (NBTCompound)paramObject;
/* 1467 */       if (getKeys().equals(nBTCompound.getKeys())) {
/* 1468 */         for (String str : getKeys()) {
/* 1469 */           if (!isEqual(this, nBTCompound, str)) {
/* 1470 */             return false;
/*      */           }
/*      */         } 
/* 1473 */         return true;
/*      */       } 
/*      */     } 
/* 1476 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public NBTCompound extractDifference(ReadableNBT paramReadableNBT) {
/* 1481 */     if (this == paramReadableNBT) {
/* 1482 */       return new NBTContainer();
/*      */     }
/* 1484 */     if (paramReadableNBT instanceof NBTCompound) {
/* 1485 */       return saveDiff(new NBTContainer(), this, (NBTCompound)paramReadableNBT);
/*      */     }
/* 1487 */     throw new NbtApiException("Unknown NBT object: " + paramReadableNBT);
/*      */   }
/*      */ 
/*      */   
/*      */   private static NBTCompound saveDiff(NBTCompound paramNBTCompound1, NBTCompound paramNBTCompound2, NBTCompound paramNBTCompound3) {
/* 1492 */     for (String str : paramNBTCompound2.getKeys()) {
/* 1493 */       saveDiff(paramNBTCompound1, paramNBTCompound2, paramNBTCompound3, str);
/*      */     }
/* 1495 */     return paramNBTCompound1;
/*      */   }
/*      */   private static void saveDiff(NBTCompound paramNBTCompound1, NBTCompound paramNBTCompound2, NBTCompound paramNBTCompound3, String paramString) {
/*      */     NBTCompound nBTCompound;
/* 1499 */     boolean bool = (paramNBTCompound2.getType(paramString) != paramNBTCompound3.getType(paramString)) ? true : false;
/* 1500 */     switch (paramNBTCompound2.getType(paramString)) {
/*      */       case NBTTagByte:
/* 1502 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1503 */           paramNBTCompound1.setByte(paramString, paramNBTCompound2.getByte(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagByteArray:
/* 1507 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1508 */           paramNBTCompound1.setByteArray(paramString, paramNBTCompound2.getByteArray(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagCompound:
/* 1512 */         nBTCompound = paramNBTCompound2.getCompound(paramString);
/* 1513 */         if (nBTCompound == null)
/* 1514 */           return;  if (bool) {
/* 1515 */           paramNBTCompound1.addCompound(paramString).mergeCompound(nBTCompound);
/*      */         } else {
/* 1517 */           NBTCompound nBTCompound1 = paramNBTCompound3.getCompound(paramString);
/* 1518 */           if (nBTCompound1 == null) {
/* 1519 */             paramNBTCompound1.addCompound(paramString).mergeCompound(nBTCompound);
/*      */             return;
/*      */           } 
/* 1522 */           NBTCompound nBTCompound2 = nBTCompound.extractDifference((ReadableNBT)nBTCompound1);
/* 1523 */           if (!nBTCompound2.getKeys().isEmpty()) {
/* 1524 */             paramNBTCompound1.addCompound(paramString).mergeCompound(nBTCompound2);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       
/*      */       case NBTTagDouble:
/* 1530 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1531 */           paramNBTCompound1.setDouble(paramString, paramNBTCompound2.getDouble(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagEnd:
/*      */         return;
/*      */       case NBTTagFloat:
/* 1537 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1538 */           paramNBTCompound1.setFloat(paramString, paramNBTCompound2.getFloat(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagInt:
/* 1542 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1543 */           paramNBTCompound1.setInteger(paramString, paramNBTCompound2.getInteger(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagIntArray:
/* 1547 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1548 */           paramNBTCompound1.setIntArray(paramString, paramNBTCompound2.getIntArray(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagList:
/* 1552 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1553 */           paramNBTCompound1.set(paramString, NBTReflectionUtil.getEntry(paramNBTCompound2, paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagLong:
/* 1557 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1558 */           paramNBTCompound1.setLong(paramString, paramNBTCompound2.getLong(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagShort:
/* 1562 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1563 */           paramNBTCompound1.setShort(paramString, paramNBTCompound2.getShort(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagString:
/* 1567 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString)) {
/* 1568 */           paramNBTCompound1.setString(paramString, paramNBTCompound2.getString(paramString));
/*      */         }
/*      */         return;
/*      */       case NBTTagLongArray:
/* 1572 */         if (bool || !isEqual(paramNBTCompound2, paramNBTCompound3, paramString))
/* 1573 */           paramNBTCompound1.setLongArray(paramString, paramNBTCompound2.getLongArray(paramString)); 
/*      */         return;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean isEqual(NBTCompound paramNBTCompound1, NBTCompound paramNBTCompound2, String paramString) {
/*      */     NBTCompound nBTCompound;
/* 1580 */     if (paramNBTCompound1.getType(paramString) != paramNBTCompound2.getType(paramString))
/* 1581 */       return false; 
/* 1582 */     switch (paramNBTCompound1.getType(paramString)) {
/*      */       case NBTTagByte:
/* 1584 */         return paramNBTCompound1.getByte(paramString).equals(paramNBTCompound2.getByte(paramString));
/*      */       case NBTTagByteArray:
/* 1586 */         return Arrays.equals(paramNBTCompound1.getByteArray(paramString), paramNBTCompound2.getByteArray(paramString));
/*      */       case NBTTagCompound:
/* 1588 */         nBTCompound = paramNBTCompound1.getCompound(paramString);
/* 1589 */         return (nBTCompound != null && nBTCompound.equals(paramNBTCompound2.getCompound(paramString)));
/*      */       
/*      */       case NBTTagDouble:
/* 1592 */         return paramNBTCompound1.getDouble(paramString).equals(paramNBTCompound2.getDouble(paramString));
/*      */       case NBTTagEnd:
/* 1594 */         return true;
/*      */       case NBTTagFloat:
/* 1596 */         return paramNBTCompound1.getFloat(paramString).equals(paramNBTCompound2.getFloat(paramString));
/*      */       case NBTTagInt:
/* 1598 */         return paramNBTCompound1.getInteger(paramString).equals(paramNBTCompound2.getInteger(paramString));
/*      */       case NBTTagIntArray:
/* 1600 */         return Arrays.equals(paramNBTCompound1.getIntArray(paramString), paramNBTCompound2.getIntArray(paramString));
/*      */       case NBTTagList:
/* 1602 */         return NBTReflectionUtil.getEntry(paramNBTCompound1, paramString).toString()
/* 1603 */           .equals(NBTReflectionUtil.getEntry(paramNBTCompound2, paramString).toString());
/*      */       case NBTTagLong:
/* 1605 */         return paramNBTCompound1.getLong(paramString).equals(paramNBTCompound2.getLong(paramString));
/*      */       case NBTTagShort:
/* 1607 */         return paramNBTCompound1.getShort(paramString).equals(paramNBTCompound2.getShort(paramString));
/*      */       case NBTTagString:
/* 1609 */         return paramNBTCompound1.getString(paramString).equals(paramNBTCompound2.getString(paramString));
/*      */       case NBTTagLongArray:
/* 1611 */         return Arrays.equals(paramNBTCompound1.getLongArray(paramString), paramNBTCompound2.getLongArray(paramString));
/*      */     } 
/* 1613 */     return false;
/*      */   }
/*      */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTCompound.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */