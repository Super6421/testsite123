/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTIntArrayList
/*    */   extends NBTList<int[]>
/*    */ {
/*    */   private final NBTContainer tmpContainer;
/*    */   
/*    */   protected NBTIntArrayList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/* 20 */     super(paramNBTCompound, paramString, paramNBTType, paramObject);
/* 21 */     this.tmpContainer = new NBTContainer();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object asTag(int[] paramArrayOfint) {
/*    */     try {
/* 27 */       Constructor constructor = ClassWrapper.NMS_NBTTAGINTARRAY.getClazz().getDeclaredConstructor(new Class[] { int[].class });
/* 28 */       constructor.setAccessible(true);
/* 29 */       return constructor.newInstance(new Object[] { paramArrayOfint });
/* 30 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException instantiationException) {
/*    */       
/* 32 */       throw new NbtApiException("Error while wrapping the Object " + paramArrayOfint + " to it's NMS object!", instantiationException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] get(int paramInt) {
/*    */     try {
/* 39 */       Object object = ReflectionMethod.LIST_GET.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 40 */       ReflectionMethod.COMPOUND_SET.run(this.tmpContainer.getCompound(), new Object[] { "tmp", object });
/* 41 */       int[] arrayOfInt = this.tmpContainer.getIntArray("tmp");
/* 42 */       this.tmpContainer.removeKey("tmp");
/* 43 */       return arrayOfInt;
/* 44 */     } catch (NumberFormatException numberFormatException) {
/* 45 */       return null;
/* 46 */     } catch (Exception exception) {
/* 47 */       throw new NbtApiException(exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTIntArrayList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */