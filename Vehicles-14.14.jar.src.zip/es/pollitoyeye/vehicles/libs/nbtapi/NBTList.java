/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTList;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NBTList<T>
/*     */   implements List<T>, ReadWriteNBTList<T>
/*     */ {
/*     */   private String listName;
/*     */   private NBTCompound parent;
/*     */   private NBTType type;
/*     */   protected Object listObject;
/*     */   
/*     */   protected NBTList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/*  31 */     this.parent = paramNBTCompound;
/*  32 */     this.listName = paramString;
/*  33 */     this.type = paramNBTType;
/*  34 */     this.listObject = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  41 */     return this.listName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTCompound getParent() {
/*  48 */     return this.parent;
/*     */   }
/*     */   
/*     */   private void validateClosed() {
/*  52 */     if (this.parent.isClosed()) {
/*  53 */       throw new NbtApiException("Tried using closed NBT data!");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateWritable() {
/*  58 */     if (getParent().isReadOnly()) {
/*  59 */       throw new NbtApiException("Tried setting data in read only mode!");
/*     */     }
/*     */   }
/*     */   
/*     */   protected void save() {
/*  64 */     validateClosed();
/*  65 */     this.parent.set(this.listName, this.listObject);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract Object asTag(T paramT);
/*     */   
/*     */   public boolean add(T paramT) {
/*  72 */     validateClosed();
/*  73 */     validateWritable();
/*     */     try {
/*  75 */       this.parent.getWriteLock().lock();
/*  76 */       if (MinecraftVersion.getVersion().getVersionId() >= MinecraftVersion.MC1_14_R1.getVersionId()) {
/*  77 */         ReflectionMethod.LIST_ADD.run(this.listObject, new Object[] { Integer.valueOf(size()), asTag(paramT) });
/*     */       } else {
/*  79 */         ReflectionMethod.LEGACY_LIST_ADD.run(this.listObject, new Object[] { asTag(paramT) });
/*     */       } 
/*  81 */       save();
/*  82 */       return true;
/*  83 */     } catch (Exception exception) {
/*  84 */       throw new NbtApiException(exception);
/*     */     } finally {
/*  86 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, T paramT) {
/*  92 */     validateClosed();
/*  93 */     validateWritable();
/*     */     try {
/*  95 */       this.parent.getWriteLock().lock();
/*  96 */       if (MinecraftVersion.getVersion().getVersionId() >= MinecraftVersion.MC1_14_R1.getVersionId()) {
/*  97 */         ReflectionMethod.LIST_ADD.run(this.listObject, new Object[] { Integer.valueOf(paramInt), asTag(paramT) });
/*     */       } else {
/*  99 */         ReflectionMethod.LEGACY_LIST_ADD.run(this.listObject, new Object[] { asTag(paramT) });
/*     */       } 
/* 101 */       save();
/* 102 */     } catch (Exception exception) {
/* 103 */       throw new NbtApiException(exception);
/*     */     } finally {
/* 105 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T set(int paramInt, T paramT) {
/* 111 */     validateClosed();
/* 112 */     validateWritable();
/*     */     try {
/* 114 */       this.parent.getWriteLock().lock();
/* 115 */       T t = get(paramInt);
/* 116 */       ReflectionMethod.LIST_SET.run(this.listObject, new Object[] { Integer.valueOf(paramInt), asTag(paramT) });
/* 117 */       save();
/* 118 */       return t;
/* 119 */     } catch (Exception exception) {
/* 120 */       throw new NbtApiException(exception);
/*     */     } finally {
/* 122 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public T remove(int paramInt) {
/* 128 */     validateClosed();
/* 129 */     validateWritable();
/*     */     try {
/* 131 */       this.parent.getWriteLock().lock();
/* 132 */       T t = get(paramInt);
/* 133 */       ReflectionMethod.LIST_REMOVE_KEY.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 134 */       save();
/* 135 */       return t;
/* 136 */     } catch (Exception exception) {
/* 137 */       throw new NbtApiException(exception);
/*     */     } finally {
/* 139 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 145 */     validateClosed();
/*     */     try {
/* 147 */       this.parent.getReadLock().lock();
/* 148 */       return ((Integer)ReflectionMethod.LIST_SIZE.run(this.listObject, new Object[0])).intValue();
/* 149 */     } catch (Exception exception) {
/* 150 */       throw new NbtApiException(exception);
/*     */     } finally {
/* 152 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTType getType() {
/* 161 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 166 */     return (size() == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 171 */     while (!isEmpty()) {
/* 172 */       remove(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 178 */     validateClosed();
/*     */     try {
/* 180 */       this.parent.getReadLock().lock(); byte b;
/* 181 */       for (b = 0; b < size(); b++) {
/* 182 */         if (paramObject.equals(get(b)))
/* 183 */           return true; 
/*     */       } 
/* 185 */       b = 0; return b;
/*     */     } finally {
/* 187 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 193 */     validateClosed();
/*     */     try {
/* 195 */       this.parent.getReadLock().lock(); byte b;
/* 196 */       for (b = 0; b < size(); b++) {
/* 197 */         if (paramObject.equals(get(b)))
/* 198 */           return b; 
/*     */       } 
/* 200 */       b = -1; return b;
/*     */     } finally {
/* 202 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> paramCollection) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial validateClosed : ()V
/*     */     //   4: aload_0
/*     */     //   5: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   8: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   11: invokeinterface lock : ()V
/*     */     //   16: aload_0
/*     */     //   17: invokevirtual size : ()I
/*     */     //   20: istore_2
/*     */     //   21: aload_1
/*     */     //   22: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   27: astore_3
/*     */     //   28: aload_3
/*     */     //   29: invokeinterface hasNext : ()Z
/*     */     //   34: ifeq -> 55
/*     */     //   37: aload_3
/*     */     //   38: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   43: astore #4
/*     */     //   45: aload_0
/*     */     //   46: aload #4
/*     */     //   48: invokevirtual add : (Ljava/lang/Object;)Z
/*     */     //   51: pop
/*     */     //   52: goto -> 28
/*     */     //   55: iload_2
/*     */     //   56: aload_0
/*     */     //   57: invokevirtual size : ()I
/*     */     //   60: if_icmpeq -> 67
/*     */     //   63: iconst_1
/*     */     //   64: goto -> 68
/*     */     //   67: iconst_0
/*     */     //   68: istore_3
/*     */     //   69: aload_0
/*     */     //   70: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   73: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   76: invokeinterface unlock : ()V
/*     */     //   81: iload_3
/*     */     //   82: ireturn
/*     */     //   83: astore #5
/*     */     //   85: aload_0
/*     */     //   86: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   89: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   92: invokeinterface unlock : ()V
/*     */     //   97: aload #5
/*     */     //   99: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #208	-> 0
/*     */     //   #210	-> 4
/*     */     //   #211	-> 16
/*     */     //   #212	-> 21
/*     */     //   #213	-> 45
/*     */     //   #214	-> 52
/*     */     //   #215	-> 55
/*     */     //   #217	-> 69
/*     */     //   #215	-> 81
/*     */     //   #217	-> 83
/*     */     //   #218	-> 97
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	69	83	finally
/*     */     //   83	85	83	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends T> paramCollection) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial validateClosed : ()V
/*     */     //   4: aload_0
/*     */     //   5: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   8: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   11: invokeinterface lock : ()V
/*     */     //   16: aload_0
/*     */     //   17: invokevirtual size : ()I
/*     */     //   20: istore_3
/*     */     //   21: aload_2
/*     */     //   22: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   27: astore #4
/*     */     //   29: aload #4
/*     */     //   31: invokeinterface hasNext : ()Z
/*     */     //   36: ifeq -> 61
/*     */     //   39: aload #4
/*     */     //   41: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   46: astore #5
/*     */     //   48: aload_0
/*     */     //   49: iload_1
/*     */     //   50: iinc #1, 1
/*     */     //   53: aload #5
/*     */     //   55: invokevirtual add : (ILjava/lang/Object;)V
/*     */     //   58: goto -> 29
/*     */     //   61: iload_3
/*     */     //   62: aload_0
/*     */     //   63: invokevirtual size : ()I
/*     */     //   66: if_icmpeq -> 73
/*     */     //   69: iconst_1
/*     */     //   70: goto -> 74
/*     */     //   73: iconst_0
/*     */     //   74: istore #4
/*     */     //   76: aload_0
/*     */     //   77: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   80: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   83: invokeinterface unlock : ()V
/*     */     //   88: iload #4
/*     */     //   90: ireturn
/*     */     //   91: astore #6
/*     */     //   93: aload_0
/*     */     //   94: getfield parent : Les/pollitoyeye/vehicles/libs/nbtapi/NBTCompound;
/*     */     //   97: invokevirtual getWriteLock : ()Ljava/util/concurrent/locks/Lock;
/*     */     //   100: invokeinterface unlock : ()V
/*     */     //   105: aload #6
/*     */     //   107: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #223	-> 0
/*     */     //   #225	-> 4
/*     */     //   #226	-> 16
/*     */     //   #227	-> 21
/*     */     //   #228	-> 48
/*     */     //   #229	-> 58
/*     */     //   #230	-> 61
/*     */     //   #232	-> 76
/*     */     //   #230	-> 88
/*     */     //   #232	-> 91
/*     */     //   #233	-> 105
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	76	91	finally
/*     */     //   91	93	91	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 238 */     validateClosed();
/*     */     try {
/* 240 */       this.parent.getReadLock().lock();
/* 241 */       for (Object object : paramCollection) {
/* 242 */         if (!contains(object))
/* 243 */           return false; 
/*     */       } 
/* 245 */       return true;
/*     */     } finally {
/* 247 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 253 */     validateClosed();
/*     */     try {
/* 255 */       this.parent.getReadLock().lock();
/* 256 */       byte b1 = -1; byte b2;
/* 257 */       for (b2 = 0; b2 < size(); b2++) {
/* 258 */         if (paramObject.equals(get(b2)))
/* 259 */           b1 = b2; 
/*     */       } 
/* 261 */       b2 = b1; return b2;
/*     */     } finally {
/* 263 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 269 */     validateClosed();
/*     */     try {
/* 271 */       this.parent.getWriteLock().lock();
/* 272 */       int i = size();
/* 273 */       for (Object object : paramCollection) {
/* 274 */         remove(object);
/*     */       }
/* 276 */       return (i != size());
/*     */     } finally {
/* 278 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 284 */     validateClosed();
/*     */     try {
/* 286 */       this.parent.getWriteLock().lock();
/* 287 */       int i = size();
/* 288 */       for (Object object : paramCollection) {
/* 289 */         for (byte b = 0; b < size(); b++) {
/* 290 */           if (!object.equals(get(b))) {
/* 291 */             remove(b--);
/*     */           }
/*     */         } 
/*     */       } 
/* 295 */       return (i != size());
/*     */     } finally {
/* 297 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 303 */     validateClosed();
/*     */     try {
/* 305 */       this.parent.getWriteLock().lock();
/* 306 */       int i = size();
/* 307 */       int j = indexOf(paramObject);
/* 308 */       if (j != -1) {
/* 309 */         remove(j);
/*     */       }
/* 311 */       return (i != size());
/*     */     } finally {
/* 313 */       this.parent.getWriteLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 319 */     return new Iterator<T>()
/*     */       {
/* 321 */         private int index = -1;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 325 */           return (NBTList.this.size() > this.index + 1);
/*     */         }
/*     */ 
/*     */         
/*     */         public T next() {
/* 330 */           if (!hasNext())
/* 331 */             throw new NoSuchElementException(); 
/* 332 */           return NBTList.this.get(++this.index);
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 337 */           NBTList.this.remove(this.index);
/* 338 */           this.index--;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator() {
/* 345 */     return listIterator(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<T> listIterator(final int startIndex) {
/* 350 */     final NBTList list = this;
/* 351 */     return new ListIterator<T>()
/*     */       {
/* 353 */         int index = startIndex - 1;
/*     */ 
/*     */         
/*     */         public void add(T param1T) {
/* 357 */           list.add(this.index, param1T);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 362 */           return (NBTList.this.size() > this.index + 1);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean hasPrevious() {
/* 367 */           return (this.index >= 0 && this.index <= NBTList.this.size());
/*     */         }
/*     */ 
/*     */         
/*     */         public T next() {
/* 372 */           if (!hasNext())
/* 373 */             throw new NoSuchElementException(); 
/* 374 */           return NBTList.this.get(++this.index);
/*     */         }
/*     */ 
/*     */         
/*     */         public int nextIndex() {
/* 379 */           return this.index + 1;
/*     */         }
/*     */ 
/*     */         
/*     */         public T previous() {
/* 384 */           if (!hasPrevious())
/* 385 */             throw new NoSuchElementException("Id: " + (this.index - 1)); 
/* 386 */           return NBTList.this.get(this.index--);
/*     */         }
/*     */ 
/*     */         
/*     */         public int previousIndex() {
/* 391 */           return this.index - 1;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 396 */           list.remove(this.index);
/* 397 */           this.index--;
/*     */         }
/*     */ 
/*     */         
/*     */         public void set(T param1T) {
/* 402 */           list.set(this.index, param1T);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 409 */     validateClosed();
/*     */     try {
/* 411 */       this.parent.getReadLock().lock();
/* 412 */       Object[] arrayOfObject = new Object[size()];
/* 413 */       for (byte b = 0; b < size(); b++)
/* 414 */         arrayOfObject[b] = get(b); 
/* 415 */       return arrayOfObject;
/*     */     } finally {
/* 417 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <E> E[] toArray(E[] paramArrayOfE) {
/* 424 */     validateClosed();
/*     */     try {
/* 426 */       this.parent.getReadLock().lock();
/* 427 */       Object[] arrayOfObject = Arrays.copyOf((Object[])paramArrayOfE, size());
/* 428 */       Arrays.fill(arrayOfObject, (Object)null);
/* 429 */       Class<?> clazz = paramArrayOfE.getClass().getComponentType();
/* 430 */       for (byte b = 0; b < size(); b++) {
/* 431 */         T t = get(b);
/* 432 */         if (clazz.isInstance(t)) {
/* 433 */           arrayOfObject[b] = get(b);
/*     */         } else {
/* 435 */           throw new ArrayStoreException("The array does not match the objects stored in the List.");
/*     */         } 
/*     */       } 
/* 438 */       return (E[])arrayOfObject;
/*     */     } finally {
/* 440 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List<T> subList(int paramInt1, int paramInt2) {
/* 446 */     validateClosed();
/*     */     try {
/* 448 */       this.parent.getReadLock().lock();
/* 449 */       ArrayList<T> arrayList = new ArrayList();
/* 450 */       for (int i = paramInt1; i < paramInt2; i++)
/* 451 */         arrayList.add(get(i)); 
/* 452 */       return arrayList;
/*     */     } finally {
/* 454 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeIf(Predicate<? super T> paramPredicate) {
/* 460 */     return super.removeIf(paramPredicate);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 465 */     validateClosed();
/*     */     try {
/* 467 */       this.parent.getReadLock().lock();
/* 468 */       return this.listObject.toString();
/*     */     } finally {
/* 470 */       this.parent.getReadLock().unlock();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */