/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.GameprofileUtil;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ObjectCreator;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTGameProfile
/*    */ {
/*    */   @Deprecated
/*    */   public static NBTCompound toNBT(GameProfile paramGameProfile) {
/* 20 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 21 */       return (NBTCompound)GameprofileUtil.writeGameProfile(NBT.createNBTObject(), paramGameProfile);
/*    */     }
/* 23 */     return new NBTContainer(ReflectionMethod.GAMEPROFILE_SERIALIZE.run(null, new Object[] { ObjectCreator.NMS_NBTTAGCOMPOUND
/* 24 */             .getInstance(new Object[0]), paramGameProfile }));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static GameProfile fromNBT(NBTCompound paramNBTCompound) {
/* 35 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 36 */       return GameprofileUtil.readGameProfile((ReadableNBT)paramNBTCompound);
/*    */     }
/* 38 */     return (GameProfile)ReflectionMethod.GAMEPROFILE_DESERIALIZE.run(null, new Object[] {
/* 39 */           NBTReflectionUtil.getToCompount(paramNBTCompound.getCompound(), paramNBTCompound)
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTGameProfile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */