/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTHandler;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public interface NBTProxy
/*    */ {
/* 11 */   public static final Map<Class<?>, NBTHandler<Object>> handlers = new HashMap<>();
/*    */ 
/*    */   
/*    */   default void init() {}
/*    */ 
/*    */   
/*    */   default Casing getCasing() {
/* 18 */     return Casing.PascalCase;
/*    */   }
/*    */ 
/*    */   
/*    */   default <T> NBTHandler<T> getHandler(Class<T> clazz) {
/* 23 */     return (NBTHandler<T>)handlers.get(clazz);
/*    */   }
/*    */   
/*    */   default Collection<NBTHandler<Object>> getHandlers() {
/* 27 */     return handlers.values();
/*    */   }
/*    */ 
/*    */   
/*    */   default <T> void registerHandler(Class<T> clazz, NBTHandler<T> handler) {
/* 32 */     handlers.put(clazz, handler);
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\NBTProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */