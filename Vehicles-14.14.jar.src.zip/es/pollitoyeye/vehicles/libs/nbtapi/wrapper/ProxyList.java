package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;

public interface ProxyList<T extends NBTProxy> extends Iterable<T> {
  T addCompound();
  
  int size();
  
  boolean isEmpty();
  
  T get(int paramInt);
  
  void remove(int paramInt);
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\ProxyList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */