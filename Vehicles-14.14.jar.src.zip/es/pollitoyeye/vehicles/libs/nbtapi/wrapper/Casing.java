/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*    */ 
/*    */ import java.util.function.UnaryOperator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Casing
/*    */ {
/* 31 */   lowercase(String::toLowerCase), PascalCase(String::toLowerCase), snake_case(String::toLowerCase), camelCase(String::toLowerCase), UPPERCASE(String::toUpperCase);
/*    */   
/*    */   private UnaryOperator<String> convert;
/*    */   
/*    */   Casing(UnaryOperator<String> paramUnaryOperator) {
/* 36 */     this.convert = paramUnaryOperator; }
/*    */   static { camelCase = new Casing("camelCase", 0, paramString -> (paramString.length() < 2) ? paramString.toLowerCase() : (Character.toLowerCase(paramString.charAt(0)) + paramString.substring(1))); snake_case = new Casing("snake_case", 1, paramString -> { StringBuilder stringBuilder = new StringBuilder(); stringBuilder.append(Character.toLowerCase(paramString.charAt(0))); for (byte b = 1; b < paramString.length(); b++) { char c = paramString.charAt(b); if (Character.isUpperCase(c)) { stringBuilder.append('_').append(Character.toLowerCase(c)); } else { stringBuilder.append(c); }
/*    */              }
/*    */            return stringBuilder.toString();
/* 40 */         }); PascalCase = new Casing("PascalCase", 2, paramString -> (paramString.length() < 2) ? paramString.toUpperCase() : (Character.toUpperCase(paramString.charAt(0)) + paramString.substring(1))); } public String convertString(String paramString) { return this.convert.apply(paramString); }
/*    */ 
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\Casing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */