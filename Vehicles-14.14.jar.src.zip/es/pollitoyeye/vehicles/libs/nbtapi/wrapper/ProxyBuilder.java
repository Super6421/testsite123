/*     */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBTType;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTHandler;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public class ProxyBuilder<T extends NBTProxy>
/*     */   implements InvocationHandler
/*     */ {
/*  20 */   private static final Map<Method, Function<Arguments, Object>> METHOD_CACHE = new ConcurrentHashMap<>();
/*     */   
/*     */   private final Class<T> target;
/*     */   private final ReadWriteNBT nbt;
/*     */   private boolean readOnly;
/*     */   
/*     */   public ProxyBuilder(ReadWriteNBT paramReadWriteNBT, Class<T> paramClass) {
/*  27 */     if (!paramClass.isInterface()) {
/*  28 */       throw new NbtApiException("A proxy can only be built from an interface! Check the wiki for examples.");
/*     */     }
/*  30 */     this.target = paramClass;
/*  31 */     this.nbt = paramReadWriteNBT;
/*     */   }
/*     */   
/*     */   public ProxyBuilder<T> readOnly() {
/*  35 */     this.readOnly = true;
/*  36 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public T build() {
/*  41 */     NBTProxy nBTProxy = (NBTProxy)Proxy.newProxyInstance(getClass().getClassLoader(), new Class[] { this.target }, this);
/*  42 */     nBTProxy.init();
/*  43 */     return (T)nBTProxy;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) {
/*  48 */     METHOD_CACHE.computeIfAbsent(paramMethod, paramMethod -> createFunction((NBTProxy)paramObject, paramMethod));
/*  49 */     return ((Function)METHOD_CACHE.get(paramMethod)).apply(new Arguments(this.target, (NBTProxy)paramObject, this.readOnly, this.nbt, paramArrayOfObject));
/*     */   }
/*     */   
/*     */   private static class Arguments {
/*     */     Class<?> target;
/*     */     NBTProxy proxy;
/*     */     ReadWriteNBT nbt;
/*     */     Object[] args;
/*     */     boolean readOnly;
/*     */     
/*     */     public Arguments(Class<?> param1Class, NBTProxy param1NBTProxy, boolean param1Boolean, ReadWriteNBT param1ReadWriteNBT, Object[] param1ArrayOfObject) {
/*  60 */       this.target = param1Class;
/*  61 */       this.proxy = param1NBTProxy;
/*  62 */       this.nbt = param1ReadWriteNBT;
/*  63 */       this.args = param1ArrayOfObject;
/*  64 */       this.readOnly = param1Boolean;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static Function<Arguments, Object> createFunction(NBTProxy paramNBTProxy, Method paramMethod) {
/*  70 */     if ("toString".equals(paramMethod.getName()) && paramMethod.getParameterCount() == 0 && paramMethod
/*  71 */       .getReturnType() == String.class) {
/*  72 */       return paramArguments -> paramArguments.nbt.toString();
/*     */     }
/*  74 */     if (paramMethod.isDefault()) {
/*  75 */       return paramArguments -> DefaultMethodInvoker.invokeDefault(paramArguments.target, paramArguments.proxy, paramMethod, paramArguments.args);
/*     */     }
/*     */     
/*  78 */     NBTTarget.Type type = getAction(paramMethod);
/*  79 */     if (type == NBTTarget.Type.SET) {
/*  80 */       String str = getNBTName(paramNBTProxy.getCasing(), paramMethod);
/*  81 */       return paramArguments -> {
/*     */           if (paramArguments.readOnly) {
/*     */             throw new NbtApiException("Tried calling a set method on a read only object.");
/*     */           }
/*     */           return setNBT(paramArguments.nbt, paramArguments.proxy, paramString, paramArguments.args[0]);
/*     */         };
/*     */     } 
/*  88 */     if (type == NBTTarget.Type.GET) {
/*  89 */       Class<?> clazz = paramMethod.getReturnType();
/*  90 */       String str = getNBTName(paramNBTProxy.getCasing(), paramMethod);
/*     */       
/*  92 */       if (clazz.isInterface() && NBTProxy.class.isAssignableFrom(clazz)) {
/*  93 */         return paramArguments -> {
/*     */             if (paramArguments.nbt.hasTag(paramString) && paramArguments.nbt.getType(paramString) != NBTType.NBTTagCompound) {
/*     */               throw new NbtApiException("Tried getting a '" + paramClass + "' proxy from the field '" + paramString + "', but it's not a TagCompound!");
/*     */             }
/*     */             
/*     */             return (new ProxyBuilder<>(paramArguments.nbt.getOrCreateCompound(paramString), paramClass)).build();
/*     */           };
/*     */       }
/*     */       
/* 102 */       if (clazz == ProxyList.class) {
/*     */ 
/*     */         
/* 105 */         Class<?> clazz1 = (Class)((ParameterizedType)paramMethod.getGenericReturnType()).getActualTypeArguments()[0];
/* 106 */         if (clazz1 != null && clazz1.isInterface() && NBTProxy.class
/* 107 */           .isAssignableFrom(clazz1)) {
/* 108 */           return paramArguments -> new ProxiedList<>(paramArguments.nbt.getCompoundList(paramString), paramClass);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 113 */       NBTHandler<?> nBTHandler = paramNBTProxy.getHandler(clazz);
/* 114 */       if (nBTHandler != null) {
/* 115 */         return paramArguments -> paramNBTHandler.get((ReadableNBT)paramArguments.nbt, paramString);
/*     */       }
/* 117 */       return paramArguments -> paramArguments.nbt.getOrNull(paramString, paramClass);
/*     */     } 
/* 119 */     if (type == NBTTarget.Type.HAS) {
/* 120 */       String str = getNBTName(paramNBTProxy.getCasing(), paramMethod);
/* 121 */       return paramArguments -> Boolean.valueOf(paramArguments.nbt.hasTag(paramString));
/*     */     } 
/* 123 */     throw new IllegalArgumentException("The method '" + paramMethod
/* 124 */         .getName() + "' in '" + paramMethod.getDeclaringClass().getName() + "' can not be handled by the NBT-API. Please check the Wiki for examples!");
/*     */   }
/*     */ 
/*     */   
/*     */   private static NBTTarget.Type getAction(Method paramMethod) {
/* 129 */     NBTTarget nBTTarget = paramMethod.<NBTTarget>getAnnotation(NBTTarget.class);
/* 130 */     if (nBTTarget != null) {
/* 131 */       if (nBTTarget.type() == NBTTarget.Type.HAS && paramMethod.getParameterCount() == 0 && paramMethod
/* 132 */         .getReturnType() == boolean.class) {
/* 133 */         return NBTTarget.Type.HAS;
/*     */       }
/* 135 */       if (nBTTarget.type() == NBTTarget.Type.GET && paramMethod.getParameterCount() == 0) {
/* 136 */         return NBTTarget.Type.GET;
/*     */       }
/* 138 */       if (nBTTarget.type() == NBTTarget.Type.SET && paramMethod.getParameterCount() == 1) {
/* 139 */         return NBTTarget.Type.SET;
/*     */       }
/*     */     } 
/* 142 */     if (paramMethod.getName().startsWith("set") && paramMethod.getParameterCount() == 1) {
/* 143 */       return NBTTarget.Type.SET;
/*     */     }
/* 145 */     if (paramMethod.getName().startsWith("get") && paramMethod.getParameterCount() == 0) {
/* 146 */       return NBTTarget.Type.GET;
/*     */     }
/* 148 */     if (paramMethod.getName().startsWith("has") && paramMethod.getParameterCount() == 0 && paramMethod
/* 149 */       .getReturnType() == boolean.class) {
/* 150 */       return NBTTarget.Type.HAS;
/*     */     }
/* 152 */     return null;
/*     */   }
/*     */   
/*     */   private static String getNBTName(Casing paramCasing, Method paramMethod) {
/* 156 */     NBTTarget nBTTarget = paramMethod.<NBTTarget>getAnnotation(NBTTarget.class);
/* 157 */     if (nBTTarget != null) {
/* 158 */       return nBTTarget.value();
/*     */     }
/* 160 */     return paramCasing.convertString(paramMethod.getName().substring(3));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object setNBT(ReadWriteNBT paramReadWriteNBT, NBTProxy paramNBTProxy, String paramString, Object paramObject) {
/* 166 */     if (paramObject == null) {
/* 167 */       paramReadWriteNBT.removeKey(paramString);
/* 168 */     } else if (paramObject instanceof Boolean) {
/* 169 */       paramReadWriteNBT.setBoolean(paramString, (Boolean)paramObject);
/* 170 */     } else if (paramObject instanceof Byte) {
/* 171 */       paramReadWriteNBT.setByte(paramString, (Byte)paramObject);
/* 172 */     } else if (paramObject instanceof Short) {
/* 173 */       paramReadWriteNBT.setShort(paramString, (Short)paramObject);
/* 174 */     } else if (paramObject instanceof Integer) {
/* 175 */       paramReadWriteNBT.setInteger(paramString, (Integer)paramObject);
/* 176 */     } else if (paramObject instanceof Long) {
/* 177 */       paramReadWriteNBT.setLong(paramString, (Long)paramObject);
/* 178 */     } else if (paramObject instanceof Float) {
/* 179 */       paramReadWriteNBT.setFloat(paramString, (Float)paramObject);
/* 180 */     } else if (paramObject instanceof Double) {
/* 181 */       paramReadWriteNBT.setDouble(paramString, (Double)paramObject);
/* 182 */     } else if (paramObject instanceof byte[]) {
/* 183 */       paramReadWriteNBT.setByteArray(paramString, (byte[])paramObject);
/* 184 */     } else if (paramObject instanceof int[]) {
/* 185 */       paramReadWriteNBT.setIntArray(paramString, (int[])paramObject);
/* 186 */     } else if (paramObject instanceof long[]) {
/* 187 */       paramReadWriteNBT.setLongArray(paramString, (long[])paramObject);
/* 188 */     } else if (paramObject instanceof String) {
/* 189 */       paramReadWriteNBT.setString(paramString, (String)paramObject);
/* 190 */     } else if (paramObject instanceof UUID) {
/* 191 */       paramReadWriteNBT.setUUID(paramString, (UUID)paramObject);
/* 192 */     } else if (paramObject.getClass().isEnum()) {
/* 193 */       paramReadWriteNBT.setEnum(paramString, (Enum)paramObject);
/*     */     } else {
/*     */       
/* 196 */       NBTHandler<?> nBTHandler = paramNBTProxy.getHandler(paramObject.getClass());
/* 197 */       if (nBTHandler != null) {
/* 198 */         nBTHandler.set(paramReadWriteNBT, paramString, paramObject);
/*     */       } else {
/* 200 */         for (NBTHandler<Object> nBTHandler1 : paramNBTProxy.getHandlers()) {
/* 201 */           if (nBTHandler1.fuzzyMatch(paramObject)) {
/* 202 */             nBTHandler1.set(paramReadWriteNBT, paramString, paramObject);
/* 203 */             return null;
/*     */           } 
/*     */         } 
/* 206 */         throw new IllegalArgumentException("Tried setting an object of type '" + paramObject.getClass().getName() + "'. This is not a supported NBT value. Please check the Wiki for examples!");
/*     */       } 
/*     */     } 
/*     */     
/* 210 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\ProxyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */