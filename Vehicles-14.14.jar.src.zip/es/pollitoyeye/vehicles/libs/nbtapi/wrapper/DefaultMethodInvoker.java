/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.NbtApiException;
/*    */ import java.lang.invoke.MethodHandles;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultMethodInvoker
/*    */ {
/*    */   private static Method invokeDefaultMethod;
/*    */   
/*    */   static {
/*    */     try {
/* 18 */       invokeDefaultMethod = InvocationHandler.class.getDeclaredMethod("invokeDefault", new Class[] { Object.class, Method.class, Object[].class });
/*    */       
/* 20 */       invokeDefaultMethod.setAccessible(true);
/* 21 */     } catch (NoSuchMethodException|SecurityException noSuchMethodException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object invokeDefault(Class<?> paramClass, Object paramObject, Method paramMethod, Object[] paramArrayOfObject) {
/* 35 */     if (invokeDefaultMethod != null) {
/*    */       try {
/* 37 */         return invokeDefaultMethod.invoke(null, new Object[] { paramObject, paramMethod, paramArrayOfObject });
/* 38 */       } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException illegalAccessException) {
/* 39 */         throw new NbtApiException("Error while trying to invoke a default method for Java 9+. " + paramObject + " " + paramMethod + " " + 
/* 40 */             Arrays.toString(paramArrayOfObject), illegalAccessException);
/*    */       } 
/*    */     }
/*    */     try {
/* 44 */       Constructor<MethodHandles.Lookup> constructor = MethodHandles.Lookup.class.getDeclaredConstructor(new Class[] { Class.class });
/* 45 */       constructor.setAccessible(true);
/* 46 */       return ((MethodHandles.Lookup)constructor.newInstance(new Object[] { paramClass })).in(paramClass).unreflectSpecial(paramMethod, paramClass).bindTo(paramObject)
/* 47 */         .invokeWithArguments(paramArrayOfObject);
/* 48 */     } catch (Throwable throwable) {
/* 49 */       throw new NbtApiException("Error while trying to invoke a default method for Java 8. " + paramObject + " " + paramMethod + " " + 
/* 50 */           Arrays.toString(paramArrayOfObject), throwable);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\DefaultMethodInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */