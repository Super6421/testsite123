/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTCompoundList;
/*    */ import java.util.ConcurrentModificationException;
/*    */ import java.util.Iterator;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ class ProxiedList<E extends NBTProxy>
/*    */   implements ProxyList<E>
/*    */ {
/*    */   private final ReadWriteNBTCompoundList nbt;
/*    */   private final Class<E> proxy;
/*    */   
/*    */   public ProxiedList(ReadWriteNBTCompoundList paramReadWriteNBTCompoundList, Class<E> paramClass) {
/* 16 */     this.nbt = paramReadWriteNBTCompoundList;
/* 17 */     this.proxy = paramClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public E get(int paramInt) {
/* 22 */     ReadWriteNBT readWriteNBT = (ReadWriteNBT)this.nbt.get(paramInt);
/* 23 */     return (new ProxyBuilder<>(readWriteNBT, this.proxy)).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 28 */     return this.nbt.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public void remove(int paramInt) {
/* 33 */     this.nbt.remove(paramInt);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Iterator<E> iterator() {
/* 39 */     return new Itr();
/*    */   }
/*    */ 
/*    */   
/*    */   public E addCompound() {
/* 44 */     ReadWriteNBT readWriteNBT = this.nbt.addCompound();
/* 45 */     return (new ProxyBuilder<>(readWriteNBT, this.proxy)).build();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEmpty() {
/* 50 */     return this.nbt.isEmpty();
/*    */   }
/*    */ 
/*    */   
/*    */   private class Itr
/*    */     implements Iterator<E>
/*    */   {
/* 57 */     int cursor = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 64 */     int lastRet = -1;
/*    */     
/*    */     public boolean hasNext() {
/* 67 */       return (this.cursor != ProxiedList.this.size());
/*    */     }
/*    */     
/*    */     public E next() {
/*    */       try {
/* 72 */         int i = this.cursor;
/* 73 */         E e = (E)ProxiedList.this.get(i);
/* 74 */         this.lastRet = i;
/* 75 */         this.cursor = i + 1;
/* 76 */         return e;
/* 77 */       } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 78 */         throw new NoSuchElementException();
/*    */       } 
/*    */     }
/*    */     
/*    */     public void remove() {
/* 83 */       if (this.lastRet < 0) {
/* 84 */         throw new IllegalStateException();
/*    */       }
/*    */       try {
/* 87 */         ProxiedList.this.remove(this.lastRet);
/* 88 */         if (this.lastRet < this.cursor)
/* 89 */           this.cursor--; 
/* 90 */         this.lastRet = -1;
/* 91 */       } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 92 */         throw new ConcurrentModificationException();
/*    */       } 
/*    */     }
/*    */     
/*    */     private Itr() {}
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\ProxiedList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */