/*    */ package es.pollitoyeye.vehicles.libs.nbtapi.wrapper;
/*    */ 
/*    */ import java.lang.annotation.ElementType;
/*    */ import java.lang.annotation.Retention;
/*    */ import java.lang.annotation.RetentionPolicy;
/*    */ import java.lang.annotation.Target;
/*    */ 
/*    */ @Retention(RetentionPolicy.RUNTIME)
/*    */ @Target({ElementType.METHOD})
/*    */ public @interface NBTTarget
/*    */ {
/*    */   String value();
/*    */   
/*    */   Type type() default Type.AUTOMATIC;
/*    */   
/*    */   public enum Type {
/* 17 */     AUTOMATIC, GET, SET, HAS;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\wrapper\NBTTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */