/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*    */ import org.bukkit.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTBlock
/*    */ {
/*    */   private final Block block;
/*    */   private final NBTChunk nbtChunk;
/*    */   
/*    */   public NBTBlock(Block paramBlock) {
/* 26 */     this.block = paramBlock;
/* 27 */     if (!MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_16_R3)) {
/* 28 */       throw new NbtApiException("NBTBlock is only working for 1.16.4+!");
/*    */     }
/* 30 */     this.nbtChunk = new NBTChunk(paramBlock.getChunk());
/*    */   }
/*    */   
/*    */   public NBTCompound getData() {
/* 34 */     return this.nbtChunk.getPersistentDataContainer().getOrCreateCompound("blocks")
/* 35 */       .getOrCreateCompound(this.block.getX() + "_" + this.block.getY() + "_" + this.block.getZ());
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTBlock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */