package es.pollitoyeye.vehicles.libs.nbtapi.iface;

import java.util.function.Predicate;

public interface ReadWriteNBTCompoundList extends ReadableNBTList<ReadWriteNBT> {
  ReadWriteNBT addCompound();
  
  ReadWriteNBT addCompound(ReadableNBT paramReadableNBT);
  
  ReadWriteNBT remove(int paramInt);
  
  void clear();
  
  boolean removeIf(Predicate<? super ReadWriteNBT> paramPredicate);
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\iface\ReadWriteNBTCompoundList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */