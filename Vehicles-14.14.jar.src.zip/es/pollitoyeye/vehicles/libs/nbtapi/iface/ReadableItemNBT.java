package es.pollitoyeye.vehicles.libs.nbtapi.iface;

public interface ReadableItemNBT extends ReadableNBT {
  boolean hasNBTData();
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\iface\ReadableItemNBT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */