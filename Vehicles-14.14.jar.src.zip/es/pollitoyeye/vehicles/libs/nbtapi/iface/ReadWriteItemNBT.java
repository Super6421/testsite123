package es.pollitoyeye.vehicles.libs.nbtapi.iface;

import java.util.function.BiConsumer;
import org.bukkit.inventory.meta.ItemMeta;

public interface ReadWriteItemNBT extends ReadWriteNBT, ReadableItemNBT {
  boolean hasCustomNbtData();
  
  void clearCustomNBT();
  
  void modifyMeta(BiConsumer<ReadableNBT, ItemMeta> paramBiConsumer);
  
  <T extends ItemMeta> void modifyMeta(Class<T> paramClass, BiConsumer<ReadableNBT, T> paramBiConsumer);
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\iface\ReadWriteItemNBT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */