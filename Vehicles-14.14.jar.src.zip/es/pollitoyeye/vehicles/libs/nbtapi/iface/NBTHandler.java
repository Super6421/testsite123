/*   */ package es.pollitoyeye.vehicles.libs.nbtapi.iface;
/*   */ 
/*   */ import javax.annotation.Nonnull;
/*   */ 
/*   */ public interface NBTHandler<T>
/*   */ {
/*   */   default boolean fuzzyMatch(Object obj) {
/* 8 */     return false;
/*   */   }
/*   */   
/*   */   void set(@Nonnull ReadWriteNBT paramReadWriteNBT, @Nonnull String paramString, @Nonnull T paramT);
/*   */   
/*   */   T get(@Nonnull ReadableNBT paramReadableNBT, @Nonnull String paramString);
/*   */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\iface\NBTHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */