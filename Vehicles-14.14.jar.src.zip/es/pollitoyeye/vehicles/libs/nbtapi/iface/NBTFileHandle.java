package es.pollitoyeye.vehicles.libs.nbtapi.iface;

import java.io.File;
import java.io.IOException;

public interface NBTFileHandle extends ReadWriteNBT {
  void save() throws IOException;
  
  File getFile();
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\iface\NBTFileHandle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */