/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.CheckUtil;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*    */ import org.bukkit.Chunk;
/*    */ 
/*    */ 
/*    */ public class NBTChunk
/*    */ {
/*    */   private final Chunk chunk;
/*    */   
/*    */   public NBTChunk(Chunk paramChunk) {
/* 13 */     this.chunk = paramChunk;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NBTCompound getPersistentDataContainer() {
/* 23 */     CheckUtil.assertAvailable(MinecraftVersion.MC1_16_R3);
/* 24 */     return new NBTPersistentDataContainer(this.chunk.getPersistentDataContainer());
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */