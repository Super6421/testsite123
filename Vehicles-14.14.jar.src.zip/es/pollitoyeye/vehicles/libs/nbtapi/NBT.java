/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.NBTFileHandle;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteItemNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableItemNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.wrapper.ProxyBuilder;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import java.util.logging.Level;
/*     */ import javax.annotation.Nullable;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBT
/*     */ {
/*     */   public static boolean preloadApi() {
/*     */     try {
/*  56 */       if (MinecraftVersion.getVersion() == MinecraftVersion.UNKNOWN) {
/*  57 */         NbtApiException.confirmedBroken = Boolean.valueOf(true);
/*  58 */         return false;
/*     */       } 
/*  60 */       for (ClassWrapper classWrapper : ClassWrapper.values()) {
/*  61 */         if (classWrapper.isEnabled() && classWrapper.getClazz() == null) {
/*  62 */           NbtApiException.confirmedBroken = Boolean.valueOf(true);
/*  63 */           return false;
/*     */         } 
/*     */       } 
/*  66 */       for (ReflectionMethod reflectionMethod : ReflectionMethod.values()) {
/*  67 */         if (reflectionMethod.isCompatible() && !reflectionMethod.isLoaded()) {
/*  68 */           NbtApiException.confirmedBroken = Boolean.valueOf(true);
/*  69 */           return false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/*  74 */       return true;
/*  75 */     } catch (Exception exception) {
/*  76 */       NbtApiException.confirmedBroken = Boolean.valueOf(true);
/*  77 */       MinecraftVersion.getLogger().log(Level.WARNING, "[NBTAPI] Error during the selfcheck!", exception);
/*  78 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadableNBT readNbt(ItemStack paramItemStack) {
/*  91 */     return (ReadableNBT)new NBTItem(paramItemStack.clone(), false, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(ItemStack paramItemStack, Function<ReadableItemNBT, T> paramFunction) {
/* 105 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, true, false);
/* 106 */     T t = paramFunction.apply(nBTItem);
/* 107 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 108 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 110 */     nBTItem.setClosed();
/* 111 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void get(ItemStack paramItemStack, Consumer<ReadableItemNBT> paramConsumer) {
/* 121 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, true, false);
/* 122 */     paramConsumer.accept(nBTItem);
/* 123 */     nBTItem.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(Entity paramEntity, Function<ReadableNBT, T> paramFunction) {
/* 135 */     NBTEntity nBTEntity = new NBTEntity(paramEntity, true);
/* 136 */     T t = paramFunction.apply(nBTEntity);
/* 137 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 138 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 140 */     nBTEntity.setClosed();
/* 141 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void get(Entity paramEntity, Consumer<ReadableNBT> paramConsumer) {
/* 151 */     NBTEntity nBTEntity = new NBTEntity(paramEntity, true);
/* 152 */     paramConsumer.accept(nBTEntity);
/* 153 */     nBTEntity.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T get(BlockState paramBlockState, Function<ReadableNBT, T> paramFunction) {
/* 167 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState, true);
/* 168 */     T t = paramFunction.apply(nBTTileEntity);
/* 169 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 170 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 172 */     nBTTileEntity.setClosed();
/* 173 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void get(BlockState paramBlockState, Consumer<ReadableNBT> paramConsumer) {
/* 183 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState, true);
/* 184 */     paramConsumer.accept(nBTTileEntity);
/* 185 */     nBTTileEntity.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getPersistentData(Entity paramEntity, Function<ReadableNBT, T> paramFunction) {
/* 199 */     T t = paramFunction.apply((new NBTEntity(paramEntity)).getPersistentDataContainer());
/* 200 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 201 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 203 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getPersistentData(BlockState paramBlockState, Function<ReadableNBT, T> paramFunction) {
/* 217 */     T t = paramFunction.apply((new NBTTileEntity(paramBlockState)).getPersistentDataContainer());
/* 218 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 219 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 221 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modify(ItemStack paramItemStack, Function<ReadWriteItemNBT, T> paramFunction) {
/* 233 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, false, true);
/* 234 */     T t = paramFunction.apply(nBTItem);
/* 235 */     nBTItem.finalizeChanges();
/* 236 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 237 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 239 */     nBTItem.setClosed();
/* 240 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modify(ItemStack paramItemStack, Consumer<ReadWriteItemNBT> paramConsumer) {
/* 251 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, false, true);
/* 252 */     paramConsumer.accept(nBTItem);
/* 253 */     nBTItem.finalizeChanges();
/* 254 */     nBTItem.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modify(Entity paramEntity, Function<ReadWriteNBT, T> paramFunction) {
/* 266 */     NBTEntity nBTEntity = new NBTEntity(paramEntity);
/* 267 */     NBTContainer nBTContainer = new NBTContainer(nBTEntity.getCompound());
/* 268 */     T t = paramFunction.apply(nBTContainer);
/* 269 */     nBTEntity.setCompound(nBTContainer.getCompound());
/* 270 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 271 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 273 */     nBTEntity.setClosed();
/* 274 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modifyComponents(ItemStack paramItemStack, Consumer<ReadWriteNBT> paramConsumer) {
/* 286 */     if (!MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 287 */       throw new NbtApiException("This method only works for 1.20.5+!");
/*     */     }
/* 289 */     ReadWriteNBT readWriteNBT = itemStackToNBT(paramItemStack);
/* 290 */     paramConsumer.accept(readWriteNBT.getOrCreateCompound("components"));
/* 291 */     ItemStack itemStack = itemStackFromNBT((ReadableNBT)readWriteNBT);
/* 292 */     paramItemStack.setItemMeta(itemStack.getItemMeta());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modifyComponents(ItemStack paramItemStack, Function<ReadWriteNBT, T> paramFunction) {
/* 305 */     if (!MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 306 */       throw new NbtApiException("This method only works for 1.20.5+!");
/*     */     }
/* 308 */     ReadWriteNBT readWriteNBT = itemStackToNBT(paramItemStack);
/* 309 */     T t = paramFunction.apply(readWriteNBT.getOrCreateCompound("components"));
/* 310 */     ItemStack itemStack = itemStackFromNBT((ReadableNBT)readWriteNBT);
/* 311 */     paramItemStack.setItemMeta(itemStack.getItemMeta());
/* 312 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getComponents(ItemStack paramItemStack, Consumer<ReadableNBT> paramConsumer) {
/* 324 */     if (!MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 325 */       throw new NbtApiException("This method only works for 1.20.5+!");
/*     */     }
/* 327 */     ReadWriteNBT readWriteNBT = itemStackToNBT(paramItemStack);
/* 328 */     paramConsumer.accept(readWriteNBT.getOrCreateCompound("components"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T getComponents(ItemStack paramItemStack, Function<ReadableNBT, T> paramFunction) {
/* 341 */     if (!MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 342 */       throw new NbtApiException("This method only works for 1.20.5+!");
/*     */     }
/* 344 */     ReadWriteNBT readWriteNBT = itemStackToNBT(paramItemStack);
/* 345 */     return paramFunction.apply(readWriteNBT.getOrCreateCompound("components"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modify(Entity paramEntity, Consumer<ReadWriteNBT> paramConsumer) {
/* 356 */     NBTEntity nBTEntity = new NBTEntity(paramEntity);
/* 357 */     NBTContainer nBTContainer = new NBTContainer(nBTEntity.getCompound());
/* 358 */     paramConsumer.accept(nBTContainer);
/* 359 */     nBTEntity.setCompound(nBTContainer.getCompound());
/* 360 */     nBTEntity.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modifyPersistentData(Entity paramEntity, Function<ReadWriteNBT, T> paramFunction) {
/* 373 */     T t = paramFunction.apply((new NBTEntity(paramEntity)).getPersistentDataContainer());
/* 374 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 375 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 377 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modifyPersistentData(Entity paramEntity, Consumer<ReadWriteNBT> paramConsumer) {
/* 388 */     paramConsumer.accept((new NBTEntity(paramEntity)).getPersistentDataContainer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modify(BlockState paramBlockState, Function<ReadWriteNBT, T> paramFunction) {
/* 400 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState);
/* 401 */     NBTContainer nBTContainer = new NBTContainer(nBTTileEntity.getCompound());
/* 402 */     T t = paramFunction.apply(nBTContainer);
/* 403 */     nBTTileEntity.setCompound(nBTContainer.getCompound());
/* 404 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 405 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 407 */     nBTTileEntity.setClosed();
/* 408 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modify(BlockState paramBlockState, Consumer<ReadWriteNBT> paramConsumer) {
/* 421 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState);
/* 422 */     NBTContainer nBTContainer = new NBTContainer(nBTTileEntity.getCompound());
/* 423 */     paramConsumer.accept(nBTContainer);
/* 424 */     nBTTileEntity.setCompound(nBTContainer.getCompound());
/* 425 */     nBTTileEntity.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T modifyPersistentData(BlockState paramBlockState, Function<ReadWriteNBT, T> paramFunction) {
/* 438 */     T t = paramFunction.apply((new NBTTileEntity(paramBlockState)).getPersistentDataContainer());
/* 439 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 440 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 442 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void modifyPersistentData(BlockState paramBlockState, Consumer<ReadWriteNBT> paramConsumer) {
/* 454 */     paramConsumer.accept((new NBTTileEntity(paramBlockState)).getPersistentDataContainer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT gameProfileToNBT(GameProfile paramGameProfile) {
/* 464 */     return NBTGameProfile.toNBT(paramGameProfile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GameProfile gameProfileFromNBT(ReadableNBT paramReadableNBT) {
/* 474 */     return NBTGameProfile.fromNBT((NBTCompound)paramReadableNBT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT itemStackToNBT(ItemStack paramItemStack) {
/* 484 */     return NBTItem.convertItemtoNBT(paramItemStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static ItemStack itemStackFromNBT(ReadableNBT paramReadableNBT) {
/* 495 */     return NBTItem.convertNBTtoItem((NBTCompound)paramReadableNBT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT itemStackArrayToNBT(ItemStack[] paramArrayOfItemStack) {
/* 505 */     return NBTItem.convertItemArraytoNBT(paramArrayOfItemStack);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static ItemStack[] itemStackArrayFromNBT(ReadableNBT paramReadableNBT) {
/* 516 */     return NBTItem.convertNBTtoItemArray((NBTCompound)paramReadableNBT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT createNBTObject() {
/* 525 */     return new NBTContainer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT parseNBT(String paramString) {
/* 535 */     return new NBTContainer(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT readNBT(InputStream paramInputStream) {
/* 545 */     return new NBTContainer(paramInputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT wrapNMSTag(Object paramObject) {
/* 556 */     return new NBTContainer(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static NBTFileHandle getFileHandle(File paramFile) {
/* 567 */     return new NBTFile(paramFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadWriteNBT readFile(File paramFile) {
/* 580 */     return NBTFile.readFrom(paramFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeFile(File paramFile, ReadWriteNBT paramReadWriteNBT) {
/* 593 */     NBTFile.saveTo(paramFile, (NBTCompound)paramReadWriteNBT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T readNbt(ItemStack paramItemStack, Class<T> paramClass) {
/* 605 */     return (T)(new ProxyBuilder(new NBTItem(paramItemStack, false, true, false), paramClass)).readOnly().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T readNbt(Entity paramEntity, Class<T> paramClass) {
/* 617 */     return (T)(new ProxyBuilder(new NBTEntity(paramEntity, true), paramClass)).readOnly().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T readNbt(BlockState paramBlockState, Class<T> paramClass) {
/* 629 */     return (T)(new ProxyBuilder(new NBTTileEntity(paramBlockState, true), paramClass)).readOnly().build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T modify(ItemStack paramItemStack, Class<X> paramClass, Function<X, T> paramFunction) {
/* 642 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, false, true);
/* 643 */     T t = paramFunction.apply((X)(new ProxyBuilder(nBTItem, paramClass)).build());
/* 644 */     nBTItem.finalizeChanges();
/* 645 */     if (t instanceof ReadableNBT || t instanceof es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBTList) {
/* 646 */       throw new NbtApiException("Tried returning part of the NBT to outside of the NBT scope!");
/*     */     }
/* 648 */     nBTItem.setClosed();
/* 649 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> void modify(ItemStack paramItemStack, Class<X> paramClass, Consumer<X> paramConsumer) {
/* 660 */     NBTItem nBTItem = new NBTItem(paramItemStack, false, false, true);
/* 661 */     paramConsumer.accept((X)(new ProxyBuilder(nBTItem, paramClass)).build());
/* 662 */     nBTItem.finalizeChanges();
/* 663 */     nBTItem.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> void modify(Entity paramEntity, Class<X> paramClass, Consumer<X> paramConsumer) {
/* 674 */     NBTEntity nBTEntity = new NBTEntity(paramEntity);
/* 675 */     NBTContainer nBTContainer = new NBTContainer(nBTEntity.getCompound());
/* 676 */     paramConsumer.accept((X)(new ProxyBuilder(nBTContainer, paramClass)).build());
/* 677 */     nBTEntity.setCompound(nBTContainer.getCompound());
/* 678 */     nBTContainer.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T modify(Entity paramEntity, Class<X> paramClass, Function<X, T> paramFunction) {
/* 690 */     NBTEntity nBTEntity = new NBTEntity(paramEntity);
/* 691 */     NBTContainer nBTContainer = new NBTContainer(nBTEntity.getCompound());
/* 692 */     T t = paramFunction.apply((X)(new ProxyBuilder(nBTContainer, paramClass)).build());
/* 693 */     nBTEntity.setCompound(nBTContainer.getCompound());
/* 694 */     nBTContainer.setClosed();
/* 695 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> void modify(BlockState paramBlockState, Class<X> paramClass, Consumer<X> paramConsumer) {
/* 706 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState);
/* 707 */     NBTContainer nBTContainer = new NBTContainer(nBTTileEntity.getCompound());
/* 708 */     paramConsumer.accept((X)(new ProxyBuilder(nBTContainer, paramClass)).build());
/* 709 */     nBTTileEntity.setCompound(nBTContainer);
/* 710 */     nBTContainer.setClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, X extends es.pollitoyeye.vehicles.libs.nbtapi.wrapper.NBTProxy> T modify(BlockState paramBlockState, Class<X> paramClass, Function<X, T> paramFunction) {
/* 722 */     NBTTileEntity nBTTileEntity = new NBTTileEntity(paramBlockState);
/* 723 */     NBTContainer nBTContainer = new NBTContainer(nBTTileEntity.getCompound());
/* 724 */     T t = paramFunction.apply((X)(new ProxyBuilder(nBTContainer, paramClass)).build());
/* 725 */     nBTTileEntity.setCompound(nBTContainer);
/* 726 */     nBTContainer.setClosed();
/* 727 */     return t;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBT.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */