/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.CheckUtil;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.block.BlockState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTTileEntity
/*     */   extends NBTCompound
/*     */ {
/*     */   private final BlockState tile;
/*     */   private final boolean readonly;
/*     */   private final Object compound;
/*     */   private boolean closed = false;
/*     */   
/*     */   protected NBTTileEntity(BlockState paramBlockState, boolean paramBoolean) {
/*  30 */     super(null, null);
/*  31 */     if (paramBlockState == null || (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_8_R3) && !paramBlockState.isPlaced())) {
/*  32 */       throw new NullPointerException("Tile can't be null/not placed!");
/*     */     }
/*  34 */     this.tile = paramBlockState;
/*  35 */     this.readonly = paramBoolean;
/*  36 */     if (paramBoolean) {
/*  37 */       this.compound = getCompound();
/*     */     } else {
/*  39 */       this.compound = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTTileEntity(BlockState paramBlockState) {
/*  50 */     super(null, null);
/*  51 */     if (paramBlockState == null || (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_8_R3) && !paramBlockState.isPlaced())) {
/*  52 */       throw new NullPointerException("Tile can't be null/not placed!");
/*     */     }
/*  54 */     this.readonly = false;
/*  55 */     this.compound = null;
/*  56 */     this.tile = paramBlockState;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setClosed() {
/*  61 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isClosed() {
/*  66 */     return this.closed;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isReadOnly() {
/*  71 */     return this.readonly;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCompound() {
/*  77 */     if (this.readonly && this.compound != null) {
/*  78 */       return this.compound;
/*     */     }
/*  80 */     if (!Bukkit.isPrimaryThread())
/*  81 */       throw new NbtApiException("BlockEntity NBT needs to be accessed sync!"); 
/*  82 */     return NBTReflectionUtil.getTileEntityNBTTagCompound(this.tile);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setCompound(Object paramObject) {
/*  87 */     if (this.readonly) {
/*  88 */       throw new NbtApiException("Tried setting data in read only mode!");
/*     */     }
/*  90 */     if (!Bukkit.isPrimaryThread())
/*  91 */       throw new NbtApiException("BlockEntity NBT needs to be accessed sync!"); 
/*  92 */     NBTReflectionUtil.setTileEntityNBTTagCompound(this.tile, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTCompound getPersistentDataContainer() {
/* 102 */     CheckUtil.assertAvailable(MinecraftVersion.MC1_14_R1);
/* 103 */     if (hasTag("PublicBukkitValues")) {
/* 104 */       return getCompound("PublicBukkitValues");
/*     */     }
/* 106 */     NBTContainer nBTContainer = new NBTContainer();
/* 107 */     nBTContainer.addCompound("PublicBukkitValues").setString("__nbtapi", "Marker to make the PersistentDataContainer have content");
/*     */     
/* 109 */     mergeCompound(nBTContainer);
/* 110 */     return getCompound("PublicBukkitValues");
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTTileEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */