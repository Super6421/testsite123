/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.util.Map;
/*    */ import org.bukkit.persistence.PersistentDataContainer;
/*    */ 
/*    */ 
/*    */ public class NBTPersistentDataContainer
/*    */   extends NBTCompound
/*    */ {
/*    */   private final PersistentDataContainer container;
/*    */   
/*    */   public NBTPersistentDataContainer(PersistentDataContainer paramPersistentDataContainer) {
/* 14 */     super(null, null);
/* 15 */     this.container = paramPersistentDataContainer;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getCompound() {
/* 20 */     return ReflectionMethod.CRAFT_PERSISTENT_DATA_CONTAINER_TO_TAG.run(this.container, new Object[0]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setCompound(Object paramObject) {
/* 27 */     Map map = (Map)ReflectionMethod.CRAFT_PERSISTENT_DATA_CONTAINER_GET_MAP.run(this.container, new Object[0]);
/* 28 */     map.clear();
/* 29 */     ReflectionMethod.CRAFT_PERSISTENT_DATA_CONTAINER_PUT_ALL.run(this.container, new Object[] { paramObject });
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTPersistentDataContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */