/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBTCompoundList;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTCompoundList
/*     */   extends NBTList<ReadWriteNBT>
/*     */   implements ReadWriteNBTCompoundList
/*     */ {
/*     */   protected NBTCompoundList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/*  19 */     super(paramNBTCompound, paramString, paramNBTType, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTListCompound addCompound() {
/*  28 */     return (NBTListCompound)addCompound((NBTCompound)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NBTCompound addCompound(NBTCompound paramNBTCompound) {
/*  39 */     if (getParent().isReadOnly()) {
/*  40 */       throw new NbtApiException("Tried setting data in read only mode!");
/*     */     }
/*     */     try {
/*  43 */       Object object = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
/*  44 */       if (MinecraftVersion.getVersion().getVersionId() >= MinecraftVersion.MC1_14_R1.getVersionId()) {
/*  45 */         ReflectionMethod.LIST_ADD.run(this.listObject, new Object[] { Integer.valueOf(size()), object });
/*     */       } else {
/*  47 */         ReflectionMethod.LEGACY_LIST_ADD.run(this.listObject, new Object[] { object });
/*     */       } 
/*  49 */       getParent().saveCompound();
/*  50 */       NBTListCompound nBTListCompound = new NBTListCompound(this, object);
/*  51 */       if (paramNBTCompound != null) {
/*  52 */         nBTListCompound.mergeCompound(paramNBTCompound);
/*     */       }
/*  54 */       return nBTListCompound;
/*  55 */     } catch (Exception exception) {
/*  56 */       throw new NbtApiException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ReadWriteNBT addCompound(ReadableNBT paramReadableNBT) {
/*  62 */     if (paramReadableNBT instanceof NBTCompound) {
/*  63 */       return addCompound((NBTCompound)paramReadableNBT);
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean add(ReadWriteNBT paramReadWriteNBT) {
/*  79 */     return (addCompound((ReadableNBT)paramReadWriteNBT) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, ReadWriteNBT paramReadWriteNBT) {
/*  84 */     if (paramReadWriteNBT != null) {
/*  85 */       throw new NbtApiException("You need to pass null! ListCompounds from other lists won't work.");
/*     */     }
/*  87 */     if (getParent().isReadOnly()) {
/*  88 */       throw new NbtApiException("Tried setting data in read only mode!");
/*     */     }
/*     */     try {
/*  91 */       Object object = ClassWrapper.NMS_NBTTAGCOMPOUND.getClazz().newInstance();
/*  92 */       if (MinecraftVersion.getVersion().getVersionId() >= MinecraftVersion.MC1_14_R1.getVersionId()) {
/*  93 */         ReflectionMethod.LIST_ADD.run(this.listObject, new Object[] { Integer.valueOf(paramInt), object });
/*     */       } else {
/*  95 */         ReflectionMethod.LEGACY_LIST_ADD.run(this.listObject, new Object[] { object });
/*     */       } 
/*  97 */       getParent().saveCompound();
/*  98 */     } catch (Exception exception) {
/*  99 */       throw new NbtApiException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NBTListCompound get(int paramInt) {
/*     */     try {
/* 106 */       Object object = ReflectionMethod.LIST_GET_COMPOUND.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 107 */       return new NBTListCompound(this, object);
/* 108 */     } catch (Exception exception) {
/* 109 */       throw new NbtApiException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public NBTListCompound set(int paramInt, ReadWriteNBT paramReadWriteNBT) {
/* 115 */     throw new NbtApiException("This method doesn't work in the ListCompound context.");
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object asTag(ReadWriteNBT paramReadWriteNBT) {
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTCompoundList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */