/*     */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteItemNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.MinecraftVersion;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import javax.annotation.Nullable;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NBTItem
/*     */   extends NBTCompound
/*     */   implements ReadWriteItemNBT
/*     */ {
/*     */   private ItemStack bukkitItem;
/*     */   private final boolean directApply;
/*     */   private final boolean finalizer;
/*  31 */   private ItemStack originalSrcStack = null;
/*  32 */   private Object cachedCompound = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTItem(ItemStack paramItemStack) {
/*  44 */     this(paramItemStack, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NBTItem(ItemStack paramItemStack, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  55 */     super(null, null, paramBoolean2);
/*  56 */     if (paramItemStack == null || paramItemStack.getType() == Material.AIR || paramItemStack.getAmount() <= 0) {
/*  57 */       throw new NullPointerException("ItemStack can't be null/air/amount of 0! This is not a NBTAPI bug!");
/*     */     }
/*  59 */     this.finalizer = paramBoolean3;
/*  60 */     if (paramBoolean3) {
/*  61 */       this.bukkitItem = paramItemStack;
/*  62 */       this.originalSrcStack = paramItemStack;
/*  63 */       this.directApply = false;
/*  64 */     } else if (paramBoolean2) {
/*  65 */       this.bukkitItem = paramItemStack;
/*  66 */       this.directApply = false;
/*     */     } else {
/*  68 */       this.directApply = paramBoolean1;
/*  69 */       this.bukkitItem = paramItemStack.clone();
/*  70 */       if (paramBoolean1) {
/*  71 */         this.originalSrcStack = paramItemStack;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public NBTItem(ItemStack paramItemStack, boolean paramBoolean) {
/*  86 */     super(null, null);
/*  87 */     if (paramItemStack == null || paramItemStack.getType() == Material.AIR || paramItemStack.getAmount() <= 0) {
/*  88 */       throw new NullPointerException("ItemStack can't be null/air/amount of 0! This is not a NBTAPI bug!");
/*     */     }
/*  90 */     this.finalizer = false;
/*  91 */     this.directApply = paramBoolean;
/*  92 */     this.bukkitItem = paramItemStack.clone();
/*  93 */     if (paramBoolean) {
/*  94 */       this.originalSrcStack = paramItemStack;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCompound() {
/* 100 */     if (this.closed) {
/* 101 */       throw new NbtApiException("Tried using closed NBT data!");
/*     */     }
/* 103 */     if (isReadOnly() && (this.cachedCompound != null || ClassWrapper.CRAFT_ITEMSTACK
/* 104 */       .getClazz().isAssignableFrom(this.bukkitItem.getClass()))) {
/* 105 */       if (this.cachedCompound == null) {
/* 106 */         this
/* 107 */           .cachedCompound = NBTReflectionUtil.getItemRootNBTTagCompound(NBTReflectionUtil.getCraftItemHandle(this.bukkitItem));
/*     */       }
/* 109 */       return this.cachedCompound;
/*     */     } 
/* 111 */     if (this.finalizer) {
/* 112 */       if (this.cachedCompound == null) {
/* 113 */         updateCachedCompound();
/*     */       }
/* 115 */       return this.cachedCompound;
/*     */     } 
/* 117 */     return NBTReflectionUtil.getItemRootNBTTagCompound(ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { this.bukkitItem }));
/*     */   }
/*     */   
/*     */   private void updateCachedCompound() {
/* 121 */     if (this.finalizer) {
/* 122 */       this
/* 123 */         .cachedCompound = NBTReflectionUtil.getItemRootNBTTagCompound(ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { this.bukkitItem }));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void finalizeChanges() {
/* 128 */     if (!this.finalizer || this.cachedCompound == null) {
/*     */       return;
/*     */     }
/*     */     
/* 132 */     if (NBTReflectionUtil.getKeys(this).isEmpty()) {
/* 133 */       this.cachedCompound = null;
/*     */     }
/* 135 */     if (ClassWrapper.CRAFT_ITEMSTACK.getClazz().isAssignableFrom(this.originalSrcStack.getClass())) {
/* 136 */       Object object = NBTReflectionUtil.getCraftItemHandle(this.originalSrcStack);
/* 137 */       NBTReflectionUtil.setItemStackCompound(object, this.cachedCompound);
/* 138 */       this.bukkitItem = this.originalSrcStack;
/*     */     } else {
/* 140 */       Object object = ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { this.bukkitItem });
/* 141 */       NBTReflectionUtil.setItemStackCompound(object, this.cachedCompound);
/* 142 */       this.bukkitItem = (ItemStack)ReflectionMethod.ITEMSTACK_BUKKITMIRROR.run(null, new Object[] { object });
/* 143 */       this.originalSrcStack.setItemMeta(this.bukkitItem.getItemMeta());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setClosed() {
/* 149 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isClosed() {
/* 154 */     return this.closed;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCompound(Object paramObject) {
/* 160 */     if (isReadOnly()) {
/* 161 */       throw new NbtApiException("Tried setting data in read only mode!");
/*     */     }
/* 163 */     if (this.closed) {
/* 164 */       throw new NbtApiException("Tried using closed NBT data!");
/*     */     }
/* 166 */     if (this.finalizer) {
/* 167 */       this.cachedCompound = paramObject;
/*     */       return;
/*     */     } 
/* 170 */     if (paramObject != null && ((Set)ReflectionMethod.COMPOUND_GET_KEYS.run(paramObject, new Object[0])).isEmpty()) {
/* 171 */       paramObject = null;
/*     */     }
/* 173 */     if (ClassWrapper.CRAFT_ITEMSTACK.getClazz().isAssignableFrom(this.bukkitItem.getClass())) {
/* 174 */       Object object = NBTReflectionUtil.getCraftItemHandle(this.bukkitItem);
/* 175 */       NBTReflectionUtil.setItemStackCompound(object, paramObject);
/*     */     } else {
/* 177 */       Object object = ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { this.bukkitItem });
/* 178 */       NBTReflectionUtil.setItemStackCompound(object, paramObject);
/* 179 */       this.bukkitItem = (ItemStack)ReflectionMethod.ITEMSTACK_BUKKITMIRROR.run(null, new Object[] { object });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void applyNBT(ItemStack paramItemStack) {
/* 194 */     if (paramItemStack == null || paramItemStack.getType() == Material.AIR) {
/* 195 */       throw new NullPointerException("ItemStack can't be null/Air! This is not a NBTAPI bug!");
/*     */     }
/* 197 */     NBTItem nBTItem = new NBTItem(new ItemStack(paramItemStack.getType()));
/* 198 */     nBTItem.mergeCompound(this);
/* 199 */     paramItemStack.setItemMeta(nBTItem.getItem().getItemMeta());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void mergeNBT(ItemStack paramItemStack) {
/* 209 */     NBTItem nBTItem = new NBTItem(paramItemStack);
/* 210 */     nBTItem.mergeCompound(this);
/* 211 */     paramItemStack.setItemMeta(nBTItem.getItem().getItemMeta());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void mergeCustomNBT(ItemStack paramItemStack) {
/* 221 */     if (paramItemStack == null || paramItemStack.getType() == Material.AIR) {
/* 222 */       throw new NullPointerException("ItemStack can't be null/Air!");
/*     */     }
/* 224 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/*     */       
/* 226 */       NBT.modify(paramItemStack, paramReadWriteItemNBT -> paramReadWriteItemNBT.mergeCompound((ReadableNBT)this));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 231 */     ItemMeta itemMeta = paramItemStack.getItemMeta();
/* 232 */     NBTReflectionUtil.getUnhandledNBTTags(itemMeta)
/* 233 */       .putAll(NBTReflectionUtil.getUnhandledNBTTags(this.bukkitItem.getItemMeta()));
/* 234 */     paramItemStack.setItemMeta(itemMeta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasCustomNbtData() {
/* 244 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4))
/*     */     {
/* 246 */       return hasNBTData();
/*     */     }
/* 248 */     finalizeChanges();
/* 249 */     ItemMeta itemMeta = this.bukkitItem.getItemMeta();
/* 250 */     return !NBTReflectionUtil.getUnhandledNBTTags(itemMeta).isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void clearCustomNBT() {
/* 258 */     finalizeChanges();
/* 259 */     if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/*     */       
/* 261 */       setCompound((Object)null);
/*     */       return;
/*     */     } 
/* 264 */     ItemMeta itemMeta = this.bukkitItem.getItemMeta();
/* 265 */     NBTReflectionUtil.getUnhandledNBTTags(itemMeta).clear();
/* 266 */     this.bukkitItem.setItemMeta(itemMeta);
/* 267 */     updateCachedCompound();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack getItem() {
/* 274 */     return this.bukkitItem;
/*     */   }
/*     */   
/*     */   protected void setItem(ItemStack paramItemStack) {
/* 278 */     this.bukkitItem = paramItemStack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNBTData() {
/* 288 */     return (getCompound() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyMeta(BiConsumer<ReadableNBT, ItemMeta> paramBiConsumer) {
/* 302 */     finalizeChanges();
/* 303 */     ItemMeta itemMeta = this.bukkitItem.getItemMeta();
/* 304 */     paramBiConsumer.accept((new NBTContainer(getResolvedObject())).setReadOnly(true), itemMeta);
/* 305 */     this.bukkitItem.setItemMeta(itemMeta);
/* 306 */     updateCachedCompound();
/* 307 */     if (this.directApply) {
/* 308 */       if (MinecraftVersion.isAtLeastVersion(MinecraftVersion.MC1_20_R4)) {
/* 309 */         throw new NbtApiException("Direct apply mode meta changes don't work anymore in 1.20.5+. Please switch to the modern NBT.modify sytnax!");
/*     */       }
/*     */       
/* 312 */       applyNBT(this.originalSrcStack);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends ItemMeta> void modifyMeta(Class<T> paramClass, BiConsumer<ReadableNBT, T> paramBiConsumer) {
/* 327 */     finalizeChanges();
/*     */     
/* 329 */     ItemMeta itemMeta = this.bukkitItem.getItemMeta();
/* 330 */     paramBiConsumer.accept((new NBTContainer(getResolvedObject())).setReadOnly(true), (T)itemMeta);
/* 331 */     this.bukkitItem.setItemMeta(itemMeta);
/* 332 */     updateCachedCompound();
/* 333 */     if (this.directApply) {
/* 334 */       applyNBT(this.originalSrcStack);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static NBTContainer convertItemtoNBT(ItemStack paramItemStack) {
/* 347 */     return NBTReflectionUtil.convertNMSItemtoNBTCompound(ReflectionMethod.ITEMSTACK_NMSCOPY.run(null, new Object[] { paramItemStack }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public static ItemStack convertNBTtoItem(NBTCompound paramNBTCompound) {
/* 360 */     return (ItemStack)ReflectionMethod.ITEMSTACK_BUKKITMIRROR.run(null, new Object[] {
/* 361 */           NBTReflectionUtil.convertNBTCompoundtoNMSItem(paramNBTCompound)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static NBTContainer convertItemArraytoNBT(ItemStack[] paramArrayOfItemStack) {
/* 374 */     NBTContainer nBTContainer = new NBTContainer();
/* 375 */     nBTContainer.setInteger("size", Integer.valueOf(paramArrayOfItemStack.length));
/* 376 */     NBTCompoundList nBTCompoundList = nBTContainer.getCompoundList("items");
/* 377 */     for (byte b = 0; b < paramArrayOfItemStack.length; b++) {
/* 378 */       ItemStack itemStack = paramArrayOfItemStack[b];
/* 379 */       if (itemStack != null && itemStack.getType() != Material.AIR) {
/*     */ 
/*     */         
/* 382 */         NBTListCompound nBTListCompound = nBTCompoundList.addCompound();
/* 383 */         nBTListCompound.setInteger("Slot", Integer.valueOf(b));
/* 384 */         nBTListCompound.mergeCompound(convertItemtoNBT(itemStack));
/*     */       } 
/* 386 */     }  return nBTContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Deprecated
/*     */   public static ItemStack[] convertNBTtoItemArray(NBTCompound paramNBTCompound) {
/* 403 */     if (!paramNBTCompound.hasTag("size")) {
/* 404 */       return null;
/*     */     }
/* 406 */     ItemStack[] arrayOfItemStack = new ItemStack[paramNBTCompound.getInteger("size").intValue()];
/* 407 */     for (byte b = 0; b < arrayOfItemStack.length; b++) {
/* 408 */       arrayOfItemStack[b] = new ItemStack(Material.AIR);
/*     */     }
/* 410 */     if (!paramNBTCompound.hasTag("items")) {
/* 411 */       return arrayOfItemStack;
/*     */     }
/* 413 */     NBTCompoundList nBTCompoundList = paramNBTCompound.getCompoundList("items");
/* 414 */     for (ReadWriteNBT readWriteNBT : nBTCompoundList) {
/* 415 */       if (readWriteNBT instanceof NBTCompound) {
/* 416 */         int i = readWriteNBT.getInteger("Slot").intValue();
/* 417 */         arrayOfItemStack[i] = convertNBTtoItem((NBTCompound)readWriteNBT);
/*     */       } 
/*     */     } 
/* 420 */     return arrayOfItemStack;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void saveCompound() {
/* 425 */     if (this.directApply)
/* 426 */       applyNBT(this.originalSrcStack); 
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */