/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.lang.reflect.Constructor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTFloatList
/*    */   extends NBTList<Float>
/*    */ {
/*    */   protected NBTFloatList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/* 18 */     super(paramNBTCompound, paramString, paramNBTType, paramObject);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object asTag(Float paramFloat) {
/*    */     try {
/* 24 */       Constructor constructor = ClassWrapper.NMS_NBTTAGFLOAT.getClazz().getDeclaredConstructor(new Class[] { float.class });
/* 25 */       constructor.setAccessible(true);
/* 26 */       return constructor.newInstance(new Object[] { paramFloat });
/* 27 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException instantiationException) {
/*    */       
/* 29 */       throw new NbtApiException("Error while wrapping the Object " + paramFloat + " to it's NMS object!", instantiationException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Float get(int paramInt) {
/*    */     try {
/* 36 */       Object object = ReflectionMethod.LIST_GET.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 37 */       return Float.valueOf(object.toString());
/* 38 */     } catch (NumberFormatException numberFormatException) {
/* 39 */       return Float.valueOf(0.0F);
/* 40 */     } catch (Exception exception) {
/* 41 */       throw new NbtApiException(exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTFloatList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */