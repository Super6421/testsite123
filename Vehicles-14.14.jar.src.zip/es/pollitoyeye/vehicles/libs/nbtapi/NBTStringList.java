/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTStringList
/*    */   extends NBTList<String>
/*    */ {
/*    */   protected NBTStringList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/* 19 */     super(paramNBTCompound, paramString, paramNBTType, paramObject);
/*    */   }
/*    */ 
/*    */   
/*    */   public String get(int paramInt) {
/*    */     try {
/* 25 */       Object object = ReflectionMethod.LIST_GET_STRING.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 26 */       if (object instanceof Optional) {
/* 27 */         return ((Optional<String>)object).orElse("");
/*    */       }
/* 29 */       return (String)object;
/* 30 */     } catch (Exception exception) {
/* 31 */       throw new NbtApiException(exception);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object asTag(String paramString) {
/*    */     try {
/* 38 */       Constructor constructor = ClassWrapper.NMS_NBTTAGSTRING.getClazz().getDeclaredConstructor(new Class[] { String.class });
/* 39 */       constructor.setAccessible(true);
/* 40 */       return constructor.newInstance(new Object[] { paramString });
/* 41 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException instantiationException) {
/*    */       
/* 43 */       throw new NbtApiException("Error while wrapping the Object " + paramString + " to it's NMS object!", instantiationException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTStringList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */