/*    */ package es.pollitoyeye.vehicles.libs.nbtapi;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.UUIDUtil;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ClassWrapper;
/*    */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.nmsmappings.ReflectionMethod;
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NBTUUIDList
/*    */   extends NBTList<UUID>
/*    */ {
/*    */   private final NBTContainer tmpContainer;
/*    */   
/*    */   protected NBTUUIDList(NBTCompound paramNBTCompound, String paramString, NBTType paramNBTType, Object paramObject) {
/* 22 */     super(paramNBTCompound, paramString, paramNBTType, paramObject);
/* 23 */     this.tmpContainer = new NBTContainer();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object asTag(UUID paramUUID) {
/*    */     try {
/* 29 */       Constructor constructor = ClassWrapper.NMS_NBTTAGINTARRAY.getClazz().getDeclaredConstructor(new Class[] { int[].class });
/* 30 */       constructor.setAccessible(true);
/* 31 */       return constructor.newInstance(new Object[] { UUIDUtil.uuidToIntArray(paramUUID) });
/* 32 */     } catch (InstantiationException|IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException instantiationException) {
/*    */       
/* 34 */       throw new NbtApiException("Error while wrapping the Object " + paramUUID + " to it's NMS object!", instantiationException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public UUID get(int paramInt) {
/*    */     try {
/* 41 */       Object object = ReflectionMethod.LIST_GET.run(this.listObject, new Object[] { Integer.valueOf(paramInt) });
/* 42 */       ReflectionMethod.COMPOUND_SET.run(this.tmpContainer.getCompound(), new Object[] { "tmp", object });
/* 43 */       int[] arrayOfInt = this.tmpContainer.getIntArray("tmp");
/* 44 */       this.tmpContainer.removeKey("tmp");
/* 45 */       return UUIDUtil.uuidFromIntArray(arrayOfInt);
/* 46 */     } catch (NumberFormatException numberFormatException) {
/* 47 */       return null;
/* 48 */     } catch (Exception exception) {
/* 49 */       throw new NbtApiException(exception);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\libs\nbtapi\NBTUUIDList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */