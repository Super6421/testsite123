/*    */ package es.pollitoyeye.vehicles.manager;
/*    */ 
/*    */ import com.google.common.collect.BiMap;
/*    */ import com.google.common.collect.HashBiMap;
/*    */ import es.pollitoyeye.vehicles.beans.VehicleInventory;
/*    */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*    */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*    */ import java.util.HashMap;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.inventory.InventoryClickEvent;
/*    */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ 
/*    */ public class VehicleInventoryManager
/*    */   implements Listener
/*    */ {
/* 21 */   private HashBiMap<Player, VehicleInventory> inventoryMap = HashBiMap.create();
/* 22 */   private HashMap<VehicleInventory, ArmorStand> armorStandMap = new HashMap<>();
/*    */   public void open(Player paramPlayer, ArmorStand paramArmorStand, VehicleType paramVehicleType, VehicleSubType paramVehicleSubType) {
/* 24 */     VehicleInventory vehicleInventory = new VehicleInventory(paramVehicleType, paramVehicleSubType, paramPlayer, paramArmorStand);
/* 25 */     this.inventoryMap.put(paramPlayer, vehicleInventory);
/* 26 */     this.armorStandMap.put(vehicleInventory, paramArmorStand);
/* 27 */     paramPlayer.openInventory(vehicleInventory.getInventory());
/*    */   }
/*    */   public void deleteAllForArmorStand(ArmorStand paramArmorStand) {
/* 30 */     if (this.armorStandMap.containsValue(paramArmorStand))
/* 31 */       for (VehicleInventory vehicleInventory : this.armorStandMap.keySet()) {
/* 32 */         if (((ArmorStand)this.armorStandMap.get(vehicleInventory)).equals(paramArmorStand)) {
/* 33 */           deleteInventory(vehicleInventory);
/*    */         }
/*    */       }  
/*    */   }
/*    */   
/*    */   public void deleteInventory(VehicleInventory paramVehicleInventory) {
/* 39 */     BiMap biMap = this.inventoryMap.inverse();
/* 40 */     if (biMap.containsKey(paramVehicleInventory)) {
/* 41 */       Player player = (Player)biMap.get(paramVehicleInventory);
/* 42 */       if (player.getOpenInventory() != null && player
/* 43 */         .getOpenInventory().getTopInventory() != null && player
/* 44 */         .getOpenInventory().getTopInventory().equals(paramVehicleInventory.getInventory())) {
/* 45 */         player.closeInventory();
/*    */       }
/* 47 */       this.inventoryMap.remove(player);
/* 48 */       this.armorStandMap.remove(paramVehicleInventory);
/*    */     } 
/*    */   }
/*    */   public void deleteInventory(Player paramPlayer, boolean paramBoolean) {
/* 52 */     if (this.inventoryMap.containsKey(paramPlayer)) {
/* 53 */       VehicleInventory vehicleInventory = (VehicleInventory)this.inventoryMap.get(paramPlayer);
/* 54 */       if (paramBoolean && paramPlayer.getOpenInventory() != null && paramPlayer
/* 55 */         .getOpenInventory().getTopInventory() != null && paramPlayer
/* 56 */         .getOpenInventory().getTopInventory().equals(vehicleInventory.getInventory())) {
/* 57 */         paramPlayer.closeInventory();
/*    */       }
/* 59 */       this.inventoryMap.remove(paramPlayer);
/* 60 */       this.armorStandMap.remove(vehicleInventory);
/*    */     } 
/*    */   }
/*    */   @EventHandler
/*    */   public void onClick(InventoryClickEvent paramInventoryClickEvent) {
/* 65 */     Player player = (Player)paramInventoryClickEvent.getWhoClicked();
/* 66 */     if (player.getOpenInventory() == null || player.getOpenInventory().getTopInventory() == null) {
/*    */       return;
/*    */     }
/* 69 */     if (paramInventoryClickEvent.getClickedInventory() != null) {
/* 70 */       VehicleInventory vehicleInventory = (VehicleInventory)this.inventoryMap.get(player);
/* 71 */       if (vehicleInventory != null && paramInventoryClickEvent.getClickedInventory().equals(vehicleInventory.getInventory())) {
/* 72 */         paramInventoryClickEvent.setCancelled(true);
/* 73 */         vehicleInventory.click(paramInventoryClickEvent);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void onPlayerLeave(PlayerQuitEvent paramPlayerQuitEvent) {
/* 80 */     deleteInventory(paramPlayerQuitEvent.getPlayer(), false);
/*    */   }
/*    */   @EventHandler
/*    */   public void onInventoryClose(InventoryCloseEvent paramInventoryCloseEvent) {
/* 84 */     deleteInventory((Player)paramInventoryCloseEvent.getPlayer(), false);
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\manager\VehicleInventoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */