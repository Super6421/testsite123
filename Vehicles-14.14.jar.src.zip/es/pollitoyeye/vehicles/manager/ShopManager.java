/*     */ package es.pollitoyeye.vehicles.manager;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import net.milkbowl.vault.economy.Economy;
/*     */ import net.milkbowl.vault.economy.EconomyResponse;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.RegisteredServiceProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShopManager
/*     */   implements Listener
/*     */ {
/*  27 */   HashMap<VehicleType, HashMap<Integer, String>> vehicleTypes = new HashMap<>(); private Economy econ;
/*  28 */   HashMap<VehicleType, HashMap<String, Integer>> vehiclePrices = new HashMap<>();
/*     */   
/*     */   public void clearConfig() {
/*  31 */     this.vehicleTypes = new HashMap<>();
/*  32 */     this.vehiclePrices = new HashMap<>();
/*     */   }
/*     */   public void loadConfig() {
/*  35 */     if (isVaultEnabled() && setupEconomy()) {
/*  36 */       FileConfiguration fileConfiguration = VehiclesMain.getPlugin().getConfig();
/*  37 */       VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/*  38 */       for (VehicleType vehicleType : VehicleType.values()) {
/*  39 */         String str = vehicleType.getConfigName().toLowerCase();
/*  40 */         if (fileConfiguration.contains(str + "-shopsize")) {
/*     */           try {
/*  42 */             int i = fileConfiguration.getInt(str + "-shopsize");
/*  43 */             String str1 = vehicleType.getConfigName() + " Shop";
/*  44 */             if (fileConfiguration.contains(str + "-shoptitle")) {
/*  45 */               str1 = fileConfiguration.getString(str + "-shoptitle").replace("&", "§");
/*     */             }
/*  47 */             Inventory inventory = Bukkit.createInventory(null, i, str1);
/*  48 */             HashMap<Object, Object> hashMap1 = new HashMap<>();
/*  49 */             HashMap<Object, Object> hashMap2 = new HashMap<>();
/*  50 */             for (String str2 : fileConfiguration.getConfigurationSection(str + "-shopslots").getKeys(false)) {
/*  51 */               int j = Integer.parseInt(str2);
/*  52 */               String str3 = fileConfiguration.getString(str + "-shopslots." + str2 + "." + str + "Type");
/*  53 */               int k = fileConfiguration.getInt(str + "-shopslots." + str2 + ".price");
/*  54 */               Material material = Material.getMaterial(fileConfiguration.getString(str + "-shopslots." + str2 + ".itemMaterial"));
/*  55 */               String str4 = fileConfiguration.getString(str + "-shopslots." + str2 + ".itemDisplayName").replace("&", "§");
/*  56 */               ArrayList<String> arrayList = new ArrayList();
/*  57 */               for (String str5 : fileConfiguration.getStringList(str + "-shopslots." + str2 + ".itemLore")) {
/*  58 */                 arrayList.add(str5.replace("&", "§"));
/*     */               }
/*  60 */               ItemStack itemStack = new ItemStack(material, 1);
/*  61 */               ItemMeta itemMeta = itemStack.getItemMeta();
/*  62 */               itemMeta.setDisplayName(str4);
/*  63 */               itemMeta.setLore(arrayList);
/*  64 */               itemStack.setItemMeta(itemMeta);
/*  65 */               inventory.setItem(j, itemStack);
/*  66 */               hashMap1.put(Integer.valueOf(j), str3);
/*  67 */               hashMap2.put(str3, Integer.valueOf(k));
/*     */             } 
/*  69 */             this.vehicleTypes.put(vehicleType, hashMap1);
/*  70 */             this.vehiclePrices.put(vehicleType, hashMap2);
/*  71 */             vehiclesMain.shopInventoryMap.put(vehicleType, inventory);
/*  72 */             vehiclesMain.shopEnabledMap.put(vehicleType, Boolean.valueOf(true));
/*  73 */           } catch (Exception exception) {
/*  74 */             System.out.println("Vehicles >> An error ocurred while loading the " + str + " shop, disabling...");
/*  75 */             exception.printStackTrace();
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } else {
/*  80 */       System.out.println("Vehicles >> Vault Economy not found, disabling shop.");
/*     */     } 
/*     */   }
/*     */   private boolean isVaultEnabled() {
/*  84 */     if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
/*  85 */       return true;
/*     */     }
/*  87 */     return false;
/*     */   }
/*     */   
/*     */   private boolean setupEconomy() {
/*  91 */     RegisteredServiceProvider registeredServiceProvider = Bukkit.getServer().getServicesManager().getRegistration(Economy.class);
/*  92 */     if (registeredServiceProvider == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     this.econ = (Economy)registeredServiceProvider.getProvider();
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onClick(InventoryClickEvent paramInventoryClickEvent) {
/* 101 */     Player player = (Player)paramInventoryClickEvent.getWhoClicked();
/* 102 */     if (player.getOpenInventory() == null || player.getOpenInventory().getTopInventory() == null) {
/*     */       return;
/*     */     }
/* 105 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 106 */     Inventory inventory = null;
/* 107 */     VehicleType vehicleType = null;
/* 108 */     for (VehicleType vehicleType1 : vehiclesMain.shopInventoryMap.keySet()) {
/* 109 */       inventory = (Inventory)vehiclesMain.shopInventoryMap.get(vehicleType1);
/* 110 */       if (player.getOpenInventory().getTopInventory().equals(inventory)) {
/* 111 */         vehicleType = vehicleType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 115 */     if (vehicleType != null) {
/* 116 */       paramInventoryClickEvent.setCancelled(true);
/* 117 */       if (paramInventoryClickEvent.getClickedInventory() != null && paramInventoryClickEvent.getClickedInventory().equals(inventory)) {
/* 118 */         HashMap hashMap1 = this.vehicleTypes.get(vehicleType);
/* 119 */         HashMap hashMap2 = this.vehiclePrices.get(vehicleType);
/* 120 */         if (hashMap1.containsKey(Integer.valueOf(paramInventoryClickEvent.getSlot()))) {
/* 121 */           String str = (String)hashMap1.get(Integer.valueOf(paramInventoryClickEvent.getSlot()));
/* 122 */           if (hashMap2.containsKey(str)) {
/* 123 */             int i = ((Integer)hashMap2.get(str)).intValue();
/* 124 */             boolean bool = false;
/* 125 */             VehicleSubType vehicleSubType = null;
/* 126 */             for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(vehicleType)) {
/* 127 */               if (vehicleSubType1.getName().equals(str)) {
/* 128 */                 vehicleSubType = vehicleSubType1;
/* 129 */                 bool = true;
/*     */                 break;
/*     */               } 
/*     */             } 
/* 133 */             if (bool) {
/* 134 */               if (vehicleSubType.getPermission() != null && 
/* 135 */                 !player.hasPermission(vehicleSubType.getPermission())) {
/* 136 */                 player.sendMessage(vehiclesMain.getLang().getValue(vehicleType.getConfigName().toLowerCase() + "-buy-nopermission"));
/*     */                 
/*     */                 return;
/*     */               } 
/* 140 */               double d = this.econ.getBalance(player.getName());
/* 141 */               if (d >= i) {
/* 142 */                 EconomyResponse economyResponse = this.econ.withdrawPlayer(player.getName(), i);
/* 143 */                 if (economyResponse.transactionSuccess()) {
/* 144 */                   player.sendMessage(vehiclesMain.getLang().getValue(vehicleType.getConfigName().toLowerCase() + "-buy-buy").replace("%type%", vehicleSubType.getDisplayName()));
/* 145 */                   vehicleType.getVehicleManager().giveItem(player, vehicleSubType.getName(), new ItemStack[0]);
/*     */                 } else {
/* 147 */                   player.sendMessage(vehiclesMain.getLang().getValue(vehicleType.getConfigName().toLowerCase() + "-error-money"));
/*     */                 } 
/*     */               } else {
/* 150 */                 player.sendMessage(vehiclesMain.getLang().getValue(vehicleType.getConfigName().toLowerCase() + "-notenoughmoney"));
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\manager\ShopManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */