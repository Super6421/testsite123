/*     */ package es.pollitoyeye.vehicles.manager;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.EulerAngle;
/*     */ 
/*     */ 
/*     */ public class StructureManager
/*     */ {
/*  20 */   private static HashMap<String, FileConfiguration> configCache = new HashMap<>();
/*     */   public static ArrayList<ArmorStand> loadStructure(Location paramLocation, String paramString, boolean paramBoolean) {
/*  22 */     if (!configCache.containsKey(paramString)) {
/*  23 */       configCache.put(paramString, 
/*  24 */           YamlConfiguration.loadConfiguration(new InputStreamReader(VehiclesMain.getPlugin().getResource(paramString))));
/*     */     }
/*     */     
/*  27 */     FileConfiguration fileConfiguration = configCache.get(paramString);
/*  28 */     ArrayList<ArmorStand> arrayList = new ArrayList();
/*  29 */     byte b = 0;
/*  30 */     while (fileConfiguration.contains("" + b)) {
/*  31 */       byte b1 = b;
/*  32 */       ItemStack itemStack1 = fileConfiguration.getItemStack(b1 + ".helmet");
/*  33 */       ItemStack itemStack2 = fileConfiguration.getItemStack(b1 + ".leggings");
/*  34 */       ItemStack itemStack3 = fileConfiguration.getItemStack(b1 + ".chestplate");
/*  35 */       ItemStack itemStack4 = fileConfiguration.getItemStack(b1 + ".boots");
/*  36 */       ItemStack itemStack5 = fileConfiguration.getItemStack(b1 + ".hand");
/*  37 */       ItemStack itemStack6 = new ItemStack(Material.AIR);
/*  38 */       if (fileConfiguration.contains(b1 + ".left-hand")) {
/*  39 */         itemStack6 = fileConfiguration.getItemStack(b1 + ".left-hand");
/*     */       }
/*  41 */       boolean bool1 = fileConfiguration.getBoolean(b1 + ".visible");
/*  42 */       boolean bool2 = fileConfiguration.getBoolean(b1 + ".small");
/*  43 */       boolean bool3 = fileConfiguration.getBoolean(b1 + ".arms");
/*  44 */       boolean bool4 = fileConfiguration.getBoolean(b1 + ".plate");
/*  45 */       EulerAngle eulerAngle1 = new EulerAngle(fileConfiguration.getDouble(b1 + ".body.x"), fileConfiguration.getDouble(b1 + ".body.y"), fileConfiguration.getDouble(b1 + ".body.z"));
/*  46 */       EulerAngle eulerAngle2 = new EulerAngle(fileConfiguration.getDouble(b1 + ".head.x"), fileConfiguration.getDouble(b1 + ".head.y"), fileConfiguration.getDouble(b1 + ".head.z"));
/*  47 */       EulerAngle eulerAngle3 = new EulerAngle(fileConfiguration.getDouble(b1 + ".leftarm.x"), fileConfiguration.getDouble(b1 + ".leftarm.y"), fileConfiguration.getDouble(b1 + ".leftarm.z"));
/*  48 */       EulerAngle eulerAngle4 = new EulerAngle(fileConfiguration.getDouble(b1 + ".rightarm.x"), fileConfiguration.getDouble(b1 + ".rightarm.y"), fileConfiguration.getDouble(b1 + ".rightarm.z"));
/*  49 */       EulerAngle eulerAngle5 = new EulerAngle(fileConfiguration.getDouble(b1 + ".leftleg.x"), fileConfiguration.getDouble(b1 + ".leftleg.y"), fileConfiguration.getDouble(b1 + ".leftleg.z"));
/*  50 */       EulerAngle eulerAngle6 = new EulerAngle(fileConfiguration.getDouble(b1 + ".rightleg.x"), fileConfiguration.getDouble(b1 + ".rightleg.y"), fileConfiguration.getDouble(b1 + ".rightleg.z"));
/*  51 */       float f1 = Float.parseFloat(fileConfiguration.get(b1 + ".pitch").toString());
/*  52 */       float f2 = Float.parseFloat(fileConfiguration.get(b1 + ".yaw").toString());
/*  53 */       double d1 = fileConfiguration.getDouble(b1 + ".position.x");
/*  54 */       double d2 = fileConfiguration.getDouble(b1 + ".position.y");
/*  55 */       double d3 = fileConfiguration.getDouble(b1 + ".position.z");
/*  56 */       Location location = new Location(paramLocation.getWorld(), paramLocation.getX() - d1, paramLocation.getY() - d2, paramLocation.getZ() - d3);
/*  57 */       if (EntityUtils.newHandRender && paramBoolean) {
/*  58 */         if (itemStack5.getType() != Material.AIR && (itemStack5.getType().isBlock() || itemStack5.getType() == Material.PLAYER_HEAD)) {
/*  59 */           if (itemStack5.getType() != Material.PLAYER_HEAD) {
/*  60 */             eulerAngle4 = new EulerAngle(4.869468613064179D, 1.5707963267948966D, 1.9896753472735356D);
/*     */           }
/*  62 */           bool3 = true;
/*  63 */           if (itemStack5.getType().toString().endsWith("_WOOL") || itemStack5.getType() == Material.PLAYER_HEAD || itemStack5.getType() == Material.BRICKS) {
/*  64 */             eulerAngle4 = new EulerAngle(-0.8028514559173915D, 2.356194490192345D, -0.017453292519943295D);
/*  65 */             f2 = 180.0F;
/*  66 */             if (itemStack5.getType() == Material.BRICKS) {
/*  67 */               location.setY(location.getY());
/*  68 */               location.setX(location.getX());
/*  69 */               location.setZ(location.getZ() - 0.71D);
/*     */             } else {
/*  71 */               location.setY(location.getY() + 0.12D);
/*  72 */               location.setX(location.getX() - 0.45D);
/*  73 */               if (paramString.equals("Tank.schem")) {
/*  74 */                 location.setZ(location.getZ() - 0.59D);
/*     */               } else {
/*  76 */                 location.setZ(location.getZ() - 0.61D);
/*     */               } 
/*     */             } 
/*     */           } else {
/*  80 */             location.setY(location.getY() - 0.41D);
/*  81 */             location.setX(location.getX() - 0.34D);
/*     */           } 
/*     */         } 
/*  84 */         if (itemStack5.getType() == Material.ELYTRA) {
/*  85 */           location.setX(location.getX() + 0.03D);
/*  86 */           location.setY(location.getY() + 0.09D);
/*  87 */           eulerAngle4 = new EulerAngle(4.71238898038469D, 0.0D, 0.0D);
/*     */         } 
/*  89 */         if (itemStack5.getType().toString().endsWith("_BANNER")) {
/*  90 */           location.setY(location.getY() + 0.12D);
/*  91 */           location.setZ(location.getZ() + 0.04D);
/*     */         } 
/*  93 */         if (itemStack5.getType() == Material.STONE_HOE) {
/*  94 */           location.setY(location.getY() + 0.16D);
/*  95 */           if (eulerAngle4.getY() < 3.0D) {
/*  96 */             eulerAngle4 = eulerAngle4.setY(eulerAngle4.getY() - 0.4D);
/*     */           } else {
/*  98 */             eulerAngle4 = eulerAngle4.setY(eulerAngle4.getY() + 0.4D);
/*     */           } 
/*     */         } 
/* 101 */         if (itemStack5.getType() == Material.WOODEN_SHOVEL) {
/* 102 */           location.setY(location.getY() + 0.1D);
/*     */         }
/*     */       } 
/* 105 */       location.setPitch(f1);
/* 106 */       location.setYaw(f2);
/* 107 */       ArmorStand armorStand = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
/*     */       
/* 109 */       EntityUtils.setGravity(armorStand, false);
/* 110 */       armorStand.teleport(location);
/* 111 */       armorStand.setHelmet(itemStack1);
/* 112 */       armorStand.setLeggings(itemStack2);
/* 113 */       armorStand.setChestplate(itemStack3);
/* 114 */       armorStand.setBoots(itemStack4);
/* 115 */       armorStand.setItemInHand(itemStack5);
/* 116 */       armorStand.getEquipment().setItemInOffHand(itemStack6);
/* 117 */       armorStand.setVisible(bool1);
/* 118 */       armorStand.setSmall(bool2);
/* 119 */       armorStand.setArms(bool3);
/* 120 */       armorStand.setBasePlate(bool4);
/* 121 */       armorStand.setBodyPose(eulerAngle1);
/* 122 */       armorStand.setHeadPose(eulerAngle2);
/* 123 */       armorStand.setLeftArmPose(eulerAngle3);
/* 124 */       armorStand.setRightArmPose(eulerAngle4);
/* 125 */       armorStand.setLeftLegPose(eulerAngle5);
/* 126 */       armorStand.setRightLegPose(eulerAngle6);
/* 127 */       arrayList.add(armorStand);
/* 128 */       b++;
/*     */     } 
/* 130 */     return arrayList;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\manager\StructureManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */