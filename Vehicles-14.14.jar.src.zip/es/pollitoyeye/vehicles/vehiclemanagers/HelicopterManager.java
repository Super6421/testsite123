/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.HelicopterType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class HelicopterManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(0.0D, -0.68D, 0.6D);
/*  33 */     HelicopterType helicopterType = HelicopterType.valueOf(paramString2);
/*  34 */     String str1 = helicopterType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Helicopter.schem", true) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(new Vector(0.5D, 0.68D, -0.1D));
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (helicopterType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(helicopterType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.48D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("HeliPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("HeliPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str2 = "Heli;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*  62 */     for (ArmorStand armorStand : arrayList) {
/*  63 */       EntityUtils.removeSlots(armorStand);
/*  64 */       float f = j - armorStand.getLocation().getYaw();
/*  65 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  66 */       double d = getMultiple(armorStand, armorStand1);
/*  67 */       armorStand.setCustomName("HeliPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  68 */       if (armorStand.getHelmet().getType() == Material.CYAN_TERRACOTTA) {
/*  69 */         armorStand.setHelmet(helicopterType.getMaterial()); continue;
/*     */       } 
/*  71 */       if (armorStand.getHelmet().getType().toString().endsWith("_BANNER")) {
/*  72 */         armorStand.setHelmet(helicopterType.getHelixMaterial());
/*     */       }
/*     */     } 
/*  75 */     armorStand1.setCustomName(str2);
/*  76 */     EntityUtils.removeSlots(armorStand1);
/*  77 */     EntityUtils.removeSlots(armorStand2);
/*  78 */     EntityUtils.removeSlots(armorStand3);
/*  79 */     EntityUtils.saveUUIDData(armorStand1);
/*  80 */     EntityUtils.saveUUIDData(armorStand2);
/*  81 */     EntityUtils.saveUUIDData(armorStand3);
/*  82 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  83 */     for (ArmorStand armorStand : arrayList) {
/*  84 */       arrayList1.add(armorStand);
/*     */     }
/*  86 */     arrayList1.add(armorStand1);
/*  87 */     arrayList1.add(armorStand2);
/*  88 */     arrayList1.add(armorStand3);
/*  89 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, helicopterType.getName(), VehicleType.HELICOPTER);
/*  90 */     EntityUtils.setYaw((Entity)armorStand1, 180.0F);
/*  91 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  92 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/*  95 */     int i = paramPlayer.getInventory().firstEmpty();
/*  96 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/*  97 */     if (i != -1) {
/*  98 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 100 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 104 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 105 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 106 */     boolean bool = false;
/* 107 */     VehicleSubType vehicleSubType = null;
/* 108 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.HELICOPTER)) {
/* 109 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 110 */         bool = true;
/* 111 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 115 */     if (bool) {
/* 116 */       HelicopterType helicopterType = (HelicopterType)vehicleSubType;
/* 117 */       String str = helicopterType.getDisplayName();
/* 118 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 119 */       itemMeta.setDisplayName(str);
/* 120 */       ArrayList<String> arrayList = new ArrayList();
/* 121 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", helicopterType.getDisplayName()));
/* 122 */       itemMeta.setLore(arrayList);
/* 123 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 124 */       itemStack.setItemMeta(itemMeta);
/* 125 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 127 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 130 */     int i = paramPlayer.getInventory().firstEmpty();
/* 131 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 132 */     if (i != -1) {
/* 133 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 135 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 139 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 140 */     if (paramDouble1 < 0.01D) {
/* 141 */       paramDouble1 = 0.01D;
/*     */     }
/* 143 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 144 */     boolean bool = false;
/* 145 */     VehicleSubType vehicleSubType = null;
/* 146 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.HELICOPTER)) {
/* 147 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 148 */         bool = true;
/* 149 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 153 */     if (bool) {
/* 154 */       HelicopterType helicopterType = (HelicopterType)vehicleSubType;
/* 155 */       String str = helicopterType.getDisplayName();
/* 156 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 157 */       itemMeta.setDisplayName(str);
/* 158 */       ArrayList<String> arrayList = new ArrayList();
/* 159 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", helicopterType.getDisplayName()));
/* 160 */       arrayList.add("");
/* 161 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 162 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + helicopterType.getMaxHealth());
/*     */       }
/* 164 */       if (vehiclesMain.fuelEnabled) {
/* 165 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + helicopterType.getFuelCapacity());
/*     */       }
/* 167 */       itemMeta.setLore(arrayList);
/* 168 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 169 */       itemStack.setItemMeta(itemMeta);
/* 170 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 172 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 175 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 176 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 177 */     String str = NumberUtils.getInstance().firstChars(d);
/* 178 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 182 */     Vector vector = new Vector();
/* 183 */     double d1 = paramFloat1;
/* 184 */     double d2 = paramFloat2;
/* 185 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 186 */     double d3 = Math.cos(Math.toRadians(d2));
/* 187 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 188 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 189 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 192 */     Location location1 = paramArmorStand2.getLocation();
/* 193 */     Location location2 = paramArmorStand1.getLocation();
/* 194 */     double d1 = -(location1.getX() - location2.getX());
/* 195 */     double d2 = location1.getY() - location2.getY();
/* 196 */     double d3 = location1.getZ() - location2.getZ();
/* 197 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 200 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\HelicopterManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */