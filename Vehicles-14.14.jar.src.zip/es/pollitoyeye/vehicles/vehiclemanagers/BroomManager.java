/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.BroomType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class BroomManager
/*     */   implements VehicleManager
/*     */ {
/*  29 */   private static float j = 0.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(-0.4D, 0.4D, 0.0D);
/*  33 */     BroomType broomType = BroomType.valueOf(paramString2);
/*     */     
/*  35 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation.clone().subtract(0.0D, 0.9D, 0.0D), "Broom.schem", true) : new ArrayList();
/*  36 */     Location location1 = paramLocation.clone().add(0.5D, -0.35D, 0.0D).add(0.5D, 0.0D, 0.5D);
/*  37 */     location1.setYaw(180.0F);
/*  38 */     location1.setPitch(0.0F);
/*  39 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  40 */     if (broomType.getModelItem() != null) {
/*  41 */       armorStand1.getEquipment().setHelmet(broomType.getModelItem());
/*     */     }
/*  43 */     EntityUtils.setGravity(armorStand1, false);
/*  44 */     armorStand1.setVisible(false);
/*  45 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -2.36D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  46 */     EntityUtils.setGravity(armorStand2, false);
/*  47 */     armorStand2.setVisible(false);
/*  48 */     armorStand2.setCustomName("BroomPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  49 */     EntityUtils.setYaw((Entity)armorStand2, 0.0F);
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("BroomPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str = "Broom;" + broomType + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*  62 */     for (ArmorStand armorStand : arrayList) {
/*  63 */       EntityUtils.removeSlots(armorStand);
/*  64 */       float f = j - armorStand.getLocation().getYaw();
/*  65 */       f += 90.0F;
/*  66 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  67 */       double d = getMultiple(armorStand, armorStand1);
/*  68 */       armorStand.setCustomName("BroomPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*     */     } 
/*  70 */     armorStand1.setCustomName(str);
/*  71 */     EntityUtils.removeSlots(armorStand1);
/*  72 */     EntityUtils.removeSlots(armorStand2);
/*  73 */     EntityUtils.removeSlots(armorStand3);
/*  74 */     EntityUtils.saveUUIDData(armorStand1);
/*  75 */     EntityUtils.saveUUIDData(armorStand2);
/*  76 */     EntityUtils.saveUUIDData(armorStand3);
/*  77 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  78 */     for (ArmorStand armorStand : arrayList) {
/*  79 */       arrayList1.add(armorStand);
/*     */     }
/*  81 */     arrayList1.add(armorStand1);
/*  82 */     arrayList1.add(armorStand2);
/*  83 */     arrayList1.add(armorStand3);
/*  84 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, broomType.getName(), VehicleType.BROOM);
/*  85 */     EntityUtils.setYaw((Entity)armorStand1, 90.0F);
/*  86 */     EntityUtils.setYaw((Entity)armorStand2, 90.0F);
/*  87 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  88 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/*  91 */     int i = paramPlayer.getInventory().firstEmpty();
/*  92 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/*  93 */     if (i != -1) {
/*  94 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/*  96 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 100 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 101 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 102 */     boolean bool = false;
/* 103 */     VehicleSubType vehicleSubType = null;
/* 104 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.BROOM)) {
/* 105 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 106 */         bool = true;
/* 107 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 111 */     if (bool) {
/* 112 */       BroomType broomType = (BroomType)vehicleSubType;
/* 113 */       String str = broomType.getDisplayName();
/* 114 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 115 */       itemMeta.setDisplayName(str);
/* 116 */       ArrayList<String> arrayList = new ArrayList();
/* 117 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", broomType.getDisplayName()));
/* 118 */       itemMeta.setLore(arrayList);
/* 119 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 120 */       itemStack.setItemMeta(itemMeta);
/*     */     } 
/* 122 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 125 */     int i = paramPlayer.getInventory().firstEmpty();
/* 126 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 127 */     if (i != -1) {
/* 128 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 130 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 134 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 135 */     if (paramDouble1 < 0.01D) {
/* 136 */       paramDouble1 = 0.01D;
/*     */     }
/* 138 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 139 */     boolean bool = false;
/* 140 */     VehicleSubType vehicleSubType = null;
/* 141 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.BROOM)) {
/* 142 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 143 */         bool = true;
/* 144 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 148 */     if (bool) {
/* 149 */       BroomType broomType = (BroomType)vehicleSubType;
/* 150 */       String str = broomType.getDisplayName();
/* 151 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 152 */       itemMeta.setDisplayName(str);
/* 153 */       ArrayList<String> arrayList = new ArrayList();
/* 154 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", broomType.getDisplayName()));
/* 155 */       arrayList.add("");
/* 156 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 157 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + broomType.getMaxHealth());
/*     */       }
/* 159 */       itemMeta.setLore(arrayList);
/* 160 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/*     */       
/* 162 */       itemStack.setItemMeta(itemMeta);
/*     */     } 
/* 164 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 167 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 168 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 169 */     String str = NumberUtils.getInstance().firstChars(d);
/* 170 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 174 */     Vector vector = new Vector();
/* 175 */     double d1 = paramFloat1;
/* 176 */     double d2 = paramFloat2;
/* 177 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 178 */     double d3 = Math.cos(Math.toRadians(d2));
/* 179 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 180 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 181 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 184 */     Location location1 = paramArmorStand2.getLocation();
/* 185 */     Location location2 = paramArmorStand1.getLocation();
/* 186 */     double d1 = location1.getX() - location2.getX();
/* 187 */     double d2 = location1.getY() - location2.getY();
/* 188 */     double d3 = location1.getZ() - location2.getZ();
/* 189 */     return new Vector(d3, d2, d1);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 192 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\BroomManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */