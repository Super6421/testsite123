/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.MechaType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class MechaManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(0.0D, 0.3D, -0.25D);
/*  33 */     MechaType mechaType = MechaType.valueOf(paramString2);
/*  34 */     String str1 = mechaType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Mecha.schem", false) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(0.0D, -0.3D, 0.25D).add(0.5D, 0.05D, 0.5D);
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (mechaType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(mechaType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, 0.5D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("MechaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, 1.5D, 0.0D), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("MechaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     ArmorStand armorStand4 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  55 */     EntityUtils.setGravity(armorStand4, false);
/*  56 */     armorStand4.setVisible(false);
/*  57 */     armorStand4.setCustomName("MechaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand4, armorStand1) + ";" + vectortoString(getPositionVector(armorStand4, armorStand1)) + ";");
/*  58 */     armorStand4.setPassenger((Entity)armorStand2);
/*  59 */     String str2 = "Mecha;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand4.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  60 */     Location location2 = armorStand4.getLocation();
/*  61 */     location2.setYaw(0.0F);
/*  62 */     armorStand4.teleport(location2);
/*  63 */     location2 = armorStand2.getLocation();
/*  64 */     location2.setYaw(0.0F);
/*  65 */     armorStand2.teleport(location2);
/*     */     
/*  67 */     for (ArmorStand armorStand : arrayList) {
/*  68 */       EntityUtils.removeSlots(armorStand);
/*  69 */       float f = j - armorStand.getLocation().getYaw();
/*  70 */       f -= 90.0F;
/*  71 */       Material material = armorStand.getHelmet().getType();
/*  72 */       String str3 = armorStand.getHelmet().hasItemMeta() ? armorStand.getHelmet().getItemMeta().getDisplayName() : null;
/*  73 */       String str4 = armorStand.getItemInHand().hasItemMeta() ? armorStand.getItemInHand().getItemMeta().getDisplayName() : null;
/*  74 */       String str5 = armorStand.getEquipment().getItemInOffHand().hasItemMeta() ? armorStand.getEquipment().getItemInOffHand().getItemMeta().getDisplayName() : null;
/*  75 */       String str6 = armorStand.getEquipment().getLeggings().hasItemMeta() ? armorStand.getEquipment().getLeggings().getItemMeta().getDisplayName() : null;
/*  76 */       String str7 = armorStand.getEquipment().getBoots().hasItemMeta() ? armorStand.getEquipment().getBoots().getItemMeta().getDisplayName() : null;
/*     */       
/*  78 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  79 */       double d = getMultiple(armorStand, armorStand1);
/*  80 */       if (material == Material.FLINT_AND_STEEL) {
/*  81 */         f -= 180.0F;
/*     */       }
/*  83 */       if (str3 != null) {
/*  84 */         if (str3.equals("WHEEL")) {
/*  85 */           f -= 180.0F;
/*  86 */           armorStand.getEquipment().setHelmet(mechaType.getWheelMaterial1());
/*     */         } 
/*  88 */         if (str3.equals("WHEEL_2")) {
/*  89 */           f -= 180.0F;
/*  90 */           armorStand.getEquipment().setHelmet(mechaType.getWheelMaterial2());
/*     */         } 
/*  92 */         if (str3.equals("BODY_1")) {
/*  93 */           armorStand.getEquipment().setHelmet(mechaType.getBodyMaterial1());
/*     */         }
/*  95 */         if (str3.equals("BODY_2")) {
/*  96 */           armorStand.getEquipment().setHelmet(mechaType.getBodyMaterial2());
/*     */         }
/*  98 */         if (str3.equals("JOINS")) {
/*  99 */           armorStand.getEquipment().setHelmet(mechaType.getJoinsMaterial());
/*     */         }
/* 101 */         if (str3.equals("LEFT_HAND")) {
/* 102 */           ItemStack itemStack = mechaType.getLeftHandMaterial();
/* 103 */           ItemMeta itemMeta = itemStack.getItemMeta();
/* 104 */           itemMeta.setDisplayName("LEFT_HAND");
/* 105 */           itemStack.setItemMeta(itemMeta);
/* 106 */           armorStand.getEquipment().setHelmet(itemStack);
/*     */         } 
/* 108 */         if (str3.equals("SEAT")) {
/* 109 */           armorStand.getEquipment().setHelmet(mechaType.getSeatMaterial());
/*     */         }
/* 111 */         if (str3.equals("ARMS")) {
/* 112 */           armorStand.getEquipment().setHelmet(mechaType.getArmsMaterial());
/*     */         }
/* 114 */         if (str3.equals("GUN_1")) {
/* 115 */           armorStand.getEquipment().setHelmet(mechaType.getGunMaterial1());
/*     */         }
/* 117 */         if (str3.equals("GUN_2")) {
/* 118 */           armorStand.getEquipment().setHelmet(mechaType.getGunMaterial2());
/*     */         }
/*     */       } 
/* 121 */       if (str4 != null) {
/* 122 */         if (str4.equals("HEADLAMP")) {
/* 123 */           armorStand.getEquipment().setItemInMainHand(mechaType.getHeadLampMaterial());
/*     */         }
/* 125 */         if (str4.equals("SHOULDER")) {
/* 126 */           armorStand.getEquipment().setItemInMainHand(mechaType.getShoulderMaterial());
/*     */         }
/*     */       } 
/* 129 */       if (str5 != null) {
/* 130 */         if (str5.equals("HEADLAMP")) {
/* 131 */           armorStand.getEquipment().setItemInOffHand(mechaType.getHeadLampMaterial());
/*     */         }
/* 133 */         if (str5.equals("SHOULDER")) {
/* 134 */           armorStand.getEquipment().setItemInOffHand(mechaType.getShoulderMaterial());
/*     */         }
/*     */       } 
/* 137 */       if (str6 != null && 
/* 138 */         str6.equals("WHEEL_JOINS_1")) {
/* 139 */         armorStand.getEquipment().setLeggings(mechaType.getWheelJoinsMaterial1());
/*     */       }
/*     */       
/* 142 */       if (str7 != null && 
/* 143 */         str7.equals("WHEEL_JOINS_2")) {
/* 144 */         armorStand.getEquipment().setBoots(mechaType.getWheelJoinsMaterial2());
/*     */       }
/*     */       
/* 147 */       armorStand.setCustomName("MechaPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*     */     } 
/* 149 */     armorStand1.setCustomName(str2);
/* 150 */     EntityUtils.removeSlots(armorStand1);
/* 151 */     EntityUtils.removeSlots(armorStand2);
/* 152 */     EntityUtils.removeSlots(armorStand4);
/* 153 */     EntityUtils.saveUUIDData(armorStand1);
/* 154 */     EntityUtils.saveUUIDData(armorStand2);
/* 155 */     EntityUtils.saveUUIDData(armorStand4);
/* 156 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 157 */     for (ArmorStand armorStand : arrayList) {
/* 158 */       arrayList1.add(armorStand);
/*     */     }
/* 160 */     arrayList1.add(armorStand1);
/* 161 */     arrayList1.add(armorStand2);
/* 162 */     arrayList1.add(armorStand4);
/* 163 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, mechaType.getName(), VehicleType.MECHA);
/* 164 */     EntityUtils.setYaw((Entity)armorStand1, 180.0F);
/* 165 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 166 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 169 */     int i = paramPlayer.getInventory().firstEmpty();
/* 170 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 171 */     if (i != -1) {
/* 172 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 174 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 178 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 179 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 180 */     boolean bool = false;
/* 181 */     VehicleSubType vehicleSubType = null;
/* 182 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.MECHA)) {
/* 183 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 184 */         bool = true;
/* 185 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 189 */     if (bool) {
/* 190 */       MechaType mechaType = (MechaType)vehicleSubType;
/* 191 */       String str = mechaType.getDisplayName();
/* 192 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 193 */       itemMeta.setDisplayName(str);
/* 194 */       ArrayList<String> arrayList = new ArrayList();
/* 195 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", mechaType.getDisplayName()));
/* 196 */       itemMeta.setLore(arrayList);
/* 197 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 198 */       itemStack.setItemMeta(itemMeta);
/* 199 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 201 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 204 */     int i = paramPlayer.getInventory().firstEmpty();
/* 205 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 206 */     if (i != -1) {
/* 207 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 209 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 213 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 214 */     if (paramDouble1 < 0.01D) {
/* 215 */       paramDouble1 = 0.01D;
/*     */     }
/* 217 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 218 */     boolean bool = false;
/* 219 */     VehicleSubType vehicleSubType = null;
/* 220 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.MECHA)) {
/* 221 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 222 */         bool = true;
/* 223 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 227 */     if (bool) {
/* 228 */       MechaType mechaType = (MechaType)vehicleSubType;
/* 229 */       String str = mechaType.getDisplayName();
/* 230 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 231 */       itemMeta.setDisplayName(str);
/* 232 */       ArrayList<String> arrayList = new ArrayList();
/* 233 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", mechaType.getDisplayName()));
/* 234 */       arrayList.add("");
/* 235 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 236 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + mechaType.getMaxHealth());
/*     */       }
/* 238 */       if (vehiclesMain.fuelEnabled) {
/* 239 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + mechaType.getFuelCapacity());
/*     */       }
/* 241 */       itemMeta.setLore(arrayList);
/* 242 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 243 */       itemStack.setItemMeta(itemMeta);
/* 244 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 246 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 249 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 250 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 251 */     String str = NumberUtils.getInstance().firstChars(d);
/* 252 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 256 */     Vector vector = new Vector();
/* 257 */     double d1 = paramFloat1;
/* 258 */     double d2 = paramFloat2;
/* 259 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 260 */     double d3 = Math.cos(Math.toRadians(d2));
/* 261 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 262 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 263 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 266 */     Location location1 = paramArmorStand2.getLocation();
/* 267 */     Location location2 = paramArmorStand1.getLocation();
/* 268 */     double d1 = -(location1.getX() - location2.getX());
/* 269 */     double d2 = location1.getY() - location2.getY();
/* 270 */     double d3 = location1.getZ() - location2.getZ();
/* 271 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 274 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\MechaManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */