/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.CustomHeadCreator;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.RacingCarType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class RacingCarManager
/*     */   implements VehicleManager {
/*  30 */   private static float j = 270.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  33 */     paramLocation = paramLocation.add(0.18D, -0.4D, 0.0D);
/*  34 */     RacingCarType racingCarType = RacingCarType.valueOf(paramString2);
/*  35 */     String str1 = racingCarType.toString();
/*     */     
/*  37 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "RacingCar.schem", false) : new ArrayList();
/*  38 */     Location location1 = paramLocation.clone().add(-0.18D, 0.4D, 0.0D).add(0.5D, 0.0D, 0.5D);
/*  39 */     location1.setYaw(180.0F);
/*  40 */     location1.setPitch(0.0F);
/*  41 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  42 */     if (racingCarType.getModelItem() != null) {
/*  43 */       armorStand1.getEquipment().setHelmet(racingCarType.getModelItem());
/*     */     }
/*  45 */     EntityUtils.setGravity(armorStand1, false);
/*  46 */     armorStand1.setVisible(false);
/*  47 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.2D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  48 */     EntityUtils.setGravity(armorStand2, false);
/*  49 */     armorStand2.setVisible(false);
/*  50 */     armorStand2.setCustomName("RCarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  51 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  52 */     EntityUtils.setGravity(armorStand3, false);
/*  53 */     armorStand3.setVisible(false);
/*  54 */     armorStand3.setCustomName("RCarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  55 */     armorStand3.setPassenger((Entity)armorStand2);
/*  56 */     String str2 = "RCar;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  57 */     Location location2 = armorStand3.getLocation();
/*  58 */     location2.setYaw(0.0F);
/*  59 */     armorStand3.teleport(location2);
/*  60 */     location2 = armorStand2.getLocation();
/*  61 */     location2.setYaw(0.0F);
/*  62 */     armorStand2.teleport(location2);
/*  63 */     ItemStack itemStack = CustomHeadCreator.createItemStack("http://textures.minecraft.net/texture/3ab0263bdd76f3e418dba5bf481b921ced397d8b8a34a5561fb7beaa46ece1");
/*  64 */     for (ArmorStand armorStand : arrayList) {
/*  65 */       EntityUtils.removeSlots(armorStand);
/*  66 */       float f = j - armorStand.getLocation().getYaw();
/*  67 */       f += 180.0F + armorStand.getLocation().getYaw() * 2.0F;
/*  68 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  69 */       double d = getMultiple(armorStand, armorStand1);
/*  70 */       armorStand.setCustomName("RCarPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  71 */       Material material1 = armorStand.getEquipment().getHelmet().getType();
/*  72 */       Material material2 = armorStand.getEquipment().getItemInHand().getType();
/*  73 */       if (material1 == Material.PLAYER_HEAD) {
/*  74 */         ItemMeta itemMeta = armorStand.getHelmet().getItemMeta();
/*  75 */         if (itemMeta.getDisplayName().equals("WHEEL_MATERIAL")) {
/*  76 */           armorStand.getEquipment().setHelmet(racingCarType.getWheelMaterial()); continue;
/*  77 */         }  if (itemMeta.getDisplayName().equals("MAIN_MATERIAL")) {
/*  78 */           armorStand.getEquipment().setHelmet(racingCarType.getMaterial()); continue;
/*  79 */         }  if (itemMeta.getDisplayName().equals("WOOL"))
/*  80 */           armorStand.getEquipment().setHelmet(itemStack);  continue;
/*     */       } 
/*  82 */       if (material2 == Material.BLACK_CARPET) {
/*  83 */         armorStand.getEquipment().setItemInHand(racingCarType.getWingMaterial()); continue;
/*  84 */       }  if (material2 == Material.BLACK_STAINED_GLASS_PANE) {
/*  85 */         armorStand.getEquipment().setItemInHand(racingCarType.getGlassMaterial());
/*     */       }
/*     */     } 
/*  88 */     armorStand1.setCustomName(str2);
/*  89 */     EntityUtils.removeSlots(armorStand1);
/*  90 */     EntityUtils.removeSlots(armorStand2);
/*  91 */     EntityUtils.removeSlots(armorStand3);
/*  92 */     EntityUtils.saveUUIDData(armorStand1);
/*  93 */     EntityUtils.saveUUIDData(armorStand2);
/*  94 */     EntityUtils.saveUUIDData(armorStand3);
/*  95 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  96 */     for (ArmorStand armorStand : arrayList) {
/*  97 */       arrayList1.add(armorStand);
/*     */     }
/*  99 */     arrayList1.add(armorStand1);
/* 100 */     arrayList1.add(armorStand2);
/* 101 */     arrayList1.add(armorStand3);
/* 102 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, racingCarType.getName(), VehicleType.RACING_CAR);
/* 103 */     EntityUtils.setYaw((Entity)armorStand1, 360.0F);
/* 104 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 105 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 108 */     int i = paramPlayer.getInventory().firstEmpty();
/* 109 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 110 */     if (i != -1) {
/* 111 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 113 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 117 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 118 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 119 */     boolean bool = false;
/* 120 */     VehicleSubType vehicleSubType = null;
/* 121 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.RACING_CAR)) {
/* 122 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 123 */         bool = true;
/* 124 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 128 */     if (bool) {
/* 129 */       RacingCarType racingCarType = (RacingCarType)vehicleSubType;
/* 130 */       String str = racingCarType.getDisplayName();
/* 131 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 132 */       itemMeta.setDisplayName(str);
/* 133 */       ArrayList<String> arrayList = new ArrayList();
/* 134 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", racingCarType.getDisplayName()));
/* 135 */       itemMeta.setLore(arrayList);
/* 136 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 137 */       itemStack.setItemMeta(itemMeta);
/* 138 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 140 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 143 */     int i = paramPlayer.getInventory().firstEmpty();
/* 144 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 145 */     if (i != -1) {
/* 146 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 148 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 152 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 153 */     if (paramDouble1 < 0.01D) {
/* 154 */       paramDouble1 = 0.01D;
/*     */     }
/* 156 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 157 */     boolean bool = false;
/* 158 */     VehicleSubType vehicleSubType = null;
/* 159 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.RACING_CAR)) {
/* 160 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 161 */         bool = true;
/* 162 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 166 */     if (bool) {
/* 167 */       RacingCarType racingCarType = (RacingCarType)vehicleSubType;
/* 168 */       String str = racingCarType.getDisplayName();
/* 169 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 170 */       itemMeta.setDisplayName(str);
/* 171 */       ArrayList<String> arrayList = new ArrayList();
/* 172 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", racingCarType.getDisplayName()));
/* 173 */       arrayList.add("");
/* 174 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 175 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + racingCarType.getMaxHealth());
/*     */       }
/* 177 */       if (vehiclesMain.fuelEnabled) {
/* 178 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + racingCarType.getFuelCapacity());
/*     */       }
/* 180 */       itemMeta.setLore(arrayList);
/* 181 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 182 */       itemStack.setItemMeta(itemMeta);
/* 183 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 185 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 188 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 189 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 190 */     String str = NumberUtils.getInstance().firstChars(d);
/* 191 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 195 */     Vector vector = new Vector();
/* 196 */     double d1 = paramFloat1;
/* 197 */     double d2 = paramFloat2;
/* 198 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 199 */     double d3 = Math.cos(Math.toRadians(d2));
/* 200 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 201 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 202 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 205 */     Location location1 = paramArmorStand2.getLocation();
/* 206 */     Location location2 = paramArmorStand1.getLocation();
/* 207 */     double d1 = -(location1.getX() - location2.getX());
/* 208 */     double d2 = location1.getY() - location2.getY();
/* 209 */     double d3 = location1.getZ() - location2.getZ();
/* 210 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 213 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\RacingCarManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */