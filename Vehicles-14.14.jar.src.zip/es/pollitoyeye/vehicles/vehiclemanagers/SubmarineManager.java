/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.SubmarineType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class SubmarineManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(0.0D, -1.0D, 0.0D);
/*  33 */     SubmarineType submarineType = SubmarineType.valueOf(paramString2);
/*  34 */     String str1 = submarineType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Submarine.schem", true) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(new Vector(0.5D, 1.0D, 0.5D));
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (submarineType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(submarineType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.3D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("SubmaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("SubmaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str2 = "Subma;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*  62 */     for (ArmorStand armorStand : arrayList) {
/*  63 */       EntityUtils.removeSlots(armorStand);
/*  64 */       float f = j - armorStand.getLocation().getYaw();
/*  65 */       if (armorStand.getHelmet().getType().toString().endsWith("_WOOL") || (armorStand.getHelmet().getType() == Material.IRON_TRAPDOOR && armorStand.getHeadPose().getZ() > 1.0D)) {
/*  66 */         f += 90.0F;
/*  67 */       } else if (armorStand.getItemInHand().getType().toString().endsWith("_WOOL") && EntityUtils.newHandRender) {
/*  68 */         f += 90.0F;
/*  69 */       } else if (armorStand.getHelmet().getType() == Material.END_ROD && armorStand.getHeadPose().getX() < 0.0D) {
/*  70 */         f += 90.0F;
/*  71 */       } else if (armorStand.getItemInHand().getType().toString().endsWith("_BANNER")) {
/*  72 */         f += 90.0F;
/*     */       } else {
/*  74 */         f -= 90.0F;
/*     */       } 
/*  76 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  77 */       double d = getMultiple(armorStand, armorStand1);
/*  78 */       armorStand.setCustomName("SubmaPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  79 */       if (armorStand.getHelmet().getType() == Material.IRON_BLOCK) {
/*  80 */         armorStand.setHelmet(submarineType.getMaterial()); continue;
/*     */       } 
/*  82 */       if (armorStand.getHelmet().getType() == Material.MAGENTA_WOOL) {
/*  83 */         armorStand.setHelmet(submarineType.getViewPort1()); continue;
/*     */       } 
/*  85 */       if (armorStand.getHelmet().getType() == Material.ORANGE_WOOL) {
/*  86 */         armorStand.setHelmet(submarineType.getViewPort2()); continue;
/*     */       } 
/*  88 */       if (armorStand.getItemInHand().getType().toString().endsWith("_WOOL")) {
/*  89 */         armorStand.setItemInHand(submarineType.getViewPort3()); continue;
/*     */       } 
/*  91 */       if (armorStand.getItemInHand().getType().toString().endsWith("_BANNER")) {
/*  92 */         armorStand.setItemInHand(submarineType.getHelixMaterial());
/*     */       }
/*     */     } 
/*  95 */     armorStand1.setCustomName(str2);
/*  96 */     EntityUtils.removeSlots(armorStand1);
/*  97 */     EntityUtils.removeSlots(armorStand2);
/*  98 */     EntityUtils.removeSlots(armorStand3);
/*  99 */     EntityUtils.saveUUIDData(armorStand1);
/* 100 */     EntityUtils.saveUUIDData(armorStand2);
/* 101 */     EntityUtils.saveUUIDData(armorStand3);
/* 102 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 103 */     for (ArmorStand armorStand : arrayList) {
/* 104 */       arrayList1.add(armorStand);
/*     */     }
/* 106 */     arrayList1.add(armorStand1);
/* 107 */     arrayList1.add(armorStand2);
/* 108 */     arrayList1.add(armorStand3);
/* 109 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, submarineType.getName(), VehicleType.SUBMARINE);
/* 110 */     EntityUtils.setYaw((Entity)armorStand1, 90.0F);
/* 111 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 112 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 115 */     int i = paramPlayer.getInventory().firstEmpty();
/* 116 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 117 */     if (i != -1) {
/* 118 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 120 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 124 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 125 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 126 */     boolean bool = false;
/* 127 */     VehicleSubType vehicleSubType = null;
/* 128 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.SUBMARINE)) {
/* 129 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 130 */         bool = true;
/* 131 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 135 */     if (bool) {
/* 136 */       SubmarineType submarineType = (SubmarineType)vehicleSubType;
/* 137 */       String str = submarineType.getDisplayName();
/* 138 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 139 */       itemMeta.setDisplayName(str);
/* 140 */       ArrayList<String> arrayList = new ArrayList();
/* 141 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", submarineType.getDisplayName()));
/* 142 */       itemMeta.setLore(arrayList);
/* 143 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 144 */       itemStack.setItemMeta(itemMeta);
/* 145 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 147 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 150 */     int i = paramPlayer.getInventory().firstEmpty();
/* 151 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 152 */     if (i != -1) {
/* 153 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 155 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 159 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 160 */     if (paramDouble1 < 0.01D) {
/* 161 */       paramDouble1 = 0.01D;
/*     */     }
/* 163 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 164 */     boolean bool = false;
/* 165 */     VehicleSubType vehicleSubType = null;
/* 166 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.SUBMARINE)) {
/* 167 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 168 */         bool = true;
/* 169 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 173 */     if (bool) {
/* 174 */       SubmarineType submarineType = (SubmarineType)vehicleSubType;
/* 175 */       String str = submarineType.getDisplayName();
/* 176 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 177 */       itemMeta.setDisplayName(str);
/* 178 */       ArrayList<String> arrayList = new ArrayList();
/* 179 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", submarineType.getDisplayName()));
/* 180 */       arrayList.add("");
/* 181 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 182 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + submarineType.getMaxHealth());
/*     */       }
/* 184 */       if (vehiclesMain.fuelEnabled) {
/* 185 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + submarineType.getFuelCapacity());
/*     */       }
/* 187 */       itemMeta.setLore(arrayList);
/* 188 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 189 */       itemStack.setItemMeta(itemMeta);
/* 190 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 192 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 195 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 196 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 197 */     String str = NumberUtils.getInstance().firstChars(d);
/* 198 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 202 */     Vector vector = new Vector();
/* 203 */     double d1 = paramFloat1;
/* 204 */     double d2 = paramFloat2;
/* 205 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 206 */     double d3 = Math.cos(Math.toRadians(d2));
/* 207 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 208 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 209 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 212 */     Location location1 = paramArmorStand2.getLocation();
/* 213 */     Location location2 = paramArmorStand1.getLocation();
/* 214 */     double d1 = -(location1.getX() - location2.getX());
/* 215 */     double d2 = location1.getY() - location2.getY();
/* 216 */     double d3 = location1.getZ() - location2.getZ();
/* 217 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 220 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\SubmarineManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */