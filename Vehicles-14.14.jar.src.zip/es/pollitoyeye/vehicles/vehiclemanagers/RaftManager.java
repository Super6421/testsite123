/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.RaftType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class RaftManager
/*     */   implements VehicleManager
/*     */ {
/*  29 */   private static float j = 270.0F;
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  31 */     paramLocation = paramLocation.add(0.0D, 0.5D, 2.5D);
/*  32 */     RaftType raftType = RaftType.valueOf(paramString2);
/*  33 */     String str1 = raftType.toString();
/*     */     
/*  35 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Raft.schem", true) : new ArrayList();
/*  36 */     Location location1 = paramLocation.clone().add(new Vector(0.5D, -0.5D, -2.2D));
/*  37 */     location1.setYaw(j);
/*  38 */     location1.setPitch(0.0F);
/*  39 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, 0.5D, 0.0D), EntityType.ARMOR_STAND);
/*  40 */     if (raftType.getModelItem() != null) {
/*  41 */       armorStand1.getEquipment().setHelmet(raftType.getModelItem());
/*     */     }
/*  43 */     EntityUtils.setGravity(armorStand1, false);
/*  44 */     armorStand1.setVisible(false);
/*  45 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  46 */     EntityUtils.setGravity(armorStand2, false);
/*  47 */     armorStand2.setVisible(false);
/*  48 */     armorStand2.setCustomName("RaftPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";" + (armorStand2.getLocation().getYaw() - armorStand1.getLocation().getYaw()));
/*  49 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 0.8D, 0.0D)), EntityType.ARMOR_STAND);
/*  50 */     EntityUtils.setGravity(armorStand3, false);
/*  51 */     armorStand3.setVisible(false);
/*  52 */     armorStand3.setCustomName("RaftPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";" + (armorStand3.getLocation().getYaw() - armorStand1.getLocation().getYaw()));
/*  53 */     String str2 = "Raft;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  54 */     Location location2 = armorStand3.getLocation();
/*  55 */     location2.setYaw(0.0F);
/*  56 */     armorStand3.teleport(location2);
/*  57 */     location2 = armorStand2.getLocation();
/*  58 */     location2.setYaw(0.0F);
/*  59 */     armorStand2.teleport(location2);
/*  60 */     for (ArmorStand armorStand : arrayList) {
/*  61 */       EntityUtils.removeSlots(armorStand);
/*  62 */       float f = armorStand.getLocation().getYaw() + 90.0F;
/*  63 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  64 */       double d = getMultiple(armorStand, armorStand1);
/*  65 */       armorStand.setCustomName("RaftPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  66 */       if (armorStand.getHelmet().getType().toString().endsWith("_BANNER")) {
/*  67 */         armorStand.setHelmet(raftType.getSailMaterial());
/*     */       }
/*     */     } 
/*  70 */     armorStand1.setCustomName(str2);
/*  71 */     EntityUtils.removeSlots(armorStand1);
/*  72 */     EntityUtils.removeSlots(armorStand2);
/*  73 */     EntityUtils.removeSlots(armorStand3);
/*  74 */     EntityUtils.saveUUIDData(armorStand1);
/*  75 */     EntityUtils.saveUUIDData(armorStand2);
/*  76 */     EntityUtils.saveUUIDData(armorStand3);
/*  77 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  78 */     for (ArmorStand armorStand : arrayList) {
/*  79 */       arrayList1.add(armorStand);
/*     */     }
/*  81 */     arrayList1.add(armorStand1);
/*  82 */     arrayList1.add(armorStand2);
/*  83 */     arrayList1.add(armorStand3);
/*  84 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, raftType.getName(), VehicleType.RAFT);
/*  85 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  86 */     return armorStand1;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/*  89 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/*  90 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/*  91 */     String str = NumberUtils.getInstance().firstChars(d);
/*  92 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/*  96 */     Vector vector = new Vector();
/*  97 */     double d1 = paramFloat1;
/*  98 */     double d2 = paramFloat2;
/*  99 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 100 */     double d3 = Math.cos(Math.toRadians(d2));
/* 101 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 102 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 103 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 106 */     Location location1 = paramArmorStand2.getLocation();
/* 107 */     Location location2 = paramArmorStand1.getLocation();
/* 108 */     double d1 = location1.getX() - location2.getX();
/* 109 */     double d2 = location1.getY() - location2.getY();
/* 110 */     double d3 = location1.getZ() - location2.getZ();
/* 111 */     if (paramArmorStand1.getHelmet().getType().toString().endsWith("_LOG")) {
/* 112 */       d3 += 0.3565D;
/* 113 */     } else if (paramArmorStand1.getHelmet().getType() == Material.VINE) {
/* 114 */       d3 += 1.2D;
/*     */     } 
/* 116 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 119 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 122 */     int i = paramPlayer.getInventory().firstEmpty();
/* 123 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 124 */     if (i != -1) {
/* 125 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 127 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 131 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 132 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 133 */     boolean bool = false;
/* 134 */     VehicleSubType vehicleSubType = null;
/* 135 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.RAFT)) {
/* 136 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 137 */         bool = true;
/* 138 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 142 */     if (bool) {
/* 143 */       RaftType raftType = (RaftType)vehicleSubType;
/* 144 */       String str = raftType.getDisplayName();
/* 145 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 146 */       itemMeta.setDisplayName(str);
/* 147 */       ArrayList<String> arrayList = new ArrayList();
/* 148 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", raftType.getDisplayName()));
/* 149 */       itemMeta.setLore(arrayList);
/* 150 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 151 */       itemStack.setItemMeta(itemMeta);
/* 152 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 154 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 157 */     int i = paramPlayer.getInventory().firstEmpty();
/* 158 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 159 */     if (i != -1) {
/* 160 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 162 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 166 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 167 */     if (paramDouble1 < 0.01D) {
/* 168 */       paramDouble1 = 0.01D;
/*     */     }
/* 170 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 171 */     boolean bool = false;
/* 172 */     VehicleSubType vehicleSubType = null;
/* 173 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.RAFT)) {
/* 174 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 175 */         bool = true;
/* 176 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 180 */     if (bool) {
/* 181 */       RaftType raftType = (RaftType)vehicleSubType;
/* 182 */       String str = raftType.getDisplayName();
/* 183 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 184 */       itemMeta.setDisplayName(str);
/* 185 */       ArrayList<String> arrayList = new ArrayList();
/* 186 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", raftType.getDisplayName()));
/* 187 */       arrayList.add("");
/* 188 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 189 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + raftType.getMaxHealth());
/*     */       }
/* 191 */       itemMeta.setLore(arrayList);
/* 192 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 193 */       itemStack.setItemMeta(itemMeta);
/* 194 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 196 */     return itemStack;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\RaftManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */