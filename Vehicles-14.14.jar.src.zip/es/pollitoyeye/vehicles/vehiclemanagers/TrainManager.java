/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.TrainType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class TrainManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.subtract(new Vector(0.3D, 1.9D, 0.3D));
/*  33 */     TrainType trainType = TrainType.valueOf(paramString2);
/*  34 */     String str1 = trainType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Train.schem", true) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(new Vector(0.8D, 0.5D, 0.8D));
/*  38 */     location1.setYaw(j);
/*  39 */     location1.setPitch(0.0F);
/*     */     
/*  41 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, 0.5D, 0.0D), EntityType.ARMOR_STAND);
/*  42 */     if (trainType.getModelItem() != null) {
/*  43 */       armorStand1.getEquipment().setHelmet(trainType.getModelItem());
/*     */     }
/*     */     
/*  46 */     EntityUtils.setGravity(armorStand1, false);
/*  47 */     armorStand1.setVisible(false);
/*  48 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*     */     
/*  50 */     EntityUtils.setGravity(armorStand2, false);
/*  51 */     armorStand2.setVisible(false);
/*  52 */     armorStand2.setCustomName("TrainPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";" + (armorStand2.getLocation().getYaw() - armorStand1.getLocation().getYaw()));
/*  53 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*     */     
/*  55 */     EntityUtils.setGravity(armorStand3, false);
/*  56 */     armorStand3.setVisible(false);
/*  57 */     armorStand3.setCustomName("TrainPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";" + (armorStand3.getLocation().getYaw() - armorStand1.getLocation().getYaw()));
/*  58 */     armorStand3.setPassenger((Entity)armorStand2);
/*  59 */     String str2 = "Train;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  60 */     Location location2 = armorStand3.getLocation();
/*  61 */     location2.setYaw(armorStand1.getLocation().getYaw());
/*  62 */     armorStand3.teleport(location2);
/*  63 */     location2 = armorStand2.getLocation();
/*  64 */     location2.setYaw(armorStand1.getLocation().getYaw());
/*  65 */     armorStand2.teleport(location2);
/*  66 */     for (ArmorStand armorStand : arrayList) {
/*  67 */       EntityUtils.removeSlots(armorStand);
/*  68 */       float f = armorStand.getLocation().getYaw() - armorStand1.getLocation().getYaw();
/*  69 */       if (armorStand.getItemInHand().getType() == Material.STICK) {
/*  70 */         f += 90.0F;
/*     */       }
/*  72 */       if (armorStand.getHelmet().getType() == Material.BRICKS || armorStand
/*  73 */         .getItemInHand().getType() == Material.BRICKS || armorStand
/*  74 */         .getHelmet().getType() == Material.BEDROCK || armorStand
/*  75 */         .getHelmet().getType() == Material.SPONGE) {
/*  76 */         f += 90.0F;
/*     */       }
/*  78 */       if (armorStand.getHelmet().getType() == Material.DARK_OAK_STAIRS) {
/*  79 */         f += 90.0F;
/*     */       }
/*  81 */       if (armorStand.getHelmet().getType() == Material.DARK_OAK_SLAB) {
/*  82 */         f += 90.0F;
/*     */       }
/*  84 */       if (armorStand.getHelmet().getType() == Material.OAK_STAIRS) {
/*  85 */         f += 90.0F;
/*     */       }
/*  87 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  88 */       double d = getMultiple(armorStand, armorStand1);
/*  89 */       armorStand.setCustomName("TrainPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  90 */       if (armorStand.getHelmet().getType() == Material.SPONGE) {
/*  91 */         armorStand.setHelmet(trainType.getWheelMaterial()); continue;
/*  92 */       }  if (armorStand.getHelmet().getType() == Material.BEDROCK) {
/*  93 */         armorStand.setHelmet(trainType.getLightMaterial()); continue;
/*  94 */       }  if (armorStand.getItemInHand().getType() == Material.BRICKS) {
/*  95 */         armorStand.setItemInHand(trainType.getChimneyMaterial()); continue;
/*  96 */       }  if (armorStand.getHelmet().getType() == Material.BRICKS) {
/*  97 */         armorStand.setHelmet(trainType.getChimneyMaterial());
/*     */       }
/*     */     } 
/* 100 */     armorStand1.setCustomName(str2);
/* 101 */     EntityUtils.removeSlots(armorStand1);
/* 102 */     EntityUtils.removeSlots(armorStand2);
/* 103 */     EntityUtils.removeSlots(armorStand3);
/* 104 */     EntityUtils.saveUUIDData(armorStand1);
/* 105 */     EntityUtils.saveUUIDData(armorStand2);
/* 106 */     EntityUtils.saveUUIDData(armorStand3);
/* 107 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 108 */     for (ArmorStand armorStand : arrayList) {
/* 109 */       arrayList1.add(armorStand);
/*     */     }
/* 111 */     arrayList1.add(armorStand1);
/* 112 */     arrayList1.add(armorStand2);
/* 113 */     arrayList1.add(armorStand3);
/* 114 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, trainType.getName(), VehicleType.TRAIN);
/* 115 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 116 */     EntityUtils.setYaw((Entity)armorStand1, EntityUtils.getYaw((Entity)armorStand1) - 90.0F);
/* 117 */     return armorStand1;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 120 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 121 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 122 */     String str = NumberUtils.getInstance().firstChars(d);
/* 123 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 127 */     Vector vector = new Vector();
/* 128 */     double d1 = paramFloat1;
/* 129 */     double d2 = paramFloat2;
/* 130 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 131 */     double d3 = Math.cos(Math.toRadians(d2));
/* 132 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 133 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 134 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 137 */     Location location1 = paramArmorStand2.getLocation();
/* 138 */     Location location2 = paramArmorStand1.getLocation();
/* 139 */     double d1 = location1.getX() - location2.getX();
/* 140 */     double d2 = location1.getY() - location2.getY();
/* 141 */     double d3 = location1.getZ() - location2.getZ();
/* 142 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 145 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 148 */     int i = paramPlayer.getInventory().firstEmpty();
/* 149 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 150 */     if (i != -1) {
/* 151 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 153 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 157 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 158 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 159 */     boolean bool = false;
/* 160 */     VehicleSubType vehicleSubType = null;
/* 161 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TRAIN)) {
/* 162 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 163 */         bool = true;
/* 164 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 168 */     if (bool) {
/* 169 */       TrainType trainType = (TrainType)vehicleSubType;
/* 170 */       String str = trainType.getDisplayName();
/* 171 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 172 */       itemMeta.setDisplayName(str);
/* 173 */       ArrayList<String> arrayList = new ArrayList();
/* 174 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", trainType.getDisplayName()));
/* 175 */       itemMeta.setLore(arrayList);
/* 176 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 177 */       itemStack.setItemMeta(itemMeta);
/* 178 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 180 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 183 */     int i = paramPlayer.getInventory().firstEmpty();
/* 184 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 185 */     if (i != -1) {
/* 186 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 188 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 192 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 193 */     if (paramDouble1 < 0.01D) {
/* 194 */       paramDouble1 = 0.01D;
/*     */     }
/* 196 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 197 */     boolean bool = false;
/* 198 */     VehicleSubType vehicleSubType = null;
/* 199 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TRAIN)) {
/* 200 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 201 */         bool = true;
/* 202 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 206 */     if (bool) {
/* 207 */       TrainType trainType = (TrainType)vehicleSubType;
/* 208 */       String str = trainType.getDisplayName();
/* 209 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 210 */       itemMeta.setDisplayName(str);
/* 211 */       ArrayList<String> arrayList = new ArrayList();
/* 212 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", trainType.getDisplayName()));
/* 213 */       arrayList.add("");
/* 214 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 215 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + trainType.getMaxHealth());
/*     */       }
/* 217 */       if (vehiclesMain.fuelEnabled) {
/* 218 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + trainType.getFuelCapacity());
/*     */       }
/* 220 */       itemMeta.setLore(arrayList);
/* 221 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 222 */       itemStack.setItemMeta(itemMeta);
/* 223 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 225 */     return itemStack;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\TrainManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */