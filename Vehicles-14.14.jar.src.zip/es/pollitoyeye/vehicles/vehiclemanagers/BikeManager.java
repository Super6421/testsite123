/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.BikeType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class BikeManager
/*     */   implements VehicleManager {
/*  28 */   private static float j = 90.0F;
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  30 */     paramLocation = paramLocation.subtract(new Vector(0.0D, -0.1D, 0.5D));
/*  31 */     BikeType bikeType = BikeType.valueOf(paramString2);
/*     */     
/*  33 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Bike.schem", true) : new ArrayList();
/*  34 */     Location location = paramLocation.clone().add(new Vector(0.5D, -0.5D, 0.8D));
/*  35 */     location.setYaw(j);
/*  36 */     location.setPitch(0.0F);
/*  37 */     ArmorStand armorStand1 = (ArmorStand)location.getWorld().spawnEntity(location.clone().add(new Vector(0.0D, 0.5D, 0.0D)), EntityType.ARMOR_STAND);
/*  38 */     if (bikeType.getModelItem() != null) {
/*  39 */       armorStand1.getEquipment().setHelmet(bikeType.getModelItem());
/*     */     }
/*  41 */     EntityUtils.setGravity(armorStand1, false);
/*     */     
/*  43 */     armorStand1.setVisible(false);
/*  44 */     ArmorStand armorStand2 = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
/*     */     
/*  46 */     EntityUtils.setGravity(armorStand2, false);
/*  47 */     armorStand2.setVisible(false);
/*  48 */     armorStand2.setCustomName(VehicleType.BIKE.getPartName() + ";" + armorStand1.getUniqueId());
/*  49 */     ArmorStand armorStand3 = (ArmorStand)location.getWorld().spawnEntity(location, EntityType.ARMOR_STAND);
/*  50 */     EntityUtils.setGravity(armorStand3, false);
/*  51 */     armorStand3.setVisible(false);
/*  52 */     armorStand3.setCustomName(VehicleType.BIKE.getPartName() + ";" + armorStand1.getUniqueId() + ";SecondSeat");
/*  53 */     ArmorStand armorStand4 = (ArmorStand)location.getWorld().spawnEntity(location.clone().subtract(new Vector(0.0D, 1.4D, 0.0D)), EntityType.ARMOR_STAND);
/*     */     
/*  55 */     EntityUtils.setGravity(armorStand4, false);
/*  56 */     armorStand4.setVisible(false);
/*  57 */     armorStand4.setCustomName(VehicleType.BIKE.getPartName() + ";" + armorStand1.getUniqueId());
/*  58 */     String str = VehicleType.BIKE.getName() + ";" + bikeType.getName() + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand4.getUniqueId() + ";";
/*  59 */     for (ArmorStand armorStand : arrayList) {
/*  60 */       armorStand.setCustomName(VehicleType.BIKE.getPartName() + ";" + armorStand1.getUniqueId());
/*  61 */       EntityUtils.removeSlots(armorStand);
/*  62 */       if (armorStand.getHelmet().getType() == Material.COAL_BLOCK) {
/*  63 */         armorStand.setHelmet(bikeType.getMaterial()); continue;
/*     */       } 
/*  65 */       if (armorStand.getHelmet().getType() == Material.PLAYER_HEAD) {
/*  66 */         armorStand.setHelmet(bikeType.getWheelMaterial()); continue;
/*     */       } 
/*  68 */       if (armorStand.getHelmet().getType() == Material.NETHER_BRICK_SLAB) {
/*  69 */         armorStand.setHelmet(bikeType.getSeatMaterial());
/*     */       }
/*     */     } 
/*  72 */     armorStand1.setCustomName(str);
/*  73 */     EntityUtils.removeSlots(armorStand1);
/*  74 */     EntityUtils.removeSlots(armorStand2);
/*  75 */     EntityUtils.removeSlots(armorStand3);
/*  76 */     EntityUtils.removeSlots(armorStand4);
/*  77 */     EntityUtils.saveUUIDData(armorStand1);
/*  78 */     EntityUtils.saveUUIDData(armorStand2);
/*  79 */     EntityUtils.saveUUIDData(armorStand3);
/*  80 */     EntityUtils.saveUUIDData(armorStand4);
/*  81 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  82 */     for (ArmorStand armorStand : arrayList) {
/*  83 */       arrayList1.add(armorStand);
/*     */     }
/*  85 */     arrayList1.add(armorStand1);
/*  86 */     arrayList1.add(armorStand2);
/*  87 */     arrayList1.add(armorStand3);
/*  88 */     arrayList1.add(armorStand4);
/*  89 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, bikeType.getName(), VehicleType.BIKE);
/*  90 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  91 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/*  94 */     int i = paramPlayer.getInventory().firstEmpty();
/*  95 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/*  96 */     if (i != -1) {
/*  97 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/*  99 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 103 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 104 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 105 */     boolean bool = false;
/* 106 */     VehicleSubType vehicleSubType = null;
/* 107 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.BIKE)) {
/* 108 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 109 */         bool = true;
/* 110 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 114 */     if (bool) {
/* 115 */       BikeType bikeType = (BikeType)vehicleSubType;
/* 116 */       String str = bikeType.getDisplayName();
/* 117 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 118 */       itemMeta.setDisplayName(str);
/* 119 */       ArrayList<String> arrayList = new ArrayList();
/* 120 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", bikeType.getDisplayName()));
/* 121 */       itemMeta.setLore(arrayList);
/* 122 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 123 */       itemStack.setItemMeta(itemMeta);
/* 124 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 126 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 129 */     int i = paramPlayer.getInventory().firstEmpty();
/* 130 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 131 */     if (i != -1) {
/* 132 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 134 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 138 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 139 */     if (paramDouble1 < 0.01D) {
/* 140 */       paramDouble1 = 0.01D;
/*     */     }
/* 142 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 143 */     boolean bool = false;
/* 144 */     VehicleSubType vehicleSubType = null;
/* 145 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.BIKE)) {
/* 146 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 147 */         bool = true;
/* 148 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 152 */     if (bool) {
/* 153 */       NumberUtils numberUtils = NumberUtils.getInstance();
/* 154 */       BikeType bikeType = (BikeType)vehicleSubType;
/* 155 */       String str = bikeType.getDisplayName();
/* 156 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 157 */       itemMeta.setDisplayName(str);
/* 158 */       ArrayList<String> arrayList = new ArrayList();
/* 159 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", bikeType.getDisplayName()));
/* 160 */       arrayList.add("");
/* 161 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 162 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + numberUtils.getLastDigitsDouble(paramDouble1) + "/" + bikeType.getMaxHealth());
/*     */       }
/* 164 */       if (vehiclesMain.fuelEnabled) {
/* 165 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + numberUtils.getLastDigitsDouble(paramDouble2) + "/" + bikeType.getFuelCapacity());
/*     */       }
/* 167 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 168 */       itemMeta.setLore(arrayList);
/* 169 */       itemStack.setItemMeta(itemMeta);
/* 170 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 172 */     return itemStack;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\BikeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */