/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.TankType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class TankManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 0.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(-0.2D, 0.3D, 0.0D);
/*  33 */     TankType tankType = TankType.valueOf(paramString2);
/*  34 */     String str1 = tankType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Tank.schem", true) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(0.2D, -0.3D, 0.0D).add(0.5D, 0.0D, 0.5D);
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (tankType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(tankType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.46D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("TankPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("TankPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str2 = "Tank;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*  62 */     for (ArmorStand armorStand : arrayList) {
/*  63 */       EntityUtils.removeSlots(armorStand);
/*  64 */       float f = j - armorStand.getLocation().getYaw();
/*  65 */       Material material1 = armorStand.getHelmet().getType();
/*  66 */       Material material2 = armorStand.getItemInHand().getType();
/*  67 */       if (armorStand.getHelmet().getType() == Material.SPRUCE_FENCE_GATE) {
/*  68 */         f -= 90.0F;
/*     */       }
/*  70 */       if (material1.toString().endsWith("_WOOL")) {
/*  71 */         f += 90.0F;
/*     */       }
/*  73 */       if (armorStand.getItemInHand().getType() == Material.ELYTRA) {
/*  74 */         f -= 90.0F;
/*     */       }
/*  76 */       if (material2.toString().endsWith("_WOOL") && EntityUtils.newHandRender) {
/*  77 */         f += 90.0F;
/*     */       }
/*  79 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  80 */       double d = getMultiple(armorStand, armorStand1);
/*  81 */       armorStand.setCustomName("TankPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  82 */       if (material1.toString().endsWith("_WOOL")) {
/*  83 */         if (material1 == Material.ORANGE_WOOL) {
/*     */ 
/*     */           
/*  86 */           armorStand.setHelmet(tankType.getFirstChains());
/*  87 */         } else if (material1 == Material.MAGENTA_WOOL) {
/*     */ 
/*     */           
/*  90 */           armorStand.setHelmet(tankType.getSecondChains());
/*  91 */         } else if (material1 == Material.LIGHT_BLUE_WOOL) {
/*     */ 
/*     */           
/*  94 */           armorStand.setHelmet(tankType.getThirdChains());
/*     */         } 
/*  96 */       } else if (material2.toString().endsWith("_WOOL")) {
/*     */ 
/*     */         
/*  99 */         armorStand.setItemInHand(tankType.getHoleMaterial());
/* 100 */       } else if (material1.toString().endsWith("_TERRACOTTA")) {
/* 101 */         if (material1 == Material.LIME_TERRACOTTA) {
/* 102 */           armorStand.setHelmet(tankType.getMaterial());
/* 103 */         } else if (material1 == Material.GREEN_TERRACOTTA) {
/* 104 */           armorStand.setHelmet(tankType.getMaterial2());
/*     */         } 
/* 106 */       } else if (material2.toString().endsWith("_TERRACOTTA")) {
/* 107 */         armorStand.setItemInHand(tankType.getMaterial());
/*     */       } 
/* 109 */       if (armorStand.getChestplate().getType() == Material.STICK) {
/* 110 */         EntityUtils.setModelGroup(armorStand, 1);
/*     */       }
/*     */     } 
/* 113 */     armorStand1.setCustomName(str2);
/* 114 */     EntityUtils.removeSlots(armorStand1);
/* 115 */     EntityUtils.removeSlots(armorStand2);
/* 116 */     EntityUtils.removeSlots(armorStand3);
/* 117 */     EntityUtils.saveUUIDData(armorStand1);
/* 118 */     EntityUtils.saveUUIDData(armorStand2);
/* 119 */     EntityUtils.saveUUIDData(armorStand3);
/* 120 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 121 */     for (ArmorStand armorStand : arrayList) {
/* 122 */       arrayList1.add(armorStand);
/*     */     }
/* 124 */     arrayList1.add(armorStand1);
/* 125 */     arrayList1.add(armorStand2);
/* 126 */     arrayList1.add(armorStand3);
/* 127 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, tankType.getName(), VehicleType.TANK);
/* 128 */     EntityUtils.setYaw((Entity)armorStand1, 90.0F);
/* 129 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 130 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 133 */     int i = paramPlayer.getInventory().firstEmpty();
/* 134 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 135 */     if (i != -1) {
/* 136 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 138 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 142 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 143 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 144 */     boolean bool = false;
/* 145 */     VehicleSubType vehicleSubType = null;
/* 146 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TANK)) {
/* 147 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 148 */         bool = true;
/* 149 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 153 */     if (bool) {
/* 154 */       TankType tankType = (TankType)vehicleSubType;
/* 155 */       String str = tankType.getDisplayName();
/* 156 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 157 */       itemMeta.setDisplayName(str);
/* 158 */       ArrayList<String> arrayList = new ArrayList();
/* 159 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", tankType.getDisplayName()));
/* 160 */       itemMeta.setLore(arrayList);
/* 161 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 162 */       itemStack.setItemMeta(itemMeta);
/* 163 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 165 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 168 */     int i = paramPlayer.getInventory().firstEmpty();
/* 169 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 170 */     if (i != -1) {
/* 171 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 173 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 177 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 178 */     if (paramDouble1 < 0.01D) {
/* 179 */       paramDouble1 = 0.01D;
/*     */     }
/* 181 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 182 */     boolean bool = false;
/* 183 */     VehicleSubType vehicleSubType = null;
/* 184 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TANK)) {
/* 185 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 186 */         bool = true;
/* 187 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 191 */     if (bool) {
/* 192 */       TankType tankType = (TankType)vehicleSubType;
/* 193 */       String str = tankType.getDisplayName();
/* 194 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 195 */       itemMeta.setDisplayName(str);
/* 196 */       ArrayList<String> arrayList = new ArrayList();
/* 197 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", tankType.getDisplayName()));
/* 198 */       arrayList.add("");
/* 199 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 200 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + tankType.getMaxHealth());
/*     */       }
/* 202 */       if (vehiclesMain.fuelEnabled) {
/* 203 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + tankType.getFuelCapacity());
/*     */       }
/* 205 */       itemMeta.setLore(arrayList);
/* 206 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 207 */       itemStack.setItemMeta(itemMeta);
/* 208 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 210 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 213 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 214 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 215 */     String str = NumberUtils.getInstance().firstChars(d);
/* 216 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 220 */     Vector vector = new Vector();
/* 221 */     double d1 = paramFloat1;
/* 222 */     double d2 = paramFloat2;
/* 223 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 224 */     double d3 = Math.cos(Math.toRadians(d2));
/* 225 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 226 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 227 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 230 */     Location location1 = paramArmorStand2.getLocation();
/* 231 */     Location location2 = paramArmorStand1.getLocation();
/* 232 */     double d1 = -(location1.getX() - location2.getX());
/* 233 */     double d2 = location1.getY() - location2.getY();
/* 234 */     double d3 = location1.getZ() - location2.getZ();
/* 235 */     Material material1 = paramArmorStand1.getItemInHand().getType();
/* 236 */     if (material1.toString().endsWith("_TERRACOTTA")) {
/* 237 */       if (!EntityUtils.newHandRender) {
/* 238 */         d1 -= 0.54D;
/*     */       } else {
/* 240 */         d1 += 0.2D;
/*     */       } 
/*     */     }
/* 243 */     if (material1.toString().endsWith("_WOOL") && EntityUtils.newHandRender) {
/* 244 */       d1 += 0.065D;
/* 245 */       d3 += 0.04D;
/*     */     } 
/* 247 */     Material material2 = paramArmorStand1.getHelmet().getType();
/* 248 */     if (material2 == Material.SPRUCE_FENCE_GATE && EntityUtils.newHandRender) {
/* 249 */       d1 -= 0.33D;
/*     */     }
/* 251 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 254 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\TankManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */