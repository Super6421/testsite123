/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.ParachuteType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ParachuteManager implements VehicleManager {
/*  27 */   private static float j = 180.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  30 */     paramLocation = paramLocation.add(0.0D, 1.0D, 0.0D);
/*  31 */     ParachuteType parachuteType = ParachuteType.valueOf(paramString2);
/*  32 */     String str1 = parachuteType.toString();
/*     */     
/*  34 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Parachute.schem", true) : new ArrayList();
/*  35 */     Location location1 = paramLocation.clone().add(new Vector(-0.1D, -1.0D, 0.0D));
/*  36 */     location1.setYaw(180.0F);
/*  37 */     location1.setPitch(0.0F);
/*  38 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  39 */     if (parachuteType.getModelItem() != null) {
/*  40 */       armorStand1.getEquipment().setHelmet(parachuteType.getModelItem());
/*     */     }
/*  42 */     EntityUtils.setGravity(armorStand1, false);
/*  43 */     armorStand1.setVisible(false);
/*  44 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.38D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  45 */     EntityUtils.setGravity(armorStand2, false);
/*  46 */     armorStand2.setVisible(false);
/*  47 */     armorStand2.setCustomName("ParaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  48 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  49 */     EntityUtils.setGravity(armorStand3, false);
/*  50 */     armorStand3.setVisible(false);
/*  51 */     armorStand3.setCustomName("ParaPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  52 */     armorStand3.setPassenger((Entity)armorStand2);
/*  53 */     String str2 = "Para;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  54 */     Location location2 = armorStand3.getLocation();
/*  55 */     location2.setYaw(0.0F);
/*  56 */     armorStand3.teleport(location2);
/*  57 */     location2 = armorStand2.getLocation();
/*  58 */     location2.setYaw(0.0F);
/*  59 */     armorStand2.teleport(location2);
/*  60 */     for (ArmorStand armorStand : arrayList) {
/*  61 */       EntityUtils.removeSlots(armorStand);
/*  62 */       float f = j - armorStand.getLocation().getYaw();
/*  63 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  64 */       double d = getMultiple(armorStand, armorStand1);
/*  65 */       armorStand.setCustomName("ParaPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  66 */       if (armorStand.getHelmet().getType().toString().endsWith("_BANNER")) {
/*  67 */         if (f == 270.0F) {
/*  68 */           armorStand.setHelmet(parachuteType.getFirstBannerMaterial()); continue;
/*     */         } 
/*  70 */         armorStand.setHelmet(parachuteType.getSecondBannerMaterial());
/*     */       } 
/*     */     } 
/*     */     
/*  74 */     armorStand1.setCustomName(str2);
/*  75 */     EntityUtils.removeSlots(armorStand1);
/*  76 */     EntityUtils.removeSlots(armorStand2);
/*  77 */     EntityUtils.removeSlots(armorStand3);
/*  78 */     EntityUtils.saveUUIDData(armorStand1);
/*  79 */     EntityUtils.saveUUIDData(armorStand2);
/*  80 */     EntityUtils.saveUUIDData(armorStand3);
/*  81 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  82 */     for (ArmorStand armorStand : arrayList) {
/*  83 */       arrayList1.add(armorStand);
/*     */     }
/*  85 */     arrayList1.add(armorStand1);
/*  86 */     arrayList1.add(armorStand2);
/*  87 */     arrayList1.add(armorStand3);
/*  88 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, parachuteType.getName(), VehicleType.PARACHUTE);
/*  89 */     EntityUtils.setYaw((Entity)armorStand1, 450.0F);
/*  90 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  91 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/*  94 */     int i = paramPlayer.getInventory().firstEmpty();
/*  95 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/*  96 */     if (i != -1) {
/*  97 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/*  99 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 103 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 104 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 105 */     boolean bool = false;
/* 106 */     VehicleSubType vehicleSubType = null;
/* 107 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.PARACHUTE)) {
/* 108 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 109 */         bool = true;
/* 110 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 114 */     if (bool) {
/* 115 */       ParachuteType parachuteType = (ParachuteType)vehicleSubType;
/* 116 */       String str = parachuteType.getDisplayName();
/* 117 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 118 */       itemMeta.setDisplayName(str);
/* 119 */       ArrayList<String> arrayList = new ArrayList();
/* 120 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", parachuteType.getDisplayName()));
/* 121 */       itemMeta.setLore(arrayList);
/* 122 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 123 */       itemStack.setItemMeta(itemMeta);
/*     */     } 
/* 125 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 128 */     int i = paramPlayer.getInventory().firstEmpty();
/* 129 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 130 */     if (i != -1) {
/* 131 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 133 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 137 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 138 */     if (paramDouble1 < 0.01D) {
/* 139 */       paramDouble1 = 0.01D;
/*     */     }
/* 141 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 142 */     boolean bool = false;
/* 143 */     VehicleSubType vehicleSubType = null;
/* 144 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.PARACHUTE)) {
/* 145 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 146 */         bool = true;
/* 147 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 151 */     if (bool) {
/* 152 */       ParachuteType parachuteType = (ParachuteType)vehicleSubType;
/* 153 */       String str = parachuteType.getDisplayName();
/* 154 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 155 */       itemMeta.setDisplayName(str);
/* 156 */       ArrayList<String> arrayList = new ArrayList();
/* 157 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", parachuteType.getDisplayName()));
/* 158 */       arrayList.add("");
/* 159 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 160 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + parachuteType.getMaxHealth());
/*     */       }
/* 162 */       itemMeta.setLore(arrayList);
/* 163 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 164 */       itemStack.setItemMeta(itemMeta);
/*     */     } 
/* 166 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 169 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 170 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 171 */     String str = NumberUtils.getInstance().firstChars(d);
/* 172 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 176 */     Vector vector = new Vector();
/* 177 */     double d1 = paramFloat1;
/* 178 */     double d2 = paramFloat2;
/* 179 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 180 */     double d3 = Math.cos(Math.toRadians(d2));
/* 181 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 182 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 183 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 186 */     Location location1 = paramArmorStand2.getLocation();
/* 187 */     Location location2 = paramArmorStand1.getLocation();
/* 188 */     double d1 = location1.getX() - location2.getX();
/* 189 */     double d2 = location1.getY() - location2.getY();
/* 190 */     double d3 = location1.getZ() - location2.getZ();
/* 191 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 194 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\ParachuteManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */