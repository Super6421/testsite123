/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.CustomHeadCreator;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.DrillType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class DrillManager
/*     */   implements VehicleManager {
/*  30 */   private static float j = 270.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  33 */     paramLocation = paramLocation.add(0.0D, 0.15D, 0.0D);
/*  34 */     DrillType drillType = DrillType.valueOf(paramString2);
/*  35 */     String str1 = drillType.toString();
/*     */     
/*  37 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Drill.schem", false) : new ArrayList();
/*  38 */     Location location1 = paramLocation.clone().add(0.0D, -0.15D, 0.0D).add(0.5D, 0.05D, 0.5D);
/*  39 */     location1.setYaw(180.0F);
/*  40 */     location1.setPitch(0.0F);
/*  41 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  42 */     if (drillType.getModelItem() != null) {
/*  43 */       armorStand1.getEquipment().setHelmet(drillType.getModelItem());
/*     */     }
/*  45 */     EntityUtils.setGravity(armorStand1, false);
/*  46 */     armorStand1.setVisible(false);
/*  47 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.46D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  48 */     EntityUtils.setGravity(armorStand2, false);
/*  49 */     armorStand2.setVisible(false);
/*  50 */     armorStand2.setCustomName("DrillPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  51 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  52 */     EntityUtils.setGravity(armorStand3, false);
/*  53 */     armorStand3.setVisible(false);
/*  54 */     armorStand3.setCustomName("DrillPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  55 */     armorStand3.setPassenger((Entity)armorStand2);
/*  56 */     String str2 = "Drill;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  57 */     Location location2 = armorStand3.getLocation();
/*  58 */     location2.setYaw(0.0F);
/*  59 */     armorStand3.teleport(location2);
/*  60 */     location2 = armorStand2.getLocation();
/*  61 */     location2.setYaw(0.0F);
/*  62 */     armorStand2.teleport(location2);
/*  63 */     ItemStack itemStack1 = CustomHeadCreator.createItemStack("http://textures.minecraft.net/texture/3ab0263bdd76f3e418dba5bf481b921ced397d8b8a34a5561fb7beaa46ece1");
/*  64 */     ItemStack itemStack2 = CustomHeadCreator.createItemStack("http://textures.minecraft.net/texture/1512be8b943d5fbf918a5b8ef5741744d261d608145a3d2f2203aff9925ab9b");
/*  65 */     ItemStack itemStack3 = CustomHeadCreator.createItemStack("http://textures.minecraft.net/texture/13fa5265a336abde301a9d59af4783e82a10dad0817716ead2962ab7c6d3dff");
/*  66 */     for (ArmorStand armorStand : arrayList) {
/*  67 */       EntityUtils.removeSlots(armorStand);
/*  68 */       float f = j - armorStand.getLocation().getYaw();
/*  69 */       Material material1 = armorStand.getHelmet().getType();
/*  70 */       Material material2 = armorStand.getItemInHand().getType();
/*  71 */       if (material2 == Material.GLASS_PANE && (
/*  72 */         armorStand.getRightArmPose().getZ() > 0.0D || armorStand.getRightArmPose().getZ() < 0.0D)) {
/*  73 */         f += 180.0F;
/*     */       }
/*     */       
/*  76 */       if (material1 == Material.PLAYER_HEAD) {
/*  77 */         ItemMeta itemMeta = armorStand.getHelmet().getItemMeta();
/*  78 */         if (itemMeta.getDisplayName().equals("WHEEL_MATERIAL")) {
/*  79 */           f += 180.0F;
/*     */         }
/*     */       } 
/*  82 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  83 */       double d = getMultiple(armorStand, armorStand1);
/*  84 */       armorStand.setCustomName("DrillPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  85 */       if (material1 == Material.PLAYER_HEAD) {
/*  86 */         ItemMeta itemMeta = armorStand.getHelmet().getItemMeta();
/*  87 */         if (itemMeta.getDisplayName().equals("WHEEL_MATERIAL")) {
/*  88 */           armorStand.setHelmet(drillType.getWheelMaterial()); continue;
/*  89 */         }  if (itemMeta.getDisplayName().equals("MAIN_MATERIAL")) {
/*  90 */           armorStand.setHelmet(drillType.getMaterial()); continue;
/*  91 */         }  if (itemMeta.getDisplayName().equals("WOOL")) {
/*  92 */           armorStand.setHelmet(itemStack1); continue;
/*  93 */         }  if (itemMeta.getDisplayName().equals("PIPE")) {
/*  94 */           armorStand.setHelmet(itemStack2); continue;
/*  95 */         }  if (itemMeta.getDisplayName().equals("DRILL_MATERIAL")) {
/*  96 */           armorStand.setHelmet(itemStack3);
/*     */         }
/*     */       } 
/*     */     } 
/* 100 */     armorStand1.setCustomName(str2);
/* 101 */     EntityUtils.removeSlots(armorStand1);
/* 102 */     EntityUtils.removeSlots(armorStand2);
/* 103 */     EntityUtils.removeSlots(armorStand3);
/* 104 */     EntityUtils.saveUUIDData(armorStand1);
/* 105 */     EntityUtils.saveUUIDData(armorStand2);
/* 106 */     EntityUtils.saveUUIDData(armorStand3);
/* 107 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 108 */     for (ArmorStand armorStand : arrayList) {
/* 109 */       arrayList1.add(armorStand);
/*     */     }
/* 111 */     arrayList1.add(armorStand1);
/* 112 */     arrayList1.add(armorStand2);
/* 113 */     arrayList1.add(armorStand3);
/* 114 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, drillType.getName(), VehicleType.DRILL);
/* 115 */     EntityUtils.setYaw((Entity)armorStand1, 90.0F);
/* 116 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 117 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 120 */     int i = paramPlayer.getInventory().firstEmpty();
/* 121 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 122 */     if (i != -1) {
/* 123 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 125 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 129 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 130 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 131 */     boolean bool = false;
/* 132 */     VehicleSubType vehicleSubType = null;
/* 133 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.DRILL)) {
/* 134 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 135 */         bool = true;
/* 136 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 140 */     if (bool) {
/* 141 */       DrillType drillType = (DrillType)vehicleSubType;
/* 142 */       String str = drillType.getDisplayName();
/* 143 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 144 */       itemMeta.setDisplayName(str);
/* 145 */       ArrayList<String> arrayList = new ArrayList();
/* 146 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", drillType.getDisplayName()));
/* 147 */       itemMeta.setLore(arrayList);
/* 148 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 149 */       itemStack.setItemMeta(itemMeta);
/* 150 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 152 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 155 */     int i = paramPlayer.getInventory().firstEmpty();
/* 156 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 157 */     if (i != -1) {
/* 158 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 160 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 164 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 165 */     if (paramDouble1 < 0.01D) {
/* 166 */       paramDouble1 = 0.01D;
/*     */     }
/* 168 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 169 */     boolean bool = false;
/* 170 */     VehicleSubType vehicleSubType = null;
/* 171 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.DRILL)) {
/* 172 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 173 */         bool = true;
/* 174 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 178 */     if (bool) {
/* 179 */       DrillType drillType = (DrillType)vehicleSubType;
/* 180 */       String str = drillType.getDisplayName();
/* 181 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 182 */       itemMeta.setDisplayName(str);
/* 183 */       ArrayList<String> arrayList = new ArrayList();
/* 184 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", drillType.getDisplayName()));
/* 185 */       arrayList.add("");
/* 186 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 187 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + drillType.getMaxHealth());
/*     */       }
/* 189 */       if (vehiclesMain.fuelEnabled) {
/* 190 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + drillType.getFuelCapacity());
/*     */       }
/* 192 */       itemMeta.setLore(arrayList);
/* 193 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 194 */       itemStack.setItemMeta(itemMeta);
/* 195 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 197 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 200 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 201 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 202 */     String str = NumberUtils.getInstance().firstChars(d);
/* 203 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 207 */     Vector vector = new Vector();
/* 208 */     double d1 = paramFloat1;
/* 209 */     double d2 = paramFloat2;
/* 210 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 211 */     double d3 = Math.cos(Math.toRadians(d2));
/* 212 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 213 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 214 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 217 */     Location location1 = paramArmorStand2.getLocation();
/* 218 */     Location location2 = paramArmorStand1.getLocation();
/* 219 */     double d1 = -(location1.getX() - location2.getX());
/* 220 */     double d2 = location1.getY() - location2.getY();
/* 221 */     double d3 = location1.getZ() - location2.getZ();
/* 222 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 225 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\DrillManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */