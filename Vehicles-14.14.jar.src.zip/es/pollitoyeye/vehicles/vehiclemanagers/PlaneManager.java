/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.PlaneType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class PlaneManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(0.5D, 0.0D, -0.1D);
/*  33 */     PlaneType planeType = PlaneType.valueOf(paramString2);
/*  34 */     String str1 = planeType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Plane.schem", true) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(new Vector(-0.02D, 0.0D, 0.6D));
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (planeType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(planeType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.25D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("PlanePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -1.25D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("PlanePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";SecondSeat");
/*  54 */     ArmorStand armorStand4 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*     */     
/*  56 */     EntityUtils.setGravity(armorStand4, false);
/*  57 */     armorStand4.setVisible(false);
/*  58 */     armorStand4.setCustomName("PlanePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand4, armorStand1) + ";" + vectortoString(getPositionVector(armorStand4, armorStand1)) + ";");
/*  59 */     armorStand4.setPassenger((Entity)armorStand2);
/*  60 */     String str2 = "Plane;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand4.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  61 */     Location location2 = armorStand4.getLocation();
/*  62 */     location2.setYaw(0.0F);
/*  63 */     armorStand4.teleport(location2);
/*  64 */     location2 = armorStand2.getLocation();
/*  65 */     location2.setYaw(0.0F);
/*  66 */     armorStand2.teleport(location2);
/*  67 */     armorStand3.teleport(location2);
/*  68 */     for (ArmorStand armorStand : arrayList) {
/*  69 */       EntityUtils.removeSlots(armorStand);
/*  70 */       float f = j - armorStand.getLocation().getYaw();
/*  71 */       if (armorStand.getHelmet().getType() == Material.GLASS_PANE && ((
/*  72 */         armorStand.getHeadPose().getX() > 0.3D && armorStand.getHeadPose().getX() < 0.4D) || (armorStand.getHeadPose().getX() > 0.4D && armorStand
/*  73 */         .getHeadPose().getX() < 0.5D && armorStand.getHeadPose().getZ() != 0.0D))) {
/*  74 */         f += 180.0F;
/*     */       }
/*     */       
/*  77 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  78 */       double d = getMultiple(armorStand, armorStand1);
/*  79 */       armorStand.setCustomName("PlanePart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  80 */       if (armorStand.getHelmet().getType() == Material.BLACK_WOOL) {
/*  81 */         armorStand.setHelmet(planeType.getWheelsMaterial()); continue;
/*     */       } 
/*  83 */       if (armorStand.getHelmet().getType() == Material.GREEN_TERRACOTTA) {
/*  84 */         armorStand.setHelmet(planeType.getMaterial()); continue;
/*     */       } 
/*  86 */       if (armorStand.getHelmet().getType() == Material.OAK_PRESSURE_PLATE) {
/*  87 */         armorStand.setHelmet(planeType.getWingsMaterial());
/*     */       }
/*     */     } 
/*  90 */     armorStand1.setCustomName(str2);
/*  91 */     EntityUtils.removeSlots(armorStand1);
/*  92 */     EntityUtils.removeSlots(armorStand2);
/*  93 */     EntityUtils.removeSlots(armorStand3);
/*  94 */     EntityUtils.removeSlots(armorStand4);
/*  95 */     EntityUtils.saveUUIDData(armorStand1);
/*  96 */     EntityUtils.saveUUIDData(armorStand2);
/*  97 */     EntityUtils.saveUUIDData(armorStand3);
/*  98 */     EntityUtils.saveUUIDData(armorStand4);
/*  99 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 100 */     for (ArmorStand armorStand : arrayList) {
/* 101 */       arrayList1.add(armorStand);
/*     */     }
/* 103 */     arrayList1.add(armorStand1);
/* 104 */     arrayList1.add(armorStand2);
/* 105 */     arrayList1.add(armorStand3);
/* 106 */     arrayList1.add(armorStand4);
/* 107 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, planeType.getName(), VehicleType.PLANE);
/* 108 */     EntityUtils.setYaw((Entity)armorStand1, 450.0F);
/* 109 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 110 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 113 */     int i = paramPlayer.getInventory().firstEmpty();
/* 114 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 115 */     if (i != -1) {
/* 116 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 118 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 122 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 123 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 124 */     boolean bool = false;
/* 125 */     VehicleSubType vehicleSubType = null;
/* 126 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.PLANE)) {
/* 127 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 128 */         bool = true;
/* 129 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 133 */     if (bool) {
/* 134 */       PlaneType planeType = (PlaneType)vehicleSubType;
/* 135 */       String str = planeType.getDisplayName();
/* 136 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 137 */       itemMeta.setDisplayName(str);
/* 138 */       ArrayList<String> arrayList = new ArrayList();
/* 139 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", planeType.getDisplayName()));
/* 140 */       itemMeta.setLore(arrayList);
/* 141 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 142 */       itemStack.setItemMeta(itemMeta);
/* 143 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 145 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 148 */     int i = paramPlayer.getInventory().firstEmpty();
/* 149 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 150 */     if (i != -1) {
/* 151 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 153 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 157 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 158 */     if (paramDouble1 < 0.01D) {
/* 159 */       paramDouble1 = 0.01D;
/*     */     }
/* 161 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 162 */     boolean bool = false;
/* 163 */     VehicleSubType vehicleSubType = null;
/* 164 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.PLANE)) {
/* 165 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 166 */         bool = true;
/* 167 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 171 */     if (bool) {
/* 172 */       PlaneType planeType = (PlaneType)vehicleSubType;
/* 173 */       NumberUtils numberUtils = NumberUtils.getInstance();
/* 174 */       String str = planeType.getDisplayName();
/* 175 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 176 */       itemMeta.setDisplayName(str);
/* 177 */       ArrayList<String> arrayList = new ArrayList();
/* 178 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", planeType.getDisplayName()));
/* 179 */       arrayList.add("");
/* 180 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 181 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + numberUtils.getLastDigitsDouble(paramDouble1) + "/" + planeType.getMaxHealth());
/*     */       }
/* 183 */       if (vehiclesMain.fuelEnabled) {
/* 184 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + numberUtils.getLastDigitsDouble(paramDouble2) + "/" + planeType.getFuelCapacity());
/*     */       }
/* 186 */       itemMeta.setLore(arrayList);
/* 187 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 188 */       itemStack.setItemMeta(itemMeta);
/* 189 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 191 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 194 */     NumberUtils numberUtils = NumberUtils.getInstance();
/* 195 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 196 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 197 */     String str = numberUtils.firstChars(d);
/* 198 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 202 */     Vector vector = new Vector();
/* 203 */     double d1 = paramFloat1;
/* 204 */     double d2 = paramFloat2;
/* 205 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 206 */     double d3 = Math.cos(Math.toRadians(d2));
/* 207 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 208 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 209 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 212 */     Location location1 = paramArmorStand2.getLocation();
/* 213 */     Location location2 = paramArmorStand1.getLocation();
/* 214 */     double d1 = location1.getX() - location2.getX();
/* 215 */     double d2 = location1.getY() - location2.getY();
/* 216 */     double d3 = location1.getZ() - location2.getZ();
/* 217 */     if (paramArmorStand1.getHelmet().getType() == Material.GLASS_PANE) {
/* 218 */       if (paramArmorStand1.getHeadPose().getX() > 0.3D && paramArmorStand1.getHeadPose().getX() < 0.4D) {
/* 219 */         if (d3 > 0.0D) {
/* 220 */           d3 -= 0.8D;
/*     */         } else {
/* 222 */           d3 += 0.8D;
/*     */         } 
/*     */       }
/* 225 */       if (paramArmorStand1.getHeadPose().getX() > 0.4D && paramArmorStand1.getHeadPose().getX() < 0.5D && 
/* 226 */         paramArmorStand1.getHeadPose().getZ() != 0.0D) {
/* 227 */         if (d3 > 0.0D) {
/* 228 */           d3 -= 0.9D;
/*     */         } else {
/* 230 */           d3 += 0.9D;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 235 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 238 */     NumberUtils numberUtils = NumberUtils.getInstance();
/* 239 */     return numberUtils.firstChars(paramVector.getX()) + "/" + numberUtils.firstChars(paramVector.getY()) + "/" + numberUtils.firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\PlaneManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */