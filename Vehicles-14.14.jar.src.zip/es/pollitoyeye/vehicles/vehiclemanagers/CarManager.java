/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.CarType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class CarManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 0.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.subtract(new Vector(0.0D, -0.1D, -0.1D));
/*  33 */     CarType carType = CarType.valueOf(paramString2);
/*  34 */     String str1 = carType.toString();
/*  35 */     ItemStack itemStack1 = carType.getMaterial();
/*  36 */     ItemStack itemStack2 = carType.getWheelsMaterial();
/*  37 */     ItemStack itemStack3 = carType.getFrontLightsMaterial();
/*  38 */     ItemStack itemStack4 = carType.getBackLightsMaterial();
/*  39 */     ItemStack itemStack5 = carType.getSteelMaterial();
/*     */     
/*  41 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Car.schem", true) : new ArrayList();
/*  42 */     Location location1 = paramLocation.clone().add(new Vector(0.6D, -0.5D, 0.45D));
/*  43 */     location1.setYaw(j);
/*  44 */     location1.setPitch(0.0F);
/*  45 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(new Vector(0.0D, 0.5D, -0.2D)), EntityType.ARMOR_STAND);
/*  46 */     if (carType.getModelItem() != null) {
/*  47 */       armorStand1.getEquipment().setHelmet(carType.getModelItem());
/*     */     }
/*     */     
/*  50 */     EntityUtils.setGravity(armorStand1, false);
/*  51 */     armorStand1.setVisible(false);
/*  52 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*     */     
/*  54 */     EntityUtils.setGravity(armorStand2, false);
/*  55 */     armorStand2.setVisible(false);
/*  56 */     armorStand2.setCustomName("CarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  57 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*     */     
/*  59 */     EntityUtils.setGravity(armorStand3, false);
/*  60 */     armorStand3.setVisible(false);
/*  61 */     armorStand3.setCustomName("CarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";SecondSeat");
/*  62 */     ArmorStand armorStand4 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*     */     
/*  64 */     EntityUtils.setGravity(armorStand4, false);
/*  65 */     armorStand4.setVisible(false);
/*  66 */     armorStand4.setCustomName("CarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand4, armorStand1) + ";" + vectortoString(getPositionVector(armorStand4, armorStand1)) + ";");
/*  67 */     armorStand4.setPassenger((Entity)armorStand2);
/*  68 */     String str2 = "Car;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand4.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  69 */     Location location2 = armorStand4.getLocation();
/*  70 */     location2.setYaw(armorStand1.getLocation().getYaw());
/*  71 */     armorStand4.teleport(location2);
/*  72 */     location2 = armorStand2.getLocation();
/*  73 */     location2.setYaw(armorStand1.getLocation().getYaw());
/*  74 */     armorStand2.teleport(location2);
/*  75 */     for (ArmorStand armorStand : arrayList) {
/*  76 */       EntityUtils.removeSlots(armorStand);
/*  77 */       armorStand.setCustomName("CarPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand, armorStand1) + ";" + vectortoString(getPositionVector(armorStand, armorStand1)) + ";");
/*  78 */       if (armorStand.getHelmet().getType() == Material.YELLOW_TERRACOTTA) {
/*  79 */         armorStand.setHelmet(itemStack1);
/*  80 */       } else if (armorStand.getHelmet().getType() == Material.PLAYER_HEAD) {
/*  81 */         armorStand.setHelmet(itemStack2);
/*     */       }
/*  83 */       else if (armorStand.getHelmet().getType() == Material.STONE) {
/*  84 */         armorStand.setHelmet(itemStack3);
/*     */       }
/*  86 */       else if (armorStand.getHelmet().getType() == Material.SPONGE) {
/*  87 */         armorStand.setHelmet(itemStack4);
/*     */       }
/*  89 */       else if (armorStand.getHelmet().getType() == Material.COAL_BLOCK) {
/*  90 */         armorStand.setHelmet(itemStack5);
/*     */       } 
/*  92 */       location2 = armorStand.getLocation().clone();
/*  93 */       if (armorStand.getHelmet().getType() == Material.GLASS_PANE && armorStand.getLocation().getYaw() == 90.0F) {
/*  94 */         location2.setYaw(90.0F);
/*  95 */         location2.setPitch(0.0F);
/*  96 */         EntityUtils.setYaw((Entity)armorStand, 90.0F);
/*  97 */         armorStand.setChestplate(new ItemStack(Material.STICK));
/*     */       } else {
/*  99 */         location2.setYaw(armorStand1.getLocation().getYaw());
/*     */       } 
/* 101 */       armorStand.teleport(location2);
/* 102 */       if (armorStand.getChestplate().getType() == Material.STICK) {
/* 103 */         EntityUtils.setYaw((Entity)armorStand, 90.0F);
/* 104 */         EntityUtils.setModelGroup(armorStand, 1);
/*     */       } 
/*     */     } 
/* 107 */     armorStand1.setCustomName(str2);
/* 108 */     EntityUtils.removeSlots(armorStand1);
/* 109 */     EntityUtils.removeSlots(armorStand2);
/* 110 */     EntityUtils.removeSlots(armorStand3);
/* 111 */     EntityUtils.removeSlots(armorStand4);
/* 112 */     EntityUtils.saveUUIDData(armorStand1);
/* 113 */     EntityUtils.saveUUIDData(armorStand2);
/* 114 */     EntityUtils.saveUUIDData(armorStand3);
/* 115 */     EntityUtils.saveUUIDData(armorStand4);
/* 116 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 117 */     for (ArmorStand armorStand : arrayList) {
/* 118 */       arrayList1.add(armorStand);
/*     */     }
/* 120 */     arrayList1.add(armorStand1);
/* 121 */     arrayList1.add(armorStand2);
/* 122 */     arrayList1.add(armorStand3);
/* 123 */     arrayList1.add(armorStand4);
/* 124 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, carType.getName(), VehicleType.CAR);
/* 125 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 126 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 129 */     int i = paramPlayer.getInventory().firstEmpty();
/* 130 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 131 */     if (i != -1) {
/* 132 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 134 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 138 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 139 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 140 */     boolean bool = false;
/* 141 */     VehicleSubType vehicleSubType = null;
/* 142 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.CAR)) {
/* 143 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 144 */         bool = true;
/* 145 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 149 */     if (bool) {
/* 150 */       CarType carType = (CarType)vehicleSubType;
/* 151 */       String str = carType.getDisplayName();
/* 152 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 153 */       itemMeta.setDisplayName(str);
/* 154 */       ArrayList<String> arrayList = new ArrayList();
/* 155 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", carType.getDisplayName()));
/* 156 */       itemMeta.setLore(arrayList);
/* 157 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 158 */       itemStack.setItemMeta(itemMeta);
/* 159 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 161 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 164 */     int i = paramPlayer.getInventory().firstEmpty();
/* 165 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 166 */     if (i != -1) {
/* 167 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 169 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 173 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 174 */     if (paramDouble1 < 0.01D) {
/* 175 */       paramDouble1 = 0.01D;
/*     */     }
/* 177 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 178 */     boolean bool = false;
/* 179 */     VehicleSubType vehicleSubType = null;
/* 180 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.CAR)) {
/* 181 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 182 */         bool = true;
/* 183 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 187 */     if (bool) {
/* 188 */       CarType carType = (CarType)vehicleSubType;
/* 189 */       String str = carType.getDisplayName();
/* 190 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 191 */       itemMeta.setDisplayName(str);
/* 192 */       ArrayList<String> arrayList = new ArrayList();
/* 193 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", carType.getDisplayName()));
/* 194 */       arrayList.add("");
/* 195 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 196 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + carType.getMaxHealth());
/*     */       }
/* 198 */       if (vehiclesMain.fuelEnabled) {
/* 199 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + carType.getFuelCapacity());
/*     */       }
/* 201 */       itemMeta.setLore(arrayList);
/* 202 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 203 */       itemStack.setItemMeta(itemMeta);
/* 204 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 206 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 209 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 210 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 211 */     String str = NumberUtils.getInstance().firstChars(d);
/* 212 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 216 */     Vector vector = new Vector();
/* 217 */     double d1 = paramFloat1;
/* 218 */     double d2 = paramFloat2;
/* 219 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 220 */     double d3 = Math.cos(Math.toRadians(d2));
/* 221 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 222 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 223 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 226 */     Location location1 = paramArmorStand2.getLocation();
/* 227 */     Location location2 = paramArmorStand1.getLocation();
/* 228 */     double d1 = location1.getX() - location2.getX();
/* 229 */     double d2 = location1.getY() - location2.getY();
/* 230 */     double d3 = location1.getZ() - location2.getZ();
/* 231 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 234 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\CarManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */