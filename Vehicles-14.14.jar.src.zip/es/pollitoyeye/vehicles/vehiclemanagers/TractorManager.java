/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.TractorType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class TractorManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 270.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(-0.4D, -0.17D, -0.125D);
/*  33 */     TractorType tractorType = TractorType.valueOf(paramString2);
/*  34 */     String str1 = tractorType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "Tractor.schem", false) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(0.4D, 0.17D, 0.125D).add(0.5D, 0.05D, 0.5D);
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (tractorType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(tractorType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -0.46D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("TractorPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("TractorPart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str2 = "Tractor;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*     */     
/*  63 */     for (ArmorStand armorStand : arrayList) {
/*  64 */       EntityUtils.removeSlots(armorStand);
/*  65 */       float f = j - armorStand.getLocation().getYaw();
/*  66 */       Material material1 = armorStand.getHelmet().getType();
/*  67 */       Material material2 = armorStand.getItemInHand().getType();
/*  68 */       if (material2 == Material.GREEN_CARPET) {
/*  69 */         armorStand.setItemInHand(tractorType.getWheelCoverMaterial());
/*  70 */         f -= 180.0F;
/*  71 */       } else if (material2 == Material.LOOM) {
/*  72 */         f -= 180.0F;
/*     */       } 
/*  74 */       if (material2 == Material.PLAYER_HEAD) {
/*  75 */         ItemMeta itemMeta = armorStand.getItemInHand().getItemMeta();
/*  76 */         if (itemMeta.getDisplayName().equals("PIPE_MATERIAL")) {
/*  77 */           f -= 180.0F;
/*  78 */           armorStand.setItemInHand(new ItemStack(Material.CONDUIT));
/*     */         } 
/*     */       } 
/*  81 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  82 */       double d = getMultiple(armorStand, armorStand1);
/*  83 */       if (material1 == Material.PLAYER_HEAD) {
/*  84 */         ItemMeta itemMeta = armorStand.getHelmet().getItemMeta();
/*  85 */         if (itemMeta.getDisplayName().equals("WHEEL_MATERIAL")) {
/*  86 */           armorStand.setHelmet(tractorType.getWheelMaterial());
/*  87 */           f -= 180.0F;
/*  88 */         } else if (itemMeta.getDisplayName().equals("MAIN_MATERIAL")) {
/*  89 */           armorStand.setHelmet(tractorType.getMaterial());
/*  90 */         } else if (itemMeta.getDisplayName().equals("MOTOR_MATERIAL")) {
/*  91 */           armorStand.setHelmet(tractorType.getMotorMaterial());
/*  92 */         } else if (itemMeta.getDisplayName().equals("BOTTOM_MATERIAL")) {
/*  93 */           armorStand.setHelmet(tractorType.getBottomMaterial());
/*  94 */         } else if (itemMeta.getDisplayName().equals("STEERING_WHEEL_MATERIAL")) {
/*  95 */           armorStand.setHelmet(tractorType.getSteeringWheelMaterial());
/*  96 */         } else if (itemMeta.getDisplayName().equals("BIG_WHEEL_OUTSIDE_MATERIAL")) {
/*  97 */           f -= 180.0F;
/*  98 */           armorStand.setHelmet(tractorType.getBigWheelOutsideMaterial());
/*  99 */         } else if (itemMeta.getDisplayName().equals("BIG_WHEEL_INSIDE_MATERIAL")) {
/* 100 */           f -= 180.0F;
/* 101 */           armorStand.setHelmet(tractorType.getBigWheelInsideMaterial());
/*     */         } 
/*     */       } 
/* 104 */       armorStand.setCustomName("TractorPart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*     */     } 
/* 106 */     armorStand1.setCustomName(str2);
/* 107 */     EntityUtils.removeSlots(armorStand1);
/* 108 */     EntityUtils.removeSlots(armorStand2);
/* 109 */     EntityUtils.removeSlots(armorStand3);
/* 110 */     EntityUtils.saveUUIDData(armorStand1);
/* 111 */     EntityUtils.saveUUIDData(armorStand2);
/* 112 */     EntityUtils.saveUUIDData(armorStand3);
/* 113 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 114 */     for (ArmorStand armorStand : arrayList) {
/* 115 */       arrayList1.add(armorStand);
/*     */     }
/* 117 */     arrayList1.add(armorStand1);
/* 118 */     arrayList1.add(armorStand2);
/* 119 */     arrayList1.add(armorStand3);
/* 120 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, tractorType.getName(), VehicleType.TRACTOR);
/* 121 */     EntityUtils.setYaw((Entity)armorStand1, 90.0F);
/* 122 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 123 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 126 */     int i = paramPlayer.getInventory().firstEmpty();
/* 127 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 128 */     if (i != -1) {
/* 129 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 131 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 135 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 136 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 137 */     boolean bool = false;
/* 138 */     VehicleSubType vehicleSubType = null;
/* 139 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TRACTOR)) {
/* 140 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 141 */         bool = true;
/* 142 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 146 */     if (bool) {
/* 147 */       TractorType tractorType = (TractorType)vehicleSubType;
/* 148 */       String str = tractorType.getDisplayName();
/* 149 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 150 */       itemMeta.setDisplayName(str);
/* 151 */       ArrayList<String> arrayList = new ArrayList();
/* 152 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", tractorType.getDisplayName()));
/* 153 */       itemMeta.setLore(arrayList);
/* 154 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 155 */       itemStack.setItemMeta(itemMeta);
/* 156 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 158 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 161 */     int i = paramPlayer.getInventory().firstEmpty();
/* 162 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 163 */     if (i != -1) {
/* 164 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 166 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 170 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 171 */     if (paramDouble1 < 0.01D) {
/* 172 */       paramDouble1 = 0.01D;
/*     */     }
/* 174 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 175 */     boolean bool = false;
/* 176 */     VehicleSubType vehicleSubType = null;
/* 177 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.TRACTOR)) {
/* 178 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 179 */         bool = true;
/* 180 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 184 */     if (bool) {
/* 185 */       TractorType tractorType = (TractorType)vehicleSubType;
/* 186 */       String str = tractorType.getDisplayName();
/* 187 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 188 */       itemMeta.setDisplayName(str);
/* 189 */       ArrayList<String> arrayList = new ArrayList();
/* 190 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", tractorType.getDisplayName()));
/* 191 */       arrayList.add("");
/* 192 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 193 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + tractorType.getMaxHealth());
/*     */       }
/* 195 */       if (vehiclesMain.fuelEnabled) {
/* 196 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + tractorType.getFuelCapacity());
/*     */       }
/* 198 */       itemMeta.setLore(arrayList);
/* 199 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 200 */       itemStack.setItemMeta(itemMeta);
/* 201 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 203 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 206 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 207 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 208 */     String str = NumberUtils.getInstance().firstChars(d);
/* 209 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 213 */     Vector vector = new Vector();
/* 214 */     double d1 = paramFloat1;
/* 215 */     double d2 = paramFloat2;
/* 216 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 217 */     double d3 = Math.cos(Math.toRadians(d2));
/* 218 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 219 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 220 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 223 */     Location location1 = paramArmorStand2.getLocation();
/* 224 */     Location location2 = paramArmorStand1.getLocation();
/* 225 */     double d1 = -(location1.getX() - location2.getX());
/* 226 */     double d2 = location1.getY() - location2.getY();
/* 227 */     double d3 = location1.getZ() - location2.getZ();
/* 228 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 231 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\TractorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */