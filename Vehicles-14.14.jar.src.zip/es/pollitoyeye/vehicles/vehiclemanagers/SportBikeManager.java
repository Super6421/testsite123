/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.SportBikeType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class SportBikeManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 90.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(-0.1D, -0.61D, 0.0D);
/*  33 */     SportBikeType sportBikeType = SportBikeType.valueOf(paramString2);
/*  34 */     String str1 = sportBikeType.toString();
/*     */     
/*  36 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation, "SportBike.schem", false) : new ArrayList();
/*  37 */     Location location1 = paramLocation.clone().add(0.1D, 0.61D, 0.0D).add(0.5D, 0.0D, 0.5D);
/*  38 */     location1.setYaw(180.0F);
/*  39 */     location1.setPitch(0.0F);
/*  40 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  41 */     if (sportBikeType.getModelItem() != null) {
/*  42 */       armorStand1.getEquipment().setHelmet(sportBikeType.getModelItem());
/*     */     }
/*  44 */     EntityUtils.setGravity(armorStand1, false);
/*  45 */     armorStand1.setVisible(false);
/*  46 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -0.85D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  47 */     EntityUtils.setGravity(armorStand2, false);
/*  48 */     armorStand2.setVisible(false);
/*  49 */     armorStand2.setCustomName("SBikePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  50 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  51 */     EntityUtils.setGravity(armorStand3, false);
/*  52 */     armorStand3.setVisible(false);
/*  53 */     armorStand3.setCustomName("SBikePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  54 */     armorStand3.setPassenger((Entity)armorStand2);
/*  55 */     String str2 = "SBike;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  56 */     Location location2 = armorStand3.getLocation();
/*  57 */     location2.setYaw(0.0F);
/*  58 */     armorStand3.teleport(location2);
/*  59 */     location2 = armorStand2.getLocation();
/*  60 */     location2.setYaw(0.0F);
/*  61 */     armorStand2.teleport(location2);
/*  62 */     for (ArmorStand armorStand : arrayList) {
/*  63 */       EntityUtils.removeSlots(armorStand);
/*  64 */       float f = j - armorStand.getLocation().getYaw();
/*  65 */       f += 270.0F + armorStand.getLocation().getYaw() * 2.0F;
/*  66 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  67 */       double d = getMultiple(armorStand, armorStand1);
/*  68 */       armorStand.setCustomName("SBikePart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  69 */       Material material = armorStand.getEquipment().getHelmet().getType();
/*  70 */       if (material == Material.PLAYER_HEAD) {
/*  71 */         ItemMeta itemMeta = armorStand.getHelmet().getItemMeta();
/*  72 */         if (itemMeta.getDisplayName().equals("WHEEL_MATERIAL")) {
/*  73 */           armorStand.getEquipment().setHelmet(sportBikeType.getWheelMaterial());
/*     */         }
/*     */       } 
/*     */     } 
/*  77 */     armorStand1.setCustomName(str2);
/*  78 */     EntityUtils.removeSlots(armorStand1);
/*  79 */     EntityUtils.removeSlots(armorStand2);
/*  80 */     EntityUtils.removeSlots(armorStand3);
/*  81 */     EntityUtils.saveUUIDData(armorStand1);
/*  82 */     EntityUtils.saveUUIDData(armorStand2);
/*  83 */     EntityUtils.saveUUIDData(armorStand3);
/*  84 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/*  85 */     for (ArmorStand armorStand : arrayList) {
/*  86 */       arrayList1.add(armorStand);
/*     */     }
/*  88 */     arrayList1.add(armorStand1);
/*  89 */     arrayList1.add(armorStand2);
/*  90 */     arrayList1.add(armorStand3);
/*  91 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, sportBikeType.getName(), VehicleType.SPORT_BIKE);
/*  92 */     EntityUtils.setYaw((Entity)armorStand1, 270.0F);
/*  93 */     EntityUtils.setYaw((Entity)armorStand2, 270.0F);
/*  94 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/*  95 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/*  98 */     int i = paramPlayer.getInventory().firstEmpty();
/*  99 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 100 */     if (i != -1) {
/* 101 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 103 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 107 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 108 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 109 */     boolean bool = false;
/* 110 */     VehicleSubType vehicleSubType = null;
/* 111 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.SPORT_BIKE)) {
/* 112 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 113 */         bool = true;
/* 114 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 118 */     if (bool) {
/* 119 */       SportBikeType sportBikeType = (SportBikeType)vehicleSubType;
/* 120 */       String str = sportBikeType.getDisplayName();
/* 121 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 122 */       itemMeta.setDisplayName(str);
/* 123 */       ArrayList<String> arrayList = new ArrayList();
/* 124 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", sportBikeType.getDisplayName()));
/* 125 */       itemMeta.setLore(arrayList);
/* 126 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 127 */       itemStack.setItemMeta(itemMeta);
/* 128 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 130 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 133 */     int i = paramPlayer.getInventory().firstEmpty();
/* 134 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 135 */     if (i != -1) {
/* 136 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 138 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 142 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 143 */     if (paramDouble1 < 0.01D) {
/* 144 */       paramDouble1 = 0.01D;
/*     */     }
/* 146 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 147 */     boolean bool = false;
/* 148 */     VehicleSubType vehicleSubType = null;
/* 149 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.SPORT_BIKE)) {
/* 150 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 151 */         bool = true;
/* 152 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 156 */     if (bool) {
/* 157 */       SportBikeType sportBikeType = (SportBikeType)vehicleSubType;
/* 158 */       String str = sportBikeType.getDisplayName();
/* 159 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 160 */       itemMeta.setDisplayName(str);
/* 161 */       ArrayList<String> arrayList = new ArrayList();
/* 162 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", sportBikeType.getDisplayName()));
/* 163 */       arrayList.add("");
/* 164 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 165 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + sportBikeType.getMaxHealth());
/*     */       }
/* 167 */       if (vehiclesMain.fuelEnabled) {
/* 168 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + sportBikeType.getFuelCapacity());
/*     */       }
/* 170 */       itemMeta.setLore(arrayList);
/* 171 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 172 */       itemStack.setItemMeta(itemMeta);
/* 173 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 175 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 178 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 179 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 180 */     String str = NumberUtils.getInstance().firstChars(d);
/* 181 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 185 */     Vector vector = new Vector();
/* 186 */     double d1 = paramFloat1;
/* 187 */     double d2 = paramFloat2;
/* 188 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 189 */     double d3 = Math.cos(Math.toRadians(d2));
/* 190 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 191 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 192 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 195 */     Location location1 = paramArmorStand2.getLocation();
/* 196 */     Location location2 = paramArmorStand1.getLocation();
/* 197 */     double d1 = -(location1.getX() - location2.getX());
/* 198 */     double d2 = location1.getY() - location2.getY();
/* 199 */     double d3 = location1.getZ() - location2.getZ();
/* 200 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 203 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\SportBikeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */