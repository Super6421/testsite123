/*     */ package es.pollitoyeye.vehicles.vehiclemanagers;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.events.VehicleSpawnedEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleManager;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.manager.StructureManager;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import es.pollitoyeye.vehicles.utils.ItemUtils;
/*     */ import es.pollitoyeye.vehicles.utils.NumberUtils;
/*     */ import es.pollitoyeye.vehicles.utils.StorageUtils;
/*     */ import es.pollitoyeye.vehicles.vehicletypes.HoverBikeType;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class HoverBikeManager
/*     */   implements VehicleManager {
/*  29 */   private static float j = 180.0F;
/*     */   
/*     */   public ArmorStand spawn(Location paramLocation, String paramString1, String paramString2) {
/*  32 */     paramLocation = paramLocation.add(-0.2D, 0.3D, 0.0D);
/*  33 */     HoverBikeType hoverBikeType = HoverBikeType.valueOf(paramString2);
/*  34 */     String str1 = hoverBikeType.toString();
/*     */ 
/*     */     
/*  37 */     ArrayList arrayList = (VehiclesMain.getPlugin()).nativeModelsEnabled ? StructureManager.loadStructure(paramLocation.clone().add(0.2D, -0.2D, -0.4D), "HoverBike.schem", true) : new ArrayList();
/*  38 */     Location location1 = paramLocation.clone().add(0.2D, -0.3D, 0.0D).add(0.5D, 0.0D, 0.5D);
/*  39 */     location1.setYaw(180.0F);
/*  40 */     location1.setPitch(0.0F);
/*  41 */     ArmorStand armorStand1 = (ArmorStand)location1.getWorld().spawnEntity(location1, EntityType.ARMOR_STAND);
/*  42 */     if (hoverBikeType.getModelItem() != null) {
/*  43 */       armorStand1.getEquipment().setHelmet(hoverBikeType.getModelItem());
/*     */     }
/*  45 */     EntityUtils.setGravity(armorStand1, false);
/*  46 */     armorStand1.setVisible(false);
/*  47 */     ArmorStand armorStand2 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().add(0.0D, -0.5D + EntityUtils.getSeatOffset(), 0.0D), EntityType.ARMOR_STAND);
/*  48 */     EntityUtils.setGravity(armorStand2, false);
/*  49 */     armorStand2.setVisible(false);
/*  50 */     armorStand2.setCustomName("HBikePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand2, armorStand1) + ";" + vectortoString(getPositionVector(armorStand2, armorStand1)) + ";");
/*  51 */     ArmorStand armorStand3 = (ArmorStand)location1.getWorld().spawnEntity(location1.clone().subtract(new Vector(0.0D, 2.4D, 0.0D)), EntityType.ARMOR_STAND);
/*  52 */     EntityUtils.setGravity(armorStand3, false);
/*  53 */     armorStand3.setVisible(false);
/*  54 */     armorStand3.setCustomName("HBikePart;" + armorStand1.getUniqueId() + ";" + getMultiple(armorStand3, armorStand1) + ";" + vectortoString(getPositionVector(armorStand3, armorStand1)) + ";");
/*  55 */     armorStand3.setPassenger((Entity)armorStand2);
/*  56 */     String str2 = "HBike;" + str1 + ";" + paramString1 + ";" + armorStand2.getUniqueId() + ";" + armorStand3.getUniqueId() + ";" + armorStand1.getLocation().getDirection().getZ();
/*  57 */     Location location2 = armorStand3.getLocation();
/*  58 */     location2.setYaw(0.0F);
/*  59 */     armorStand3.teleport(location2);
/*  60 */     location2 = armorStand2.getLocation();
/*  61 */     location2.setYaw(0.0F);
/*  62 */     armorStand2.teleport(location2);
/*  63 */     for (ArmorStand armorStand : arrayList) {
/*  64 */       EntityUtils.removeSlots(armorStand);
/*  65 */       float f = j - armorStand.getLocation().getYaw();
/*  66 */       Material material = armorStand.getHelmet().getType();
/*  67 */       if (material.toString().endsWith("_TERRACOTTA") || armorStand.getItemInHand().getType() != Material.AIR) {
/*  68 */         if (material == Material.LIME_TERRACOTTA || material == Material.YELLOW_TERRACOTTA) {
/*  69 */           f -= 90.0F;
/*     */         } else {
/*  71 */           f += 90.0F;
/*     */         } 
/*     */       }
/*  74 */       if (armorStand.getHelmet().getType() == Material.BROWN_CARPET) {
/*  75 */         f -= 90.0F;
/*     */       }
/*  77 */       Vector vector = getPositionVector(armorStand, armorStand1);
/*  78 */       double d = getMultiple(armorStand, armorStand1);
/*  79 */       armorStand.setCustomName("HBikePart;" + armorStand1.getUniqueId() + ";" + d + ";" + vectortoString(vector) + ";" + f);
/*  80 */       if (material.toString().endsWith("_TERRACOTTA")) {
/*  81 */         if (material == Material.ORANGE_TERRACOTTA) {
/*  82 */           armorStand.setHelmet(hoverBikeType.getMaterial1());
/*  83 */         } else if (material == Material.MAGENTA_TERRACOTTA) {
/*  84 */           armorStand.setHelmet(hoverBikeType.getMaterial2());
/*  85 */         } else if (material == Material.LIGHT_BLUE_TERRACOTTA) {
/*  86 */           armorStand.setHelmet(hoverBikeType.getMaterial3());
/*  87 */         } else if (material == Material.YELLOW_TERRACOTTA) {
/*  88 */           armorStand.setHelmet(hoverBikeType.getMaterial4());
/*  89 */         } else if (material == Material.LIME_TERRACOTTA) {
/*  90 */           armorStand.setHelmet(hoverBikeType.getMaterial5());
/*  91 */         } else if (material == Material.PINK_TERRACOTTA) {
/*  92 */           armorStand.setHelmet(hoverBikeType.getMaterial6());
/*  93 */         } else if (material == Material.GRAY_TERRACOTTA) {
/*  94 */           armorStand.setHelmet(hoverBikeType.getMaterial7());
/*     */         } 
/*     */       }
/*  97 */       if (armorStand.getHelmet().getType() == Material.BROWN_CARPET) {
/*  98 */         armorStand.setHelmet(hoverBikeType.getCarpetMaterial());
/*     */       }
/* 100 */       if (armorStand.getItemInHand().getType() == Material.WOODEN_SHOVEL) {
/* 101 */         armorStand.setItemInHand(hoverBikeType.getSpadeMaterial());
/*     */       }
/* 103 */       if (armorStand.getItemInHand().getType() == Material.STONE_HOE) {
/* 104 */         armorStand.setItemInHand(hoverBikeType.getHoeMaterial());
/*     */       }
/*     */     } 
/* 107 */     armorStand1.setCustomName(str2);
/* 108 */     EntityUtils.removeSlots(armorStand1);
/* 109 */     EntityUtils.removeSlots(armorStand2);
/* 110 */     EntityUtils.removeSlots(armorStand3);
/* 111 */     EntityUtils.saveUUIDData(armorStand1);
/* 112 */     EntityUtils.saveUUIDData(armorStand2);
/* 113 */     EntityUtils.saveUUIDData(armorStand3);
/* 114 */     ArrayList<ArmorStand> arrayList1 = new ArrayList();
/* 115 */     for (ArmorStand armorStand : arrayList) {
/* 116 */       arrayList1.add(armorStand);
/*     */     }
/* 118 */     arrayList1.add(armorStand1);
/* 119 */     arrayList1.add(armorStand2);
/* 120 */     arrayList1.add(armorStand3);
/* 121 */     VehicleSpawnedEvent vehicleSpawnedEvent = new VehicleSpawnedEvent(paramString1, paramLocation, arrayList1, hoverBikeType.getName(), VehicleType.HOVER_BIKE);
/* 122 */     EntityUtils.setYaw((Entity)armorStand1, 0.0F);
/* 123 */     EntityUtils.setYaw((Entity)armorStand3, 180.0F);
/* 124 */     EntityUtils.setYaw((Entity)armorStand2, 180.0F);
/* 125 */     Bukkit.getPluginManager().callEvent((Event)vehicleSpawnedEvent);
/* 126 */     return armorStand1;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack) {
/* 129 */     int i = paramPlayer.getInventory().firstEmpty();
/* 130 */     ItemStack itemStack = getItem(paramString, paramArrayOfItemStack);
/* 131 */     if (i != -1) {
/* 132 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 134 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack) {
/* 138 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 139 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 140 */     boolean bool = false;
/* 141 */     VehicleSubType vehicleSubType = null;
/* 142 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.HOVER_BIKE)) {
/* 143 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 144 */         bool = true;
/* 145 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 149 */     if (bool) {
/* 150 */       HoverBikeType hoverBikeType = (HoverBikeType)vehicleSubType;
/* 151 */       String str = hoverBikeType.getDisplayName();
/* 152 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 153 */       itemMeta.setDisplayName(str);
/* 154 */       ArrayList<String> arrayList = new ArrayList();
/* 155 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", hoverBikeType.getDisplayName()));
/* 156 */       itemMeta.setLore(arrayList);
/* 157 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 158 */       itemStack.setItemMeta(itemMeta);
/* 159 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 161 */     return itemStack;
/*     */   }
/*     */   public void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 164 */     int i = paramPlayer.getInventory().firstEmpty();
/* 165 */     ItemStack itemStack = getItem(paramString, paramDouble1, paramDouble2, paramArrayOfItemStack);
/* 166 */     if (i != -1) {
/* 167 */       paramPlayer.getInventory().setItem(i, itemStack);
/*     */     } else {
/* 169 */       paramPlayer.getWorld().dropItem(paramPlayer.getLocation(), itemStack);
/*     */     } 
/*     */   }
/*     */   public ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack) {
/* 173 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/* 174 */     if (paramDouble1 < 0.01D) {
/* 175 */       paramDouble1 = 0.01D;
/*     */     }
/* 177 */     ItemStack itemStack = new ItemStack(Material.CHEST);
/* 178 */     boolean bool = false;
/* 179 */     VehicleSubType vehicleSubType = null;
/* 180 */     for (VehicleSubType vehicleSubType1 : vehiclesMain.vehicleSubTypesMap.get(VehicleType.HOVER_BIKE)) {
/* 181 */       if (vehicleSubType1.getName().equals(paramString)) {
/* 182 */         bool = true;
/* 183 */         vehicleSubType = vehicleSubType1;
/*     */         break;
/*     */       } 
/*     */     } 
/* 187 */     if (bool) {
/* 188 */       String str = vehicleSubType.getDisplayName();
/* 189 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 190 */       itemMeta.setDisplayName(str);
/* 191 */       ArrayList<String> arrayList = new ArrayList();
/* 192 */       arrayList.add(vehiclesMain.getLang().getValue("package-description").replace("<type>", vehicleSubType.getDisplayName()));
/* 193 */       arrayList.add("");
/* 194 */       if (vehiclesMain.vehicleHealthEnabled) {
/* 195 */         arrayList.add(vehiclesMain.getLang().getValue("package-health-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble1) + "/" + vehicleSubType.getMaxHealth());
/*     */       }
/* 197 */       if (vehiclesMain.fuelEnabled) {
/* 198 */         arrayList.add(vehiclesMain.getLang().getValue("package-fuel-prefix") + NumberUtils.getInstance().getLastDigitsDouble(paramDouble2) + "/" + vehicleSubType.getFuelCapacity());
/*     */       }
/* 200 */       itemMeta.setLore(arrayList);
/* 201 */       ItemUtils.addUUIDToItemMeta(itemMeta);
/* 202 */       itemStack.setItemMeta(itemMeta);
/* 203 */       StorageUtils.saveInventoryToItem(paramArrayOfItemStack, itemStack);
/*     */     } 
/* 205 */     return itemStack;
/*     */   }
/*     */   private double getMultiple(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 208 */     Vector vector = getDirection(90.0F, paramArmorStand2.getLocation().getPitch());
/* 209 */     double d = -getPositionVector(paramArmorStand1, paramArmorStand2).clone().divide(vector.clone()).getX();
/* 210 */     String str = NumberUtils.getInstance().firstChars(d);
/* 211 */     return Double.parseDouble(str);
/*     */   }
/*     */   
/*     */   private Vector getDirection(float paramFloat1, float paramFloat2) {
/* 215 */     Vector vector = new Vector();
/* 216 */     double d1 = paramFloat1;
/* 217 */     double d2 = paramFloat2;
/* 218 */     vector.setY(-Math.sin(Math.toRadians(d2)));
/* 219 */     double d3 = Math.cos(Math.toRadians(d2));
/* 220 */     vector.setX(-d3 * Math.sin(Math.toRadians(d1)));
/* 221 */     vector.setZ(d3 * Math.cos(Math.toRadians(d1)));
/* 222 */     return vector;
/*     */   }
/*     */   private Vector getPositionVector(ArmorStand paramArmorStand1, ArmorStand paramArmorStand2) {
/* 225 */     Location location1 = paramArmorStand2.getLocation();
/* 226 */     Location location2 = paramArmorStand1.getLocation();
/* 227 */     double d1 = -(location1.getX() - location2.getX());
/* 228 */     double d2 = location1.getY() - location2.getY();
/* 229 */     double d3 = location1.getZ() - location2.getZ();
/* 230 */     Material material1 = paramArmorStand1.getItemInHand().getType();
/* 231 */     if (material1.toString().endsWith("_TERRACOTTA")) {
/* 232 */       if (!EntityUtils.newHandRender) {
/* 233 */         d1 -= 0.54D;
/*     */       } else {
/* 235 */         d1 += 0.2D;
/*     */       } 
/*     */     }
/* 238 */     if (material1.toString().endsWith("_WOOL") && EntityUtils.newHandRender) {
/* 239 */       d1 += 0.065D;
/* 240 */       d3 += 0.04D;
/*     */     } 
/* 242 */     Material material2 = paramArmorStand1.getHelmet().getType();
/* 243 */     if (material2 == Material.SPRUCE_FENCE_GATE && EntityUtils.newHandRender) {
/* 244 */       d1 -= 0.33D;
/*     */     }
/* 246 */     return new Vector(d1, d2, d3);
/*     */   }
/*     */   private String vectortoString(Vector paramVector) {
/* 249 */     return NumberUtils.getInstance().firstChars(paramVector.getX()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getY()) + "/" + NumberUtils.getInstance().firstChars(paramVector.getZ());
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\vehiclemanagers\HoverBikeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */