package es.pollitoyeye.vehicles.interfaces;

import org.bukkit.inventory.ItemStack;

public interface VehicleSubType {
  String getName();
  
  String getDisplayName();
  
  String getPermission();
  
  double getMaxHealth();
  
  int getFuelCapacity();
  
  double getFuelWasteSpeed();
  
  ItemStack getModelItem();
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\interfaces\VehicleSubType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */