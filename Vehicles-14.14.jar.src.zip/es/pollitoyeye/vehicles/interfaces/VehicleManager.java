package es.pollitoyeye.vehicles.interfaces;

import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface VehicleManager {
  ArmorStand spawn(Location paramLocation, String paramString1, String paramString2);
  
  void giveItem(Player paramPlayer, String paramString, ItemStack[] paramArrayOfItemStack);
  
  ItemStack getItem(String paramString, ItemStack[] paramArrayOfItemStack);
  
  void giveItem(Player paramPlayer, String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack);
  
  ItemStack getItem(String paramString, double paramDouble1, double paramDouble2, ItemStack[] paramArrayOfItemStack);
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\interfaces\VehicleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */