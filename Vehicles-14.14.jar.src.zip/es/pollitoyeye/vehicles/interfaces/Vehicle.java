package es.pollitoyeye.vehicles.interfaces;

import es.pollitoyeye.vehicles.enums.VehicleType;
import java.util.List;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;

public interface Vehicle {
  void dismounted();
  
  void remove();
  
  void damage(double paramDouble);
  
  void setHealth(double paramDouble);
  
  ArmorStand getMainStand();
  
  VehicleType getType();
  
  void onDriverRightClick();
  
  void setFuel(double paramDouble);
  
  double getFuel();
  
  List<Player> getRidingPlayers();
  
  long getInteractBlockingTime();
  
  void onDriverLeftClick();
}


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\interfaces\Vehicle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */