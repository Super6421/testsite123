/*    */ package es.pollitoyeye.vehicles.utils;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.ArmorStand;
/*    */ 
/*    */ 
/*    */ public class MaterialUtils
/*    */ {
/*    */   public static boolean canGoUp(ArmorStand paramArmorStand, Block paramBlock, Location paramLocation) {
/* 12 */     if (!paramArmorStand.isOnGround()) {
/* 13 */       return false;
/*    */     }
/* 15 */     double d = Math.abs(paramLocation.getY() - Double.valueOf(paramLocation.getY()).intValue());
/* 16 */     if ((paramBlock.getType() == Material.SNOW || paramBlock.getType().toString().endsWith("_CARPET")) && d == 0.0D) {
/* 17 */       return true;
/*    */     }
/* 19 */     if (paramBlock.getState() instanceof org.bukkit.block.data.Ageable) {
/* 20 */       return false;
/*    */     }
/* 22 */     if (!paramBlock.getType().isSolid()) {
/* 23 */       return false;
/*    */     }
/* 25 */     boolean bool1 = (d >= 0.25D) ? true : false;
/* 26 */     if (bool1 && paramBlock.getType().toString().endsWith("_SLAB") && paramBlock.getBoundingBox().getHeight() < 1.0D && paramBlock.getBoundingBox().getMinY() - paramBlock.getY() == 0.0D) {
/* 27 */       return false;
/*    */     }
/* 29 */     Material material = paramBlock.getLocation().add(0.0D, 1.0D, 0.0D).getBlock().getType();
/* 30 */     if (material.isSolid() && (!bool1 || material.isOccluding())) {
/* 31 */       return false;
/*    */     }
/* 33 */     boolean bool2 = (d == 0.9375D) ? true : false;
/* 34 */     if (bool2 && (paramBlock.getType().toString().equals("GRASS_PATH") || paramBlock.getType().toString().equals("DIRT_PATH") || paramBlock.getType() == Material.FARMLAND)) {
/* 35 */       return false;
/*    */     }
/* 37 */     boolean bool3 = (d == 0.875D) ? true : false;
/* 38 */     if (bool3 && paramBlock.getType() == Material.SOUL_SAND) {
/* 39 */       return false;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 46 */     if (canBeClimbed(paramBlock.getType()) || !paramBlock.getType().isOccluding() || bool1) {
/* 47 */       return true;
/*    */     }
/* 49 */     return false;
/*    */   }
/*    */   
/*    */   public static boolean canBeClimbed(Material paramMaterial) {
/* 53 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\MaterialUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */