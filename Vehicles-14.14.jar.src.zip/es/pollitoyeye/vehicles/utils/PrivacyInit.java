/*    */ package es.pollitoyeye.vehicles.utils;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrivacyInit
/*    */ {
/*    */   public static void run(Object paramObject) throws Exception {
/* 13 */     ClassLoader classLoader = paramObject.getClass().getClassLoader();
/* 14 */     Class<?> clazz1 = Class.forName("es.pollitoyeye.vehicles.VehiclesMain", true, classLoader);
/* 15 */     Class<?> clazz2 = Class.forName("es.pollitoyeye.vehicles.listeners.EventListener", true, classLoader);
/* 16 */     Class<?> clazz3 = Class.forName("es.pollitoyeye.vehicles.beans.Language", true, classLoader);
/*    */     
/*    */     try {
/* 19 */       Field field = clazz1.getDeclaredField("pl");
/* 20 */       field.setAccessible(true);
/* 21 */       field.set(null, paramObject);
/* 22 */       field.setAccessible(false);
/* 23 */     } catch (Exception exception) {}
/*    */ 
/*    */     
/* 26 */     Field field1 = clazz1.getDeclaredField("standPrefix");
/* 27 */     field1.setAccessible(true);
/* 28 */     field1.set(null, ".");
/* 29 */     field1.setAccessible(false);
/*    */     
/* 31 */     Object object = clazz3.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 32 */     Field field2 = clazz1.getDeclaredField("lang");
/* 33 */     field2.setAccessible(true);
/* 34 */     field2.set(null, object);
/* 35 */     field2.setAccessible(false);
/* 36 */     clazz3.getMethod("load", new Class[0]).invoke(object, new Object[0]);
/*    */     
/* 38 */     Field field3 = clazz2.getDeclaredField("vehiclePartsNames");
/* 39 */     field3.setAccessible(true);
/* 40 */     String[] arrayOfString = (String[])field3.get(null);
/* 41 */     ArrayList<String> arrayList = new ArrayList();
/* 42 */     for (String str1 : arrayOfString) {
/* 43 */       arrayList.add(str1.startsWith(";") ? str1.substring(1) : str1);
/*    */     }
/* 45 */     field3.set(null, arrayList.toArray(new String[0]));
/* 46 */     field3.setAccessible(false);
/*    */     
/* 48 */     String[][] arrayOfString1 = { { "CarManager", "180" }, { "ParachuteManager", "450" }, { "PlaneManager", "450" }, { "RaftManager", "180" }, { "BikeManager", "0.0" }, { "HelicopterManager", "180" }, { "SubmarineManager", "180" }, { "TankManager", "180" }, { "TrainManager", "180" }, { "BroomManager", "-180" }, { "HoverBikeManager", "270" }, { "DrillManager", "450" }, { "RacingCarManager", "180" }, { "SportBikeManager", "180" }, { "TractorManager", "450" }, { "MechaManager", "270" } };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 67 */     String str = "es.pollitoyeye.vehicles.vehiclemanagers.";
/* 68 */     for (String[] arrayOfString2 : arrayOfString1) {
/* 69 */       Class<?> clazz = Class.forName(str + str, true, classLoader);
/* 70 */       Field field = clazz.getDeclaredField("j");
/* 71 */       field.setAccessible(true);
/* 72 */       field.set(null, Float.valueOf(Float.parseFloat(arrayOfString2[1])));
/* 73 */       field.setAccessible(false);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\PrivacyInit.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */