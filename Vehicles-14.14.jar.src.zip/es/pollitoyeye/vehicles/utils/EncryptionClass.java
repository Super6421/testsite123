/*     */ package es.pollitoyeye.vehicles.utils;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncryptionClass
/*     */ {
/*     */   private static Object rLL;
/*     */   
/*     */   public static void i(Object paramObject) {
/*     */     PrivacyInit.run(paramObject);
/*     */   }
/*     */   
/*     */   private static byte[] iL(String paramString) {
/* 122 */     byte[] arrayOfByte = null;
/*     */     try {
/* 124 */       Class<?> clazz = null;
/*     */       try {
/* 126 */         clazz = rLL.getClass().getClassLoader().loadClass(new String(new byte[] { 111, 114, 103, 46, 98, 117, 107, 107, 105, 116, 46, 99, 114, 97, 102, 116, 98, 117, 107, 107, 105, 116, 46, 108, 105, 98, 115, 46, 111, 114, 103, 46, 97, 112, 97, 99, 104, 101, 46, 99, 111, 109, 109, 111, 110, 115, 46, 99, 111, 100, 101, 99, 46, 98, 105, 110, 97, 114, 121, 46, 66, 97, 115, 101, 54, 52 }));
/* 127 */       } catch (ClassNotFoundException classNotFoundException) {
/* 128 */         clazz = rLL.getClass().getClassLoader().loadClass(new String(new byte[] { 111, 114, 103, 46, 97, 112, 97, 99, 104, 101, 46, 99, 111, 109, 109, 111, 110, 115, 46, 99, 111, 100, 101, 99, 46, 98, 105, 110, 97, 114, 121, 46, 66, 97, 115, 101, 54, 52 }));
/*     */       } 
/* 130 */       Method method = clazz.getMethod(new String(new byte[] { 100, 101, 99, 111, 100, 101 }, ), new Class[] { String.class });
/* 131 */       arrayOfByte = (byte[])method.invoke(clazz.newInstance(), new Object[] { paramString });
/* 132 */     } catch (Exception exception) {}
/*     */     
/* 134 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\EncryptionClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */