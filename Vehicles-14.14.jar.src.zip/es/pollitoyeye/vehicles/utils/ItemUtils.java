/*    */ package es.pollitoyeye.vehicles.utils;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import java.util.UUID;
/*    */ import org.bukkit.NamespacedKey;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.persistence.PersistentDataContainer;
/*    */ import org.bukkit.persistence.PersistentDataType;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class ItemUtils
/*    */ {
/*    */   public static void addUUIDToItemMeta(ItemMeta paramItemMeta) {
/* 14 */     NamespacedKey namespacedKey = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "UUID");
/* 15 */     PersistentDataContainer persistentDataContainer = paramItemMeta.getPersistentDataContainer();
/* 16 */     persistentDataContainer.set(namespacedKey, PersistentDataType.STRING, UUID.randomUUID().toString());
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\ItemUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */