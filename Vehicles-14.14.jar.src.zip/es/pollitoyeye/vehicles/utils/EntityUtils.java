/*      */ package es.pollitoyeye.vehicles.utils;
/*      */ 
/*      */ import es.pollitoyeye.vehicles.VehiclesMain;
/*      */ import es.pollitoyeye.vehicles.beans.BoundingBoxData;
/*      */ import es.pollitoyeye.vehicles.beans.VehiclePassengerList;
/*      */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*      */ import es.pollitoyeye.vehicles.listeners.EventListener;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import org.bukkit.Bukkit;
/*      */ import org.bukkit.ChatColor;
/*      */ import org.bukkit.Chunk;
/*      */ import org.bukkit.Color;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.NamespacedKey;
/*      */ import org.bukkit.Particle;
/*      */ import org.bukkit.Server;
/*      */ import org.bukkit.World;
/*      */ import org.bukkit.block.Block;
/*      */ import org.bukkit.block.BlockState;
/*      */ import org.bukkit.entity.ArmorStand;
/*      */ import org.bukkit.entity.Entity;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.Event;
/*      */ import org.bukkit.event.block.BlockPlaceEvent;
/*      */ import org.bukkit.inventory.EquipmentSlot;
/*      */ import org.bukkit.inventory.ItemStack;
/*      */ import org.bukkit.inventory.meta.ItemMeta;
/*      */ import org.bukkit.metadata.FixedMetadataValue;
/*      */ import org.bukkit.metadata.MetadataValue;
/*      */ import org.bukkit.persistence.PersistentDataContainer;
/*      */ import org.bukkit.persistence.PersistentDataType;
/*      */ import org.bukkit.plugin.Plugin;
/*      */ 
/*      */ 
/*      */ public class EntityUtils
/*      */ {
/*      */   private static String path;
/*      */   private static String version;
/*      */   private static String bukkitVersion;
/*      */   private static Class<?> EntityLivingClass;
/*      */   private static Class<?> CraftPlayerClass;
/*      */   private static Class<?> CraftEntityClass;
/*      */   private static Class<?> CreeperClass;
/*      */   private static Class<?> ArmorStandClass;
/*      */   private static Class<?> BukkitArmorStandClass;
/*      */   private static Class<?> EntityTypesClass;
/*      */   private static Class<?> EnumItemSlotClass;
/*      */   private static Method getHandlePlayer;
/*      */   private static Method getHandleEntity;
/*      */   private static Field azField;
/*      */   private static Field baField;
/*      */   private static Field jumpField;
/*      */   private static Method getInputMethod;
/*      */   private static Method isForwardMethod;
/*      */   private static Method isBackwardMethod;
/*      */   private static Method isJumpMethod;
/*      */   private static Method isLeftMethod;
/*      */   private static Method isRightMethod;
/*      */   private static boolean newPlayerInput = false;
/*      */   private static Field entityYawField;
/*      */   public static Class<?> MinecraftEntityClass;
/*      */   public static Class<?> DataWatcherClass;
/*      */   private static Class<?> compoundClass;
/*      */   private static boolean newValueOutputCompound = false;
/*      */   private static Object addingOrChangingLockType;
/*      */   private static Object removingOrChangingLockType;
/*      */   private static Method addEquipmentLockMethod;
/*      */   private static Constructor<?> compoundConstructor;
/*      */   private static Method c;
/*      */   private static Method f;
/*      */   private static Method setInt;
/*      */   private static Field noClip;
/*      */   private static Method setLocationMethod;
/*      */   private static Method setCanTickMethod;
/*      */   private static Method getBukkitEntityPlayer;
/*      */   private static Field vehicleField;
/*      */   private static Field passengersField;
/*      */   private static Constructor<?> packetPlayOutCameraConstructor;
/*      */   private static Field playerConnectionField;
/*      */   private static Method sendPacketMethod;
/*      */   private static Constructor<?> packetPlayOutEntityDestroyConstructor;
/*      */   private static boolean newMetadataPacketConstructor;
/*      */   private static Constructor<?> packetPlayOutEntityMetadataConstructor;
/*      */   private static Constructor<?> packetPlayOutEntityEquipmentConstructor;
/*      */   private static Method getIdMethod;
/*      */   private static Method getDataWatcherMethod;
/*      */   private static Method dataWatcherGetListMethod;
/*      */   private static Constructor<?> packetPlayOutEntityTeleportConstructor;
/*      */   private static Class<?> positionMoveRotation;
/*      */   private static Constructor<?> positionMoveRotationConstructor;
/*      */   private static Class<?> vec3;
/*      */   private static Constructor<?> vec3Constructor;
/*      */   private static Class<?> relative;
/*      */   private static boolean newPacketPlayOutEntityTeleport;
/*      */   private static Field packetPlayOutEntityTeleportAField;
/*      */   private static Field packetPlayOutEntityTeleportBField;
/*      */   private static Field packetPlayOutEntityTeleportCField;
/*      */   private static Field packetPlayOutEntityTeleportDField;
/*      */   private static Field packetPlayOutEntityTeleportEField;
/*      */   private static Field packetPlayOutEntityTeleportFField;
/*      */   private static Field packetPlayOutEntityTeleportGField;
/*      */   private static Constructor<?> packetPlayOutEntityHeadRotationConstructor;
/*      */   private static Constructor<?> packetPlayOutSpawnEntityLivingConstructor;
/*      */   private static Method entityGetBlockPositionMethod;
/*      */   private static boolean newPacketPlayOutSpawnEntityLivingConstructor = false;
/*      */   private static Class<?> blockPosition;
/*      */   private static Class<?> nmsWorld;
/*      */   private static Class<?> craftWorld;
/*      */   private static Method getHandleWorld;
/*      */   private static Constructor<?> creeperConstructor;
/*      */   private static Constructor<?> armorStandConstructor;
/*      */   private static Method setInvisibleMethod;
/*      */   private static Method setSmallMethod;
/*      */   private static Method setArmsMethod;
/*      */   private static Method getArmorStandPoseMethod;
/*      */   private static Method setArmorStandPoseMethod;
/*      */   private static Method armorStandGetEquipmentMethod;
/*      */   private static Field boundingBox;
/*      */   private static Field sizeField;
/*      */   private static Class<?> axisAlignedBB;
/*      */   private static Constructor<?> axisAlignedBBConstructor;
/*      */   private static Object creeperEntityTypesValue;
/*      */   private static Object armorStandEntityTypesValue;
/*      */   private static Class<?> EnumHandClass;
/*      */   private static Class<?> CraftEventFactoryClass;
/*      */   private static Class<?> WorldServerClass;
/*      */   private static Class<?> EntityHumanClass;
/*      */   private static Constructor<?> entitySizeConstructor;
/*      */   private static Constructor<?> pairConstructor;
/*      */   private static Method pairGetFirstMethod;
/*      */   private static Method pairGetSecondMethod;
/*      */   private static Method itemStackAsNMSCopyMethod;
/*      */   private static Class<?> NMSItemStackClass;
/*      */   private static Method getDimensionManagerMethod;
/*      */   private static Class<?> DimensionManagerClass;
/*      */   private static Method getMinYField;
/*      */   private static Method getHeightField;
/*      */   public static boolean newHandRender = false;
/*      */   public static boolean obfuscated = true;
/*  146 */   private static double seatOffset = 0.0D;
/*      */   
/*      */   private static NamespacedKey modelGroupKey;
/*      */   public static int minecraftVersion;
/*      */   public static int minecraftSubVersion;
/*      */   private static Object enumHandMainValue;
/*      */   
/*      */   public static void initReflection(String[] paramArrayOfString) {
/*      */     try {
/*  155 */       modelGroupKey = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "MODEL_GROUP");
/*  156 */       path = Bukkit.getServer().getClass().getPackage().getName();
/*  157 */       bukkitVersion = Bukkit.getVersion();
/*  158 */       version = path.substring(path.lastIndexOf(paramArrayOfString[0]) + 1, path.length());
/*  159 */       boolean bool1 = false;
/*  160 */       if (version.equals("craftbukkit")) {
/*      */         
/*  162 */         String str = getMinecraftVersion(Bukkit.getServer());
/*  163 */         if (!str.startsWith("1.")) {
/*  164 */           obfuscated = false;
/*  165 */           bool1 = true;
/*  166 */           version = "v" + str.replace(".", "_");
/*  167 */         } else if (str.equals("1.20.5") || str.equals("1.20.6")) {
/*  168 */           version = "v1_20_R4";
/*  169 */         } else if (str.equals("1.21") || str.equals("1.21.1")) {
/*  170 */           version = "v1_21_R1";
/*  171 */         } else if (str.equals("1.21.3")) {
/*  172 */           version = "v1_21_R2";
/*  173 */         } else if (str.equals("1.21.4")) {
/*  174 */           version = "v1_21_R3";
/*  175 */         } else if (str.equals("1.21.5")) {
/*  176 */           version = "v1_21_R4";
/*  177 */         } else if (str.equals("1.21.6") || str.equals("1.21.7") || str.equals("1.21.8")) {
/*  178 */           version = "v1_21_R5";
/*  179 */         } else if (str.equals("1.21.9") || str.equals("1.21.10")) {
/*  180 */           version = "v1_21_R6";
/*  181 */         } else if (str.equals("1.21.11")) {
/*  182 */           version = "v1_21_R7";
/*      */         } 
/*      */       } 
/*      */       
/*  186 */       newHandRender = true;
/*      */       
/*  188 */       minecraftVersion = Integer.parseInt(version.split("_")[1]);
/*  189 */       minecraftSubVersion = 0;
/*  190 */       if ((version.split("_")).length > 2) {
/*  191 */         minecraftSubVersion = Integer.parseInt(version.split("_")[2].replace("R", ""));
/*      */       }
/*  193 */       if (minecraftVersion >= 17) {
/*  194 */         bool1 = true;
/*      */       }
/*  196 */       if (!obfuscated || minecraftVersion > 20 || (minecraftVersion == 20 && minecraftSubVersion > 1)) {
/*  197 */         seatOffset = -0.25D;
/*      */       }
/*  199 */       BukkitArmorStandClass = Class.forName("org.bukkit.entity.ArmorStand");
/*      */       
/*  201 */       EntityLivingClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.EntityLiving" : "net.minecraft.world.entity.LivingEntity") : ("net.minecraft.server." + version + ".EntityLiving"));
/*  202 */       CraftPlayerClass = Class.forName(obfuscated ? ("org.bukkit.craftbukkit." + version + ".entity.CraftPlayer") : "org.bukkit.craftbukkit.entity.CraftPlayer");
/*  203 */       getHandlePlayer = CraftPlayerClass.getMethod("getHandle", new Class[0]);
/*  204 */       CraftEntityClass = Class.forName(obfuscated ? ("org.bukkit.craftbukkit" + paramArrayOfString[0] + version + ".entity.CraftEntity") : "org.bukkit.craftbukkit.entity.CraftEntity");
/*  205 */       getHandleEntity = CraftEntityClass.getMethod("getHandle", new Class[0]);
/*  206 */       MinecraftEntityClass = Class.forName(bool1 ? "net.minecraft.world.entity.Entity" : ("net.minecraft.server." + version + ".Entity"));
/*  207 */       if (!obfuscated) {
/*  208 */         entityYawField = MinecraftEntityClass.getDeclaredField("yRot");
/*  209 */         entityYawField.setAccessible(true);
/*  210 */       } else if (minecraftVersion >= 21) {
/*  211 */         if (minecraftSubVersion >= 7) {
/*  212 */           entityYawField = MinecraftEntityClass.getDeclaredField("aZ");
/*  213 */         } else if (minecraftSubVersion >= 6) {
/*  214 */           entityYawField = MinecraftEntityClass.getDeclaredField("aZ");
/*  215 */         } else if (minecraftSubVersion >= 5) {
/*  216 */           entityYawField = MinecraftEntityClass.getDeclaredField("aY");
/*  217 */         } else if (minecraftSubVersion >= 4) {
/*  218 */           entityYawField = MinecraftEntityClass.getDeclaredField("aE");
/*  219 */         } else if (minecraftSubVersion >= 2) {
/*  220 */           entityYawField = MinecraftEntityClass.getDeclaredField("aA");
/*      */         } else {
/*  222 */           entityYawField = MinecraftEntityClass.getDeclaredField("aD");
/*      */         } 
/*  224 */         entityYawField.setAccessible(true);
/*  225 */       } else if (minecraftVersion >= 20) {
/*  226 */         if (minecraftSubVersion >= 4) {
/*  227 */           entityYawField = MinecraftEntityClass.getDeclaredField("aF");
/*      */         } else {
/*  229 */           entityYawField = MinecraftEntityClass.getDeclaredField("aG");
/*      */         } 
/*  231 */         entityYawField.setAccessible(true);
/*  232 */       } else if (minecraftVersion >= 19 && minecraftSubVersion >= 3) {
/*  233 */         entityYawField = MinecraftEntityClass.getDeclaredField("aE");
/*  234 */         entityYawField.setAccessible(true);
/*  235 */       } else if (minecraftVersion >= 18) {
/*  236 */         entityYawField = MinecraftEntityClass.getDeclaredField("aA");
/*  237 */         entityYawField.setAccessible(true);
/*      */       }
/*  239 */       else if (minecraftVersion >= 17) {
/*  240 */         entityYawField = MinecraftEntityClass.getDeclaredField("ay");
/*  241 */         entityYawField.setAccessible(true);
/*      */       } else {
/*  243 */         entityYawField = EntityLivingClass.getField("yaw");
/*      */       } 
/*  245 */       DataWatcherClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.syncher.DataWatcher" : "net.minecraft.network.syncher.SynchedEntityData") : ("net.minecraft.server." + version + ".DataWatcher"));
/*  246 */       compoundClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.nbt.NBTTagCompound" : "net.minecraft.nbt.CompoundTag") : ("net.minecraft.server." + version + ".NBTTagCompound"));
/*  247 */       compoundConstructor = compoundClass.getConstructor(new Class[0]);
/*  248 */       if (!obfuscated || (minecraftVersion == 21 && minecraftSubVersion >= 5) || minecraftVersion > 21)
/*      */       {
/*  250 */         newValueOutputCompound = true;
/*      */       }
/*  252 */       if (newValueOutputCompound) {
/*  253 */         Class<?> clazz = Class.forName("org.bukkit.entity.ArmorStand$LockType");
/*  254 */         Method method = clazz.getMethod("valueOf", new Class[] { String.class });
/*  255 */         addingOrChangingLockType = method.invoke(null, new Object[] { "ADDING_OR_CHANGING" });
/*  256 */         removingOrChangingLockType = method.invoke(null, new Object[] { "REMOVING_OR_CHANGING" });
/*  257 */         addEquipmentLockMethod = ArmorStand.class.getMethod("addEquipmentLock", new Class[] { EquipmentSlot.class, clazz });
/*  258 */       } else if (minecraftVersion >= 18) {
/*  259 */         c = MinecraftEntityClass.getMethod("f", new Class[] { compoundClass });
/*  260 */         f = MinecraftEntityClass.getMethod("g", new Class[] { compoundClass });
/*      */       }
/*  262 */       else if (minecraftVersion >= 17) {
/*  263 */         c = MinecraftEntityClass.getMethod("save", new Class[] { compoundClass });
/*  264 */         f = MinecraftEntityClass.getMethod("load", new Class[] { compoundClass });
/*      */       }
/*  266 */       else if (minecraftVersion == 16) {
/*  267 */         c = MinecraftEntityClass.getMethod("a_", new Class[] { compoundClass });
/*  268 */         f = MinecraftEntityClass.getMethod("load", new Class[] { compoundClass });
/*      */       } else {
/*  270 */         c = MinecraftEntityClass.getMethod("c", new Class[] { compoundClass });
/*  271 */         f = MinecraftEntityClass.getMethod("f", new Class[] { compoundClass });
/*      */       } 
/*      */       
/*  274 */       if (!obfuscated) {
/*  275 */         setInt = compoundClass.getMethod("putInt", new Class[] { String.class, int.class });
/*  276 */       } else if (minecraftVersion >= 18) {
/*  277 */         setInt = compoundClass.getMethod("a", new Class[] { String.class, int.class });
/*      */       } else {
/*  279 */         setInt = compoundClass.getMethod("setInt", new Class[] { String.class, int.class });
/*      */       } 
/*      */       try {
/*  282 */         noClip = MinecraftEntityClass.getField("noclip");
/*  283 */       } catch (NoSuchFieldException noSuchFieldException) {}
/*      */       
/*  285 */       if (!obfuscated) {
/*  286 */         setLocationMethod = MinecraftEntityClass.getMethod("snapTo", new Class[] { double.class, double.class, double.class, float.class, float.class });
/*      */       }
/*  288 */       else if (minecraftVersion >= 18) {
/*  289 */         setLocationMethod = MinecraftEntityClass.getMethod("a", new Class[] { double.class, double.class, double.class, float.class, float.class });
/*      */       } else {
/*      */         
/*  292 */         setLocationMethod = MinecraftEntityClass.getMethod("setLocation", new Class[] { double.class, double.class, double.class, float.class, float.class });
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  298 */       if (!obfuscated) {
/*  299 */         newPlayerInput = true;
/*  300 */       } else if (version.startsWith("v1_14")) {
/*  301 */         azField = EntityLivingClass.getField("bb");
/*  302 */         baField = EntityLivingClass.getField("bd");
/*  303 */       } else if (version.startsWith("v1_16_R3") || version.startsWith("v1_16_R2")) {
/*  304 */         azField = EntityLivingClass.getField("aR");
/*  305 */         baField = EntityLivingClass.getField("aT");
/*  306 */       } else if (version.startsWith("v1_16")) {
/*  307 */         azField = EntityLivingClass.getField("aY");
/*  308 */         baField = EntityLivingClass.getField("ba");
/*  309 */       } else if (version.startsWith("v1_15")) {
/*  310 */         azField = EntityLivingClass.getField("aZ");
/*  311 */         baField = EntityLivingClass.getField("bb");
/*  312 */       } else if (minecraftVersion >= 21) {
/*  313 */         if (minecraftSubVersion >= 2) {
/*  314 */           newPlayerInput = true;
/*  315 */         } else if (minecraftVersion == 21) {
/*  316 */           azField = EntityLivingClass.getField("bo");
/*  317 */           baField = EntityLivingClass.getField("bq");
/*      */         } 
/*  319 */       } else if (minecraftVersion >= 20) {
/*  320 */         if (minecraftSubVersion >= 4) {
/*  321 */           azField = EntityLivingClass.getField("bo");
/*  322 */           baField = EntityLivingClass.getField("bq");
/*  323 */         } else if (minecraftSubVersion > 1) {
/*  324 */           azField = EntityLivingClass.getField("bk");
/*  325 */           baField = EntityLivingClass.getField("bm");
/*      */         } else {
/*  327 */           azField = EntityLivingClass.getField("bl");
/*  328 */           baField = EntityLivingClass.getField("bn");
/*      */         } 
/*  330 */       } else if (minecraftVersion >= 19) {
/*  331 */         if (minecraftSubVersion >= 3) {
/*  332 */           azField = EntityLivingClass.getField("bj");
/*  333 */           baField = EntityLivingClass.getField("bl");
/*      */         } else {
/*  335 */           azField = EntityLivingClass.getField("bo");
/*  336 */           baField = EntityLivingClass.getField("bq");
/*      */         } 
/*  338 */       } else if (minecraftVersion >= 18) {
/*  339 */         if (minecraftSubVersion >= 2) {
/*  340 */           azField = EntityLivingClass.getField("bo");
/*  341 */           baField = EntityLivingClass.getField("bq");
/*      */         } else {
/*  343 */           azField = EntityLivingClass.getField("bp");
/*  344 */           baField = EntityLivingClass.getField("br");
/*      */         } 
/*  346 */       } else if (minecraftVersion >= 17) {
/*  347 */         azField = EntityLivingClass.getField("bo");
/*  348 */         baField = EntityLivingClass.getField("bq");
/*      */       } 
/*      */ 
/*      */       
/*  352 */       if (!obfuscated) {
/*  353 */         jumpField = EntityLivingClass.getDeclaredField("jumping");
/*  354 */       } else if (minecraftVersion >= 21) {
/*  355 */         if (minecraftSubVersion >= 7) {
/*  356 */           jumpField = EntityLivingClass.getDeclaredField("by");
/*  357 */         } else if (minecraftSubVersion >= 6) {
/*  358 */           jumpField = EntityLivingClass.getDeclaredField("bx");
/*      */         } else {
/*  360 */           jumpField = EntityLivingClass.getDeclaredField("bn");
/*      */         } 
/*  362 */       } else if (minecraftVersion >= 20) {
/*  363 */         if (minecraftSubVersion >= 4) {
/*  364 */           jumpField = EntityLivingClass.getDeclaredField("bn");
/*  365 */         } else if (minecraftSubVersion > 1) {
/*  366 */           jumpField = EntityLivingClass.getDeclaredField("bj");
/*      */         } else {
/*  368 */           jumpField = EntityLivingClass.getDeclaredField("bk");
/*      */         } 
/*  370 */       } else if (minecraftVersion >= 19) {
/*  371 */         if (minecraftSubVersion >= 3) {
/*  372 */           jumpField = EntityLivingClass.getDeclaredField("bi");
/*      */         } else {
/*  374 */           jumpField = EntityLivingClass.getDeclaredField("bn");
/*      */         } 
/*  376 */       } else if (minecraftVersion >= 18) {
/*  377 */         if (minecraftSubVersion >= 2) {
/*  378 */           jumpField = EntityLivingClass.getDeclaredField("bn");
/*      */         } else {
/*  380 */           jumpField = EntityLivingClass.getDeclaredField("bo");
/*      */         } 
/*  382 */       } else if (minecraftVersion >= 17) {
/*  383 */         jumpField = EntityLivingClass.getDeclaredField("bn");
/*      */       } else {
/*  385 */         jumpField = EntityLivingClass.getDeclaredField("jumping");
/*      */       } 
/*  387 */       jumpField.setAccessible(true);
/*  388 */       if (newPlayerInput) {
/*  389 */         getInputMethod = Player.class.getMethod("getCurrentInput", new Class[0]);
/*  390 */         Class<?> clazz = Class.forName("org.bukkit.Input");
/*  391 */         isForwardMethod = clazz.getMethod("isForward", new Class[0]);
/*  392 */         isBackwardMethod = clazz.getMethod("isBackward", new Class[0]);
/*  393 */         isJumpMethod = clazz.getMethod("isJump", new Class[0]);
/*  394 */         isLeftMethod = clazz.getMethod("isLeft", new Class[0]);
/*  395 */         isRightMethod = clazz.getMethod("isRight", new Class[0]);
/*      */       } 
/*  397 */       Class<?> clazz1 = Class.forName(
/*  398 */           bool1 ? (obfuscated ? "net.minecraft.server.level.EntityPlayer" : "net.minecraft.server.level.ServerPlayer") : ("net.minecraft.server." + version + ".EntityPlayer"));
/*      */       
/*  400 */       getBukkitEntityPlayer = clazz1.getMethod("getBukkitEntity", new Class[0]);
/*      */ 
/*      */       
/*  403 */       if (!obfuscated) {
/*  404 */         vehicleField = MinecraftEntityClass.getDeclaredField("vehicle");
/*      */       }
/*  406 */       else if (minecraftVersion >= 18) {
/*  407 */         vehicleField = MinecraftEntityClass.getDeclaredField("av");
/*      */       }
/*  409 */       else if (minecraftVersion >= 17) {
/*  410 */         vehicleField = MinecraftEntityClass.getDeclaredField("au");
/*      */       } else {
/*  412 */         vehicleField = MinecraftEntityClass.getDeclaredField("vehicle");
/*      */       } 
/*      */       
/*  415 */       vehicleField.setAccessible(true);
/*      */       
/*  417 */       if (!obfuscated) {
/*  418 */         passengersField = MinecraftEntityClass.getDeclaredField("passengers");
/*  419 */       } else if (minecraftVersion >= 17) {
/*  420 */         passengersField = MinecraftEntityClass.getDeclaredField("au");
/*  421 */       } else if (minecraftVersion >= 17) {
/*  422 */         passengersField = MinecraftEntityClass.getDeclaredField("at");
/*      */       } else {
/*  424 */         passengersField = MinecraftEntityClass.getDeclaredField("passengers");
/*      */       } 
/*  426 */       passengersField.setAccessible(true);
/*      */ 
/*      */ 
/*      */       
/*  430 */       packetPlayOutCameraConstructor = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutCamera" : "net.minecraft.network.protocol.game.ClientboundSetCameraPacket") : ("net.minecraft.server." + version + ".PacketPlayOutCamera")).getConstructor(new Class[] { MinecraftEntityClass });
/*  431 */       if (!obfuscated) {
/*  432 */         playerConnectionField = clazz1.getField("connection");
/*  433 */       } else if (minecraftVersion == 21 && minecraftSubVersion >= 7) {
/*  434 */         playerConnectionField = clazz1.getField("g");
/*  435 */       } else if (minecraftVersion == 21 && minecraftSubVersion >= 5) {
/*  436 */         playerConnectionField = clazz1.getField("g");
/*  437 */       } else if (minecraftVersion == 21 && minecraftSubVersion >= 2) {
/*  438 */         playerConnectionField = clazz1.getField("f");
/*  439 */       } else if (minecraftVersion >= 20) {
/*  440 */         playerConnectionField = clazz1.getField("c");
/*  441 */       } else if (minecraftVersion >= 18) {
/*  442 */         playerConnectionField = clazz1.getField("b");
/*      */       }
/*  444 */       else if (minecraftVersion > 16) {
/*      */ 
/*      */         
/*  447 */         playerConnectionField = clazz1.getField("b");
/*      */       } else {
/*      */         
/*  450 */         playerConnectionField = clazz1.getField("playerConnection");
/*      */       } 
/*  452 */       Class<?> clazz2 = Class.forName(bool1 ? (obfuscated ? "net.minecraft.server.network.PlayerConnection" : "net.minecraft.server.network.ServerGamePacketListenerImpl") : ("net.minecraft.server." + version + ".PlayerConnection"));
/*  453 */       String str1 = "sendPacket";
/*  454 */       if (!obfuscated) {
/*  455 */         str1 = "send";
/*  456 */       } else if (minecraftVersion >= 21) {
/*  457 */         str1 = "b";
/*  458 */       } else if (minecraftVersion >= 20 && minecraftSubVersion > 1) {
/*  459 */         str1 = "b";
/*  460 */       } else if (minecraftVersion >= 18) {
/*  461 */         str1 = "a";
/*      */       } 
/*      */       
/*  464 */       sendPacketMethod = clazz2.getMethod(str1, new Class[] { Class.forName(bool1 ? "net.minecraft.network.protocol.Packet" : ("net.minecraft.server." + version + ".Packet")) });
/*      */ 
/*      */       
/*  467 */       (new Class[1])[0] = int.class; (new Class[1])[0] = int[].class; packetPlayOutEntityDestroyConstructor = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutEntityDestroy" : "net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket") : ("net.minecraft.server." + version + ".PacketPlayOutEntityDestroy")).getConstructor((minecraftVersion == 17 && bukkitVersion.contains("(MC: 1.17)")) ? new Class[1] : new Class[1]);
/*  468 */       newMetadataPacketConstructor = (!obfuscated || minecraftVersion > 19 || (minecraftVersion == 19 && minecraftSubVersion >= 2));
/*      */       
/*  470 */       String str2 = "getDataWatcher";
/*  471 */       String str3 = "";
/*  472 */       if (!obfuscated) {
/*  473 */         str2 = "getEntityData";
/*  474 */         str3 = "getNonDefaultValues";
/*  475 */       } else if (minecraftVersion >= 21) {
/*  476 */         if (minecraftSubVersion >= 7) {
/*  477 */           str2 = "aD";
/*  478 */         } else if (minecraftSubVersion >= 6) {
/*  479 */           str2 = "aC";
/*  480 */         } else if (minecraftSubVersion >= 5) {
/*  481 */           str2 = "au";
/*  482 */         } else if (minecraftSubVersion >= 4) {
/*  483 */           str2 = "ar";
/*  484 */         } else if (minecraftSubVersion >= 2) {
/*  485 */           str2 = "au";
/*      */         } else {
/*  487 */           str2 = "ar";
/*      */         } 
/*  489 */         str3 = "c";
/*  490 */       } else if (minecraftVersion >= 20) {
/*  491 */         if (minecraftSubVersion >= 4) {
/*  492 */           str2 = "ap";
/*  493 */         } else if (minecraftSubVersion > 2) {
/*  494 */           str2 = "an";
/*  495 */         } else if (minecraftSubVersion > 1) {
/*  496 */           str2 = "al";
/*      */         } else {
/*  498 */           str2 = "aj";
/*      */         } 
/*  500 */         str3 = "c";
/*  501 */       } else if (minecraftVersion == 19 && minecraftSubVersion >= 2) {
/*  502 */         if (minecraftSubVersion >= 3) {
/*  503 */           str2 = "aj";
/*      */         } else {
/*  505 */           str2 = "al";
/*      */         } 
/*      */         
/*  508 */         str3 = "c";
/*  509 */       } else if (minecraftVersion >= 18) {
/*  510 */         str2 = "ai";
/*      */       } 
/*  512 */       getDataWatcherMethod = MinecraftEntityClass.getMethod(str2, new Class[0]);
/*  513 */       if (newMetadataPacketConstructor) {
/*  514 */         dataWatcherGetListMethod = DataWatcherClass.getMethod(str3, new Class[0]);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  520 */       (new Class[2])[0] = int.class; (new Class[2])[1] = dataWatcherGetListMethod.getReturnType();
/*  521 */       (new Class[3])[0] = int.class; (new Class[3])[1] = DataWatcherClass; (new Class[3])[2] = boolean.class; packetPlayOutEntityMetadataConstructor = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutEntityMetadata" : "net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket") : ("net.minecraft.server." + version + ".PacketPlayOutEntityMetadata")).getConstructor(newMetadataPacketConstructor ? new Class[2] : new Class[3]);
/*  522 */       Class<?> clazz3 = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutEntityEquipment" : "net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket") : ("net.minecraft.server." + version + ".PacketPlayOutEntityEquipment"));
/*  523 */       EnumItemSlotClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.EnumItemSlot" : "net.minecraft.world.entity.EquipmentSlot") : ("net.minecraft.server." + version + ".EnumItemSlot"));
/*  524 */       if (!obfuscated || minecraftVersion >= 16) {
/*      */         
/*  526 */         packetPlayOutEntityEquipmentConstructor = clazz3.getConstructor(new Class[] { int.class, List.class });
/*      */       } else {
/*  528 */         NMSItemStackClass = Class.forName("net.minecraft.server." + version + ".ItemStack");
/*      */         
/*  530 */         packetPlayOutEntityEquipmentConstructor = clazz3.getConstructor(new Class[] { int.class, EnumItemSlotClass, NMSItemStackClass });
/*      */       } 
/*  532 */       Class<?> clazz4 = Class.forName("com.mojang.datafixers.util.Pair");
/*  533 */       pairConstructor = clazz4.getConstructor(new Class[] { Object.class, Object.class });
/*  534 */       pairGetFirstMethod = clazz4.getMethod("getFirst", new Class[0]);
/*  535 */       pairGetSecondMethod = clazz4.getMethod("getSecond", new Class[0]);
/*  536 */       String str4 = "getId";
/*  537 */       if (!obfuscated) {
/*  538 */         str4 = "getId";
/*  539 */       } else if (minecraftVersion >= 21) {
/*  540 */         if (minecraftSubVersion >= 7) {
/*  541 */           str4 = "aA";
/*  542 */         } else if (minecraftSubVersion >= 6) {
/*  543 */           str4 = "az";
/*  544 */         } else if (minecraftSubVersion >= 5) {
/*  545 */           str4 = "ar";
/*  546 */         } else if (minecraftSubVersion >= 4) {
/*  547 */           str4 = "ao";
/*  548 */         } else if (minecraftSubVersion >= 2) {
/*  549 */           str4 = "ar";
/*      */         } else {
/*  551 */           str4 = "an";
/*      */         } 
/*  553 */       } else if (minecraftVersion >= 20) {
/*  554 */         if (minecraftSubVersion >= 4) {
/*  555 */           str4 = "al";
/*  556 */         } else if (minecraftSubVersion > 2) {
/*  557 */           str4 = "aj";
/*  558 */         } else if (minecraftSubVersion > 1) {
/*  559 */           str4 = "ah";
/*      */         } else {
/*  561 */           str4 = "af";
/*      */         } 
/*  563 */       } else if (minecraftVersion == 19 && minecraftSubVersion >= 2) {
/*  564 */         if (minecraftSubVersion >= 3) {
/*  565 */           str4 = "af";
/*      */         } else {
/*  567 */           str4 = "ah";
/*      */         }
/*      */       
/*  570 */       } else if (minecraftVersion >= 18) {
/*  571 */         str4 = "ae";
/*      */       } 
/*  573 */       getIdMethod = MinecraftEntityClass.getMethod(str4, new Class[0]);
/*      */       
/*  575 */       Class<?> clazz5 = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutEntityTeleport" : "net.minecraft.network.protocol.game.ClientboundTeleportEntityPacket") : ("net.minecraft.server." + version + ".PacketPlayOutEntityTeleport"));
/*  576 */       if (!obfuscated || minecraftVersion > 21 || (minecraftVersion == 21 && minecraftSubVersion >= 2)) {
/*      */         
/*  578 */         newPacketPlayOutEntityTeleport = true;
/*  579 */         positionMoveRotation = Class.forName("net.minecraft.world.entity.PositionMoveRotation");
/*  580 */         vec3 = Class.forName(obfuscated ? "net.minecraft.world.phys.Vec3D" : "net.minecraft.world.phys.Vec3");
/*  581 */         vec3Constructor = vec3.getConstructor(new Class[] { double.class, double.class, double.class });
/*  582 */         positionMoveRotationConstructor = positionMoveRotation.getConstructor(new Class[] { vec3, vec3, float.class, float.class });
/*  583 */         relative = Class.forName("net.minecraft.world.entity.Relative");
/*      */ 
/*      */         
/*  586 */         packetPlayOutEntityTeleportConstructor = clazz5.getConstructors()[0];
/*      */       } else {
/*  588 */         newPacketPlayOutEntityTeleport = false;
/*  589 */         packetPlayOutEntityTeleportConstructor = clazz5.getConstructor(new Class[] { MinecraftEntityClass });
/*  590 */         if (minecraftVersion < 20 || (minecraftVersion == 20 && minecraftSubVersion < 4)) {
/*  591 */           packetPlayOutEntityTeleportAField = clazz5.getDeclaredField("a");
/*  592 */           packetPlayOutEntityTeleportBField = clazz5.getDeclaredField("b");
/*  593 */           packetPlayOutEntityTeleportCField = clazz5.getDeclaredField("c");
/*  594 */           packetPlayOutEntityTeleportDField = clazz5.getDeclaredField("d");
/*  595 */           packetPlayOutEntityTeleportEField = clazz5.getDeclaredField("e");
/*  596 */           packetPlayOutEntityTeleportFField = clazz5.getDeclaredField("f");
/*  597 */           packetPlayOutEntityTeleportGField = clazz5.getDeclaredField("g");
/*      */         } else {
/*  599 */           packetPlayOutEntityTeleportAField = clazz5.getDeclaredField("b");
/*  600 */           packetPlayOutEntityTeleportBField = clazz5.getDeclaredField("c");
/*  601 */           packetPlayOutEntityTeleportCField = clazz5.getDeclaredField("d");
/*  602 */           packetPlayOutEntityTeleportDField = clazz5.getDeclaredField("e");
/*  603 */           packetPlayOutEntityTeleportEField = clazz5.getDeclaredField("f");
/*  604 */           packetPlayOutEntityTeleportFField = clazz5.getDeclaredField("g");
/*  605 */           packetPlayOutEntityTeleportGField = clazz5.getDeclaredField("h");
/*      */         } 
/*  607 */         packetPlayOutEntityTeleportGField.setAccessible(true);
/*  608 */         packetPlayOutEntityTeleportFField.setAccessible(true);
/*  609 */         packetPlayOutEntityTeleportEField.setAccessible(true);
/*  610 */         packetPlayOutEntityTeleportDField.setAccessible(true);
/*  611 */         packetPlayOutEntityTeleportCField.setAccessible(true);
/*  612 */         packetPlayOutEntityTeleportBField.setAccessible(true);
/*  613 */         packetPlayOutEntityTeleportAField.setAccessible(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  618 */       packetPlayOutEntityHeadRotationConstructor = Class.forName(bool1 ? (obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutEntityHeadRotation" : "net.minecraft.network.protocol.game.ClientboundRotateHeadPacket") : ("net.minecraft.server." + version + ".PacketPlayOutEntityHeadRotation")).getConstructor(new Class[] { MinecraftEntityClass, byte.class });
/*  619 */       if (!obfuscated || minecraftVersion >= 21) {
/*  620 */         newPacketPlayOutSpawnEntityLivingConstructor = true;
/*  621 */         blockPosition = Class.forName(obfuscated ? "net.minecraft.core.BlockPosition" : "net.minecraft.core.BlockPos");
/*  622 */         if (!obfuscated) {
/*  623 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("blockPosition", new Class[0]);
/*  624 */         } else if (minecraftSubVersion >= 7) {
/*  625 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("dK", new Class[0]);
/*  626 */         } else if (minecraftSubVersion >= 6) {
/*  627 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("dF", new Class[0]);
/*  628 */         } else if (minecraftSubVersion >= 5) {
/*  629 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("dx", new Class[0]);
/*  630 */         } else if (minecraftSubVersion >= 3) {
/*  631 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("dv", new Class[0]);
/*  632 */         } else if (minecraftSubVersion >= 2) {
/*  633 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("dw", new Class[0]);
/*      */         } else {
/*  635 */           entityGetBlockPositionMethod = MinecraftEntityClass.getMethod("do", new Class[0]);
/*      */         } 
/*      */         
/*  638 */         packetPlayOutSpawnEntityLivingConstructor = Class.forName(obfuscated ? "net.minecraft.network.protocol.game.PacketPlayOutSpawnEntity" : "net.minecraft.network.protocol.game.ClientboundAddEntityPacket").getConstructor(new Class[] { MinecraftEntityClass, int.class, blockPosition });
/*      */       }
/*  640 */       else if (minecraftVersion > 19 || (minecraftVersion == 19 && minecraftSubVersion >= 2)) {
/*      */         
/*  642 */         packetPlayOutSpawnEntityLivingConstructor = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutSpawnEntity").getConstructor(new Class[] { MinecraftEntityClass });
/*      */       }
/*  644 */       else if (minecraftVersion >= 19) {
/*      */         
/*  646 */         packetPlayOutSpawnEntityLivingConstructor = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutSpawnEntity").getConstructor(new Class[] { EntityLivingClass });
/*      */       }
/*      */       else {
/*      */         
/*  650 */         packetPlayOutSpawnEntityLivingConstructor = Class.forName(bool1 ? "net.minecraft.network.protocol.game.PacketPlayOutSpawnEntityLiving" : ("net.minecraft.server." + version + ".PacketPlayOutSpawnEntityLiving")).getConstructor(new Class[] { EntityLivingClass });
/*      */       } 
/*      */       
/*  653 */       nmsWorld = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.level.World" : "net.minecraft.world.level.Level") : ("net.minecraft.server." + version + ".World"));
/*  654 */       craftWorld = Class.forName(obfuscated ? ("org.bukkit.craftbukkit." + version + ".CraftWorld") : "org.bukkit.craftbukkit.CraftWorld");
/*  655 */       getHandleWorld = craftWorld.getMethod("getHandle", new Class[0]);
/*  656 */       boolean bool2 = (version.equals("v26_1") || version.equals("v26_0")) ? true : false;
/*  657 */       EntityTypesClass = Class.forName(bool1 ? ((obfuscated || !bool2) ? "net.minecraft.world.entity.EntityTypes" : "net.minecraft.world.entity.EntityType") : ("net.minecraft.server." + version + ".EntityTypes"));
/*  658 */       if (!obfuscated) {
/*  659 */         creeperEntityTypesValue = EntityTypesClass.getField("CREEPER").get(null);
/*  660 */         armorStandEntityTypesValue = EntityTypesClass.getField("ARMOR_STAND").get(null);
/*  661 */       } else if (minecraftVersion >= 21) {
/*  662 */         if (minecraftSubVersion >= 7) {
/*  663 */           creeperEntityTypesValue = EntityTypesClass.getField("I").get(null);
/*  664 */           armorStandEntityTypesValue = EntityTypesClass.getField("h").get(null);
/*  665 */         } else if (minecraftSubVersion >= 6) {
/*  666 */           creeperEntityTypesValue = EntityTypesClass.getField("H").get(null);
/*  667 */           armorStandEntityTypesValue = EntityTypesClass.getField("h").get(null);
/*  668 */         } else if (minecraftSubVersion >= 4) {
/*  669 */           creeperEntityTypesValue = EntityTypesClass.getField("F").get(null);
/*  670 */           armorStandEntityTypesValue = EntityTypesClass.getField("g").get(null);
/*  671 */         } else if (minecraftSubVersion >= 3) {
/*  672 */           creeperEntityTypesValue = EntityTypesClass.getField("E").get(null);
/*  673 */           armorStandEntityTypesValue = EntityTypesClass.getField("f").get(null);
/*  674 */         } else if (minecraftSubVersion >= 2) {
/*  675 */           creeperEntityTypesValue = EntityTypesClass.getField("F").get(null);
/*  676 */           armorStandEntityTypesValue = EntityTypesClass.getField("f").get(null);
/*      */         } else {
/*  678 */           creeperEntityTypesValue = EntityTypesClass.getField("x").get(null);
/*  679 */           armorStandEntityTypesValue = EntityTypesClass.getField("d").get(null);
/*      */         } 
/*  681 */       } else if (minecraftVersion >= 20) {
/*  682 */         if (minecraftSubVersion >= 4) {
/*  683 */           creeperEntityTypesValue = EntityTypesClass.getField("x").get(null);
/*  684 */         } else if (minecraftSubVersion > 2) {
/*  685 */           creeperEntityTypesValue = EntityTypesClass.getField("v").get(null);
/*      */         } else {
/*  687 */           creeperEntityTypesValue = EntityTypesClass.getField("u").get(null);
/*      */         } 
/*  689 */         armorStandEntityTypesValue = EntityTypesClass.getField("d").get(null);
/*  690 */       } else if (minecraftVersion == 19 && minecraftSubVersion >= 2) {
/*  691 */         if (minecraftSubVersion >= 3) {
/*  692 */           creeperEntityTypesValue = EntityTypesClass.getField("u").get(null);
/*      */         } else {
/*  694 */           creeperEntityTypesValue = EntityTypesClass.getField("r").get(null);
/*      */         } 
/*  696 */         armorStandEntityTypesValue = EntityTypesClass.getField("d").get(null);
/*  697 */       } else if (minecraftVersion >= 19) {
/*  698 */         creeperEntityTypesValue = EntityTypesClass.getField("q").get(null);
/*  699 */         armorStandEntityTypesValue = EntityTypesClass.getField("d").get(null);
/*  700 */       } else if (minecraftVersion >= 18) {
/*  701 */         creeperEntityTypesValue = EntityTypesClass.getField("o").get(null);
/*  702 */         armorStandEntityTypesValue = EntityTypesClass.getField("c").get(null);
/*  703 */       } else if (minecraftVersion >= 17) {
/*  704 */         creeperEntityTypesValue = EntityTypesClass.getField("o").get(null);
/*  705 */         armorStandEntityTypesValue = EntityTypesClass.getField("c").get(null);
/*      */       } else {
/*  707 */         creeperEntityTypesValue = EntityTypesClass.getField("CREEPER").get(null);
/*  708 */         armorStandEntityTypesValue = EntityTypesClass.getField("ARMOR_STAND").get(null);
/*      */       } 
/*  710 */       CreeperClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.monster.EntityCreeper" : "net.minecraft.world.entity.monster.Creeper") : ("net.minecraft.server." + version + ".EntityCreeper"));
/*  711 */       creeperConstructor = CreeperClass.getConstructor(new Class[] { (!obfuscated && !bool2) ? Class.forName("net.minecraft.world.entity.EntityType") : EntityTypesClass, nmsWorld });
/*  712 */       ArmorStandClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.decoration.EntityArmorStand" : "net.minecraft.world.entity.decoration.ArmorStand") : ("net.minecraft.server." + version + ".EntityArmorStand"));
/*  713 */       armorStandConstructor = ArmorStandClass.getConstructor(new Class[] { (!obfuscated && !bool2) ? Class.forName("net.minecraft.world.entity.EntityType") : EntityTypesClass, nmsWorld });
/*  714 */       String str5 = "getEquipment";
/*  715 */       if (!obfuscated) {
/*  716 */         str5 = "getItemBySlot";
/*  717 */       } else if (minecraftVersion >= 21) {
/*  718 */         str5 = "a";
/*  719 */       } else if (minecraftVersion >= 20 && minecraftSubVersion >= 4) {
/*  720 */         str5 = "a";
/*  721 */       } else if (minecraftVersion >= 19) {
/*  722 */         str5 = "c";
/*  723 */       } else if (minecraftVersion >= 18) {
/*  724 */         str5 = "b";
/*      */       } 
/*  726 */       armorStandGetEquipmentMethod = ArmorStandClass.getMethod(str5, new Class[] { EnumItemSlotClass });
/*  727 */       String str6 = "setInvisible";
/*  728 */       if (!obfuscated) {
/*  729 */         str6 = "setInvisible";
/*  730 */       } else if (minecraftVersion >= 21) {
/*  731 */         if (minecraftSubVersion >= 7) {
/*  732 */           str6 = "l";
/*  733 */         } else if (minecraftSubVersion >= 5) {
/*  734 */           str6 = "l";
/*      */         } else {
/*  736 */           str6 = "k";
/*      */         } 
/*  738 */       } else if (minecraftVersion >= 20 && minecraftSubVersion >= 4) {
/*  739 */         str6 = "k";
/*  740 */       } else if (minecraftVersion >= 18) {
/*  741 */         str6 = "j";
/*      */       } 
/*  743 */       setInvisibleMethod = MinecraftEntityClass.getMethod(str6, new Class[] { boolean.class });
/*  744 */       String str7 = "setSmall";
/*  745 */       if (!obfuscated && minecraftVersion >= 18) {
/*  746 */         str7 = "setSmall";
/*  747 */       } else if (minecraftVersion >= 18) {
/*  748 */         str7 = "a";
/*      */       } 
/*  750 */       setSmallMethod = ArmorStandClass.getMethod(str7, new Class[] { boolean.class });
/*  751 */       String str8 = "setArms";
/*  752 */       if (!obfuscated) {
/*  753 */         str8 = "setShowArms";
/*  754 */       } else if (minecraftVersion >= 18) {
/*  755 */         str8 = "r";
/*      */       } 
/*  757 */       setArmsMethod = ArmorStandClass.getMethod(str8, new Class[] { boolean.class });
/*  758 */       if (version.startsWith("v1_14") || version.startsWith("v1_16") || version.startsWith("v1_15")) {
/*  759 */         getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("B", new Class[0]);
/*  760 */         setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("g", new Class[] { compoundClass });
/*  761 */       } else if (!obfuscated) {
/*  762 */         getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("getArmorStandPose", new Class[0]);
/*  763 */         setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("setArmorStandPose", new Class[] { Class.forName("net.minecraft.world.entity.decoration.ArmorStand$ArmorStandPose") });
/*  764 */       } else if (minecraftVersion >= 21) {
/*  765 */         if (minecraftSubVersion >= 7) {
/*  766 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("B", new Class[0]);
/*  767 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("a", new Class[] { Class.forName("net.minecraft.world.entity.decoration.EntityArmorStand$a") });
/*  768 */         } else if (minecraftSubVersion >= 6) {
/*  769 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("C", new Class[0]);
/*  770 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("a", new Class[] { Class.forName("net.minecraft.world.entity.decoration.EntityArmorStand$a") });
/*  771 */         } else if (minecraftSubVersion >= 5) {
/*  772 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("B", new Class[0]);
/*  773 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("a", new Class[] { Class.forName("net.minecraft.world.entity.decoration.EntityArmorStand$a") });
/*      */         } else {
/*  775 */           if (minecraftSubVersion >= 4) {
/*  776 */             getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("E", new Class[0]);
/*  777 */           } else if (minecraftSubVersion >= 2) {
/*  778 */             getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("F", new Class[0]);
/*      */           } else {
/*  780 */             getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("I", new Class[0]);
/*      */           } 
/*  782 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*      */         } 
/*  784 */       } else if (minecraftVersion >= 20) {
/*  785 */         if (minecraftSubVersion >= 4) {
/*  786 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("I", new Class[0]);
/*  787 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*  788 */         } else if (minecraftSubVersion > 2) {
/*  789 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("K", new Class[0]);
/*  790 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*  791 */         } else if (minecraftSubVersion > 1) {
/*  792 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("I", new Class[0]);
/*  793 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*      */         } else {
/*  795 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("G", new Class[0]);
/*  796 */           setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*      */         } 
/*  798 */       } else if (minecraftVersion == 19 && minecraftSubVersion >= 2) {
/*  799 */         if (minecraftSubVersion >= 3) {
/*  800 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("G", new Class[0]);
/*      */         } else {
/*  802 */           getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("E", new Class[0]);
/*      */         } 
/*  804 */         setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*  805 */       } else if (minecraftVersion >= 18) {
/*  806 */         getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("D", new Class[0]);
/*  807 */         setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*  808 */       } else if (minecraftVersion >= 17) {
/*  809 */         getArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("F", new Class[0]);
/*  810 */         setArmorStandPoseMethod = ArmorStandClass.getDeclaredMethod("c", new Class[] { compoundClass });
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  815 */         setCanTickMethod = BukkitArmorStandClass.getMethod("setCanTick", new Class[] { boolean.class });
/*  816 */       } catch (NoSuchMethodException noSuchMethodException) {}
/*      */ 
/*      */       
/*  819 */       if (!obfuscated) {
/*  820 */         boundingBox = MinecraftEntityClass.getDeclaredField("bb");
/*  821 */       } else if (minecraftVersion >= 21) {
/*  822 */         if (minecraftSubVersion >= 7) {
/*  823 */           boundingBox = MinecraftEntityClass.getDeclaredField("bb");
/*  824 */         } else if (minecraftSubVersion >= 6) {
/*  825 */           boundingBox = MinecraftEntityClass.getDeclaredField("bb");
/*  826 */         } else if (minecraftSubVersion >= 5) {
/*  827 */           boundingBox = MinecraftEntityClass.getDeclaredField("ba");
/*  828 */         } else if (minecraftSubVersion >= 4) {
/*  829 */           boundingBox = MinecraftEntityClass.getDeclaredField("aG");
/*  830 */         } else if (minecraftSubVersion >= 2) {
/*  831 */           boundingBox = MinecraftEntityClass.getDeclaredField("aC");
/*      */         } else {
/*  833 */           boundingBox = MinecraftEntityClass.getDeclaredField("aF");
/*      */         } 
/*  835 */       } else if (minecraftVersion >= 20) {
/*  836 */         if (minecraftSubVersion >= 4) {
/*  837 */           boundingBox = MinecraftEntityClass.getDeclaredField("aH");
/*      */         } else {
/*  839 */           boundingBox = MinecraftEntityClass.getDeclaredField("aI");
/*      */         }
/*      */       
/*  842 */       } else if (minecraftVersion >= 19 && minecraftSubVersion >= 3) {
/*  843 */         boundingBox = MinecraftEntityClass.getDeclaredField("aG");
/*  844 */       } else if (minecraftVersion >= 18) {
/*  845 */         boundingBox = MinecraftEntityClass.getDeclaredField("aC");
/*      */       }
/*  847 */       else if (minecraftVersion >= 17) {
/*  848 */         boundingBox = MinecraftEntityClass.getDeclaredField("aA");
/*      */       } else {
/*  850 */         boundingBox = MinecraftEntityClass.getDeclaredField("boundingBox");
/*      */       } 
/*  852 */       boundingBox.setAccessible(true);
/*      */       
/*  854 */       if (!obfuscated) {
/*  855 */         sizeField = MinecraftEntityClass.getDeclaredField("dimensions");
/*  856 */       } else if (minecraftVersion >= 21) {
/*  857 */         if (minecraftSubVersion >= 7) {
/*  858 */           sizeField = MinecraftEntityClass.getDeclaredField("bz");
/*  859 */         } else if (minecraftSubVersion >= 6) {
/*  860 */           sizeField = MinecraftEntityClass.getDeclaredField("bz");
/*  861 */         } else if (minecraftSubVersion >= 5) {
/*  862 */           sizeField = MinecraftEntityClass.getDeclaredField("by");
/*  863 */         } else if (minecraftSubVersion >= 4) {
/*  864 */           sizeField = MinecraftEntityClass.getDeclaredField("be");
/*  865 */         } else if (minecraftSubVersion >= 2) {
/*  866 */           sizeField = MinecraftEntityClass.getDeclaredField("bb");
/*      */         } else {
/*  868 */           sizeField = MinecraftEntityClass.getDeclaredField("bd");
/*      */         } 
/*  870 */       } else if (minecraftVersion >= 20) {
/*  871 */         if (minecraftSubVersion >= 4) {
/*  872 */           sizeField = MinecraftEntityClass.getDeclaredField("bf");
/*      */         } else {
/*  874 */           sizeField = MinecraftEntityClass.getDeclaredField("bh");
/*      */         } 
/*  876 */       } else if (minecraftVersion >= 19) {
/*  877 */         if (minecraftSubVersion >= 3) {
/*  878 */           sizeField = MinecraftEntityClass.getDeclaredField("be");
/*      */         } else {
/*  880 */           sizeField = MinecraftEntityClass.getDeclaredField("aZ");
/*      */         } 
/*  882 */       } else if (minecraftVersion >= 18) {
/*  883 */         if (minecraftSubVersion >= 2) {
/*  884 */           sizeField = MinecraftEntityClass.getDeclaredField("aZ");
/*      */         } else {
/*  886 */           sizeField = MinecraftEntityClass.getDeclaredField("aY");
/*      */         } 
/*  888 */       } else if (minecraftVersion >= 17) {
/*  889 */         sizeField = MinecraftEntityClass.getDeclaredField("aW");
/*      */       } else {
/*  891 */         sizeField = MinecraftEntityClass.getDeclaredField("size");
/*      */       } 
/*  893 */       sizeField.setAccessible(true);
/*  894 */       Class<?> clazz6 = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.EntitySize" : "net.minecraft.world.entity.EntityDimensions") : ("net.minecraft.server." + version + ".EntitySize"));
/*  895 */       if (!obfuscated) {
/*  896 */         entitySizeConstructor = clazz6.getDeclaredConstructor(new Class[] { float.class, float.class, boolean.class });
/*  897 */         entitySizeConstructor.setAccessible(true);
/*  898 */       } else if (minecraftVersion > 20 || (minecraftVersion == 20 && minecraftSubVersion >= 4)) {
/*      */         
/*  900 */         entitySizeConstructor = clazz6.getDeclaredConstructor(new Class[] { float.class, float.class, boolean.class });
/*  901 */         entitySizeConstructor.setAccessible(true);
/*      */       } else {
/*      */         
/*  904 */         entitySizeConstructor = clazz6.getConstructor(new Class[] { float.class, float.class, boolean.class });
/*      */       } 
/*  906 */       axisAlignedBB = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.phys.AxisAlignedBB" : "net.minecraft.world.phys.AABB") : ("net.minecraft.server." + version + ".AxisAlignedBB"));
/*  907 */       axisAlignedBBConstructor = axisAlignedBB.getConstructor(new Class[] { double.class, double.class, double.class, double.class, double.class, double.class });
/*      */       
/*  909 */       EnumHandClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.EnumHand" : "net.minecraft.world.InteractionHand") : ("net.minecraft.server." + version + ".EnumHand"));
/*  910 */       if (!obfuscated) {
/*  911 */         enumHandMainValue = EnumHandClass.getField("MAIN_HAND").get(null);
/*  912 */       } else if (minecraftVersion >= 18) {
/*  913 */         enumHandMainValue = EnumHandClass.getField("a").get(null);
/*  914 */       } else if (minecraftVersion >= 17) {
/*  915 */         enumHandMainValue = EnumHandClass.getField("a").get(null);
/*      */       } else {
/*  917 */         enumHandMainValue = EnumHandClass.getField("MAIN_HAND").get(null);
/*      */       } 
/*  919 */       CraftEventFactoryClass = Class.forName(obfuscated ? ("org.bukkit.craftbukkit." + version + ".event.CraftEventFactory") : "org.bukkit.craftbukkit.event.CraftEventFactory");
/*  920 */       WorldServerClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.server.level.WorldServer" : "net.minecraft.server.level.ServerLevel") : ("net.minecraft.server." + version + ".WorldServer"));
/*  921 */       EntityHumanClass = Class.forName(bool1 ? (obfuscated ? "net.minecraft.world.entity.player.EntityHuman" : "net.minecraft.world.entity.player.Player") : ("net.minecraft.server." + version + ".EntityHuman"));
/*  922 */       Class<?> clazz7 = Class.forName(obfuscated ? ("org.bukkit.craftbukkit." + version + ".inventory.CraftItemStack") : "org.bukkit.craftbukkit.inventory.CraftItemStack");
/*  923 */       itemStackAsNMSCopyMethod = clazz7.getMethod("asNMSCopy", new Class[] { ItemStack.class });
/*  924 */       if (!obfuscated) {
/*  925 */         DimensionManagerClass = Class.forName("net.minecraft.world.level.dimension.DimensionType");
/*  926 */         getDimensionManagerMethod = nmsWorld.getMethod("dimensionType", new Class[0]);
/*  927 */         getMinYField = DimensionManagerClass.getMethod("minY", new Class[0]);
/*  928 */         getHeightField = DimensionManagerClass.getMethod("height", new Class[0]);
/*  929 */       } else if (minecraftVersion >= 18) {
/*  930 */         DimensionManagerClass = Class.forName("net.minecraft.world.level.dimension.DimensionManager");
/*      */       } 
/*  932 */       if (obfuscated && minecraftVersion >= 21) {
/*  933 */         if (minecraftSubVersion >= 7) {
/*  934 */           getDimensionManagerMethod = nmsWorld.getMethod("F_", new Class[0]);
/*  935 */           getMinYField = DimensionManagerClass.getMethod("h", new Class[0]);
/*  936 */           getHeightField = DimensionManagerClass.getMethod("i", new Class[0]);
/*  937 */         } else if (minecraftSubVersion >= 6) {
/*  938 */           getDimensionManagerMethod = nmsWorld.getMethod("H_", new Class[0]);
/*  939 */           getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  940 */           getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  941 */         } else if (minecraftSubVersion >= 5) {
/*  942 */           getDimensionManagerMethod = nmsWorld.getMethod("G_", new Class[0]);
/*  943 */           getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  944 */           getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  945 */         } else if (minecraftSubVersion >= 4) {
/*  946 */           getDimensionManagerMethod = nmsWorld.getMethod("F_", new Class[0]);
/*  947 */           getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  948 */           getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  949 */         } else if (minecraftSubVersion >= 2) {
/*  950 */           getDimensionManagerMethod = nmsWorld.getMethod("G_", new Class[0]);
/*  951 */           getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  952 */           getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*      */         } else {
/*  954 */           getDimensionManagerMethod = nmsWorld.getMethod("D_", new Class[0]);
/*  955 */           getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  956 */           getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*      */         } 
/*  958 */       } else if (obfuscated && minecraftVersion >= 20) {
/*  959 */         if (minecraftSubVersion >= 4) {
/*  960 */           getDimensionManagerMethod = nmsWorld.getMethod("D_", new Class[0]);
/*  961 */         } else if (minecraftSubVersion > 2) {
/*  962 */           getDimensionManagerMethod = nmsWorld.getMethod("E_", new Class[0]);
/*  963 */         } else if (minecraftSubVersion > 1) {
/*  964 */           getDimensionManagerMethod = nmsWorld.getMethod("C_", new Class[0]);
/*      */         } else {
/*  966 */           getDimensionManagerMethod = nmsWorld.getMethod("x_", new Class[0]);
/*      */         } 
/*  968 */         getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  969 */         getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  970 */       } else if (obfuscated && minecraftVersion == 19 && minecraftSubVersion >= 2) {
/*  971 */         if (minecraftSubVersion >= 3) {
/*  972 */           getDimensionManagerMethod = nmsWorld.getMethod("q_", new Class[0]);
/*      */         } else {
/*  974 */           getDimensionManagerMethod = nmsWorld.getMethod("r_", new Class[0]);
/*      */         } 
/*  976 */         getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  977 */         getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  978 */       } else if (obfuscated && minecraftVersion >= 19) {
/*  979 */         getDimensionManagerMethod = nmsWorld.getMethod("q_", new Class[0]);
/*  980 */         getMinYField = DimensionManagerClass.getMethod("n", new Class[0]);
/*  981 */         getHeightField = DimensionManagerClass.getMethod("o", new Class[0]);
/*  982 */       } else if (obfuscated && minecraftVersion >= 18) {
/*  983 */         if (minecraftSubVersion >= 2) {
/*  984 */           getDimensionManagerMethod = nmsWorld.getMethod("q_", new Class[0]);
/*  985 */           getMinYField = DimensionManagerClass.getMethod("j", new Class[0]);
/*  986 */           getHeightField = DimensionManagerClass.getMethod("k", new Class[0]);
/*      */         } else {
/*  988 */           getDimensionManagerMethod = nmsWorld.getMethod("q_", new Class[0]);
/*  989 */           getMinYField = DimensionManagerClass.getMethod("k", new Class[0]);
/*  990 */           getHeightField = DimensionManagerClass.getMethod("l", new Class[0]);
/*      */         } 
/*      */       } 
/*  993 */     } catch (Exception exception) {
/*  994 */       EventListener.joinMessage = ChatColor.AQUA + "[Vehicles]" + ChatColor.GRAY + " It seems the plugin is not compatible \nwith your version, if you are using a version >= 1.14 \nplease contact @Pollitoyeye on spigotmc.org with the\nsubject \"" + version + "\" and send him the server log.";
/*      */ 
/*      */ 
/*      */       
/*  998 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getMinecraftVersion(Server paramServer) {
/*      */     try {
/* 1005 */       Method method = paramServer.getClass().getMethod("getMinecraftVersion", new Class[0]);
/* 1006 */       return (String)method.invoke(paramServer, new Object[0]);
/* 1007 */     } catch (Exception exception) {
/*      */       try {
/* 1009 */         Method method = Bukkit.class.getMethod("getVersion", new Class[0]);
/* 1010 */         String str = (String)method.invoke(null, new Object[0]);
/* 1011 */         return str.split("\\(MC: ")[1].split("\\)")[0];
/* 1012 */       } catch (Exception exception1) {
/* 1013 */         exception1.printStackTrace();
/* 1014 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static float[] sidesFront(Player paramPlayer) {
/* 1020 */     float[] arrayOfFloat = new float[2];
/* 1021 */     if (newPlayerInput) {
/*      */       try {
/* 1023 */         Object object = getInputMethod.invoke(paramPlayer, new Object[0]);
/* 1024 */         boolean bool1 = ((Boolean)isForwardMethod.invoke(object, new Object[0])).booleanValue();
/* 1025 */         boolean bool2 = ((Boolean)isBackwardMethod.invoke(object, new Object[0])).booleanValue();
/* 1026 */         boolean bool3 = ((Boolean)isLeftMethod.invoke(object, new Object[0])).booleanValue();
/* 1027 */         boolean bool4 = ((Boolean)isRightMethod.invoke(object, new Object[0])).booleanValue();
/* 1028 */         arrayOfFloat[0] = bool3 ? 5.88F : (bool4 ? -5.88F : 0.0F);
/* 1029 */         arrayOfFloat[1] = bool1 ? 0.98F : (bool2 ? -0.98F : 0.0F);
/* 1030 */       } catch (Exception exception) {
/* 1031 */         exception.printStackTrace();
/*      */       } 
/* 1033 */       return arrayOfFloat;
/*      */     } 
/*      */     try {
/* 1036 */       Object object1 = CraftPlayerClass.cast(paramPlayer);
/*      */       
/* 1038 */       Object object2 = EntityLivingClass.cast(getHandlePlayer.invoke(object1, new Object[0]));
/* 1039 */       arrayOfFloat[0] = azField.getFloat(object2) * 6.0F;
/* 1040 */       arrayOfFloat[1] = baField.getFloat(object2);
/* 1041 */     } catch (Exception exception) {
/* 1042 */       exception.printStackTrace();
/*      */     } 
/* 1044 */     return arrayOfFloat;
/*      */   }
/*      */   
/*      */   public static boolean isSpacePressed(Player paramPlayer) {
/* 1048 */     if (newPlayerInput)
/*      */       try {
/* 1050 */         Object object = getInputMethod.invoke(paramPlayer, new Object[0]);
/* 1051 */         return ((Boolean)isJumpMethod.invoke(object, new Object[0])).booleanValue();
/* 1052 */       } catch (Exception exception) {
/* 1053 */         exception.printStackTrace();
/*      */         
/* 1055 */         return false;
/*      */       }  
/*      */     try {
/* 1058 */       Object object1 = CraftPlayerClass.cast(paramPlayer);
/*      */       
/* 1060 */       Object object2 = EntityLivingClass.cast(getHandlePlayer.invoke(object1, new Object[0]));
/* 1061 */       return jumpField.getBoolean(object2);
/* 1062 */     } catch (Exception exception) {
/* 1063 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setYaw(Entity paramEntity, float paramFloat) {
/* 1068 */     if (paramEntity == null) {
/*      */       return;
/*      */     }
/*      */     try {
/* 1072 */       Object object1 = CraftEntityClass.cast(paramEntity);
/*      */       
/* 1074 */       Object object2 = EntityLivingClass.cast(getHandleEntity.invoke(object1, new Object[0]));
/* 1075 */       entityYawField.setFloat(object2, paramFloat % 360.0F);
/* 1076 */     } catch (Exception exception) {
/* 1077 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static float getYaw(Entity paramEntity) {
/* 1083 */     if (paramEntity == null) {
/* 1084 */       return 0.0F;
/*      */     }
/* 1086 */     float f = 0.0F;
/*      */     try {
/* 1088 */       Object object1 = CraftEntityClass.cast(paramEntity);
/*      */       
/* 1090 */       Object object2 = EntityLivingClass.cast(getHandleEntity.invoke(object1, new Object[0]));
/* 1091 */       f = entityYawField.getFloat(object2);
/* 1092 */     } catch (Exception exception) {
/* 1093 */       exception.printStackTrace();
/*      */     } 
/* 1095 */     return f;
/*      */   }
/*      */   
/*      */   public static double getSeatOffset() {
/* 1099 */     return seatOffset;
/*      */   }
/*      */   
/*      */   public static void removeSlots(ArmorStand paramArmorStand) {
/*      */     try {
/* 1104 */       if (newValueOutputCompound) {
/* 1105 */         for (EquipmentSlot equipmentSlot : EquipmentSlot.values()) {
/* 1106 */           addEquipmentLockMethod.invoke(paramArmorStand, new Object[] { equipmentSlot, addingOrChangingLockType });
/* 1107 */           addEquipmentLockMethod.invoke(paramArmorStand, new Object[] { equipmentSlot, removingOrChangingLockType });
/*      */         } 
/*      */       } else {
/* 1110 */         Object object1 = getHandleEntity.invoke(CraftEntityClass.cast(paramArmorStand), new Object[0]);
/* 1111 */         Object object2 = compoundConstructor.newInstance(new Object[0]);
/* 1112 */         c.invoke(object1, new Object[] { object2 });
/* 1113 */         setInt.invoke(object2, new Object[] { "DisabledSlots", Integer.valueOf(2096896) });
/* 1114 */         f.invoke(object1, new Object[] { object2 });
/*      */       } 
/* 1116 */     } catch (Exception exception) {
/* 1117 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setGravity(ArmorStand paramArmorStand, boolean paramBoolean) {
/* 1122 */     paramArmorStand.setGravity(paramBoolean);
/* 1123 */     if (noClip == null) {
/*      */       return;
/*      */     }
/*      */     try {
/* 1127 */       Object object = getHandleEntity.invoke(CraftEntityClass.cast(paramArmorStand), new Object[0]);
/* 1128 */       noClip.setAccessible(true);
/* 1129 */       noClip.setBoolean(object, !paramBoolean);
/* 1130 */       noClip.setAccessible(false);
/* 1131 */     } catch (Exception exception) {
/* 1132 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setCanTick(ArmorStand paramArmorStand) {
/* 1137 */     if (paramArmorStand == null) {
/*      */       return;
/*      */     }
/* 1140 */     if (setCanTickMethod == null) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/* 1145 */       setCanTickMethod.invoke(paramArmorStand, new Object[] {
/* 1146 */             Boolean.valueOf(true) });
/* 1147 */     } catch (Exception exception) {
/* 1148 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setLocation(Entity paramEntity, Location paramLocation) {
/*      */     try {
/* 1154 */       Object object = getHandleEntity.invoke(CraftEntityClass.cast(paramEntity), new Object[0]);
/* 1155 */       setLocationMethod.invoke(object, new Object[] {
/* 1156 */             Double.valueOf(paramLocation.getX()), Double.valueOf(paramLocation.getY()), Double.valueOf(paramLocation.getZ()), Float.valueOf(paramLocation.getYaw()), Float.valueOf(paramLocation.getPitch()) });
/* 1157 */     } catch (Exception exception) {
/* 1158 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void checkChunks(Location paramLocation, int paramInt) {
/* 1163 */     for (byte b = 0; b < 3; b++) {
/* 1164 */       for (byte b1 = 0; b1 < 3; b1++) {
/* 1165 */         Chunk chunk = paramLocation.clone().add(((b - 1) * paramInt), 0.0D, ((b1 - 1) * paramInt)).getChunk();
/* 1166 */         if (!chunk.isLoaded()) {
/* 1167 */           chunk.load();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void saveUUIDData(ArmorStand paramArmorStand) {
/* 1174 */     ItemStack itemStack = new ItemStack(Material.ANVIL);
/* 1175 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 1176 */     itemMeta.setDisplayName(paramArmorStand.getUniqueId().toString());
/* 1177 */     itemStack.setItemMeta(itemMeta);
/* 1178 */     paramArmorStand.setChestplate(itemStack);
/*      */   }
/*      */   
/*      */   public static boolean checkSavedUUID(Entity paramEntity, String paramString) {
/* 1182 */     if (!(paramEntity instanceof ArmorStand)) {
/* 1183 */       return false;
/*      */     }
/* 1185 */     if (paramString == null) {
/* 1186 */       return false;
/*      */     }
/* 1188 */     ArmorStand armorStand = (ArmorStand)paramEntity;
/* 1189 */     ItemStack itemStack = armorStand.getChestplate();
/* 1190 */     if (itemStack != null && itemStack.getType() == Material.ANVIL) {
/* 1191 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 1192 */       if (itemMeta.hasDisplayName() && 
/* 1193 */         itemMeta.getDisplayName().equals(paramString)) {
/* 1194 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1198 */     return false;
/*      */   }
/*      */   
/*      */   public static String getSavedUUID(Entity paramEntity) {
/* 1202 */     if (!(paramEntity instanceof ArmorStand)) {
/* 1203 */       return null;
/*      */     }
/* 1205 */     ArmorStand armorStand = (ArmorStand)paramEntity;
/* 1206 */     ItemStack itemStack = armorStand.getChestplate();
/* 1207 */     if (itemStack != null && itemStack.getType() == Material.ANVIL) {
/* 1208 */       ItemMeta itemMeta = itemStack.getItemMeta();
/* 1209 */       if (itemMeta.hasDisplayName()) {
/* 1210 */         return itemMeta.getDisplayName();
/*      */       }
/*      */     } 
/* 1213 */     return null;
/*      */   }
/*      */   public static void setBoundingBox(ArmorStand paramArmorStand, BoundingBoxData paramBoundingBoxData) {
/*      */     try {
/* 1217 */       double d1 = paramBoundingBoxData.getHeight();
/* 1218 */       double d2 = paramBoundingBoxData.getXWidth();
/* 1219 */       double d3 = paramBoundingBoxData.getZWidth();
/* 1220 */       Location location = paramArmorStand.getLocation();
/* 1221 */       Object object1 = getHandleEntity.invoke(CraftEntityClass.cast(paramArmorStand), new Object[0]);
/* 1222 */       Object object2 = axisAlignedBBConstructor.newInstance(new Object[] {
/* 1223 */             Double.valueOf(location.getX() - d2), Double.valueOf(location.getY() + paramBoundingBoxData.getHeightOffset()), Double.valueOf(location.getZ() - d3), 
/* 1224 */             Double.valueOf(location.getX() + d2), Double.valueOf(location.getY() + d1), Double.valueOf(location.getZ() + d3) });
/* 1225 */       boundingBox.set(object1, object2);
/* 1226 */       if (minecraftVersion >= 17) {
/* 1227 */         float f1 = (float)paramBoundingBoxData.getXWidth() * 2.0F;
/* 1228 */         float f2 = (float)paramBoundingBoxData.getHeight();
/* 1229 */         Object object = entitySizeConstructor.newInstance(new Object[] { Float.valueOf(f1), Float.valueOf(f2), Boolean.valueOf(true) });
/* 1230 */         sizeField.set(object1, object);
/*      */       } 
/* 1232 */     } catch (Exception exception) {
/* 1233 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(ArmorStand paramArmorStand, BoundingBoxData paramBoundingBoxData) {
/* 1238 */     double d1 = paramBoundingBoxData.getHeight();
/* 1239 */     double d2 = paramBoundingBoxData.getXWidth();
/* 1240 */     double d3 = paramBoundingBoxData.getZWidth();
/* 1241 */     double d4 = paramBoundingBoxData.getHeightOffset();
/*      */     try {
/* 1243 */       Location location = paramArmorStand.getLocation();
/*      */       
/* 1245 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() + d3), new Location(paramArmorStand
/* 1246 */             .getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() + d3));
/* 1247 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() - d3), new Location(paramArmorStand
/* 1248 */             .getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() + d3));
/* 1249 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() - d3), new Location(paramArmorStand
/* 1250 */             .getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() - d3));
/* 1251 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() + d3), new Location(paramArmorStand
/* 1252 */             .getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() - d3));
/*      */       
/* 1254 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() + d3), new Location(paramArmorStand
/* 1255 */             .getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() + d3));
/* 1256 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() - d3), new Location(paramArmorStand
/* 1257 */             .getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() + d3));
/* 1258 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() - d3), new Location(paramArmorStand
/* 1259 */             .getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() - d3));
/* 1260 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() + d3), new Location(paramArmorStand
/* 1261 */             .getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() - d3));
/*      */       
/* 1263 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() - d3), new Location(paramArmorStand
/* 1264 */             .getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() - d3));
/* 1265 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() + d2, location.getY() + d4, location.getZ() + d3), new Location(paramArmorStand
/* 1266 */             .getWorld(), location.getX() + d2, location.getY() + d1, location.getZ() + d3));
/* 1267 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() - d3), new Location(paramArmorStand
/* 1268 */             .getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() - d3));
/* 1269 */       drawLine(new Location(paramArmorStand.getWorld(), location.getX() - d2, location.getY() + d4, location.getZ() + d3), new Location(paramArmorStand
/* 1270 */             .getWorld(), location.getX() - d2, location.getY() + d1, location.getZ() + d3));
/* 1271 */     } catch (Exception exception) {
/* 1272 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   private static List<Location> buildLine(Location paramLocation1, Location paramLocation2, double paramDouble) {
/* 1276 */     ArrayList<Location> arrayList = new ArrayList();
/* 1277 */     if (paramLocation1 == null) return arrayList;
/*      */     
/* 1279 */     arrayList.add(paramLocation1);
/* 1280 */     if (paramLocation2 == null) return arrayList; 
/* 1281 */     if (!paramLocation1.getWorld().equals(paramLocation2.getWorld())) return arrayList; 
/* 1282 */     World world = paramLocation1.getWorld();
/* 1283 */     double d1 = paramLocation1.distance(paramLocation2);
/* 1284 */     double d2 = d1 / paramDouble;
/* 1285 */     if (d2 < 1.0D) return arrayList; 
/* 1286 */     double d3 = (paramLocation2.getX() - paramLocation1.getX()) / d2;
/* 1287 */     double d4 = (paramLocation2.getY() - paramLocation1.getY()) / d2;
/* 1288 */     double d5 = (paramLocation2.getZ() - paramLocation1.getZ()) / d2;
/* 1289 */     double d6 = 0.0D;
/* 1290 */     Location location = paramLocation1;
/* 1291 */     while (paramDouble > 0.0D && d6 <= d1) {
/* 1292 */       location = new Location(world, location.getX() + d3, location.getY() + d4, location.getZ() + d5, location.getYaw(), location.getPitch());
/* 1293 */       arrayList.add(location);
/* 1294 */       d6 += paramDouble;
/*      */     } 
/* 1296 */     return arrayList;
/*      */   }
/*      */   private static void drawLine(Location paramLocation1, Location paramLocation2) {
/* 1299 */     for (Location location : buildLine(paramLocation1, paramLocation2, 0.1D)) {
/* 1300 */       Particle particle = null;
/*      */       try {
/* 1302 */         particle = Particle.valueOf("REDSTONE");
/* 1303 */       } catch (Exception exception) {
/* 1304 */         particle = Particle.valueOf("DUST");
/*      */       } 
/* 1306 */       location.getWorld().spawnParticle(particle, location, 1, new Particle.DustOptions(Color.fromBGR(255, 0, 0), 1.0F));
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Player getPlayerFromEntityPlayer(Object paramObject) {
/*      */     try {
/* 1312 */       return (Player)getBukkitEntityPlayer.invoke(paramObject, new Object[0]);
/* 1313 */     } catch (Exception exception) {
/*      */       
/* 1315 */       return null;
/*      */     } 
/*      */   }
/*      */   public static void setVehicle(Object paramObject1, Object paramObject2) {
/*      */     try {
/* 1320 */       vehicleField.set(paramObject1, paramObject2);
/* 1321 */     } catch (Exception exception) {
/* 1322 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getVehicle(Object paramObject) {
/*      */     try {
/* 1328 */       return vehicleField.get(paramObject);
/* 1329 */     } catch (Exception exception) {
/* 1330 */       exception.printStackTrace();
/*      */       
/* 1332 */       return null;
/*      */     } 
/*      */   }
/*      */   public static void setCustomPassengerList(Entity paramEntity) {
/*      */     try {
/* 1337 */       if (minecraftVersion < 17 && obfuscated) {
/* 1338 */         Object object = getHandleEntity.invoke(CraftEntityClass.cast(paramEntity), new Object[0]);
/* 1339 */         List list = (List)passengersField.get(object);
/* 1340 */         VehiclePassengerList vehiclePassengerList = new VehiclePassengerList();
/* 1341 */         for (Object object1 : list) {
/* 1342 */           vehiclePassengerList.add(object1);
/*      */         }
/* 1344 */         vehiclePassengerList.setVehicle(object);
/* 1345 */         passengersField.set(object, vehiclePassengerList);
/*      */       } else {
/* 1347 */         paramEntity.setMetadata("VEHICLES_UNDERWATER_VEHICLE", (MetadataValue)new FixedMetadataValue((Plugin)VehiclesMain.getPlugin(), Boolean.valueOf(true)));
/*      */       } 
/* 1349 */     } catch (Exception exception) {
/* 1350 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setCamera(Player paramPlayer, Object paramObject) {
/*      */     try {
/* 1356 */       Object object1 = packetPlayOutCameraConstructor.newInstance(new Object[] { paramObject });
/* 1357 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1358 */       Object object3 = playerConnectionField.get(object2);
/* 1359 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1360 */     } catch (Exception exception) {
/* 1361 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getNMSPlayer(Player paramPlayer) {
/*      */     try {
/* 1367 */       return getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1368 */     } catch (Exception exception) {
/* 1369 */       exception.printStackTrace();
/* 1370 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getNMSEntity(Entity paramEntity) {
/*      */     try {
/* 1376 */       Object object = CraftEntityClass.cast(paramEntity);
/* 1377 */       return getHandleEntity.invoke(object, new Object[0]);
/*      */     }
/* 1379 */     catch (Exception exception) {
/* 1380 */       exception.printStackTrace();
/* 1381 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object sendCameraEntity(Player paramPlayer, Location paramLocation) {
/*      */     try {
/* 1387 */       Object object = creeperConstructor.newInstance(new Object[] { creeperEntityTypesValue, getHandleWorld
/* 1388 */             .invoke(craftWorld.cast(paramLocation.getWorld()), new Object[0]) });
/* 1389 */       setLocationMethod.invoke(object, new Object[] {
/* 1390 */             Double.valueOf(paramLocation.getX()), Double.valueOf(paramLocation.getY()), Double.valueOf(paramLocation.getZ()), Float.valueOf(paramLocation.getYaw()), Float.valueOf(paramLocation.getPitch()) });
/* 1391 */       setInvisibleMethod.invoke(object, new Object[] { Boolean.valueOf(true) });
/* 1392 */       sendSpawnPacket(paramPlayer, object);
/* 1393 */       return object;
/* 1394 */     } catch (Exception exception) {
/* 1395 */       exception.printStackTrace();
/* 1396 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object createNMSArmorStand(Location paramLocation, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*      */     try {
/* 1402 */       Object object = armorStandConstructor.newInstance(new Object[] { armorStandEntityTypesValue, getHandleWorld
/* 1403 */             .invoke(craftWorld.cast(paramLocation.getWorld()), new Object[0]) });
/* 1404 */       setLocationMethod.invoke(object, new Object[] {
/* 1405 */             Double.valueOf(paramLocation.getX()), Double.valueOf(paramLocation.getY()), Double.valueOf(paramLocation.getZ()), Float.valueOf(paramLocation.getYaw()), Float.valueOf(paramLocation.getPitch()) });
/* 1406 */       if (paramBoolean1) {
/* 1407 */         setInvisibleMethod.invoke(object, new Object[] { Boolean.valueOf(true) });
/*      */       }
/* 1409 */       if (paramBoolean2) {
/* 1410 */         setSmallMethod.invoke(object, new Object[] { Boolean.valueOf(true) });
/*      */       }
/* 1412 */       if (paramBoolean3) {
/* 1413 */         setArmsMethod.invoke(object, new Object[] { Boolean.valueOf(true) });
/*      */       }
/* 1415 */       return object;
/* 1416 */     } catch (Exception exception) {
/* 1417 */       exception.printStackTrace();
/* 1418 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setArmorStandPose(Object paramObject1, Object paramObject2) {
/*      */     try {
/* 1424 */       setArmorStandPoseMethod.setAccessible(true);
/* 1425 */       setArmorStandPoseMethod.invoke(paramObject1, new Object[] { paramObject2 });
/* 1426 */     } catch (Exception exception) {
/* 1427 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getArmorStandPose(Object paramObject) {
/*      */     try {
/* 1433 */       getArmorStandPoseMethod.setAccessible(true);
/* 1434 */       return getArmorStandPoseMethod.invoke(paramObject, new Object[0]);
/* 1435 */     } catch (Exception exception) {
/* 1436 */       exception.printStackTrace();
/* 1437 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void sendSpawnPacket(Player paramPlayer, Object paramObject) {
/*      */     try {
/* 1443 */       Object object1 = null;
/* 1444 */       if (newPacketPlayOutSpawnEntityLivingConstructor) {
/* 1445 */         object1 = packetPlayOutSpawnEntityLivingConstructor.newInstance(new Object[] { paramObject, Integer.valueOf(0), entityGetBlockPositionMethod.invoke(paramObject, new Object[0]) });
/*      */       } else {
/* 1447 */         object1 = packetPlayOutSpawnEntityLivingConstructor.newInstance(new Object[] { paramObject });
/*      */       } 
/* 1449 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1450 */       Object object3 = playerConnectionField.get(object2);
/* 1451 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1452 */     } catch (Exception exception) {
/* 1453 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void sendEquipmentPacket(Player paramPlayer, Object paramObject1, Object paramObject2) {
/*      */     try {
/* 1460 */       int i = ((Integer)getIdMethod.invoke(paramObject1, new Object[0])).intValue();
/* 1461 */       Object object1 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1462 */       Object object2 = playerConnectionField.get(object1);
/* 1463 */       if (!obfuscated || minecraftVersion >= 16) {
/* 1464 */         Object object = packetPlayOutEntityEquipmentConstructor.newInstance(new Object[] { Integer.valueOf(i), paramObject2 });
/* 1465 */         sendPacketMethod.invoke(object2, new Object[] { object });
/*      */         return;
/*      */       } 
/* 1468 */       for (Object object : paramObject2) {
/* 1469 */         Object object3 = pairGetFirstMethod.invoke(object, new Object[0]);
/* 1470 */         Object object4 = pairGetSecondMethod.invoke(object, new Object[0]);
/* 1471 */         Object object5 = packetPlayOutEntityEquipmentConstructor.newInstance(new Object[] { Integer.valueOf(i), object3, object4 });
/* 1472 */         sendPacketMethod.invoke(object2, new Object[] { object5 });
/*      */       } 
/* 1474 */     } catch (Exception exception) {
/* 1475 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sendEmptyEquipmentPacket(Player paramPlayer, Object paramObject) {
/*      */     // Byte code:
/*      */     //   0: new java/util/ArrayList
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.getIdMethod : Ljava/lang/reflect/Method;
/*      */     //   11: aload_1
/*      */     //   12: iconst_0
/*      */     //   13: anewarray java/lang/Object
/*      */     //   16: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   19: checkcast java/lang/Integer
/*      */     //   22: invokevirtual intValue : ()I
/*      */     //   25: istore_3
/*      */     //   26: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.getHandlePlayer : Ljava/lang/reflect/Method;
/*      */     //   29: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.CraftPlayerClass : Ljava/lang/Class;
/*      */     //   32: aload_0
/*      */     //   33: invokevirtual cast : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   36: iconst_0
/*      */     //   37: anewarray java/lang/Object
/*      */     //   40: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   43: astore #4
/*      */     //   45: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.playerConnectionField : Ljava/lang/reflect/Field;
/*      */     //   48: aload #4
/*      */     //   50: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   53: astore #5
/*      */     //   55: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.obfuscated : Z
/*      */     //   58: ifeq -> 69
/*      */     //   61: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.minecraftVersion : I
/*      */     //   64: bipush #16
/*      */     //   66: if_icmplt -> 196
/*      */     //   69: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.EnumItemSlotClass : Ljava/lang/Class;
/*      */     //   72: invokevirtual getEnumConstants : ()[Ljava/lang/Object;
/*      */     //   75: astore #6
/*      */     //   77: aload #6
/*      */     //   79: arraylength
/*      */     //   80: istore #7
/*      */     //   82: iconst_0
/*      */     //   83: istore #8
/*      */     //   85: iload #8
/*      */     //   87: iload #7
/*      */     //   89: if_icmpge -> 154
/*      */     //   92: aload #6
/*      */     //   94: iload #8
/*      */     //   96: aaload
/*      */     //   97: astore #9
/*      */     //   99: aload_2
/*      */     //   100: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.pairConstructor : Ljava/lang/reflect/Constructor;
/*      */     //   103: iconst_2
/*      */     //   104: anewarray java/lang/Object
/*      */     //   107: dup
/*      */     //   108: iconst_0
/*      */     //   109: aload #9
/*      */     //   111: aastore
/*      */     //   112: dup
/*      */     //   113: iconst_1
/*      */     //   114: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.itemStackAsNMSCopyMethod : Ljava/lang/reflect/Method;
/*      */     //   117: aconst_null
/*      */     //   118: iconst_1
/*      */     //   119: anewarray java/lang/Object
/*      */     //   122: dup
/*      */     //   123: iconst_0
/*      */     //   124: new org/bukkit/inventory/ItemStack
/*      */     //   127: dup
/*      */     //   128: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*      */     //   131: invokespecial <init> : (Lorg/bukkit/Material;)V
/*      */     //   134: aastore
/*      */     //   135: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   138: aastore
/*      */     //   139: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   142: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   147: pop
/*      */     //   148: iinc #8, 1
/*      */     //   151: goto -> 85
/*      */     //   154: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.packetPlayOutEntityEquipmentConstructor : Ljava/lang/reflect/Constructor;
/*      */     //   157: iconst_2
/*      */     //   158: anewarray java/lang/Object
/*      */     //   161: dup
/*      */     //   162: iconst_0
/*      */     //   163: iload_3
/*      */     //   164: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   167: aastore
/*      */     //   168: dup
/*      */     //   169: iconst_1
/*      */     //   170: aload_2
/*      */     //   171: aastore
/*      */     //   172: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   175: astore #6
/*      */     //   177: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.sendPacketMethod : Ljava/lang/reflect/Method;
/*      */     //   180: aload #5
/*      */     //   182: iconst_1
/*      */     //   183: anewarray java/lang/Object
/*      */     //   186: dup
/*      */     //   187: iconst_0
/*      */     //   188: aload #6
/*      */     //   190: aastore
/*      */     //   191: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   194: pop
/*      */     //   195: return
/*      */     //   196: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.EnumItemSlotClass : Ljava/lang/Class;
/*      */     //   199: invokevirtual getEnumConstants : ()[Ljava/lang/Object;
/*      */     //   202: astore #6
/*      */     //   204: aload #6
/*      */     //   206: arraylength
/*      */     //   207: istore #7
/*      */     //   209: iconst_0
/*      */     //   210: istore #8
/*      */     //   212: iload #8
/*      */     //   214: iload #7
/*      */     //   216: if_icmpge -> 301
/*      */     //   219: aload #6
/*      */     //   221: iload #8
/*      */     //   223: aaload
/*      */     //   224: astore #9
/*      */     //   226: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.packetPlayOutEntityEquipmentConstructor : Ljava/lang/reflect/Constructor;
/*      */     //   229: iconst_3
/*      */     //   230: anewarray java/lang/Object
/*      */     //   233: dup
/*      */     //   234: iconst_0
/*      */     //   235: iload_3
/*      */     //   236: invokestatic valueOf : (I)Ljava/lang/Integer;
/*      */     //   239: aastore
/*      */     //   240: dup
/*      */     //   241: iconst_1
/*      */     //   242: aload #9
/*      */     //   244: aastore
/*      */     //   245: dup
/*      */     //   246: iconst_2
/*      */     //   247: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.itemStackAsNMSCopyMethod : Ljava/lang/reflect/Method;
/*      */     //   250: aconst_null
/*      */     //   251: iconst_1
/*      */     //   252: anewarray java/lang/Object
/*      */     //   255: dup
/*      */     //   256: iconst_0
/*      */     //   257: new org/bukkit/inventory/ItemStack
/*      */     //   260: dup
/*      */     //   261: getstatic org/bukkit/Material.AIR : Lorg/bukkit/Material;
/*      */     //   264: invokespecial <init> : (Lorg/bukkit/Material;)V
/*      */     //   267: aastore
/*      */     //   268: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   271: aastore
/*      */     //   272: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   275: astore #10
/*      */     //   277: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.sendPacketMethod : Ljava/lang/reflect/Method;
/*      */     //   280: aload #5
/*      */     //   282: iconst_1
/*      */     //   283: anewarray java/lang/Object
/*      */     //   286: dup
/*      */     //   287: iconst_0
/*      */     //   288: aload #10
/*      */     //   290: aastore
/*      */     //   291: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   294: pop
/*      */     //   295: iinc #8, 1
/*      */     //   298: goto -> 212
/*      */     //   301: goto -> 309
/*      */     //   304: astore_2
/*      */     //   305: aload_2
/*      */     //   306: invokevirtual printStackTrace : ()V
/*      */     //   309: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1480	-> 0
/*      */     //   #1481	-> 8
/*      */     //   #1482	-> 26
/*      */     //   #1483	-> 45
/*      */     //   #1484	-> 55
/*      */     //   #1485	-> 69
/*      */     //   #1486	-> 99
/*      */     //   #1485	-> 148
/*      */     //   #1488	-> 154
/*      */     //   #1489	-> 177
/*      */     //   #1490	-> 195
/*      */     //   #1492	-> 196
/*      */     //   #1493	-> 226
/*      */     //   #1494	-> 277
/*      */     //   #1492	-> 295
/*      */     //   #1498	-> 301
/*      */     //   #1496	-> 304
/*      */     //   #1497	-> 305
/*      */     //   #1499	-> 309
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	195	304	java/lang/Exception
/*      */     //   196	301	304	java/lang/Exception
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object getArmorStandEquipment(Object paramObject) {
/*      */     // Byte code:
/*      */     //   0: new java/util/ArrayList
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_1
/*      */     //   8: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.EnumItemSlotClass : Ljava/lang/Class;
/*      */     //   11: invokevirtual getEnumConstants : ()[Ljava/lang/Object;
/*      */     //   14: astore_2
/*      */     //   15: aload_2
/*      */     //   16: arraylength
/*      */     //   17: istore_3
/*      */     //   18: iconst_0
/*      */     //   19: istore #4
/*      */     //   21: iload #4
/*      */     //   23: iload_3
/*      */     //   24: if_icmpge -> 80
/*      */     //   27: aload_2
/*      */     //   28: iload #4
/*      */     //   30: aaload
/*      */     //   31: astore #5
/*      */     //   33: aload_1
/*      */     //   34: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.pairConstructor : Ljava/lang/reflect/Constructor;
/*      */     //   37: iconst_2
/*      */     //   38: anewarray java/lang/Object
/*      */     //   41: dup
/*      */     //   42: iconst_0
/*      */     //   43: aload #5
/*      */     //   45: aastore
/*      */     //   46: dup
/*      */     //   47: iconst_1
/*      */     //   48: getstatic es/pollitoyeye/vehicles/utils/EntityUtils.armorStandGetEquipmentMethod : Ljava/lang/reflect/Method;
/*      */     //   51: aload_0
/*      */     //   52: iconst_1
/*      */     //   53: anewarray java/lang/Object
/*      */     //   56: dup
/*      */     //   57: iconst_0
/*      */     //   58: aload #5
/*      */     //   60: aastore
/*      */     //   61: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   64: aastore
/*      */     //   65: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   68: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   73: pop
/*      */     //   74: iinc #4, 1
/*      */     //   77: goto -> 21
/*      */     //   80: aload_1
/*      */     //   81: areturn
/*      */     //   82: astore_1
/*      */     //   83: aload_1
/*      */     //   84: invokevirtual printStackTrace : ()V
/*      */     //   87: aconst_null
/*      */     //   88: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1503	-> 0
/*      */     //   #1504	-> 8
/*      */     //   #1505	-> 33
/*      */     //   #1504	-> 74
/*      */     //   #1507	-> 80
/*      */     //   #1508	-> 82
/*      */     //   #1509	-> 83
/*      */     //   #1510	-> 87
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	81	82	java/lang/Exception
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void sendMetadataPacket(Player paramPlayer, Object paramObject1, Object paramObject2) {
/*      */     try {
/* 1516 */       int i = ((Integer)getIdMethod.invoke(paramObject1, new Object[0])).intValue();
/* 1517 */       Object object1 = null;
/* 1518 */       if (newMetadataPacketConstructor) {
/* 1519 */         Object object = dataWatcherGetListMethod.invoke(paramObject2, new Object[0]);
/* 1520 */         if (object == null) {
/*      */           return;
/*      */         }
/*      */         
/* 1524 */         object1 = packetPlayOutEntityMetadataConstructor.newInstance(new Object[] { Integer.valueOf(i), object });
/*      */       } else {
/* 1526 */         object1 = packetPlayOutEntityMetadataConstructor.newInstance(new Object[] { Integer.valueOf(i), paramObject2, Boolean.valueOf(true) });
/*      */       } 
/* 1528 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1529 */       Object object3 = playerConnectionField.get(object2);
/* 1530 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1531 */     } catch (Exception exception) {
/* 1532 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getMetadata(Object paramObject) {
/*      */     try {
/* 1538 */       return getDataWatcherMethod.invoke(paramObject, new Object[0]);
/*      */     }
/* 1540 */     catch (Exception exception) {
/* 1541 */       exception.printStackTrace();
/* 1542 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void sendLocationPacket(Object paramObject, Location paramLocation, Player paramPlayer) {
/*      */     try {
/* 1548 */       setLocationMethod.invoke(paramObject, new Object[] { Double.valueOf(paramLocation.getX()), Double.valueOf(paramLocation.getY()), Double.valueOf(paramLocation.getZ()), Float.valueOf(paramLocation.getYaw()), Integer.valueOf(0) });
/* 1549 */       Object object1 = getLocationPacket(paramObject, paramLocation);
/* 1550 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1551 */       Object object3 = playerConnectionField.get(object2);
/* 1552 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1553 */     } catch (Exception exception) {
/* 1554 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void sendPacket(Object paramObject, Player paramPlayer) {
/*      */     try {
/* 1560 */       Object object1 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1561 */       Object object2 = playerConnectionField.get(object1);
/* 1562 */       sendPacketMethod.invoke(object2, new Object[] { paramObject });
/* 1563 */     } catch (Exception exception) {
/* 1564 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Object getLocationPacket(Object paramObject, Location paramLocation) {
/*      */     try {
/* 1570 */       int i = ((Integer)getIdMethod.invoke(paramObject, new Object[0])).intValue();
/* 1571 */       Object object = null;
/* 1572 */       if (newPacketPlayOutEntityTeleport) {
/* 1573 */         Object object1 = positionMoveRotationConstructor.newInstance(new Object[] { vec3Constructor
/*      */               
/* 1575 */               .newInstance(new Object[] { Double.valueOf(paramLocation.getX()), Double.valueOf(paramLocation.getY()), Double.valueOf(paramLocation.getZ()) }), vec3Constructor
/* 1576 */               .newInstance(new Object[] { Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(0)
/* 1577 */                 }), Float.valueOf(paramLocation.getYaw()), 
/* 1578 */               Float.valueOf(paramLocation.getPitch()) });
/*      */ 
/*      */ 
/*      */         
/* 1582 */         object = packetPlayOutEntityTeleportConstructor.newInstance(new Object[] { Integer.valueOf(i), object1, Collections.EMPTY_SET, Boolean.valueOf(false) });
/*      */       } else {
/* 1584 */         object = packetPlayOutEntityTeleportConstructor.newInstance(new Object[] { paramObject });
/* 1585 */         packetPlayOutEntityTeleportAField.set(object, Integer.valueOf(i));
/* 1586 */         packetPlayOutEntityTeleportBField.set(object, Double.valueOf(paramLocation.getX()));
/* 1587 */         packetPlayOutEntityTeleportCField.set(object, Double.valueOf(paramLocation.getY()));
/* 1588 */         packetPlayOutEntityTeleportDField.set(object, Double.valueOf(paramLocation.getZ()));
/* 1589 */         packetPlayOutEntityTeleportEField.set(object, Byte.valueOf((byte)(int)(paramLocation.getYaw() * 256.0F / 360.0F)));
/* 1590 */         packetPlayOutEntityTeleportFField.set(object, Byte.valueOf((byte)(int)(paramLocation.getPitch() * 256.0F / 360.0F)));
/* 1591 */         packetPlayOutEntityTeleportGField.set(object, Boolean.valueOf(false));
/*      */       } 
/* 1593 */       return object;
/* 1594 */     } catch (Exception exception) {
/* 1595 */       exception.printStackTrace();
/* 1596 */       return null;
/*      */     } 
/*      */   }
/*      */   public static void sendYawPacket(Object paramObject, float paramFloat, Player paramPlayer) {
/*      */     try {
/* 1601 */       Object object1 = packetPlayOutEntityHeadRotationConstructor.newInstance(new Object[] { paramObject, Byte.valueOf((byte)(int)(paramFloat * 256.0F / 360.0F)) });
/* 1602 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1603 */       Object object3 = playerConnectionField.get(object2);
/* 1604 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1605 */     } catch (Exception exception) {
/* 1606 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setEntityInvisible(Object paramObject, Player paramPlayer) {
/*      */     try {
/* 1612 */       setInvisibleMethod.invoke(paramObject, new Object[] { Boolean.valueOf(true) });
/* 1613 */       int i = ((Integer)getIdMethod.invoke(paramObject, new Object[0])).intValue();
/* 1614 */       Object object1 = getDataWatcherMethod.invoke(paramObject, new Object[0]);
/* 1615 */       Object object2 = null;
/* 1616 */       if (newMetadataPacketConstructor) {
/* 1617 */         Object object = dataWatcherGetListMethod.invoke(object1, new Object[0]);
/* 1618 */         object2 = packetPlayOutEntityMetadataConstructor.newInstance(new Object[] { Integer.valueOf(i), object });
/*      */       } else {
/* 1620 */         object2 = packetPlayOutEntityMetadataConstructor.newInstance(new Object[] { Integer.valueOf(i), object1, Boolean.valueOf(true) });
/*      */       } 
/* 1622 */       Object object3 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1623 */       Object object4 = playerConnectionField.get(object3);
/* 1624 */       sendPacketMethod.invoke(object4, new Object[] { object2 });
/* 1625 */     } catch (Exception exception) {
/* 1626 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void sendRemovePacket(Player paramPlayer, Object paramObject) {
/*      */     try {
/* 1632 */       Object object1 = null;
/* 1633 */       if (minecraftVersion == 17 && bukkitVersion.contains("(MC: 1.17)")) {
/*      */         
/* 1635 */         object1 = packetPlayOutEntityDestroyConstructor.newInstance(new Object[] { Integer.valueOf(((Integer)getIdMethod.invoke(paramObject, new Object[0])).intValue()) });
/*      */       } else {
/*      */         
/* 1638 */         object1 = packetPlayOutEntityDestroyConstructor.newInstance(new Object[] { { ((Integer)getIdMethod.invoke(paramObject, new Object[0])).intValue() } });
/*      */       } 
/* 1640 */       Object object2 = getHandlePlayer.invoke(CraftPlayerClass.cast(paramPlayer), new Object[0]);
/* 1641 */       Object object3 = playerConnectionField.get(object2);
/* 1642 */       sendPacketMethod.invoke(object3, new Object[] { object1 });
/* 1643 */     } catch (Exception exception) {
/* 1644 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static double getCurrentFuel(ArmorStand paramArmorStand, VehicleSubType paramVehicleSubType) {
/* 1649 */     ItemStack itemStack = paramArmorStand.getEquipment().getBoots();
/* 1650 */     if (itemStack == null || itemStack.getType() != Material.STICK) {
/* 1651 */       return paramVehicleSubType.getFuelCapacity();
/*      */     }
/* 1653 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 1654 */     if (!itemMeta.hasDisplayName()) {
/* 1655 */       return paramVehicleSubType.getFuelCapacity();
/*      */     }
/* 1657 */     return Double.parseDouble(itemMeta.getDisplayName().replace(",", "."));
/*      */   }
/*      */   
/*      */   public static void setCurrentFuel(ArmorStand paramArmorStand, double paramDouble) {
/* 1661 */     ItemStack itemStack = new ItemStack(Material.STICK);
/* 1662 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 1663 */     itemMeta.setDisplayName("" + paramDouble);
/* 1664 */     itemStack.setItemMeta(itemMeta);
/* 1665 */     paramArmorStand.getEquipment().setBoots(itemStack);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BlockPlaceEvent createBlockPlaceEvent(Player paramPlayer, BlockState paramBlockState, Block paramBlock, ItemStack paramItemStack) {
/*      */     try {
/* 1681 */       BlockPlaceEvent blockPlaceEvent = new BlockPlaceEvent(paramBlock, paramBlock.getState(), paramBlock, paramItemStack, paramPlayer, true, EquipmentSlot.CHEST);
/* 1682 */       Bukkit.getServer().getPluginManager().callEvent((Event)blockPlaceEvent);
/* 1683 */       return blockPlaceEvent;
/* 1684 */     } catch (Exception exception) {
/* 1685 */       exception.printStackTrace();
/* 1686 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setModelGroup(ArmorStand paramArmorStand, int paramInt) {
/* 1691 */     PersistentDataContainer persistentDataContainer = paramArmorStand.getPersistentDataContainer();
/* 1692 */     persistentDataContainer.set(modelGroupKey, PersistentDataType.INTEGER, Integer.valueOf(paramInt));
/*      */   }
/*      */   
/*      */   public static int getModelGroup(ArmorStand paramArmorStand) {
/* 1696 */     PersistentDataContainer persistentDataContainer = paramArmorStand.getPersistentDataContainer();
/* 1697 */     if (!persistentDataContainer.has(modelGroupKey, PersistentDataType.INTEGER)) {
/* 1698 */       return 0;
/*      */     }
/* 1700 */     return ((Integer)persistentDataContainer.get(modelGroupKey, PersistentDataType.INTEGER)).intValue();
/*      */   }
/*      */   
/*      */   public static int getWorldMinY(World paramWorld) {
/* 1704 */     if (minecraftVersion < 18) {
/* 1705 */       return 0;
/*      */     }
/*      */     try {
/* 1708 */       Object object1 = getHandleWorld.invoke(craftWorld.cast(paramWorld), new Object[0]);
/* 1709 */       Object object2 = getDimensionManagerMethod.invoke(object1, new Object[0]);
/* 1710 */       Object object3 = getMinYField.invoke(object2, new Object[0]);
/* 1711 */       return ((Integer)object3).intValue();
/* 1712 */     } catch (Exception exception) {
/* 1713 */       exception.printStackTrace();
/*      */ 
/*      */       
/* 1716 */       return 0;
/*      */     } 
/*      */   }
/*      */   public static int getWorldMaxY(World paramWorld) {
/* 1720 */     if (minecraftVersion < 18) {
/* 1721 */       return 254;
/*      */     }
/*      */     try {
/* 1724 */       Object object1 = getHandleWorld.invoke(craftWorld.cast(paramWorld), new Object[0]);
/* 1725 */       Object object2 = getDimensionManagerMethod.invoke(object1, new Object[0]);
/* 1726 */       Object object3 = getHeightField.invoke(object2, new Object[0]);
/* 1727 */       int i = getWorldMinY(paramWorld);
/* 1728 */       return i + ((Integer)object3).intValue();
/* 1729 */     } catch (Exception exception) {
/* 1730 */       exception.printStackTrace();
/*      */       
/* 1732 */       return 254;
/*      */     } 
/*      */   }
/*      */   public static String getVersion() {
/* 1736 */     return version;
/*      */   }
/*      */   
/*      */   public static boolean isObfuscated() {
/* 1740 */     return obfuscated;
/*      */   }
/*      */   
/*      */   public static void spawnFlashParticle(Location paramLocation, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 1744 */     if (!obfuscated || minecraftVersion >= 21) {
/* 1745 */       paramLocation.getWorld().spawnParticle(Particle.FLASH, paramLocation, paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, Color.WHITE);
/*      */     } else {
/* 1747 */       paramLocation.getWorld().spawnParticle(Particle.FLASH, paramLocation, paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\EntityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */