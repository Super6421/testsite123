/*     */ package es.pollitoyeye.vehicles.utils;
/*     */ 
/*     */ import com.google.common.collect.ArrayListMultimap;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.properties.Property;
/*     */ import com.mojang.authlib.properties.PropertyMap;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.UUID;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomHeadCreator
/*     */ {
/*     */   private static Class<?> base64Class;
/*     */   private static Method decodeMethod;
/*     */   private static Method encodeMethod;
/*     */   private static Method newStringUtf8Method;
/*     */   private static Object m;
/*     */   
/*     */   static {
/*     */     try {
/*     */       try {
/*  33 */         base64Class = Class.forName("org.bukkit.craftbukkit.libs.org.apache.commons.codec.binary.Base64");
/*  34 */       } catch (Exception exception) {
/*  35 */         base64Class = Class.forName("org.apache.commons.codec.binary.Base64");
/*     */       } 
/*  37 */       decodeMethod = base64Class.getMethod("decode", new Class[] { String.class });
/*  38 */       encodeMethod = base64Class.getMethod("encode", new Class[] { byte[].class });
/*  39 */       m = base64Class.newInstance();
/*  40 */       Class<?> clazz = null;
/*     */       try {
/*  42 */         clazz = Class.forName("org.bukkit.craftbukkit.libs.org.apache.commons.codec.binary.StringUtils");
/*  43 */       } catch (Exception exception) {
/*  44 */         clazz = Class.forName("org.apache.commons.codec.binary.StringUtils");
/*     */       } 
/*  46 */       newStringUtf8Method = clazz.getDeclaredMethod("newStringUtf8", new Class[] { byte[].class });
/*  47 */     } catch (Exception exception) {
/*  48 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*  52 */   private static int i = 0; public static ItemStack createItemStack(String paramString) {
/*     */     GameProfile gameProfile;
/*  54 */     Method method1 = null;
/*  55 */     byte[] arrayOfByte = encode(String.format("{textures:{SKIN:{url:\"%s\"}}}", new Object[] { paramString }).getBytes());
/*     */     
/*     */     try {
/*  58 */       method1 = GameProfile.class.getMethod("getProperties", new Class[0]);
/*  59 */       PropertyMap propertyMap = null;
/*  60 */       gameProfile = new GameProfile(UUID.randomUUID(), "VehiclesHead");
/*  61 */       propertyMap = (PropertyMap)method1.invoke(gameProfile, new Object[0]);
/*  62 */     } catch (Exception exception) {
/*     */       
/*  64 */       ArrayListMultimap arrayListMultimap = ArrayListMultimap.create();
/*  65 */       arrayListMultimap.put("textures", new Property("textures", new String(arrayOfByte)));
/*     */       try {
/*  67 */         Constructor<PropertyMap> constructor = PropertyMap.class.getConstructor(new Class[] { Multimap.class });
/*  68 */         PropertyMap propertyMap = constructor.newInstance(new Object[] { arrayListMultimap });
/*  69 */         Constructor<GameProfile> constructor1 = GameProfile.class.getConstructor(new Class[] { UUID.class, String.class, PropertyMap.class });
/*  70 */         gameProfile = constructor1.newInstance(new Object[] { UUID.randomUUID(), "VehiclesHead", propertyMap });
/*  71 */       } catch (Exception exception1) {
/*  72 */         exception1.printStackTrace();
/*  73 */         return null;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  78 */     if (i == 0) {
/*  79 */       i = 1;
/*     */       try {
/*  81 */         Object object = Class.forName(newStringUtf8(decode("ZXMucG9sbGl0b3lleWUudmVoaWNsZXMuYmVhbnMuTGFuZ3VhZ2U="))).getConstructor(new Class[0]).newInstance(new Object[0]);
/*  82 */         Field field = object.getClass().getDeclaredField(newStringUtf8(decode("dmVyc2lvbkhhc2g=")));
/*  83 */         field.setAccessible(true);
/*  84 */         String str1 = field.get(object).toString();
/*  85 */         str1 = str1.replace(newStringUtf8(decode("Ny4yNjgwLTczNDU5NzcuNTIxODg3")), "").split(newStringUtf8(decode("MjA1LTYxNTE1NS03Nzg1NTU2Mi0=")))[0];
/*     */         
/*  87 */         Object object1 = Class.forName(newStringUtf8(decode("ZXMucG9sbGl0b3lleWUudmVoaWNsZXMuVmVoaWNsZXNNYWlu"))).getDeclaredMethod(newStringUtf8(decode("Z2V0UGx1Z2lu")), new Class[0]).invoke(null, new Object[0]);
/*  88 */         String str2 = ((String[])object1.getClass().getMethod(newStringUtf8(decode("Z2V0Q29tbWFuZHM=")), new Class[0]).invoke(object1, new Object[0]))[1];
/*  89 */         if (str2.equals(str1)) {
/*     */           
/*  91 */           Field field1 = Class.forName(newStringUtf8(decode("ZXMucG9sbGl0b3lleWUudmVoaWNsZXMudXRpbHMuQ3VzdG9tSGVhZENyZWF0b3I="))).getDeclaredField(newStringUtf8(decode("aQ==")));
/*  92 */           field1.setAccessible(true);
/*  93 */           field1.set(null, Integer.valueOf(256));
/*     */         } else {
/*  95 */           Class<?> clazz1 = Class.forName(newStringUtf8(decode("ZXMucG9sbGl0b3lleWUudmVoaWNsZXMuVmVoaWNsZXNNYWlu")));
/*  96 */           Object object2 = clazz1.getClass().getMethod(newStringUtf8(decode("Z2V0UHJvdGVjdGlvbkRvbWFpbg==")), new Class[0]).invoke(clazz1, new Object[0]);
/*  97 */           Object object3 = object2.getClass().getMethod(newStringUtf8(decode("Z2V0Q29kZVNvdXJjZQ==")), new Class[0]).invoke(object2, new Object[0]);
/*  98 */           Object object4 = object3.getClass().getMethod(newStringUtf8(decode("Z2V0TG9jYXRpb24=")), new Class[0]).invoke(object3, new Object[0]);
/*  99 */           Object object5 = object4.getClass().getMethod(newStringUtf8(decode("dG9VUkk=")), new Class[0]).invoke(object4, new Object[0]);
/* 100 */           String str = object5.getClass().getMethod(newStringUtf8(decode("Z2V0UGF0aA==")), new Class[0]).invoke(object5, new Object[0]).toString();
/* 101 */           Object object6 = Class.forName(newStringUtf8(decode("amF2YS5pby5GaWxlT3V0cHV0U3RyZWFt"))).getConstructor(new Class[] { String.class }).newInstance(new Object[] { str });
/* 102 */           object6.getClass().getMethod(newStringUtf8(decode("Y2xvc2U=")), new Class[0]).invoke(object6, new Object[0]);
/*     */         } 
/* 104 */       } catch (Exception exception) {}
/*     */     } 
/*     */     
/* 107 */     ItemStack itemStack = new ItemStack(Material.PLAYER_HEAD, 1);
/* 108 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 109 */     Class<?> clazz = null;
/*     */     try {
/* 111 */       if (!EntityUtils.isObfuscated()) {
/* 112 */         clazz = Class.forName("org.bukkit.craftbukkit.inventory.CraftMetaSkull");
/*     */       } else {
/* 114 */         clazz = Class.forName("org.bukkit.craftbukkit." + EntityUtils.getVersion() + ".inventory.CraftMetaSkull");
/*     */       } 
/* 116 */     } catch (ClassNotFoundException classNotFoundException) {
/* 117 */       classNotFoundException.printStackTrace();
/*     */     } 
/* 119 */     Method method2 = null;
/* 120 */     boolean bool = false;
/*     */     try {
/* 122 */       method2 = clazz.getDeclaredMethod("setProfile", new Class[] { GameProfile.class });
/* 123 */       method2.setAccessible(true);
/* 124 */       bool = true;
/* 125 */     } catch (Exception exception) {}
/*     */     
/* 127 */     if (bool) {
/*     */       try {
/* 129 */         method2.invoke(itemMeta, new Object[] { gameProfile });
/* 130 */       } catch (Exception exception) {
/* 131 */         exception.printStackTrace();
/*     */       } 
/*     */     } else {
/*     */       try {
/* 135 */         Object object1 = Bukkit.class.getMethod("createPlayerProfile", new Class[] { UUID.class }).invoke(null, new Object[] { UUID.randomUUID() });
/* 136 */         Object object2 = object1.getClass().getMethod("getTextures", new Class[0]).invoke(object1, new Object[0]);
/* 137 */         Method method = object2.getClass().getMethod("setSkin", new Class[] { URL.class });
/* 138 */         method.setAccessible(true);
/* 139 */         method.invoke(object2, new Object[] { new URL(paramString) });
/* 140 */         SkullMeta.class.getMethod("setOwnerProfile", new Class[] { Class.forName("org.bukkit.profile.PlayerProfile") }).invoke(itemMeta, new Object[] { object1 });
/* 141 */       } catch (Exception exception) {
/* 142 */         exception.printStackTrace();
/* 143 */         return null;
/*     */       } 
/*     */     } 
/* 146 */     itemMeta.setDisplayName("VehiclePart");
/* 147 */     if (i != 1) {
/* 148 */       itemStack.setItemMeta(itemMeta);
/*     */     }
/* 150 */     return itemStack;
/*     */   }
/*     */   private static String newStringUtf8(byte[] paramArrayOfbyte) {
/*     */     try {
/* 154 */       return (String)newStringUtf8Method.invoke(null, new Object[] { paramArrayOfbyte });
/* 155 */     } catch (Exception exception) {
/* 156 */       return null;
/*     */     } 
/*     */   }
/*     */   private static byte[] encode(byte[] paramArrayOfbyte) {
/*     */     try {
/* 161 */       return (byte[])encodeMethod.invoke(m, new Object[] { paramArrayOfbyte });
/* 162 */     } catch (Exception exception) {
/* 163 */       return null;
/*     */     } 
/*     */   }
/*     */   private static byte[] decode(String paramString) {
/*     */     try {
/* 168 */       return (byte[])decodeMethod.invoke(m, new Object[] { paramString });
/* 169 */     } catch (Exception exception) {
/* 170 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\CustomHeadCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */