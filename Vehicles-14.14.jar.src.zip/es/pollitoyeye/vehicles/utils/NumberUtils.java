/*    */ package es.pollitoyeye.vehicles.utils;
/*    */ 
/*    */ import java.math.RoundingMode;
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class NumberUtils {
/*    */   private static NumberUtils instance;
/*    */   
/*    */   public static NumberUtils getInstance() {
/* 12 */     if (instance == null) {
/* 13 */       instance = new NumberUtils();
/*    */     }
/* 15 */     return instance;
/*    */   }
/*    */   
/*    */   private DecimalFormat firstCharsFormat;
/*    */   
/*    */   NumberUtils() {
/* 21 */     NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.ROOT);
/* 22 */     this.firstCharsFormat = (DecimalFormat)numberFormat;
/* 23 */     this.firstCharsFormat.applyPattern("0.000");
/* 24 */     this.firstCharsFormat.setRoundingMode(RoundingMode.DOWN);
/* 25 */     numberFormat = NumberFormat.getNumberInstance(Locale.ROOT);
/* 26 */     this.lastDigitsFormat = (DecimalFormat)numberFormat;
/* 27 */     this.lastDigitsFormat.applyPattern("##.##");
/*    */   }
/*    */   private DecimalFormat lastDigitsFormat;
/*    */   public String firstChars(double paramDouble) {
/* 31 */     return this.firstCharsFormat.format(paramDouble).replace(",", ".");
/*    */   }
/*    */   
/*    */   public String getLastDigitsDouble(double paramDouble) {
/* 35 */     return this.lastDigitsFormat.format(paramDouble).replace(",", ".");
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\NumberUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */