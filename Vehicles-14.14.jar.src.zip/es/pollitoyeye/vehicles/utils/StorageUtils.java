/*     */ package es.pollitoyeye.vehicles.utils;
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.NBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadWriteNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.iface.ReadableNBT;
/*     */ import es.pollitoyeye.vehicles.libs.nbtapi.utils.DataFixerUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.NamespacedKey;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.block.ShulkerBox;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.BlockStateMeta;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.persistence.PersistentDataContainer;
/*     */ import org.bukkit.persistence.PersistentDataType;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class StorageUtils {
/*     */   public static void saveInventoryToItem(ItemStack[] paramArrayOfItemStack, ItemStack paramItemStack) {
/*  30 */     NamespacedKey namespacedKey1 = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "Storage");
/*  31 */     NamespacedKey namespacedKey2 = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "SVersion");
/*  32 */     ItemMeta itemMeta = paramItemStack.getItemMeta();
/*  33 */     PersistentDataContainer persistentDataContainer = itemMeta.getPersistentDataContainer();
/*  34 */     ArrayList<byte[]> arrayList = new ArrayList();
/*  35 */     for (ItemStack itemStack : paramArrayOfItemStack) {
/*  36 */       if (itemStack != null)
/*     */       {
/*     */         
/*  39 */         arrayList.add(serializeItemStack(itemStack)); } 
/*     */     } 
/*     */     try {
/*  42 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*  43 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/*  44 */       objectOutputStream.writeObject(arrayList);
/*  45 */       persistentDataContainer.set(namespacedKey1, PersistentDataType.BYTE_ARRAY, byteArrayOutputStream.toByteArray());
/*  46 */       persistentDataContainer.set(namespacedKey2, PersistentDataType.INTEGER, Integer.valueOf(4323));
/*  47 */       objectOutputStream.close();
/*  48 */     } catch (Exception exception) {
/*  49 */       exception.printStackTrace();
/*     */     } 
/*  51 */     paramItemStack.setItemMeta(itemMeta);
/*     */   }
/*     */   
/*     */   public static void loadInventoryIntoArmorStand(ArmorStand paramArmorStand, ItemStack paramItemStack) {
/*  55 */     ArrayList<ItemStack> arrayList = new ArrayList();
/*  56 */     NamespacedKey namespacedKey1 = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "Storage");
/*  57 */     NamespacedKey namespacedKey2 = new NamespacedKey((Plugin)VehiclesMain.getPlugin(), "SVersion");
/*  58 */     ItemMeta itemMeta = paramItemStack.getItemMeta();
/*  59 */     PersistentDataContainer persistentDataContainer = itemMeta.getPersistentDataContainer();
/*  60 */     if (persistentDataContainer.has(namespacedKey1, PersistentDataType.BYTE_ARRAY)) {
/*     */       
/*     */       try {
/*  63 */         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream((byte[])persistentDataContainer.get(namespacedKey1, PersistentDataType.BYTE_ARRAY));
/*  64 */         ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
/*  65 */         int i = 3837;
/*  66 */         if (persistentDataContainer.has(namespacedKey2, PersistentDataType.INTEGER)) {
/*  67 */           i = ((Integer)persistentDataContainer.get(namespacedKey2, PersistentDataType.INTEGER)).intValue();
/*     */         }
/*     */ 
/*     */         
/*  71 */         ArrayList arrayList1 = (ArrayList)objectInputStream.readObject();
/*  72 */         for (byte[] arrayOfByte : arrayList1) {
/*  73 */           arrayList.add(deserializeItemStack(arrayOfByte, i));
/*     */         }
/*  75 */         objectInputStream.close();
/*  76 */       } catch (Exception exception) {
/*  77 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*  80 */     ItemStack itemStack = new ItemStack(Material.SHULKER_BOX, 1);
/*  81 */     BlockStateMeta blockStateMeta = (BlockStateMeta)itemStack.getItemMeta();
/*  82 */     ShulkerBox shulkerBox = (ShulkerBox)blockStateMeta.getBlockState();
/*  83 */     shulkerBox.getInventory().setContents(arrayList.<ItemStack>toArray(new ItemStack[arrayList.size()]));
/*  84 */     shulkerBox.update();
/*  85 */     blockStateMeta.setBlockState((BlockState)shulkerBox);
/*  86 */     itemStack.setItemMeta((ItemMeta)blockStateMeta);
/*  87 */     paramArmorStand.getEquipment().setLeggings(itemStack);
/*     */   }
/*     */   
/*     */   public static byte[] serializeItemStack(ItemStack paramItemStack) {
/*  91 */     int i = EntityUtils.minecraftVersion;
/*  92 */     if (!EntityUtils.obfuscated || i > 21 || (i == 21 && EntityUtils.minecraftSubVersion >= 5)) {
/*  93 */       return serializeItemStack_21_8(paramItemStack);
/*     */     }
/*  95 */     if (i > 21 || (i == 21 && EntityUtils.minecraftSubVersion >= 4)) {
/*  96 */       return serializeItemStack_20_5(paramItemStack);
/*     */     }
/*  98 */     if (i > 20 || (i == 20 && EntityUtils.minecraftSubVersion >= 4)) {
/*  99 */       return serializeItemStack_20_4(paramItemStack);
/*     */     }
/* 101 */     return serializeItemStack_20_0(paramItemStack);
/*     */   }
/*     */   
/*     */   private static byte[] serializeItemStack_20_5(ItemStack paramItemStack) {
/* 105 */     if (paramItemStack == null)
/* 106 */       return null; 
/* 107 */     ByteArrayOutputStream byteArrayOutputStream = null;
/*     */     try {
/* 109 */       Class<?> clazz1 = getNMSClass("NBTTagCompound", "net.minecraft.nbt");
/* 110 */       Class<?> clazz2 = getNMSClass("NBTBase", "net.minecraft.nbt");
/*     */       
/* 112 */       Object object1 = getOBClass("inventory.CraftItemStack").getMethod("asNMSCopy", new Class[] { ItemStack.class }).invoke(null, new Object[] { paramItemStack });
/* 113 */       Class<?> clazz3 = getOBClass("CraftRegistry");
/* 114 */       Method method = clazz3.getDeclaredMethod("getMinecraftRegistry", new Class[0]);
/* 115 */       Object object2 = method.invoke(null, new Object[0]);
/* 116 */       String str = "b";
/* 117 */       Object object3 = clazz1.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 118 */       if (paramItemStack.getType() != Material.AIR) {
/* 119 */         object3 = getNMSClass("ItemStack", "net.minecraft.world.item").getMethod(str, new Class[] { Class.forName("net.minecraft.core.HolderLookup$a"), clazz2 }).invoke(object1, new Object[] { object2, object3 });
/*     */       }
/*     */       
/* 122 */       byteArrayOutputStream = new ByteArrayOutputStream();
/* 123 */       getNMSClass("NBTCompressedStreamTools", "net.minecraft.nbt")
/* 124 */         .getMethod("a", new Class[] { clazz1, OutputStream.class }).invoke(null, new Object[] { object3, byteArrayOutputStream });
/* 125 */     } catch (Exception exception) {
/* 126 */       exception.printStackTrace();
/*     */     } 
/* 128 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] serializeItemStack_20_4(ItemStack paramItemStack) {
/* 133 */     if (paramItemStack == null)
/* 134 */       return null; 
/* 135 */     ByteArrayOutputStream byteArrayOutputStream = null;
/*     */     try {
/* 137 */       Class<?> clazz1 = getNMSClass("NBTTagCompound", "net.minecraft.nbt");
/*     */       
/* 139 */       Object object1 = getOBClass("inventory.CraftItemStack").getMethod("asNMSCopy", new Class[] { ItemStack.class }).invoke(null, new Object[] { paramItemStack });
/* 140 */       Class<?> clazz2 = getOBClass("CraftRegistry");
/* 141 */       Method method = clazz2.getDeclaredMethod("getMinecraftRegistry", new Class[0]);
/* 142 */       Object object2 = method.invoke(null, new Object[0]);
/* 143 */       String str = "b";
/* 144 */       Object object3 = getNMSClass("ItemStack", "net.minecraft.world.item").getMethod(str, new Class[] { Class.forName("net.minecraft.core.HolderLookup$a") }).invoke(object1, new Object[] { object2 });
/*     */       
/* 146 */       byteArrayOutputStream = new ByteArrayOutputStream();
/* 147 */       getNMSClass("NBTCompressedStreamTools", "net.minecraft.nbt")
/* 148 */         .getMethod("a", new Class[] { clazz1, OutputStream.class }).invoke(null, new Object[] { object3, byteArrayOutputStream });
/* 149 */     } catch (Exception exception) {
/* 150 */       exception.printStackTrace();
/*     */     } 
/* 152 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] serializeItemStack_20_0(ItemStack paramItemStack) {
/* 157 */     if (paramItemStack == null)
/* 158 */       return null; 
/* 159 */     ByteArrayOutputStream byteArrayOutputStream = null;
/*     */     try {
/* 161 */       Class<?> clazz = getNMSClass("NBTTagCompound", "net.minecraft.nbt");
/* 162 */       Constructor<?> constructor = clazz.getConstructor(new Class[0]);
/* 163 */       Object object1 = constructor.newInstance(new Object[0]);
/*     */       
/* 165 */       Object object2 = getOBClass("inventory.CraftItemStack").getMethod("asNMSCopy", new Class[] { ItemStack.class }).invoke(null, new Object[] { paramItemStack });
/* 166 */       String str = "save";
/* 167 */       if (EntityUtils.minecraftVersion >= 18) {
/* 168 */         str = "b";
/*     */       }
/* 170 */       getNMSClass("ItemStack", "net.minecraft.world.item").getMethod(str, new Class[] { clazz }).invoke(object2, new Object[] { object1 });
/*     */       
/* 172 */       byteArrayOutputStream = new ByteArrayOutputStream();
/* 173 */       getNMSClass("NBTCompressedStreamTools", "net.minecraft.nbt")
/* 174 */         .getMethod("a", new Class[] { clazz, OutputStream.class }).invoke(null, new Object[] { object1, byteArrayOutputStream });
/* 175 */     } catch (Exception exception) {
/* 176 */       exception.printStackTrace();
/*     */     } 
/* 178 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */   
/*     */   public static ItemStack deserializeItemStack(byte[] paramArrayOfbyte, int paramInt) {
/* 182 */     if (!EntityUtils.obfuscated || paramInt > 21 || (paramInt == 21 && EntityUtils.minecraftSubVersion >= 5)) {
/* 183 */       return deserializeItemStack_21_8(paramArrayOfbyte, paramInt);
/*     */     }
/* 185 */     if (paramInt > 20 || (paramInt == 20 && EntityUtils.minecraftSubVersion >= 4)) {
/* 186 */       return deserializeItemStack_20_4(paramArrayOfbyte);
/*     */     }
/* 188 */     return deserializeItemStack_20_0(paramArrayOfbyte);
/*     */   }
/*     */   
/*     */   private static byte[] serializeItemStack_21_8(ItemStack paramItemStack) {
/* 192 */     if (paramItemStack == null) {
/* 193 */       return null;
/*     */     }
/* 195 */     ReadWriteNBT readWriteNBT = NBT.itemStackToNBT(paramItemStack);
/* 196 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 197 */     readWriteNBT.writeCompound(byteArrayOutputStream);
/*     */     
/* 199 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ItemStack deserializeItemStack_21_8(byte[] paramArrayOfbyte, int paramInt) {
/* 204 */     if (paramArrayOfbyte == null) {
/* 205 */       return null;
/*     */     }
/* 207 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 208 */     ReadWriteNBT readWriteNBT = null;
/*     */     try {
/* 210 */       readWriteNBT = NBT.readNBT(byteArrayInputStream);
/* 211 */       int i = DataFixerUtil.getCurrentVersion();
/* 212 */       if (paramInt != i)
/*     */       {
/* 214 */         readWriteNBT = DataFixerUtil.fixUpItemData(readWriteNBT, paramInt, DataFixerUtil.getCurrentVersion());
/*     */       }
/* 216 */     } catch (Exception exception) {
/* 217 */       exception.printStackTrace();
/*     */     } 
/* 219 */     return NBT.itemStackFromNBT((ReadableNBT)readWriteNBT);
/*     */   }
/*     */   
/*     */   public static ItemStack deserializeItemStack_20_4(byte[] paramArrayOfbyte) {
/* 223 */     if (paramArrayOfbyte == null) {
/* 224 */       return null;
/*     */     }
/* 226 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 227 */     Class<?> clazz1 = getNMSClass("NBTBase", "net.minecraft.nbt");
/* 228 */     Class<?> clazz2 = getNMSClass("ItemStack", "net.minecraft.world.item");
/* 229 */     Object object = null;
/* 230 */     ItemStack itemStack = null;
/*     */     try {
/* 232 */       Class<?> clazz3 = getNMSClass("NBTReadLimiter", "net.minecraft.nbt");
/* 233 */       Method method1 = clazz3.getMethod("a", new Class[0]);
/*     */       
/* 235 */       object = getNMSClass("NBTCompressedStreamTools", "net.minecraft.nbt").getMethod("a", new Class[] { InputStream.class, clazz3 }).invoke(null, new Object[] { byteArrayInputStream, method1.invoke(null, new Object[0]) });
/* 236 */       Class<?> clazz4 = getOBClass("CraftRegistry");
/* 237 */       Method method2 = clazz4.getDeclaredMethod("getMinecraftRegistry", new Class[0]);
/* 238 */       Object object1 = method2.invoke(null, new Object[0]);
/* 239 */       Object object2 = clazz2.getMethod("a", new Class[] { Class.forName("net.minecraft.core.HolderLookup$a"), clazz1 }).invoke(null, new Object[] { object1, object });
/*     */ 
/*     */       
/* 242 */       Object object3 = Class.forName("java.util.Optional").getMethod("get", new Class[0]).invoke(object2, new Object[0]);
/*     */       
/* 244 */       itemStack = (ItemStack)getOBClass("inventory.CraftItemStack").getMethod("asBukkitCopy", new Class[] { clazz2 }).invoke(null, new Object[] { object3 });
/* 245 */     } catch (Exception exception) {
/* 246 */       exception.printStackTrace();
/*     */     } 
/* 248 */     return itemStack;
/*     */   }
/*     */   
/*     */   public static ItemStack deserializeItemStack_20_0(byte[] paramArrayOfbyte) {
/* 252 */     if (paramArrayOfbyte == null) {
/* 253 */       return null;
/*     */     }
/* 255 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/* 256 */     Class<?> clazz1 = getNMSClass("NBTTagCompound", "net.minecraft.nbt");
/* 257 */     Class<?> clazz2 = getNMSClass("ItemStack", "net.minecraft.world.item");
/* 258 */     Object object = null;
/* 259 */     ItemStack itemStack = null;
/*     */     try {
/* 261 */       boolean bool = false;
/* 262 */       Class<?> clazz = null;
/* 263 */       Method method = null;
/* 264 */       if (EntityUtils.minecraftVersion > 20 || (EntityUtils.minecraftVersion == 20 && EntityUtils.minecraftSubVersion >= 3)) {
/* 265 */         bool = true;
/* 266 */         clazz = getNMSClass("NBTReadLimiter", "net.minecraft.nbt");
/* 267 */         method = clazz.getMethod("a", new Class[0]);
/*     */       } 
/* 269 */       (new Class[2])[0] = InputStream.class; (new Class[2])[1] = clazz; (new Class[1])[0] = InputStream.class;
/* 270 */       (new Object[2])[0] = byteArrayInputStream; (new Object[2])[1] = method.invoke(null, new Object[0]); (new Object[1])[0] = byteArrayInputStream; object = getNMSClass("NBTCompressedStreamTools", "net.minecraft.nbt").getMethod("a", bool ? new Class[2] : new Class[1]).invoke(null, bool ? new Object[2] : new Object[1]);
/* 271 */       Object object1 = clazz2.getMethod("a", new Class[] { clazz1 }).invoke(null, new Object[] { object });
/*     */ 
/*     */       
/* 274 */       itemStack = (ItemStack)getOBClass("inventory.CraftItemStack").getMethod("asBukkitCopy", new Class[] { clazz2 }).invoke(null, new Object[] { object1 });
/* 275 */     } catch (Exception exception) {
/* 276 */       exception.printStackTrace();
/*     */     } 
/* 278 */     return itemStack;
/*     */   }
/*     */   
/*     */   public static Class<?> getNMSClass(String paramString1, String paramString2) {
/* 282 */     String str1 = EntityUtils.getVersion();
/* 283 */     int i = EntityUtils.minecraftVersion;
/* 284 */     String str2 = "net.minecraft.server." + str1 + "." + paramString1;
/* 285 */     if (i >= 17) {
/* 286 */       str2 = paramString2 + "." + paramString1;
/*     */     }
/* 288 */     Class<?> clazz = null;
/*     */     try {
/* 290 */       clazz = Class.forName(str2);
/* 291 */     } catch (ClassNotFoundException classNotFoundException) {
/* 292 */       classNotFoundException.printStackTrace();
/* 293 */       System.err.println("Unable to find reflection class " + str2 + "!");
/*     */     } 
/* 295 */     return clazz;
/*     */   }
/*     */   
/*     */   public static Class<?> getOBClass(String paramString) {
/* 299 */     String str1 = EntityUtils.getVersion();
/* 300 */     String str2 = "org.bukkit.craftbukkit." + str1 + "." + paramString;
/* 301 */     Class<?> clazz = null;
/*     */     try {
/* 303 */       clazz = Class.forName(str2);
/* 304 */     } catch (ClassNotFoundException classNotFoundException) {
/* 305 */       classNotFoundException.printStackTrace();
/* 306 */       System.err.println("Unable to find reflection class " + str2 + "!");
/*     */     } 
/* 308 */     return clazz;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicle\\utils\StorageUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */