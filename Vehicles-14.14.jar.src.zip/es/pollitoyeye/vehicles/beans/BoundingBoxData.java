/*    */ package es.pollitoyeye.vehicles.beans;
/*    */ 
/*    */ 
/*    */ public class BoundingBoxData
/*    */ {
/*    */   private double height;
/*    */   private double xWidth;
/*    */   
/*    */   public BoundingBoxData(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 10 */     this.height = paramDouble1;
/* 11 */     setHeightOffset(paramDouble2);
/* 12 */     this.xWidth = paramDouble3;
/* 13 */     this.zWidth = paramDouble4;
/*    */   } private double zWidth; private double heightOffset; public BoundingBoxData() {}
/*    */   public double getHeight() {
/* 16 */     return this.height;
/*    */   }
/*    */   public void setHeight(double paramDouble) {
/* 19 */     this.height = paramDouble;
/*    */   }
/*    */   public double getZWidth() {
/* 22 */     return this.zWidth;
/*    */   }
/*    */   public void setZWidth(double paramDouble) {
/* 25 */     this.zWidth = paramDouble;
/*    */   }
/*    */   public double getXWidth() {
/* 28 */     return this.xWidth;
/*    */   }
/*    */   public void setXWidth(double paramDouble) {
/* 31 */     this.xWidth = paramDouble;
/*    */   }
/*    */   public double getHeightOffset() {
/* 34 */     return this.heightOffset;
/*    */   }
/*    */   public void setHeightOffset(double paramDouble) {
/* 37 */     this.heightOffset = paramDouble;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\beans\BoundingBoxData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */