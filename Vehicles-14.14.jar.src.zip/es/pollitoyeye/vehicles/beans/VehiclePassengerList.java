/*    */ package es.pollitoyeye.vehicles.beans;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*    */ import java.util.ArrayList;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class VehiclePassengerList<K>
/*    */   extends ArrayList<K>
/*    */ {
/*    */   private static final long serialVersionUID = -2989387673529876658L;
/*    */   private Object vehicle;
/*    */   
/*    */   public boolean remove(Object paramObject) {
/* 14 */     if (paramObject.getClass().getSimpleName().equals("EntityPlayer")) {
/* 15 */       Player player = EntityUtils.getPlayerFromEntityPlayer(paramObject);
/* 16 */       if (!player.isSneaking() && player.getHealth() > 0.0D && EntityUtils.getVehicle(paramObject) == null) {
/* 17 */         EntityUtils.setVehicle(paramObject, this.vehicle);
/* 18 */         return false;
/*    */       } 
/*    */     } 
/* 21 */     return super.remove(paramObject);
/*    */   }
/*    */   public void setVehicle(Object paramObject) {
/* 24 */     this.vehicle = paramObject;
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\beans\VehiclePassengerList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */