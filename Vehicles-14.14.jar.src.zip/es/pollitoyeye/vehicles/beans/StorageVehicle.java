/*     */ package es.pollitoyeye.vehicles.beans;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.events.VehicleInventoryOpenEvent;
/*     */ import es.pollitoyeye.vehicles.interfaces.Vehicle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.BlockState;
/*     */ import org.bukkit.block.ShulkerBox;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.BlockStateMeta;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public abstract class StorageVehicle implements Vehicle {
/*     */   private Inventory inv;
/*     */   
/*     */   public StorageVehicle(ArmorStand paramArmorStand) {
/*  26 */     this.mainStand = paramArmorStand;
/*     */   }
/*     */   private ArmorStand mainStand;
/*     */   public void openStorage(Player paramPlayer) {
/*  30 */     if (isStorageOpen()) {
/*     */       return;
/*     */     }
/*  33 */     VehicleInventoryOpenEvent vehicleInventoryOpenEvent = new VehicleInventoryOpenEvent(paramPlayer, this);
/*  34 */     Bukkit.getPluginManager().callEvent((Event)vehicleInventoryOpenEvent);
/*  35 */     if (vehicleInventoryOpenEvent.isCancelled()) {
/*     */       return;
/*     */     }
/*  38 */     Inventory inventory = Bukkit.createInventory(null, 27, VehiclesMain.getPlugin().getLang().getValue("vehicle-storage-title"));
/*  39 */     inventory.setContents(getInventory().getContents());
/*  40 */     this.inv = inventory;
/*  41 */     paramPlayer.openInventory(this.inv);
/*     */   }
/*     */   
/*     */   public ArrayList<ItemStack> addItemsToStorage(Collection<ItemStack> paramCollection) {
/*  45 */     boolean bool = isStorageOpen();
/*  46 */     Inventory inventory = getInventory();
/*  47 */     ArrayList<ItemStack> arrayList = new ArrayList();
/*  48 */     for (ItemStack itemStack : paramCollection) {
/*  49 */       for (ItemStack itemStack1 : inventory.addItem(new ItemStack[] { itemStack }).values()) {
/*  50 */         arrayList.add(itemStack1);
/*     */       }
/*     */     } 
/*  53 */     if (!bool) {
/*  54 */       ItemStack itemStack = new ItemStack(Material.SHULKER_BOX, 1);
/*  55 */       BlockStateMeta blockStateMeta = (BlockStateMeta)itemStack.getItemMeta();
/*  56 */       ShulkerBox shulkerBox = (ShulkerBox)blockStateMeta.getBlockState();
/*  57 */       shulkerBox.getInventory().setContents(inventory.getContents());
/*  58 */       shulkerBox.update();
/*  59 */       blockStateMeta.setBlockState((BlockState)shulkerBox);
/*  60 */       itemStack.setItemMeta((ItemMeta)blockStateMeta);
/*  61 */       this.mainStand.getEquipment().setLeggings(itemStack);
/*     */     } 
/*  63 */     return arrayList;
/*     */   }
/*     */   public Inventory getInventory() {
/*  66 */     if (isStorageOpen()) {
/*  67 */       return this.inv;
/*     */     }
/*  69 */     ItemStack itemStack = this.mainStand.getEquipment().getLeggings();
/*  70 */     if (itemStack == null || itemStack.getType() != Material.SHULKER_BOX) {
/*  71 */       itemStack = new ItemStack(Material.SHULKER_BOX, 1);
/*     */     }
/*  73 */     BlockStateMeta blockStateMeta = (BlockStateMeta)itemStack.getItemMeta();
/*  74 */     ShulkerBox shulkerBox = (ShulkerBox)blockStateMeta.getBlockState();
/*  75 */     return shulkerBox.getInventory();
/*     */   }
/*     */   
/*     */   public void dropItems(Location paramLocation) {
/*  79 */     Inventory inventory = getInventory();
/*  80 */     for (ItemStack itemStack : inventory.getContents()) {
/*  81 */       if (itemStack != null) {
/*  82 */         paramLocation.getWorld().dropItem(paramLocation, itemStack);
/*     */       }
/*     */     } 
/*  85 */     inventory.clear();
/*     */   }
/*     */   public boolean isStorageOpen() {
/*  88 */     return (this.inv != null);
/*     */   }
/*     */   
/*     */   public void closeStorage(boolean paramBoolean) {
/*  92 */     if (this.inv == null) {
/*     */       return;
/*     */     }
/*  95 */     if (!paramBoolean && 
/*  96 */       this.inv.getViewers() != null) {
/*  97 */       for (HumanEntity humanEntity : (HumanEntity[])this.inv.getViewers().toArray((Object[])new HumanEntity[this.inv.getViewers().size()])) {
/*  98 */         humanEntity.closeInventory();
/*     */       }
/*     */     }
/*     */     
/* 102 */     ItemStack itemStack = new ItemStack(Material.SHULKER_BOX, 1);
/* 103 */     BlockStateMeta blockStateMeta = (BlockStateMeta)itemStack.getItemMeta();
/* 104 */     ShulkerBox shulkerBox = (ShulkerBox)blockStateMeta.getBlockState();
/* 105 */     for (byte b = 0; b < this.inv.getSize(); b++) {
/* 106 */       ItemStack itemStack1 = this.inv.getItem(b);
/* 107 */       if (itemStack1 != null)
/*     */       {
/*     */         
/* 110 */         if (itemStack1.getType().toString().endsWith("SHULKER_BOX") && !(VehiclesMain.getPlugin()).allowShulkersInVehicleStorage) {
/* 111 */           this.mainStand.getWorld().dropItem(this.mainStand.getLocation(), itemStack1);
/* 112 */           this.inv.setItem(b, new ItemStack(Material.AIR));
/*     */         } 
/*     */       }
/*     */     } 
/* 116 */     shulkerBox.getInventory().setContents(this.inv.getContents());
/* 117 */     shulkerBox.update();
/* 118 */     blockStateMeta.setBlockState((BlockState)shulkerBox);
/* 119 */     itemStack.setItemMeta((ItemMeta)blockStateMeta);
/* 120 */     this.mainStand.getEquipment().setLeggings(itemStack);
/* 121 */     this.inv.setContents(new ItemStack[0]);
/* 122 */     this.inv = null;
/*     */   }
/*     */   
/*     */   public ArrayList<ItemStack> removeItemsFromStorage(Collection<ItemStack> paramCollection) {
/* 126 */     boolean bool = isStorageOpen();
/* 127 */     Inventory inventory = getInventory();
/* 128 */     ArrayList<ItemStack> arrayList = new ArrayList();
/* 129 */     for (ItemStack itemStack : paramCollection) {
/* 130 */       int i = itemStack.getAmount();
/* 131 */       for (byte b = 0; b < inventory.getSize(); b++) {
/* 132 */         ItemStack itemStack1 = inventory.getItem(b);
/* 133 */         if (itemStack1 != null)
/*     */         {
/*     */           
/* 136 */           if (itemStack1.getType() == itemStack.getType()) {
/* 137 */             int j = itemStack1.getAmount();
/* 138 */             j -= i;
/* 139 */             i -= itemStack1.getAmount();
/* 140 */             if (j <= 0) {
/* 141 */               inventory.setItem(b, new ItemStack(Material.AIR));
/*     */             } else {
/* 143 */               itemStack1.setAmount(j);
/* 144 */               inventory.setItem(b, itemStack1);
/*     */             } 
/* 146 */             if (i <= 0)
/*     */               break; 
/*     */           } 
/*     */         }
/*     */       } 
/* 151 */       if (i > 0) {
/* 152 */         itemStack.setAmount(i);
/* 153 */         arrayList.add(itemStack);
/*     */       } 
/*     */     } 
/* 156 */     if (!bool) {
/* 157 */       ItemStack itemStack = new ItemStack(Material.SHULKER_BOX, 1);
/* 158 */       BlockStateMeta blockStateMeta = (BlockStateMeta)itemStack.getItemMeta();
/* 159 */       ShulkerBox shulkerBox = (ShulkerBox)blockStateMeta.getBlockState();
/* 160 */       shulkerBox.getInventory().setContents(inventory.getContents());
/* 161 */       shulkerBox.update();
/* 162 */       blockStateMeta.setBlockState((BlockState)shulkerBox);
/* 163 */       itemStack.setItemMeta((ItemMeta)blockStateMeta);
/* 164 */       this.mainStand.getEquipment().setLeggings(itemStack);
/*     */     } 
/* 166 */     return arrayList;
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\beans\StorageVehicle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */