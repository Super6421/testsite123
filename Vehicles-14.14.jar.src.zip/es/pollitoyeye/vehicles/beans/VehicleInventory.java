/*     */ package es.pollitoyeye.vehicles.beans;
/*     */ 
/*     */ import es.pollitoyeye.vehicles.VehiclesMain;
/*     */ import es.pollitoyeye.vehicles.enums.VehicleType;
/*     */ import es.pollitoyeye.vehicles.interfaces.VehicleSubType;
/*     */ import es.pollitoyeye.vehicles.utils.CustomHeadCreator;
/*     */ import es.pollitoyeye.vehicles.utils.EntityUtils;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ 
/*     */ public class VehicleInventory
/*     */ {
/*     */   private Inventory inv;
/*     */   private VehicleType vehicleType;
/*     */   private VehicleSubType subType;
/*     */   private Player player;
/*     */   private ItemStack fuelBucket;
/*     */   private ArmorStand mainStand;
/*     */   
/*     */   public VehicleInventory(VehicleType paramVehicleType, VehicleSubType paramVehicleSubType, Player paramPlayer, ArmorStand paramArmorStand) {
/*  31 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/*  32 */     this.vehicleType = paramVehicleType;
/*  33 */     this.subType = paramVehicleSubType;
/*  34 */     this.player = paramPlayer;
/*  35 */     this.mainStand = paramArmorStand;
/*  36 */     this.inv = Bukkit.createInventory(null, 9, vehiclesMain.getLang().getValue("vehicle-inventory-title"));
/*  37 */     ItemStack itemStack = new ItemStack(Material.LIGHT_GRAY_STAINED_GLASS_PANE);
/*  38 */     ItemMeta itemMeta = itemStack.getItemMeta();
/*  39 */     itemMeta.setDisplayName(" ");
/*  40 */     itemStack.setItemMeta(itemMeta);
/*  41 */     for (byte b = 0; b < 9; b++) {
/*  42 */       this.inv.setItem(b, itemStack);
/*     */     }
/*  44 */     loadCurrentFuel();
/*     */   }
/*     */   public Inventory getInventory() {
/*  47 */     return this.inv;
/*     */   }
/*     */   private void loadCurrentFuel() {
/*  50 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/*  51 */     double d = EntityUtils.getCurrentFuel(this.mainStand, this.subType);
/*  52 */     String str1 = "100";
/*  53 */     if (d < this.subType.getFuelCapacity()) {
/*  54 */       str1 = (new DecimalFormat("#.##")).format(d * 100.0D / this.subType.getFuelCapacity());
/*     */     }
/*  56 */     String str2 = vehiclesMain.getLang().getValue("vehicle-inventory-fuel-name");
/*  57 */     str2 = str2.replace("<fuelPercentage>", "" + str1);
/*  58 */     this.fuelBucket = CustomHeadCreator.createItemStack("http://textures.minecraft.net/texture/9e162daa331c6cf8d6138b83fb848bd35c78d2f5f2199de6e9e18a4388265b7");
/*  59 */     ItemMeta itemMeta = this.fuelBucket.getItemMeta();
/*  60 */     itemMeta.setDisplayName(str2);
/*  61 */     itemMeta.setLore(Arrays.asList(new String[] { vehiclesMain.getLang().getValue("vehicle-inventory-fuel-description") }));
/*  62 */     this.fuelBucket.setItemMeta(itemMeta);
/*  63 */     this.inv.setItem(4, this.fuelBucket);
/*     */   }
/*     */   
/*     */   public void click(InventoryClickEvent paramInventoryClickEvent) {
/*  67 */     VehiclesMain vehiclesMain = VehiclesMain.getPlugin();
/*  68 */     ItemStack itemStack1 = paramInventoryClickEvent.getCursor();
/*  69 */     ItemStack itemStack2 = this.inv.getItem(paramInventoryClickEvent.getSlot());
/*  70 */     if (itemStack2 == null) {
/*     */       return;
/*     */     }
/*  73 */     if (paramInventoryClickEvent.getSlot() == 4 && 
/*  74 */       itemStack1 != null && itemStack1.getType() != Material.AIR) {
/*  75 */       double d = EntityUtils.getCurrentFuel(this.mainStand, this.subType);
/*  76 */       if (d >= this.subType.getFuelCapacity()) {
/*  77 */         this.player.sendMessage(vehiclesMain.getLang().getValue("vehicle-inventory-fuel-full"));
/*     */         return;
/*     */       } 
/*  80 */       boolean bool = false;
/*  81 */       int i = 0;
/*  82 */       for (ItemStack itemStack : vehiclesMain.materialFuelValues.keySet()) {
/*  83 */         if (itemStack.getType() == itemStack1.getType()) {
/*  84 */           ItemMeta itemMeta1 = itemStack.getItemMeta();
/*  85 */           ItemMeta itemMeta2 = itemStack1.getItemMeta();
/*  86 */           if (itemMeta1.hasDisplayName()) {
/*  87 */             if (!itemMeta2.hasDisplayName()) {
/*     */               continue;
/*     */             }
/*  90 */             if (!itemMeta1.getDisplayName().equals(itemMeta2.getDisplayName())) {
/*     */               continue;
/*     */             }
/*     */           } 
/*  94 */           if (itemMeta1.hasLore() && itemMeta1.getLore().size() > 0) {
/*  95 */             if (!itemMeta2.hasLore()) {
/*     */               continue;
/*     */             }
/*  98 */             List<String> list = itemMeta1.getLore();
/*  99 */             List list1 = itemMeta2.getLore();
/* 100 */             if (list.size() != list1.size()) {
/*     */               continue;
/*     */             }
/* 103 */             for (byte b = 0; b < list.size(); b++) {
/* 104 */               if (!((String)list.get(b)).equals(list1.get(b)));
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 109 */           bool = true;
/* 110 */           i = ((Integer)vehiclesMain.materialFuelValues.get(itemStack)).intValue();
/*     */         } 
/*     */       } 
/* 113 */       if (!bool) {
/* 114 */         this.player.sendMessage(vehiclesMain.getLang().getValue("vehicle-inventory-fuel-invalid-item"));
/*     */         return;
/*     */       } 
/* 117 */       byte b1 = 0;
/* 118 */       for (byte b2 = 0; b2 < itemStack1.getAmount(); b2++) {
/* 119 */         d += i;
/* 120 */         b1++;
/* 121 */         if (d >= this.subType.getFuelCapacity()) {
/* 122 */           d = this.subType.getFuelCapacity();
/*     */           break;
/*     */         } 
/*     */       } 
/* 126 */       EntityUtils.setCurrentFuel(this.mainStand, d);
/* 127 */       loadCurrentFuel();
/* 128 */       this.player.sendMessage(vehiclesMain.getLang().getValue("vehicle-inventory-fuel-added"));
/* 129 */       if (b1 == itemStack1.getAmount()) {
/* 130 */         if (itemStack1.getType() == Material.LAVA_BUCKET) {
/* 131 */           itemStack1.setType(Material.BUCKET);
/*     */         } else {
/* 133 */           itemStack1.setType(Material.AIR);
/*     */         } 
/* 135 */         paramInventoryClickEvent.setCursor(itemStack1);
/*     */         return;
/*     */       } 
/* 138 */       itemStack1.setAmount(itemStack1.getAmount() - b1);
/* 139 */       paramInventoryClickEvent.setCursor(itemStack1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\beans\VehicleInventory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */