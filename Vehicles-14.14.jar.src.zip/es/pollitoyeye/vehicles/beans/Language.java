/*    */ package es.pollitoyeye.vehicles.beans;
/*    */ 
/*    */ import es.pollitoyeye.vehicles.VehiclesMain;
/*    */ import java.io.File;
/*    */ import java.util.HashMap;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.configuration.file.YamlConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Language
/*    */ {
/* 13 */   final String versionHash = "7.2680-7345977.521887%%%%%%205-615155-77855562-893538759-16205661123230702341794037-145468682-5635270469-145468682-5635270469-145468682-5635270469-145468682-5635270469";
/*    */ 
/*    */ 
/*    */   
/* 17 */   HashMap<String, String> traductions = new HashMap<>();
/*    */   public void load() {
/* 19 */     File file = new File(VehiclesMain.getPlugin().getDataFolder() + File.separator + "lang.yml");
/* 20 */     YamlConfiguration yamlConfiguration = null;
/* 21 */     if (file.exists()) {
/* 22 */       yamlConfiguration = YamlConfiguration.loadConfiguration(file);
/*    */     } else {
/* 24 */       VehiclesMain.getPlugin().saveResource("lang.yml", false);
/* 25 */       yamlConfiguration = YamlConfiguration.loadConfiguration(file);
/*    */     } 
/* 27 */     if (yamlConfiguration != null) {
/* 28 */       for (String str : yamlConfiguration.getKeys(false)) {
/* 29 */         this.traductions.put(str, yamlConfiguration.getString(str));
/*    */       }
/* 31 */       System.out.println("Vehicles >> lang.yml loaded.");
/*    */     } else {
/* 33 */       System.out.println("Vehicles >> Error loading lang.yml");
/*    */     } 
/*    */   }
/*    */   public String getValue(String paramString) {
/* 37 */     if (this.traductions.containsKey(paramString)) {
/* 38 */       return ((String)this.traductions.get(paramString)).replace("&", "§");
/*    */     }
/* 40 */     return ChatColor.RED + "Message \"" + paramString + "\" not found in lang.yml, please delete the file to make it update and refill it with your messages.";
/*    */   }
/*    */ }


/* Location:              D:\загрузки\Work\Vehicles-14.14.jar!\es\pollitoyeye\vehicles\beans\Language.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */