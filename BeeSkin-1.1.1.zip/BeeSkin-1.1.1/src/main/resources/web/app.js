'use strict';
/* BeeSkin Studio — редактор скинов AgeOfGlory.
 * 3D-просмотрщик на чистом WebGL (без CDN/зависимостей), два слоя рисования
 * (base / outer-hat), инструменты, undo/redo, загрузка и применение скина.
 *
 * UV-раскладка модели сверена с эталонным рендерером (daidr/minecraft-skin-renderer,
 * createBoxUV + привязка граней UV_SKIN) и с раскладкой Java-скина 64x64.
 */

// ───────────────────────── Состояние ─────────────────────────

const $ = (s) => document.querySelector(s);
const SIZE = 64;
const token = (new URLSearchParams(location.search).get('token')) || '';

const state = {
  tool: 'pencil',
  view: '3d',
  layer: 'base',            // слой, на котором рисуется
  model: 'classic',         // classic (4px) / slim (3px)
  animate: true,
  grid: true,
  parts: { head: true, body: true, leftArm: true, rightArm: true, leftLeg: true, rightLeg: true },
  color: '#f6c453',
  history: [],
  future: [],
  rotX: -0.08,
  rotY: -0.38,
  zoom: 1.0,
  drag: false,
  orbit: false,
  paint3d: false,
  lastX: 0,
  lastY: 0,
  phase: 0,
  userEdited: false,
  session: { player: null, expiresAt: 0 }
};

let palette = [
  '#f6c453', '#e7a43a', '#f5e9bd', '#fffdf1', '#47765d', '#315b48', '#233633',
  '#d87864', '#b65048', '#536f91', '#80a5c4', '#9a6b43', '#d5aba9', '#bed096',
  '#6f8479', '#1f2927'
];

// ─────────────────────── Слои рисования ───────────────────────

const skin = $('#textureCanvas');
const ctx = skin.getContext('2d', { willReadFrequently: true });
const baseLayer = document.createElement('canvas');
const outerLayer = document.createElement('canvas');
baseLayer.width = baseLayer.height = SIZE;
outerLayer.width = outerLayer.height = SIZE;
const baseCtx = baseLayer.getContext('2d', { willReadFrequently: true });
const outerCtx = outerLayer.getContext('2d', { willReadFrequently: true });
[ctx, baseCtx, outerCtx].forEach(c => { c.imageSmoothingEnabled = false; });

function activeCtx() { return state.layer === 'outer' ? outerCtx : baseCtx; }

/** Композит: base + outer (hat) — именно это видит Minecraft. */
function compositeLayers() {
  ctx.clearRect(0, 0, SIZE, SIZE);
  ctx.drawImage(baseLayer, 0, 0);
  ctx.drawImage(outerLayer, 0, 0);
  uploadTexture();
}

function snapshot() {
  return { base: baseCtx.getImageData(0, 0, SIZE, SIZE), outer: outerCtx.getImageData(0, 0, SIZE, SIZE) };
}

function resetHistory() {
  state.history = [snapshot()];
  state.future = [];
  updateHistoryButtons();
}

function pushHistory() {
  state.history.push(snapshot());
  if (state.history.length > 40) state.history.shift();
  state.future = [];
  state.userEdited = true;
  updateHistoryButtons();
}

function restore(image) {
  baseCtx.putImageData(image.base, 0, 0);
  outerCtx.putImageData(image.outer, 0, 0);
  compositeLayers();
  draw2d();
}

function undo() {
  if (state.history.length > 1) {
    state.future.push(state.history.pop());
    restore(state.history[state.history.length - 1]);
  }
}

function redo() {
  if (state.future.length) {
    const next = state.future.pop();
    state.history.push(next);
    restore(next);
  }
}

function updateHistoryButtons() {
  $('#undo').classList.toggle('disabled', state.history.length <= 1);
  $('#redo').classList.toggle('disabled', state.future.length === 0);
}

/**
 * Вставить изображение в редактор: БАЗОВЫЙ слой = весь скин,
 * outer-слой очищается (в Minecraft hat — это оверлей поверх base).
 */
function putImage(img) {
  baseCtx.clearRect(0, 0, SIZE, SIZE);
  outerCtx.clearRect(0, 0, SIZE, SIZE);
  baseCtx.drawImage(img, 0, 0, SIZE, SIZE);
  compositeLayers();
  resetHistory();
  draw2d();
  render();
}

// ───────────────── Демо-скин (стартовый) ─────────────────

function seed() {
  baseCtx.clearRect(0, 0, SIZE, SIZE);
  outerCtx.clearRect(0, 0, SIZE, SIZE);
  const fill = (t, c, x, y, w, h) => { t.fillStyle = c; t.fillRect(x, y, w, h); };
  // base
  fill(baseCtx, '#e9a83b', 0, 0, 32, 16);
  fill(baseCtx, '#f5e9bd', 8, 8, 8, 8);
  fill(baseCtx, '#d8902f', 24, 8, 8, 8);
  fill(baseCtx, '#47765d', 16, 16, 24, 32);
  fill(baseCtx, '#315b48', 40, 16, 16, 32);
  fill(baseCtx, '#315b48', 0, 16, 16, 32);
  fill(baseCtx, '#345b49', 16, 48, 16, 16);
  fill(baseCtx, '#345b49', 32, 48, 16, 16);
  baseCtx.fillStyle = '#233633';
  baseCtx.fillRect(24, 27, 16, 4);
  // outer (hat)
  fill(outerCtx, '#e9a83b', 32, 0, 32, 16);
  fill(outerCtx, '#f6c453', 40, 8, 8, 8);
  fill(outerCtx, '#557c62', 16, 32, 24, 16);
  fill(outerCtx, '#557c62', 40, 32, 16, 16);
  compositeLayers();
  resetHistory();
  state.userEdited = false;
}

// ─────────── Геометрия модели (эталонная раскладка) ───────────
/*
 * Координаты: Y вверх, модель смотрит в +Z (лицом к камере),
 * правая сторона персонажа = -X.
 *
 * UV: l = грань -X, r = грань +X, f = +Z, b = -Z, t = +Y, d = -Y.
 * Проверено по эталону: левая колонка полоски распаковки (например,
 * (16,20) для туловища) всегда уходит на грань -X — именно так рендерит
 * Minecraft (знаменитый лев/право «перевёрнутый» относительно персонажа).
 */
function strip(x, y, frontW, sideW, h) {
  return {
    l: [x, y + sideW, sideW, h],
    f: [x + sideW, y + sideW, frontW, h],
    r: [x + sideW + frontW, y + sideW, sideW, h],
    b: [x + sideW + frontW + sideW, y + sideW, frontW, h],
    t: [x + sideW, y, frontW, sideW],
    d: [x + sideW + frontW, y, sideW, sideW]
  };
}

/** UV-прямоугольники всех частей для модели и слоя. */
function rectsFor(model, layer) {
  const o = layer === 'outer';
  const armW = model === 'slim' ? 3 : 4;
  return {
    head:     o ? strip(32, 0, 8, 8, 8) : strip(0, 0, 8, 8, 8),
    body:     o ? strip(16, 32, 8, 4, 12) : strip(16, 16, 8, 4, 12),
    rightArm: o ? strip(40, 32, armW, 4, 12) : strip(40, 16, armW, 4, 12),
    leftArm:  o ? strip(48, 48, armW, 4, 12) : strip(32, 48, armW, 4, 12),
    rightLeg: o ? strip(0, 32, 4, 4, 12) : strip(0, 16, 4, 4, 12),
    leftLeg:  o ? strip(0, 48, 4, 4, 12) : strip(16, 48, 4, 4, 12)
  };
}

/** Мир-коробки всех частей (центр, размеры; инфляция hat-слоя 0.5, как в игре). */
function boxesFor(model, layer, walk) {
  const armW = model === 'slim' ? 3 : 4;
  const shoulder = 4 + armW / 2;
  const inflate = layer === 'outer' ? 0.5 : 0;
  const mk = (name, x, y, z, w, h, d) => ({
    name, x, y, z,
    w: w + inflate * 2, h: h + inflate * 2, d: d + inflate * 2
  });
  return [
    mk('head', 0, 10, 0, 8, 8, 8),
    mk('body', 0, 0, 0, 8, 12, 4),
    mk('rightArm', -shoulder, 0, 0, armW, 12, 4),
    mk('leftArm', shoulder, 0, 0, armW, 12, 4),
    mk('rightLeg', -2, -12 + walk, 0, 4, 12, 4),
    mk('leftLeg', 2, -12 - walk, 0, 4, 12, 4)
  ];
}

function walkOffset() { return state.animate ? Math.sin(state.phase) * 0.16 : 0; }

// ───────────────────── WebGL рендерер ─────────────────────

const glState = { gl: null, program: null, texture: null, loc: {}, buffers: null, matrix: null };
const glCanvas = $('#glCanvas');

function initGL() {
  const gl = glState.gl = glCanvas.getContext('webgl', { alpha: true, antialias: true, premultipliedAlpha: false });
  if (!gl) {
    $('#stageLoading').remove();
    toast('3D недоступен в этом браузере — включён 2D-режим', false);
    setView('2d');
    return;
  }
  const vs = `attribute vec3 aPos;attribute vec2 aUv;attribute vec3 aNormal;uniform mat4 uMatrix;
varying vec2 vUv;varying vec3 vNormal;
void main(){gl_Position=uMatrix*vec4(aPos,1.0);vUv=aUv;vNormal=aNormal;}`;
  const fs = `precision mediump float;uniform sampler2D uTex;varying vec2 vUv;varying vec3 vNormal;
void main(){vec4 c=texture2D(uTex,vUv);if(c.a<0.08)discard;
float light=.72+max(dot(normalize(vNormal),normalize(vec3(-.4,.8,.65))),0.0)*.38;
gl_FragColor=vec4(c.rgb*light,c.a);}`;
  const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); return s; };
  const p = gl.createProgram();
  gl.attachShader(p, sh(gl.VERTEX_SHADER, vs));
  gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
  gl.linkProgram(p);
  gl.useProgram(p);
  glState.program = p;
  glState.loc = {
    pos: gl.getAttribLocation(p, 'aPos'),
    uv: gl.getAttribLocation(p, 'aUv'),
    normal: gl.getAttribLocation(p, 'aNormal'),
    matrix: gl.getUniformLocation(p, 'uMatrix'),
    tex: gl.getUniformLocation(p, 'uTex')
  };
  glState.texture = gl.createTexture();
  glState.buffers = { pos: gl.createBuffer(), uv: gl.createBuffer(), normal: gl.createBuffer() };
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.enable(gl.DEPTH_TEST);
  gl.enable(gl.CULL_FACE);
  gl.cullFace(gl.BACK);
  gl.frontFace(gl.CCW);
  uploadTexture();
  $('#stageLoading').remove();
  render();
}

function uploadTexture() {
  const gl = glState.gl;
  if (!gl) return;
  gl.bindTexture(gl.TEXTURE_2D, glState.texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, skin);
}

function m4() { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
function mul(a, b) {
  const r = new Array(16);
  for (let c = 0; c < 4; c++) for (let r0 = 0; r0 < 4; r0++)
    r[c * 4 + r0] = a[r0] * b[c * 4] + a[4 + r0] * b[c * 4 + 1] + a[8 + r0] * b[c * 4 + 2] + a[12 + r0] * b[c * 4 + 3];
  return r;
}
function persp(fovy, asp, n, f) {
  const t = 1 / Math.tan(fovy / 2), o = m4();
  o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); o[15] = 0;
  return o;
}
function trans(x, y, z) { const o = m4(); o[12] = x; o[13] = y; o[14] = z; return o; }
function rx(a) { const o = m4(), c = Math.cos(a), s = Math.sin(a); o[5] = c; o[6] = s; o[9] = -s; o[10] = c; return o; }
function ry(a) { const o = m4(), c = Math.cos(a), s = Math.sin(a); o[0] = c; o[2] = -s; o[8] = s; o[10] = c; return o; }
function inv4(a) {
  const b = a, o = new Array(16);
  const n = b[0] * (b[5] * (b[10] * b[15] - b[14] * b[11]) - b[9] * (b[6] * b[15] - b[14] * b[7]) + b[13] * (b[6] * b[11] - b[10] * b[7]))
    - b[4] * (b[1] * (b[10] * b[15] - b[14] * b[11]) - b[9] * (b[2] * b[15] - b[14] * b[3]) + b[13] * (b[2] * b[11] - b[10] * b[3]))
    + b[8] * (b[1] * (b[6] * b[15] - b[14] * b[7]) - b[5] * (b[2] * b[15] - b[14] * b[3]) + b[13] * (b[2] * b[7] - b[6] * b[3]))
    - b[12] * (b[1] * (b[6] * b[11] - b[10] * b[7]) - b[5] * (b[2] * b[11] - b[10] * b[3]) + b[9] * (b[2] * b[7] - b[6] * b[3]));
  if (!n) return null;
  o[0] = (b[5] * (b[10] * b[15] - b[14] * b[11]) - b[9] * (b[6] * b[15] - b[14] * b[7]) + b[13] * (b[6] * b[11] - b[10] * b[7])) / n;
  o[4] = -(b[4] * (b[10] * b[15] - b[14] * b[11]) - b[8] * (b[6] * b[15] - b[14] * b[7]) + b[12] * (b[6] * b[11] - b[10] * b[7])) / n;
  o[8] = (b[4] * (b[9] * b[15] - b[13] * b[11]) - b[8] * (b[5] * b[15] - b[13] * b[7]) + b[12] * (b[5] * b[11] - b[9] * b[7])) / n;
  o[12] = -(b[4] * (b[9] * b[14] - b[13] * b[10]) - b[8] * (b[5] * b[14] - b[13] * b[6]) + b[12] * (b[5] * b[10] - b[9] * b[6])) / n;
  o[1] = -(b[1] * (b[10] * b[15] - b[14] * b[11]) - b[9] * (b[2] * b[15] - b[14] * b[3]) + b[13] * (b[2] * b[11] - b[10] * b[3])) / n;
  o[5] = (b[0] * (b[10] * b[15] - b[14] * b[11]) - b[8] * (b[2] * b[15] - b[14] * b[3]) + b[12] * (b[2] * b[11] - b[10] * b[3])) / n;
  o[9] = -(b[0] * (b[9] * b[15] - b[13] * b[11]) - b[8] * (b[1] * b[15] - b[13] * b[3]) + b[12] * (b[1] * b[11] - b[9] * b[3])) / n;
  o[13] = (b[0] * (b[9] * b[14] - b[13] * b[10]) - b[8] * (b[1] * b[14] - b[13] * b[2]) + b[12] * (b[1] * b[10] - b[9] * b[2])) / n;
  o[2] = (b[1] * (b[6] * b[15] - b[14] * b[7]) - b[5] * (b[2] * b[15] - b[14] * b[3]) + b[13] * (b[2] * b[7] - b[6] * b[3])) / n;
  o[6] = -(b[0] * (b[6] * b[15] - b[14] * b[7]) - b[4] * (b[2] * b[15] - b[14] * b[3]) + b[12] * (b[2] * b[7] - b[6] * b[3])) / n;
  o[10] = (b[0] * (b[5] * b[15] - b[13] * b[7]) - b[4] * (b[1] * b[15] - b[13] * b[3]) + b[12] * (b[1] * b[7] - b[5] * b[3])) / n;
  o[14] = -(b[0] * (b[5] * b[14] - b[13] * b[6]) - b[4] * (b[1] * b[14] - b[13] * b[2]) + b[8] * (b[1] * b[6] - b[5] * b[2])) / n;
  o[3] = -(b[1] * (b[6] * b[11] - b[10] * b[7]) - b[5] * (b[2] * b[11] - b[10] * b[3]) + b[9] * (b[2] * b[7] - b[6] * b[3])) / n;
  o[7] = (b[0] * (b[6] * b[11] - b[10] * b[7]) - b[4] * (b[2] * b[11] - b[10] * b[3]) + b[8] * (b[2] * b[7] - b[6] * b[3])) / n;
  o[11] = -(b[0] * (b[5] * b[11] - b[9] * b[7]) - b[4] * (b[1] * b[11] - b[9] * b[3]) + b[8] * (b[1] * b[7] - b[5] * b[3])) / n;
  o[15] = (b[0] * (b[5] * b[10] - b[9] * b[6]) - b[4] * (b[1] * b[10] - b[9] * b[2]) + b[8] * (b[1] * b[6] - b[5] * b[2])) / n;
  return o;
}
function tp(m, p) {
  const x = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12];
  const y = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13];
  const z = m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14];
  const w = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
  return [x / w, y / w, z / w];
}

/** Сборка меша одной коробки: 6 граней, по 6 вершин, UV под эталонную раскладку. */
function pushBox(out, b, rects) {
  const X = b.w / 2, Y = b.h / 2, Z = b.d / 2;
  const x = b.x, y = b.y, z = b.z;
  const cL = [x - X, y - Y, z + Z], cR = [x + X, y - Y, z + Z];
  const tR = [x + X, y + Y, z + Z], tL = [x - X, y + Y, z + Z];
  const bL = [x - X, y - Y, z - Z], bR = [x + X, y - Y, z - Z];
  const hR = [x + X, y + Y, z - Z], hL = [x - X, y + Y, z - Z];
  const face = (verts, normal, uvs) => {
    // 6 вершин = два треугольника: (v0,v1,v2) и (v3,v0,v2) — порядок даёт CCW снаружи
    for (let i = 0; i < 4; i++) out.v.push(...verts[i]);
    out.v.push(...verts[0], ...verts[2]);
    for (let i = 0; i < 4; i++) out.u.push(...uvs[i]);
    out.u.push(...uvs[0], ...uvs[2]);
    for (let i = 0; i < 6; i++) out.n.push(...normal);
  };
  // УВ из прямоугольника: u0/u1 — левый/правый край, vT/vB — верх/низ
  const uvsOf = (rect) => {
    const [rx, ry, rw2, rh2] = rect;
    const u0 = rx / SIZE, u1 = (rx + rw2) / SIZE;
    const vT = 1 - ry / SIZE, vB = 1 - (ry + rh2) / SIZE;
    return { u0, u1, vT, vB };
  };
  const std = (rect) => { const { u0, u1, vT, vB } = uvsOf(rect); return [[u0, vB], [u1, vB], [u1, vT], [u0, vT]]; };
  // порядок вершин — против часовой стрелки снаружи (нужно для CULL_FACE).
  // Для нижней грани UV-паттерн особенный (сверен с эталоном MC):
  // мир +X → правый край прямоугольника, задняя кромка → верх прямоугольника.
  const dbot = (rect) => { const { u0, u1, vT, vB } = uvsOf(rect); return [[u1, vB], [u0, vB], [u0, vT], [u1, vT]]; };
  face([cL, cR, tR, tL], [0, 0, 1], std(rects.f));
  face([bR, bL, hL, hR], [0, 0, -1], std(rects.b));
  face([bL, cL, tL, hL], [-1, 0, 0], std(rects.l));
  face([cR, bR, hR, tR], [1, 0, 0], std(rects.r));
  face([cL, cR, bR, bL], [0, 1, 0], std(rects.t));
  face([cR, cL, bL, bR], [0, -1, 0], dbot(rects.d));
}

/** Меш всех видимых частей; оба слоя (base + hat) рендерятся всегда, как в игре. */
function mesh() {
  const out = { v: [], u: [], n: [] };
  const walk = walkOffset();
  for (const layer of ['base', 'outer']) {
    const rects = rectsFor(state.model, layer);
    for (const b of boxesFor(state.model, layer, walk)) {
      if (!state.parts[b.name]) continue;
      pushBox(out, b, rects[b.name]);
    }
  }
  return { v: new Float32Array(out.v), u: new Float32Array(out.u), n: new Float32Array(out.n) };
}

function render() {
  const gl = glState.gl;
  if (!gl) return;
  const c = glCanvas;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = Math.max(1, Math.floor(c.clientWidth * dpr));
  const h = Math.max(1, Math.floor(c.clientHeight * dpr));
  if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
  gl.viewport(0, 0, w, h);
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);
  gl.enable(gl.CULL_FACE);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  const camera = persp(0.8, w / h, 0.1, 100);
  let mat = mul(camera, mul(trans(0, 1.0, -50 / state.zoom), mul(rx(state.rotX), ry(state.rotY))));
  const d = mesh();
  const bind = (loc, size, data, buffer) => {
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
  };
  bind(glState.loc.pos, 3, d.v, glState.buffers.pos);
  bind(glState.loc.uv, 2, d.u, glState.buffers.uv);
  bind(glState.loc.normal, 3, d.n, glState.buffers.normal);
  gl.useProgram(glState.program);
  glState.matrix = mat;
  gl.uniformMatrix4fv(glState.loc.matrix, false, new Float32Array(mat));
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, glState.texture);
  gl.uniform1i(glState.loc.tex, 0);
  gl.drawArrays(gl.TRIANGLES, 0, d.v.length / 3);
  if (state.animate) {
    state.phase += 0.045;
    if (!state.raf) {
      state.raf = true;
      requestAnimationFrame(() => { state.raf = false; render(); });
    }
  }
}

// ───────────────── Пикап (рисование по 3D) ─────────────────

/** Пиксель текстуры по точке мира на грани (UV совпадает с рендером). */
function uvAt(b, rects, faceKey, px, py, pz) {
  const [rx, ry, rw, rh] = rects[faceKey];
  const X = b.w / 2, Y = b.h / 2, Z = b.d / 2;
  let u, row;
  switch (faceKey) {
    case 'f': u = (px - (b.x - X)) / b.w; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'b': u = 1 - (px - (b.x - X)) / b.w; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'l': u = (pz - (b.z - Z)) / b.d; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'r': u = 1 - (pz - (b.z - Z)) / b.d; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 't': u = (px - (b.x - X)) / b.w; row = ry + ((pz - (b.z - Z)) / b.d) * rh; break;
    default:  u = (px - (b.x - X)) / b.w; row = ry + ((pz - (b.z - Z)) / b.d) * rh; // d
  }
  return [
    Math.max(0, Math.min(63, Math.floor(rx + Math.max(0, Math.min(0.999, u)) * rw))),
    Math.max(0, Math.min(63, Math.floor(ry + Math.max(0, Math.min(0.999, (row - ry) / rh))) ))
  ];
}

/** Луч из камеры в точку экрана → ближайшая грань активного слоя. */
function pickAt(cx, cy) {
  if (!glState.matrix) return null;
  const screen = glCanvas.getBoundingClientRect();
  const ndcX = (cx - screen.left) / screen.width * 2 - 1;
  const ndcY = 1 - (cy - screen.top) / screen.height * 2;
  const inv = inv4(glState.matrix);
  if (!inv) return null;
  const nearP = tp(inv, [ndcX, ndcY, -1]);
  const farP = tp(inv, [ndcX, ndcY, 1]);
  const dir = [farP[0] - nearP[0], farP[1] - nearP[1], farP[2] - nearP[2]];
  const len = Math.hypot(dir[0], dir[1], dir[2]) || 1;
  dir[0] /= len; dir[1] /= len; dir[2] /= len;

  const rects = rectsFor(state.model, state.layer);
  const walk = walkOffset();
  let bestT = Infinity, best = null;
  for (const b of boxesFor(state.model, state.layer, walk)) {
    if (!state.parts[b.name]) continue;
    const mn = [b.x - b.w / 2, b.y - b.h / 2, b.z - b.d / 2];
    const mx = [b.x + b.w / 2, b.y + b.h / 2, b.z + b.d / 2];
    let t0 = 0.001, t1 = 1e9, ok = true;
    for (let i = 0; i < 3; i++) {
      if (Math.abs(dir[i]) < 1e-7) {
        if (nearP[i] < mn[i] || nearP[i] > mx[i]) { ok = false; break; }
      } else {
        let a = (mn[i] - nearP[i]) / dir[i], c2 = (mx[i] - nearP[i]) / dir[i];
        if (a > c2) [a, c2] = [c2, a];
        t0 = Math.max(t0, a); t1 = Math.min(t1, c2);
        if (t0 > t1) { ok = false; break; }
      }
    }
    if (!ok) continue;
    const t = t0;
    if (t > bestT) continue;
    const p = [nearP[0] + dir[0] * t, nearP[1] + dir[1] * t, nearP[2] + dir[2] * t];
    // какая грань: максимум |t * dir| по осям
    const ax = Math.abs(dir[0]) * t, ay = Math.abs(dir[1]) * t, az = Math.abs(dir[2]) * t;
    let faceKey;
    if (az >= ax && az >= ay) faceKey = dir[2] > 0 ? 'f' : 'b';
    else if (ax >= ay) faceKey = dir[0] > 0 ? 'r' : 'l';
    else faceKey = dir[1] > 0 ? 't' : 'd';
    const uv = uvAt(b, rects[b.name], faceKey, p[0], p[1], p[2]);
    bestT = t;
    best = { x: uv[0], y: uv[1] };
  }
  return best;
}

// ───────────────────── Инструменты ─────────────────────

function pixelOf(e) {
  const r = skin.getBoundingClientRect();
  return [
    Math.floor((e.clientX - r.left) / r.width * SIZE),
    Math.floor((e.clientY - r.top) / r.height * SIZE)
  ];
}

function hexFrom(d) {
  return '#' + [...d].slice(0, 3).map(v => v.toString(16).padStart(2, '0')).join('');
}

function setColor(v) {
  state.color = v;
  $('#color').value = v;
  $('#hex').textContent = v.toUpperCase();
}

/** Пипетка берёт цвет из КОМПОЗИТА (того, что видит пользователь). */
function pickColor(x, y) {
  const d = ctx.getImageData(x, y, 1, 1).data;
  if (d[3] === 0) { toast('Здесь прозрачный пиксель', false); return; }
  setColor(hexFrom(d));
  toast('Цвет: ' + hexFrom(d).toUpperCase());
}

/**
 * Свет/тень правят видимый пиксель: если его прикрывает outer-слой —
 * правим outer, иначе base.
 */
function adjustPixel(x, y, amount) {
  const outerPx = outerCtx.getImageData(x, y, 1, 1).data;
  const target = outerPx[3] > 0 ? outerCtx : baseCtx;
  const d = target.getImageData(x, y, 1, 1).data;
  if (d[3] === 0) return;
  const px = new Uint8ClampedArray(4);
  for (let i = 0; i < 3; i++) {
    px[i] = amount >= 0
      ? d[i] + (255 - d[i]) * amount
      : d[i] * (1 + amount);
  }
  px[3] = 255;
  target.putImageData(new ImageData(px, 1, 1), x, y);
  compositeLayers();
  draw2d();
  render();
}

function flood(x, y, target) {
  const source = target.getImageData(x, y, 1, 1).data;
  const goal = state.color;
  if (hexFrom(source).toLowerCase() === goal) return;
  const img = target.getImageData(0, 0, SIZE, SIZE);
  const data = img.data;
  const r = parseInt(goal.slice(1, 3), 16), g = parseInt(goal.slice(3, 5), 16), b = parseInt(goal.slice(5, 7), 16);
  const queue = new Int32Array(SIZE * SIZE);
  let head = 0, tail = 0;
  const seen = new Uint8Array(SIZE * SIZE);
  const seedIdx = (y * SIZE + x) | 0;
  seen[seedIdx] = 1;
  // сам кликнутый пиксель тоже закрашиваем (иначе останется «дырка» посреди залива)
  const sI = seedIdx * 4;
  data[sI] = r; data[sI + 1] = g; data[sI + 2] = b; data[sI + 3] = 255;
  queue[tail++] = seedIdx;
  const match = i => data[i] === source[0] && data[i + 1] === source[1] && data[i + 2] === source[2] && data[i + 3] === source[3];
  while (head < tail) {
    const idx = queue[head++];
    const px = idx % SIZE, py = (idx / SIZE) | 0;
    const nb = [[px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]];
    for (const [nx, ny] of nb) {
      if (nx < 0 || ny < 0 || nx >= SIZE || ny >= SIZE) continue;
      const nIdx = (ny * SIZE + nx) | 0;
      if (seen[nIdx]) continue;
      const i = nIdx * 4;
      if (match(i)) {
        seen[nIdx] = 1;
        queue[tail++] = nIdx;
        data[i] = r; data[i + 1] = g; data[i + 2] = b; data[i + 3] = 255;
      }
    }
  }
  target.putImageData(img, 0, 0);
  compositeLayers();
  draw2d();
  render();
}

/** Основной вызов инструмента в точке (x, y). */
function paintAt(x, y) {
  if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) return;
  const target = activeCtx();
  switch (state.tool) {
    case 'picker': pickColor(x, y); return;
    case 'fill': flood(x, y, target); return;
    case 'eraser': target.clearRect(x, y, 1, 1); break;
    case 'light': adjustPixel(x, y, 0.35); return;
    case 'shadow': adjustPixel(x, y, -0.35); return;
    case 'noise': {
      const usePalette = Math.random() > 0.45;
      target.fillStyle = usePalette ? palette[(Math.random() * palette.length) | 0] : state.color;
      target.fillRect(x, y, 1, 1);
      break;
    }
    default: // pencil
      target.fillStyle = state.color;
      target.fillRect(x, y, 1, 1);
  }
  compositeLayers();
  draw2d();
  render();
}

function draw2d() {
  // композит уже на skin-канвасе; для 2D-вида только выключаем сглаживание
  ctx.imageSmoothingEnabled = false;
}

// ─────────────── События 2D-канваса ───────────────

skin.addEventListener('pointerdown', e => {
  if (e.button !== 0) return;
  e.preventDefault();
  const [x, y] = pixelOf(e);
  state.drag = true;
  skin.setPointerCapture(e.pointerId);
  paintAt(x, y);
});
skin.addEventListener('pointermove', e => {
  if (!state.drag) return;
  const [x, y] = pixelOf(e);
  paintAt(x, y);
});
const stop2d = () => {
  // история: одно действие = один шаг undo (снапшот — ПОСЛЕ изменения)
  if (state.drag && state.tool !== 'picker') pushHistory();
  state.drag = false;
};
skin.addEventListener('pointerup', stop2d);
skin.addEventListener('pointercancel', stop2d);
skin.addEventListener('contextmenu', e => e.preventDefault());

// ─────────────── События 3D-канваса ───────────────

glCanvas.addEventListener('pointerdown', e => {
  e.preventDefault();
  state.lastX = e.clientX;
  state.lastY = e.clientY;
  if (e.button !== 0) {
    state.drag = true; state.orbit = true;
    glCanvas.setPointerCapture(e.pointerId);
    return;
  }
  const hit = pickAt(e.clientX, e.clientY);
  if (hit) {
    state.drag = true; state.paint3d = true;
    paintAt(hit.x, hit.y);
    glCanvas.setPointerCapture(e.pointerId);
  } else {
    // пустое место — вращение камеры
    state.drag = true; state.orbit = true;
    glCanvas.setPointerCapture(e.pointerId);
  }
});
glCanvas.addEventListener('pointermove', e => {
  if (!state.drag) return;
  if (state.orbit) {
    state.rotY += (e.clientX - state.lastX) * 0.012;
    state.rotX += (e.clientY - state.lastY) * 0.008;
    state.rotX = Math.max(-1.2, Math.min(1.2, state.rotX));
    state.lastX = e.clientX;
    state.lastY = e.clientY;
    if (!state.animate) render();
  } else if (state.paint3d) {
    const hit = pickAt(e.clientX, e.clientY);
    if (hit) paintAt(hit.x, hit.y);
  }
});
const stop3d = () => {
  if (state.paint3d && state.tool !== 'picker') pushHistory();
  state.drag = false; state.orbit = false; state.paint3d = false;
};
glCanvas.addEventListener('pointerup', stop3d);
glCanvas.addEventListener('pointercancel', stop3d);
glCanvas.addEventListener('contextmenu', e => e.preventDefault());
glCanvas.addEventListener('wheel', e => {
  e.preventDefault();
  setZoom(state.zoom * (e.deltaY < 0 ? 1.08 : 0.93));
}, { passive: false });

function setZoom(z) {
  state.zoom = Math.max(0.7, Math.min(1.25, z));
  $('#zoomValue').textContent = Math.round(state.zoom * 100) + '%';
  if (!state.animate) render();
}

// ───────────────────── UI ─────────────────────

function toast(message, isError) {
  const box = $('#toasts');
  const el = document.createElement('div');
  el.className = 'toast' + (isError ? ' error' : '');
  el.textContent = message;
  box.appendChild(el);
  setTimeout(() => el.classList.add('show'), 10);
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 250);
  }, 3000);
}

function makePalette() {
  const el = $('#palette');
  el.innerHTML = '';
  palette.forEach(c => {
    const b = document.createElement('button');
    b.style.background = c;
    b.title = c;
    b.onclick = () => setColor(c);
    el.append(b);
  });
}

function setTool(tool) {
  state.tool = tool;
  document.querySelectorAll('.rail-tool[data-tool]').forEach(x => x.classList.toggle('active', x.dataset.tool === tool));
}

function setView(view) {
  state.view = view;
  document.querySelectorAll('.view-toggle button').forEach(x => x.classList.toggle('active', x.dataset.view === view));
  $('#stage').classList.toggle('show-2d', view === '2d');
  $('#stageHint').textContent = view === '2d'
    ? 'Пиксельный слой · рисуй прямо по текстуре'
    : 'Потяни мышью, чтобы вращать · колёсико — масштаб';
  if (view === '2d') draw2d();
}

// панели инструментов
document.querySelectorAll('.rail-tool[data-tool]').forEach(b => { b.onclick = () => setTool(b.dataset.tool); });
$('#undo').onclick = undo;
$('#redo').onclick = redo;

document.addEventListener('keydown', e => {
  if (e.target && /input|textarea/i.test(e.target.tagName)) return;
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); return; }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); return; }
  const map = { p: 'pencil', e: 'eraser', f: 'fill', i: 'picker', o: 'light', u: 'shadow', n: 'noise' };
  const tool = map[e.key.toLowerCase()];
  if (tool) setTool(tool);
});

// цвет
$('#color').addEventListener('input', e => setColor(e.target.value));

// палитра
$('#auto').onclick = () => {
  const data = ctx.getImageData(0, 0, SIZE, SIZE).data;
  const seen = new Map();
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] > 10) {
      const c = '#' + [data[i], data[i + 1], data[i + 2]].map(v => v.toString(16).padStart(2, '0')).join('');
      seen.set(c, (seen.get(c) || 0) + 1);
    }
  }
  const top = [...seen.entries()].sort((a, b) => b[1] - a[1]).slice(0, 16).map(x => x[0]);
  if (top.length) palette = top;
  makePalette();
  toast('Палитра построена из скина');
};

// виды, слои, части, модель
document.querySelectorAll('.view-toggle button').forEach(b => { b.onclick = () => setView(b.dataset.view); });
document.querySelectorAll('.layer-toggle button').forEach(b => {
  b.onclick = () => {
    state.layer = b.dataset.layer;
    document.querySelectorAll('.layer-toggle button').forEach(x => x.classList.toggle('active', x === b));
    toast(b.dataset.layer === 'outer' ? 'Рисуем по слою Outer / Hat' : 'Рисуем по слою Base');
  };
});
document.querySelectorAll('[data-part]').forEach(b => {
  b.onclick = () => {
    const p = b.dataset.part;
    state.parts[p] = !state.parts[p];
    b.classList.toggle('active', state.parts[p]);
    if (!state.animate) render();
  };
});
document.querySelectorAll('[data-model]').forEach(b => {
  b.onclick = () => {
    state.model = b.dataset.model;
    document.querySelectorAll('[data-model]').forEach(x => x.classList.toggle('active', x === b));
    $('#modelLabel').textContent = state.model.toUpperCase();
    if (!state.animate) render();
  };
});
document.querySelectorAll('[data-tab]').forEach(b => {
  b.onclick = () => {
    document.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('active', x === b));
    $('#paintTab').classList.toggle('hidden', b.dataset.tab !== 'paint');
    $('#partsTab').classList.toggle('hidden', b.dataset.tab !== 'parts');
  };
});

// анимация, сетка, ночь
$('#animateBtn').onclick = () => {
  state.animate = !state.animate;
  $('#animateBtn').classList.toggle('active', state.animate);
  $('#animateBtn').textContent = state.animate ? '◉ Движение' : '○ Статика';
  if (state.animate) render();
};
$('#gridBtn').onclick = () => {
  state.grid = !state.grid;
  $('#gridBtn').classList.toggle('active', state.grid);
  $('#stage').classList.toggle('no-grid', !state.grid);
};
$('#timeBtn').onclick = () => {
  document.body.classList.toggle('night');
  $('#timeBtn').textContent = document.body.classList.contains('night') ? '☾' : '☼';
};
$('#resetBtn').onclick = () => {
  if (confirm('Сбросить текущий скин?')) {
    seed();
    draw2d();
    render();
    toast('Скин сброшен к демо');
  }
};

// зум и пресеты
$('#zoomOut').onclick = () => setZoom(state.zoom - 0.1);
$('#zoomIn').onclick = () => setZoom(state.zoom + 0.1);
document.querySelectorAll('[data-preset]').forEach(b => {
  b.onclick = () => {
    state.rotX = -0.08;
    state.rotY = { front: 0, side: Math.PI / 2, back: Math.PI }[b.dataset.preset] || 0;
    if (!state.animate) render();
  };
});

window.addEventListener('resize', () => { if (!state.animate) render(); });

// ─────────── Загрузка / сессия / применение ───────────

function loadFile(file) {
  if (!file) return;
  if (file.type !== 'image/png') { toast('Нужен PNG-файл', true); return; }
  const url = URL.createObjectURL(file);
  const im = new Image();
  im.onload = () => {
    URL.revokeObjectURL(url);
    if (im.naturalWidth !== 64 || im.naturalHeight !== 64) {
      toast(`Файл ${im.naturalWidth}×${im.naturalHeight} — нужен ровно 64×64`, true);
      return;
    }
    pushHistory();
    putImage(im);
    state.userEdited = true;
    toast('Скин загружен в редактор');
  };
  im.onerror = () => { URL.revokeObjectURL(url); toast('Не удалось прочитать файл', true); };
  im.src = url;
}

$('#file').addEventListener('change', e => loadFile(e.target.files[0]));
const drop = $('#dropzone');
drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('drag'); });
drop.addEventListener('dragleave', () => drop.classList.remove('drag'));
drop.addEventListener('drop', e => {
  e.preventDefault();
  drop.classList.remove('drag');
  loadFile(e.dataTransfer.files[0]);
});

$('#download').onclick = () => {
  const a = document.createElement('a');
  a.download = 'ageofglory-skin.png';
  a.href = skin.toDataURL('image/png');
  a.click();
  toast('PNG сохранён');
};

async function apply() {
  const button = $('#applyTop');
  if (button.disabled) return;
  if (!token) { toast('Откройте редактор по ссылке из игры', true); return; }
  button.disabled = true;
  const old = button.innerHTML;
  button.innerHTML = 'Отправляем…';
  try {
    const blob = await new Promise(res => skin.toBlob(res, 'image/png'));
    const r = await fetch(`/api/apply?token=${encodeURIComponent(token)}&model=${state.model}`, {
      method: 'POST',
      headers: { 'Content-Type': 'image/png' },
      body: blob
    });
    let j = {};
    try { j = await r.json(); } catch (e) { /* нет json */ }
    if (!r.ok) throw new Error(j.message || j.error || 'ошибка сервера');
    toast('Скин отправлен на применение в игру');
    $('#sessionText').textContent = 'Скин отправлен на сервер';
  } catch (e) {
    toast('Ошибка: ' + (e.message || e), true);
  } finally {
    button.disabled = false;
    button.innerHTML = old;
  }
}
$('#applyTop').onclick = apply;

// сессия: имя игрока, обратный отсчёт, предзагрузка текущего скина
let sessionTimer = null;
function updateSessionText() {
  const base = state.session.player ? 'Игрок: ' + state.session.player : 'Сессия';
  const left = state.session.expiresAt - Date.now();
  if (left <= 0) {
    $('#sessionText').textContent = base + ' · сессия истекла';
    clearInterval(sessionTimer);
    return;
  }
  const min = Math.floor(left / 60000);
  const sec = Math.floor((left % 60000) / 1000);
  $('#sessionText').textContent = `${base} · ${min}:${String(sec).padStart(2, '0')}`;
}

async function loadSession() {
  if (!token) {
    $('#sessionText').textContent = 'Откройте ссылку из игры';
    return;
  }
  for (let i = 0; i < 40 && !state.userEdited; i++) {
    try {
      const r = await fetch('/api/session?token=' + encodeURIComponent(token));
      const j = await r.json();
      if (j.player) state.session.player = j.player;
      if (j.model && !state.userEdited && state.model !== j.model) {
        state.model = j.model;
        document.querySelectorAll('[data-model]').forEach(x => x.classList.toggle('active', x.dataset.model === j.model));
        $('#modelLabel').textContent = j.model.toUpperCase();
      }
      if (j.expiresAt) {
        state.session.expiresAt = j.expiresAt;
        if (!sessionTimer) {
          sessionTimer = setInterval(updateSessionText, 1000);
          updateSessionText();
        }
      }
      if (j.skinReady) {
        const blob = await fetch('/api/skin.png?token=' + encodeURIComponent(token)).then(x => x.ok ? x.blob() : null);
        if (blob) {
          const im = await createImageBitmap(blob).catch(() => null);
          const image = im || await new Promise(res => {
            const u = URL.createObjectURL(blob);
            const x = new Image();
            x.onload = () => { URL.revokeObjectURL(u); res(x); };
            x.src = u;
          });
          if (image && image.width === 64 && image.height === 64 && !state.userEdited) {
            putImage(image);
            toast('Ваш текущий скин загружен');
          }
        }
      }
      return;
    } catch (e) {
      if (i === 39) $('#sessionText').textContent = 'Сессия недоступна';
    }
    await new Promise(res => setTimeout(res, 500));
  }
}

// ───────────────────── Старт ─────────────────────

makePalette();
seed();
initGL();
draw2d();
loadSession();
