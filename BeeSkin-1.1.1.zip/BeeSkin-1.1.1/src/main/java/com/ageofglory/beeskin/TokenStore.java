package com.ageofglory.beeskin;

import org.bukkit.entity.Player;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Хранилище сессий редактора.
 * <p>
 * Сессия = токен (32 случайных байта, base64url) + игрок + срок действия.
 * Одновременно у игрока живёт только последняя выданная сессия:
 * повторный вызов команды инвалидирует старую ссылку.
 */
public final class TokenStore {

    public static final class Session {
        public final String token;
        public final UUID playerId;
        public final String playerName;
        /** Миллисекунды epoch, после которых сессия недействительна. */
        public final long expiresAt;
        /** Текущий PNG скина (64x64), либо null если ещё не получен. */
        public volatile byte[] png;
        /** Модель текущей текстуры: classic (4px) / slim (3px). */
        public volatile String model = "classic";

        Session(String token, UUID playerId, String playerName, long expiresAt) {
            this.token = token;
            this.playerId = playerId;
            this.playerName = playerName;
            this.expiresAt = expiresAt;
        }

        boolean valid() {
            return System.currentTimeMillis() < expiresAt;
        }
    }

    private final Map<String, Session> byToken = new ConcurrentHashMap<>();
    private final Map<UUID, Session> byPlayer = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();
    private volatile long ttlMs;

    public TokenStore(int minutes) {
        this.ttlMs = toMs(minutes);
    }

    /** Обновить TTL после перезагрузки конфига (новые токены). */
    public void setTtl(int minutes) {
        this.ttlMs = toMs(minutes);
    }

    public long ttlMs() {
        return ttlMs;
    }

    /** Выдать игроку новую сессию, инвалидируя его предыдущую. */
    public Session issue(Player player) {
        Session old = byPlayer.get(player.getUniqueId());
        if (old != null) {
            byToken.remove(old.token, old);
        }
        Session session = new Session(newToken(), player.getUniqueId(), player.getName(),
                System.currentTimeMillis() + ttlMs);
        byToken.put(session.token, session);
        byPlayer.put(player.getUniqueId(), session);
        return session;
    }

    /** Найти живую сессию по токену, либо null. */
    public Session find(String token) {
        if (token == null || token.isEmpty()) {
            return null;
        }
        Session session = byToken.get(token);
        return session != null && session.valid() ? session : null;
    }

    /** Найти живую сессию игрока, либо null. */
    public Session findByPlayer(UUID id) {
        Session session = byPlayer.get(id);
        return session != null && session.valid() ? session : null;
    }

    /** Список живых сессий (для /skineditor sessions). */
    public java.util.Collection<Session> active() {
        cleanup();
        return byToken.values();
    }

    /** Удалить просроченные сессии. Вернуть количество удалённых. */
    public int cleanup() {
        int removed = 0;
        var it = byToken.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Session> e = it.next();
            if (!e.getValue().valid()) {
                it.remove();
                byPlayer.remove(e.getValue().playerId, e.getValue());
                removed++;
            }
        }
        return removed;
    }

    private String newToken() {
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private static long toMs(int minutes) {
        return Math.max(1, minutes) * 60_000L;
    }
}
