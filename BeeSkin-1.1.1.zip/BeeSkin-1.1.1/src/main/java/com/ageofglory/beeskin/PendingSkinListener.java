package com.ageofglory.beeskin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Применяет «зависшие» скины при входе игрока.
 * <p>
 * Источники pending:
 * <ul>
 *   <li>игрок сохранил скин, но в момент применения был офлайн;</li>
 *   <li>MineSkin API был недоступен — повторим попытку при входе;</li>
 *   <li>SkinsRestorer был установлен/поднят позже, чем скин сохранялся.</li>
 * </ul>
 */
public final class PendingSkinListener implements Listener {

    private final BeeSkinPlugin plugin;

    public PendingSkinListener(BeeSkinPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Path file = SkinApplier.pendingFile(plugin, player.getUniqueId());
        if (!Files.isRegularFile(file)) {
            return;
        }
        plugin.getLogger().info("Pending-скин для " + player.getName() + " — пробуем применить при входе.");
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                byte[] png = Files.readAllBytes(file);
                SkinApplier.retryOnJoin(plugin, player.getUniqueId(), png);
            } catch (Exception e) {
                plugin.getLogger().warning("Не удалось прочитать pending-скин " + player.getName()
                        + ": " + e.getMessage());
            }
        });
    }
}
