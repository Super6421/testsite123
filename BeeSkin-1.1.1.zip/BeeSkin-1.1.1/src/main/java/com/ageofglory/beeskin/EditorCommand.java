package com.ageofglory.beeskin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /skineditor — открыть редактор;
 * /skineditor url &lt;игрок&gt; — выдать ссылку онлайн-игроку (beeskin.admin);
 * /skineditor sessions — активные сессии (beeskin.admin);
 * /skineditor reload — перезагрузить конфиг (beeskin.admin).
 */
public final class EditorCommand implements CommandExecutor, TabCompleter {

    private final BeeSkinPlugin plugin;
    private final TokenStore tokens;

    public EditorCommand(BeeSkinPlugin plugin, TokenStore tokens) {
        this.plugin = plugin;
        this.tokens = tokens;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("§cBeeSkin: редактор открывают только игроки.");
                return true;
            }
            open(player);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (!admin(sender)) {
                    return true;
                }
                plugin.reloadPlugin();
                sender.sendMessage("§aBeeSkin: конфиг перезагружен (ttl="
                        + plugin.getConfig().getInt("token-minutes", 15) + " мин).");
            }
            case "sessions" -> {
                if (!admin(sender)) {
                    return true;
                }
                listSessions(sender);
            }
            case "url" -> {
                if (!admin(sender)) {
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage("§eИспользование: /skineditor url <игрок>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage("§cИгрок " + args[1] + " не найден онлайн.");
                    return true;
                }
                TokenStore.Session session = tokens.issue(target);
                SkinLoader.loadAsync(plugin, session, target);
                target.sendMessage(header());
                target.sendMessage(ChatColor.WHITE + "Администратор открыл редактор для вас: "
                        + ChatColor.AQUA + plugin.publicUrl(session.token));
                target.sendMessage(ttlHint());
                sender.sendMessage("§aСсылка выдана игроку " + target.getName() + " в его чат.");
            }
            default -> {
                sender.sendMessage("§eBeeSkin: /skineditor | url <игрок> | sessions | reload");
            }
        }
        return true;
    }

    private void open(Player player) {
        if (!player.hasPermission("beeskin.use")) {
            player.sendMessage(ChatColor.RED + "Нет прав.");
            return;
        }
        TokenStore.Session session = tokens.issue(player);
        SkinLoader.loadAsync(plugin, session, player);
        player.sendMessage(header());
        player.sendMessage(ChatColor.WHITE + "Открой редактор: " + ChatColor.AQUA + plugin.publicUrl(session.token));
        player.sendMessage(ttlHint());
    }

    private void listSessions(CommandSender sender) {
        List<TokenStore.Session> list = new ArrayList<>(tokens.active());
        if (list.isEmpty()) {
            sender.sendMessage("§aBeeSkin: активных сессий нет.");
            return;
        }
        sender.sendMessage(ChatColor.GOLD + "BeeSkin — активных сессий: " + list.size());
        long now = System.currentTimeMillis();
        for (TokenStore.Session s : list) {
            long leftMin = Math.max(0, (s.expiresAt - now) / 60_000L);
            sender.sendMessage("§7 - §f" + s.playerName + " §7(осталось ~" + leftMin + " мин, скин готов: "
                    + (s.png != null ? "да" : "нет") + ")");
        }
    }

    private boolean admin(CommandSender sender) {
        if (sender.hasPermission("beeskin.admin")) {
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Нет прав (beeskin.admin).");
        return false;
    }

    private String header() {
        return ChatColor.GOLD + "BeeSkin " + ChatColor.YELLOW + "для AgeOfGlory";
    }

    private String ttlHint() {
        int minutes = plugin.getConfig().getInt("token-minutes", 15);
        return ChatColor.GRAY + "Ссылка действует " + minutes + " минут и привязана к вашему аккаунту. "
                + "Повторный вызов команды выдаст новую ссылку.";
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("beeskin.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return filter(List.of("url", "sessions", "reload"), prefix);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("url")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                names.add(p.getName().toLowerCase(Locale.ROOT));
            }
            return filter(names, prefix);
        }
        return List.of();
    }

    private static List<String> filter(List<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.startsWith(prefix)) {
                out.add(o);
            }
            if (out.size() >= 50) {
                break;
            }
        }
        return out;
    }
}
