package com.ageofglory.beeskin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Применение скинов через SkinsRestorer (runtime-only, без compile-зависимости).
 * <p>
 * Пайплайн:
 * <ol>
 *   <li>сохранить PNG в {@code plugins/BeeSkin/pending/<uuid>.png} — страховка:
 *       если игрок офлайн или SR недоступен, скин применится при следующем входе;</li>
 *   <li>посчитать текстуру через MineSkin API (блокирующий сетевой вызов — только в
 *       асинхронной задаче, никогда на main thread);</li>
 *   <li>на main thread: {@code SkinApplier.applySkin(player, property)} + сохранить
 *       property в storage SkinsRestorer ({@code setPlayerSkinData}), чтобы скин
 *       пережил перезаход;</li>
 *   <li>если MineSkin недоступен и включён {@code local-fallback} с HTTPS public-url —
 *       отдать PNG клиентам напрямую с нашего сервера, вложив URL в валидный
 *       Mojang-совместимый textures-профиль.</li>
 * </ol>
 */
final class SkinApplier {

    /** Кэшированные reflective-ручки SkinsRestorer (инициализация один раз). */
    static final class SR {
        final Object api;          // net.skinsrestorer.api.SkinsRestorer
        final Object mineSkinApi;  // MineSkinAPI
        final Object classic;      // SkinVariant.CLASSIC
        final Object slim;         // SkinVariant.SLIM
        final Method genSkin;      // genSkin(byte[], SkinVariant)
        final Object applier;      // SkinApplier<Player>
        final Method applySkin;    // applySkin(Player, SkinProperty)
        final Method setPlayerSkinData; // SkinStorage.setPlayerSkinData(UUID, String, SkinProperty, long)
        final Class<?> skinPropertyClass;

        private SR(Object api, Object mineSkinApi, Object classic, Object slim, Method genSkin,
                   Object applier, Method applySkin, Method setPlayerSkinData, Class<?> skinPropertyClass) {
            this.api = api;
            this.mineSkinApi = mineSkinApi;
            this.classic = classic;
            this.slim = slim;
            this.genSkin = genSkin;
            this.applier = applier;
            this.applySkin = applySkin;
            this.setPlayerSkinData = setPlayerSkinData;
            this.skinPropertyClass = skinPropertyClass;
        }

        static SR tryInit() {
            try {
                Object api = Class.forName("net.skinsrestorer.api.SkinsRestorerProvider")
                        .getMethod("get").invoke(null);

                Object mineSkinApi = api.getClass().getMethod("getMineSkinAPI").invoke(api);

                Class<?> variantClass = Class.forName("net.skinsrestorer.api.property.SkinVariant");
                @SuppressWarnings("unchecked")
                Class<Enum> enumClass = (Class<Enum>) variantClass.asSubclass(Enum.class);
                Object classic = Enum.valueOf(enumClass, "CLASSIC");
                Object slim;
                try {
                    slim = Enum.valueOf(enumClass, "SLIM");
                } catch (IllegalArgumentException e) {
                    slim = classic; // старые версии SR
                }

                Method genSkin = null;
                for (Method m : mineSkinApi.getClass().getMethods()) {
                    if (m.getName().equals("genSkin") && m.getParameterCount() == 2
                            && m.getParameterTypes()[0] == byte[].class) {
                        genSkin = m;
                        break;
                    }
                }
                if (genSkin == null) {
                    throw new NoSuchMethodException("MineSkinAPI.genSkin(byte[], SkinVariant)");
                }

                Object applier = api.getClass().getMethod("getSkinApplier", Class.class)
                        .invoke(api, Player.class);
                Method applySkin = null;
                for (Method m : applier.getClass().getMethods()) {
                    if (m.getName().equals("applySkin") && m.getParameterCount() == 2) {
                        applySkin = m;
                        break;
                    }
                }
                if (applySkin == null) {
                    throw new NoSuchMethodException("SkinApplier.applySkin(Player, SkinProperty)");
                }

                Method setPlayerSkinData = null;
                try {
                    Object storage = api.getClass().getMethod("getSkinStorage").invoke(api);
                    for (Method m : storage.getClass().getMethods()) {
                        if (m.getName().equals("setPlayerSkinData") && m.getParameterCount() == 4
                                && m.getParameterTypes()[0] == UUID.class) {
                            setPlayerSkinData = m;
                            break;
                        }
                    }
                } catch (Throwable ignored) {
                    // storage отсутствует — сохранение после применения просто пропустим
                }

                return new SR(api, mineSkinApi, classic, slim, genSkin, applier, applySkin,
                        setPlayerSkinData, Class.forName("net.skinsrestorer.api.property.SkinProperty"));
            } catch (Throwable t) {
                return null;
            }
        }
    }

    private static volatile SR srCache;
    private static volatile boolean srChecked;

    static SR sr() {
        if (!srChecked) {
            srCache = SR.tryInit();
            srChecked = true;
        }
        return srCache;
    }

    static boolean isAvailable() {
        return sr() != null;
    }

    // ── Файлы pending ──────────────────────────────────────────

    static Path pendingDir(BeeSkinPlugin plugin) {
        return plugin.getDataFolder().toPath().resolve("pending");
    }

    static Path pendingFile(BeeSkinPlugin plugin, UUID uuid) {
        return pendingDir(plugin).resolve(uuid + ".png");
    }

    private static void savePending(BeeSkinPlugin plugin, UUID uuid, byte[] png) {
        try {
            Path file = pendingFile(plugin, uuid);
            Files.createDirectories(file.getParent());
            Files.write(file, png, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception e) {
            plugin.getLogger().warning("Не удалось сохранить pending-скин: " + e.getMessage());
        }
    }

    private static void deletePending(BeeSkinPlugin plugin, UUID uuid) {
        try {
            Files.deleteIfExists(pendingFile(plugin, uuid));
        } catch (Exception ignored) {
            // не критично
        }
    }

    /** Удалить pending/served файлы старше N дней. Вызывать раз в сутки + при старте. */
    static void cleanUpOld(BeeSkinPlugin plugin, int days) {
        long cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(Math.max(1, days));
        try {
            for (Path dir : new Path[]{pendingDir(plugin), EditorServer.servedDir(plugin)}) {
                if (!Files.isDirectory(dir)) {
                    continue;
                }
                Files.list(dir).forEach(f -> {
                    try {
                        if (Files.getLastModifiedTime(f).toMillis() < cutoff) {
                            Files.deleteIfExists(f);
                        }
                    } catch (Exception ignored) {
                        // пропускаем
                    }
                });
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Ошибка очистки pending: " + e.getMessage());
        }
    }

    // ── Применение ─────────────────────────────────────────────

    /**
     * Применить скин игроку. Вызывать на main thread (файл пишется локально,
     * сеть уходит в async).
     */
    static void apply(BeeSkinPlugin plugin, UUID uuid, String playerName, byte[] png, boolean slim) {
        savePending(plugin, uuid, png);
        SR sr = sr();
        Player online = Bukkit.getPlayer(uuid);
        if (sr == null) {
            if (online != null) {
                online.sendMessage("§cBeeSkin: на сервере не установлен SkinsRestorer — применить скин невозможно. "
                        + "Скин сохранён, скачайте его через «Скачать результат».");
            } else {
                plugin.getLogger().info("SkinsRestorer не найден; pending-скин " + uuid
                        + " дождётся установки плагина и входа игрока.");
            }
            return;
        }
        // MineSkin генерация — блокирующий сетевой вызов, только async.
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> generateAndApply(plugin, uuid, playerName, png, slim, sr));
    }

    /** Повторное применение при входе (из PendingSkinListener). */
    static void retryOnJoin(BeeSkinPlugin plugin, UUID uuid, byte[] png) {
        SR sr = sr();
        if (sr == null) {
            return; // без SR применить нельзя — файл остаётся
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin,
                () -> generateAndApply(plugin, uuid, Bukkit.getPlayer(uuid) != null ? Bukkit.getPlayer(uuid).getName() : null,
                        png, false, sr));
    }

    private static void generateAndApply(BeeSkinPlugin plugin, UUID uuid, String playerName, byte[] png,
                                         boolean slim, SR sr) {
        Object property = null;
        Throwable error = null;
        try {
            Object variant = slim ? sr.slim : sr.classic;
            Object response = sr.genSkin.invoke(sr.mineSkinApi, png, variant);
            Object raw = response.getClass().getMethod("getProperty").invoke(response);
            property = unwrapProperty(raw);
        } catch (Throwable t) {
            error = root(t);
        }

        if (property == null) {
            // MineSkin недоступен — пробуем локальный fallback (если включён и есть HTTPS URL).
            property = localFallbackProperty(plugin, png, slim, error);
        }

        final Object finalProperty = property;
        final Throwable finalError = error;
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null) {
                plugin.getLogger().info("Скин готов, но игрок " + uuid + " офлайн — применится при входе.");
                return;
            }
            if (finalProperty == null) {
                String detail = finalError == null ? "неизвестная ошибка" : finalError.getClass().getSimpleName()
                        + ": " + String.valueOf(finalError.getMessage());
                plugin.getLogger().warning("SkinsRestorer: генерация текстуры не удалась (" + detail
                        + "). Pending-скин сохранён, повторим при входе.");
                player.sendMessage("§cBeeSkin: не удалось обработать текстуру (" + detail
                        + "). Попробуйте ещё раз позже.");
                return;
            }
            try {
                sr.applySkin.invoke(sr.applier, player, finalProperty);
                persist(plugin, sr, player, finalProperty);
                deletePending(plugin, player.getUniqueId());
                player.sendMessage("§aBeeSkin: скин применён — изменения видны всем без перезахода.");
            } catch (Throwable t) {
                Throwable root = root(t);
                String detail = root.getClass().getSimpleName() + ": " + String.valueOf(root.getMessage());
                plugin.getLogger().warning("SkinsRestorer applySkin не удался: " + detail
                        + ". Pending-скин сохранён, повторим при входе.");
                player.sendMessage("§cBeeSkin: не удалось применить скин (" + detail
                        + "). Попробуйте ещё раз позже.");
            }
        });
    }

    /** SkinProperty может приходить и как Optional (старые версии SR). */
    private static Object unwrapProperty(Object raw) {
        if (raw instanceof Optional<?> opt) {
            return opt.orElse(null);
        }
        return raw;
    }

    /**
     * Локальный fallback: собираем Mojang-совместимый textures-профиль,
     * где url указывает на наш сервер (GET /skin/<name>.png).
     * Работает только при включённом local-fallback и HTTPS public-url —
     * клиент Minecraft не загружает текстуры по http.
     */
    private static Object localFallbackProperty(BeeSkinPlugin plugin, byte[] png, boolean slim, Throwable mineSkinError) {
        if (!plugin.getConfig().getBoolean("local-fallback", false)) {
            return null;
        }
        String publicUrl = plugin.getConfig().getString("public-url", "").trim();
        if (publicUrl.isEmpty() || !publicUrl.regionMatches(true, 0, "https://", 0, 8)) {
            if (mineSkinError != null) {
                plugin.getLogger().warning("MineSkin недоступен, local-fallback пропущен: "
                        + "нужен HTTPS public-url. (" + mineSkinError.getMessage() + ")");
            }
            return null;
        }
        try {
            SR sr = sr();
            String name = java.util.UUID.randomUUID().toString().replace("-", "") + ".png";
            Path dir = EditorServer.servedDir(plugin);
            Files.createDirectories(dir);
            Files.write(dir.resolve(name), png, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            String url = publicUrl.replaceAll("/$", "") + "/skin/" + name;
            String json = "{\"textures\":{\"SKIN\":{\"url\":\"" + url
                    + "\",\"metadata\":{\"model\":\"" + (slim ? "slim" : "classic") + "\"}}},\"signature\":\"\",\"signed\":false}";
            String value = Base64.getEncoder().encodeToString(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return sr.skinPropertyClass.getMethod("of", String.class, String.class).invoke(null, value, "");
        } catch (Exception e) {
            plugin.getLogger().warning("Local fallback не удался: " + e.getMessage());
            return null;
        }
    }

    /** Сохранить property в storage SR, чтобы скин пережил перезаход. */
    private static void persist(BeeSkinPlugin plugin, SR sr, Player player, Object property) {
        if (sr.setPlayerSkinData == null) {
            plugin.getLogger().warning("Не удалось сохранить скин в storage SkinsRestorer "
                    + "(getSkinStorage недоступен) — скин переживёт перезаход, только пока действует сессия.");
            return;
        }
        try {
            Object storage = sr.api.getClass().getMethod("getSkinStorage").invoke(sr.api);
            sr.setPlayerSkinData.invoke(storage, player.getUniqueId(), player.getName(), property,
                    System.currentTimeMillis());
        } catch (Throwable t) {
            plugin.getLogger().warning("Не удалось сохранить скин в storage SkinsRestorer: " + root(t).getMessage()
                    + " — после перезахода скин вернётся к Mojang-текстуре.");
        }
    }

    private static Throwable root(Throwable t) {
        Throwable r = t;
        while (r.getCause() != null && r.getCause() != r) {
            r = r.getCause();
        }
        return r;
    }
}
