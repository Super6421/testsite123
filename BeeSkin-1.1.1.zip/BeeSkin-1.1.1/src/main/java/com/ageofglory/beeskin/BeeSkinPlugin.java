package com.ageofglory.beeskin;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Objects;

public final class BeeSkinPlugin extends JavaPlugin {

    private EditorServer editorServer;
    private TokenStore tokenStore;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        tokenStore = new TokenStore(getConfig().getInt("token-minutes", 15));

        getServer().getPluginManager().registerEvents(new PendingSkinListener(this), this);

        try {
            editorServer = new EditorServer(this, tokenStore);
            editorServer.start();
        } catch (IOException ex) {
            getLogger().severe("Не удалось запустить веб-сервер на "
                    + getConfig().getString("bind-address", "0.0.0.0") + ":"
                    + getConfig().getInt("port", 8765) + " — " + ex.getMessage());
            getLogger().severe("BeeSkin отключён. Освободите порт или измените bind-address/port в config.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        PluginCommand command = Objects.requireNonNull(getCommand("skineditor"), "команда skineditor не объявлена");
        EditorCommand executor = new EditorCommand(this, tokenStore);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        // Поддерживающие задачи: очистка сессий и устаревших pending-файлов.
        getServer().getScheduler().runTaskTimer(this, tokenStore::cleanup, 100L, 600L); // каждые 5 минут
        long dailyTicks = 20L * 60 * 60 * 24;
        getServer().getScheduler().runTaskTimer(this,
                () -> SkinApplier.cleanUpOld(this, getConfig().getInt("pending-expiry-days", 7)),
                dailyTicks, dailyTicks);
        SkinApplier.cleanUpOld(this, getConfig().getInt("pending-expiry-days", 7));

        getLogger().info("BeeSkin v" + getDescription().getVersion() + " включён для AgeOfGlory. Порт: " + editorServer.port());
        getLogger().info("Игроки открывают редактор по ссылке: " + publicBase());
        if (getConfig().getString("public-url", "").trim().isEmpty()
                && getConfig().getString("bind-address", "0.0.0.0").equals("0.0.0.0")) {
            getLogger().info("Подсказка: для публичной ссылки с доменом/HTTPS настройте public-url в config.yml "
                    + "(и reverse-proxy на 127.0.0.1:" + editorServer.port() + ").");
        }
    }

    @Override
    public void onDisable() {
        if (editorServer != null) {
            editorServer.stop();
        }
    }

    /** Перезагрузить конфиг и применить изменения без рестарта. */
    public void reloadPlugin() {
        reloadConfig();
        if (tokenStore != null) {
            tokenStore.setTtl(getConfig().getInt("token-minutes", 15));
        }
        SkinApplier.cleanUpOld(this, getConfig().getInt("pending-expiry-days", 7));
    }

    /** Базовый публичный URL без токена: https://host или http://host:port. */
    public String publicBase() {
        String configured = getConfig().getString("public-url", "").trim();
        if (!configured.isEmpty()) {
            return configured.replaceAll("/$", "");
        }
        String host = getConfig().getString("url-host", "").trim();
        if (host.isEmpty()) {
            host = detectHost();
        }
        return "http://" + host + ":" + (editorServer == null ? getConfig().getInt("port", 8765) : editorServer.port());
    }

    /** Полная ссылка редактора для токена. */
    public String publicUrl(String token) {
        return publicBase() + "/?token=" + token;
    }

    /** Первый локальный IPv4 (не loopback, не virtual). */
    private String detectHost() {
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) {
                    continue;
                }
                Enumeration<InetAddress> addresses = ni.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress address = addresses.nextElement();
                    if (address instanceof Inet4Address inet && !inet.isLoopbackAddress()) {
                        return inet.getHostAddress();
                    }
                }
            }
        } catch (SocketException ignored) {
            // переходим к fallback
        }
        try {
            InetAddress local = InetAddress.getLocalHost();
            if (local != null && !local.isLoopbackAddress()) {
                return local.getHostAddress();
            }
        } catch (Exception ignored) {
            // остаёмся на loopback
        }
        return "127.0.0.1";
    }
}
