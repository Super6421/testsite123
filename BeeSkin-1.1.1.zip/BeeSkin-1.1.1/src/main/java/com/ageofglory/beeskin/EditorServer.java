package com.ageofglory.beeskin;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.bukkit.Bukkit;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Встроенный HTTP-сервер BeeSkin: раздача веб-редактора и API.
 * <p>
 * Маршруты:
 * <ul>
 *   <li>{@code GET /} , {@code GET /index.html} , {@code /app.js} , {@code /app.css} , {@code /favicon.svg} — статика
 *       (совместимы с префиксом {@code /web/});</li>
 *   <li>{@code GET /api/session?token=} — данные сессии (игрок, срок, готовность скина);</li>
 *   <li>{@code GET /api/skin.png?token=|uuid} — текущий PNG скина игрока;</li>
 *   <li>{@code POST /api/apply?token=&model=} — загрузка нового скина (JSON data-URL или raw PNG);</li>
 *   <li>{@code GET /skin/<name>.png} — публичная отдача PNG для локального fallback (HTTPS).</li>
 * </ul>
 */
public final class EditorServer {

    private static final Set<String> STATIC_NAMES = Set.of("index.html", "app.js", "app.css", "favicon.svg");
    private static final Pattern SKIN_FILE = Pattern.compile("^[A-Za-z0-9_-]{1,64}\\.png$");

    private final BeeSkinPlugin plugin;
    private final TokenStore tokens;

    private HttpServer server;
    private ExecutorService pool;
    private final Map<String, byte[]> assets = new HashMap<>();
    private final Map<UUID, Long> lastApplyAt = new ConcurrentHashMap<>();

    public EditorServer(BeeSkinPlugin plugin, TokenStore tokens) {
        this.plugin = plugin;
        this.tokens = tokens;
    }

    public void start() throws IOException {
        loadAssets();
        String bind = plugin.getConfig().getString("bind-address", "0.0.0.0");
        int port = plugin.getConfig().getInt("port", 8765);
        server = HttpServer.create(new InetSocketAddress(bind, port), 64);
        server.createContext("/", this::handle);

        // Бounded пул: медленный запрос не блокирует остальные (head-of-line blocking).
        AtomicInteger seq = new AtomicInteger();
        pool = new ThreadPoolExecutor(2, 8, 60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(128),
                r -> {
                    Thread t = new Thread(r, "BeeSkin-http-" + seq.incrementAndGet());
                    t.setDaemon(true);
                    return t;
                },
                new ThreadPoolExecutor.CallerRunsPolicy());
        server.setExecutor(pool);
        server.start();
    }

    public int port() {
        return server == null ? plugin.getConfig().getInt("port", 8765) : server.getAddress().getPort();
    }

    public void stop() {
        if (server != null) {
            server.stop(1);
        }
        if (pool != null) {
            pool.shutdown();
            try {
                if (!pool.awaitTermination(3, TimeUnit.SECONDS)) {
                    pool.shutdownNow();
                }
            } catch (InterruptedException e) {
                pool.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }

    // ── Статика ────────────────────────────────────────────────

    private void loadAssets() throws IOException {
        assets.clear();
        for (String name : STATIC_NAMES) {
            try (InputStream in = plugin.getResource("web/" + name)) {
                if (in == null) {
                    throw new IOException("Статический файл web/" + name + " не найден в JAR");
                }
                assets.put(name, in.readAllBytes());
            }
        }
    }

    /** Путь может начинаться с "/web/" (совместимость со старой разметкой). */
    private byte[] staticAsset(String path) {
        String name = path.startsWith("/web/") ? path.substring("/web/".length()) : path;
        if (name.startsWith("/")) {
            name = name.substring(1);
        }
        if (!STATIC_NAMES.contains(name)) {
            return null;
        }
        return assets.get(name);
    }

    private String mime(String name) {
        return switch (name) {
            case "index.html" -> "text/html; charset=utf-8";
            case "app.js" -> "application/javascript; charset=utf-8";
            case "app.css" -> "text/css; charset=utf-8";
            case "favicon.svg" -> "image/svg+xml";
            default -> "application/octet-stream";
        };
    }

    // ── Диспетчер ──────────────────────────────────────────────

    private void handle(HttpExchange ex) {
        try {
            String method = ex.getRequestMethod();
            String path = ex.getRequestURI().getPath();

            if ("OPTIONS".equalsIgnoreCase(method)) {
                preflight(ex);
                return;
            }

            if ("GET".equalsIgnoreCase(method) || "HEAD".equalsIgnoreCase(method)) {
                byte[] asset = path.equals("/") ? assets.get("index.html") : staticAsset(path);
                if (asset != null) {
                    String name = path.equals("/") ? "index.html" : staticName(path);
                    String cache = name.equals("index.html") ? "no-cache" : "max-age=300";
                    send(ex, 200, mime(name), cache, asset);
                    return;
                }
                if (path.startsWith("/skin/")) {
                    serveSkinFile(ex, path.substring("/skin/".length()));
                    return;
                }
                if (path.equals("/api/session")) {
                    session(ex);
                    return;
                }
                if (path.equals("/api/skin.png")) {
                    sessionSkinPng(ex);
                    return;
                }
            }

            if ("POST".equalsIgnoreCase(method) && path.equals("/api/apply")) {
                apply(ex);
                return;
            }

            send(ex, 404, "application/json; charset=utf-8", "no-store", jsonError("not_found"));
        } catch (Exception e) {
            plugin.getLogger().warning("BeeSkin HTTP ошибка: " + e);
            try {
                send(ex, 500, "application/json; charset=utf-8", "no-store", jsonError("server_error"));
            } catch (IOException ignored) {
                // клиент уже отключился
            }
        } finally {
            lastApplyAt.entrySet().removeIf(e -> System.currentTimeMillis() - e.getValue() > 5 * 60_000L);
            ex.close();
        }
    }

    private String staticName(String path) {
        String name = path.startsWith("/web/") ? path.substring("/web/".length()) : path;
        if (name.startsWith("/")) {
            name = name.substring(1);
        }
        return name;
    }

    private void preflight(HttpExchange ex) throws IOException {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Access-Control-Max-Age", "86400");
        ex.sendResponseHeaders(204, -1);
    }

    // ── API ────────────────────────────────────────────────────

    private void session(HttpExchange ex) throws IOException {
        TokenStore.Session s = tokens.find(query(ex, "token"));
        if (s == null) {
            send(ex, 401, "application/json; charset=utf-8", "no-store", jsonError("invalid_token"));
            return;
        }
        String body = "{\"player\":\"" + jsonEsc(s.playerName)
                + "\",\"expiresAt\":" + s.expiresAt
                + ",\"skinReady\":" + (s.png != null)
                + ",\"model\":\"" + (s.model != null && s.model.equals("slim") ? "slim" : "classic") + "\"}";
        send(ex, 200, "application/json; charset=utf-8", "no-store", body.getBytes(StandardCharsets.UTF_8));
    }

    /** Текущий скин игрока для предзагрузки в редактор. */
    private void sessionSkinPng(HttpExchange ex) throws IOException {
        String key = query(ex, "token");
        TokenStore.Session s = tokens.find(key);
        if (s == null) {
            try {
                s = tokens.findByPlayer(UUID.fromString(key));
            } catch (IllegalArgumentException ignored) {
                // ключ не UUID — остаёмся с null
            }
        }
        if (s == null || s.png == null) {
            send(ex, 404, "text/plain; charset=utf-8", "no-store", "not found".getBytes(StandardCharsets.UTF_8));
            return;
        }
        send(ex, 200, "image/png", "no-store", s.png);
    }

    /** Публичная отдача PNG (local fallback). Имя файла — случайный токен. */
    private void serveSkinFile(HttpExchange ex, String fileName) throws IOException {
        if (!SKIN_FILE.matcher(fileName).matches()) {
            send(ex, 400, "application/json; charset=utf-8", "no-store", jsonError("bad_request"));
            return;
        }
        Path file = plugin.getDataFolder().toPath().resolve("served").resolve(fileName);
        if (!Files.isRegularFile(file)) {
            send(ex, 404, "application/json; charset=utf-8", "no-store", jsonError("not_found"));
            return;
        }
        byte[] data = Files.readAllBytes(file);
        // Клиент Minecraft кэширует текстуры по URL; заголовок обязателен.
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        send(ex, 200, "image/png", "public, max-age=31536000, immutable", data);
    }

    // ── /api/apply ─────────────────────────────────────────────

    private void apply(HttpExchange ex) throws IOException {
        TokenStore.Session s = tokens.find(query(ex, "token"));
        if (s == null) {
            send(ex, 401, "application/json; charset=utf-8", "no-store", jsonError("invalid_token"));
            return;
        }
        if (!originAllowed(ex)) {
            plugin.getLogger().warning("Отклонён /api/apply: Origin=" + ex.getRequestHeaders().getFirst("Origin")
                    + " для игрока " + s.playerName);
            send(ex, 403, "application/json; charset=utf-8", "no-store", jsonError("origin_forbidden"));
            return;
        }

        long cooldownMs = plugin.getConfig().getInt("apply-cooldown-seconds", 10) * 1000L;
        long now = System.currentTimeMillis();
        Long last = lastApplyAt.get(s.playerId);
        if (last != null && now - last < cooldownMs) {
            long left = (cooldownMs - (now - last) + 999) / 1000;
            send(ex, 429, "application/json; charset=utf-8", "no-store",
                    ("{\"error\":\"too_soon\",\"message\":\"Слишком быстро, повторите через " + left + " c\"}")
                            .getBytes(StandardCharsets.UTF_8));
            return;
        }

        int maxPng = plugin.getConfig().getInt("max-upload-bytes", 1_048_576);
        byte[] body = readBody(ex, maxPng * 2);
        if (body == null) {
            send(ex, 413, "application/json; charset=utf-8", "no-store", jsonError("request_too_large"));
            return;
        }

        byte[] png = extractPng(body, ex.getRequestHeaders().getFirst("Content-Type"), maxPng);
        if (png == null) {
            send(ex, 400, "application/json; charset=utf-8", "no-store", jsonError("invalid_png"));
            return;
        }
        if (png.length > maxPng) {
            send(ex, 413, "application/json; charset=utf-8", "no-store", jsonError("file_too_large"));
            return;
        }
        BufferedImage image;
        try {
            image = ImageIO.read(new ByteArrayInputStream(png));
        } catch (Exception e) {
            image = null;
        }
        if (image == null || image.getWidth() != 64 || image.getHeight() != 64) {
            send(ex, 400, "application/json; charset=utf-8", "no-store", jsonError("skin_must_be_64x64"));
            return;
        }

        String model = query(ex, "model");
        lastApplyAt.put(s.playerId, now);
        s.png = png; // обновляем кэш сессии: предпросмотр снова покажет новый скин
        plugin.getLogger().info("Загружен скин: игрок=" + s.playerName + " размер=" + png.length + " модель="
                + (model.equals("slim") ? "slim" : "classic"));

        Bukkit.getScheduler().runTask(plugin, () -> SkinApplier.apply(plugin, s.playerId, s.playerName, png,
                "slim".equalsIgnoreCase(model)));
        send(ex, 200, "application/json; charset=utf-8", "no-store",
                "{\"ok\":true,\"message\":\"Скин отправлен на применение\"}".getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Origin-проверка для POST /api/apply.
     * Разрешаем: запросы без Origin (не браузеры), own origin, public-url origin
     * и явно указанные allowed-origins.
     */
    private boolean originAllowed(HttpExchange ex) {
        String origin = ex.getRequestHeaders().getFirst("Origin");
        if (origin == null || origin.isBlank()) {
            return true;
        }
        java.util.Set<String> allowed = new java.util.HashSet<>(plugin.getConfig().getStringList("allowed-origins"));
        String publicUrl = plugin.getConfig().getString("public-url", "").trim();
        if (!publicUrl.isEmpty()) {
            allowed.add(stripTrailing(publicUrl));
        }
        // own origin: http://<bind>:<port> — только для bind не на всех интерфейсах
        String bind = plugin.getConfig().getString("bind-address", "0.0.0.0");
        if (!bind.equals("0.0.0.0") && !bind.equals("::")) {
            allowed.add("http://" + bind + ":" + port());
        }
        for (String a : allowed) {
            if (origin.equalsIgnoreCase(a)) {
                return true;
            }
        }
        return false;
    }

    private static String stripTrailing(String s) {
        return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
    }

    // ── Чтение тела ────────────────────────────────────────────

    /** Прочитать тело с жёстким лимитом. null = превышен лимит. */
    private static byte[] readBody(HttpExchange ex, int max) throws IOException {
        String lengthHeader = ex.getRequestHeaders().getFirst("Content-Length");
        if (lengthHeader != null) {
            try {
                if (Long.parseLong(lengthHeader) > max) {
                    return null;
                }
            } catch (NumberFormatException ignored) {
                // доверимся посчету при чтении
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(max, 8192));
        byte[] buffer = new byte[8192];
        int total = 0;
        int read;
        while ((read = ex.getRequestBody().read(buffer)) != -1) {
            total += read;
            if (total > max) {
                return null;
            }
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    /**
     * Извлечь PNG из тела запроса.
     * Поддерживает raw PNG (Content-Type: image/png) и JSON {"png":"data:image/png;base64,..."}
     * (совместимость со старым фронтендом).
     */
    static byte[] extractPng(byte[] body, String contentType, int maxPng) {
        if (body.length == 0) {
            return null;
        }
        if (contentType != null && contentType.toLowerCase(Locale.ROOT).startsWith("image/png")) {
            return isValidPng(body) ? body : null;
        }
        // JSON: ищем "png":"..." линейным сканом (без regex — тело до мегабайта).
        String text = new String(body, StandardCharsets.UTF_8);
        String dataUrl = jsonStringValue(text, "png");
        if (dataUrl == null) {
            return null;
        }
        String prefix = "data:image/png;base64,";
        String b64;
        if (dataUrl.startsWith(prefix)) {
            b64 = dataUrl.substring(prefix.length());
        } else if (looksLikeBase64(dataUrl) && dataUrl.length() <= maxPng * 4 / 3 + 8) {
            b64 = dataUrl;
        } else {
            return null;
        }
        try {
            byte[] png = Base64.getDecoder().decode(b64);
            return isValidPng(png) ? png : null;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static boolean isValidPng(byte[] data) {
        if (data.length < 8) {
            return false;
        }
        // PNG signature
        return data[0] == (byte) 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G';
    }

    private static boolean looksLikeBase64(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!(Character.isLetterOrDigit(c) || c == '+' || c == '/' || c == '=' || c == '-' || c == '_')) {
                return false;
            }
        }
        return s.length() >= 100;
    }

    /**
     * Извлечь строковое значение ключа из плоского JSON (линейный поиск).
     * Возвращает null, если ключ или строка не найдены.
     */
    static String jsonStringValue(String json, String key) {
        String needle = "\"" + key + "\"";
        int i = json.indexOf(needle);
        if (i < 0) {
            return null;
        }
        i = json.indexOf(':', i + needle.length());
        if (i < 0) {
            return null;
        }
        i++;
        while (i < json.length() && Character.isWhitespace(json.charAt(i))) {
            i++;
        }
        if (i >= json.length() || json.charAt(i) != '"') {
            return null;
        }
        i++;
        int start = i;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                i += 2;
                continue;
            }
            if (c == '"') {
                return json.substring(start, i);
            }
            i++;
        }
        return null;
    }

    // ── Утилиты ответа ─────────────────────────────────────────

    private void send(HttpExchange ex, int code, String type, String cacheControl, byte[] body) throws IOException {
        boolean head = "HEAD".equalsIgnoreCase(ex.getRequestMethod());
        var headers = ex.getResponseHeaders();
        headers.set("Content-Type", type);
        headers.set("Cache-Control", cacheControl);
        headers.add("X-Content-Type-Options", "nosniff");
        ex.sendResponseHeaders(code, head ? -1 : body.length);
        if (!head) {
            try (OutputStream out = ex.getResponseBody()) {
                out.write(body);
            }
        }
    }

    static byte[] jsonError(String error) {
        return (error.equals("invalid_token") ? "{\"error\":\"invalid_token\",\"message\":\"Ссылка недействительна или истекла\"}"
                : error.equals("skin_must_be_64x64") ? "{\"error\":\"skin_must_be_64x64\",\"message\":\"Скин должен быть PNG 64x64\"}"
                : error.equals("request_too_large") || error.equals("file_too_large")
                ? "{\"error\":\"file_too_large\",\"message\":\"Файл слишком большой\"}"
                : "{\"error\":\"" + error + "\"}").getBytes(StandardCharsets.UTF_8);
    }

    private static String query(HttpExchange e, String k) {
        String q = e.getRequestURI().getRawQuery();
        if (q == null) {
            return "";
        }
        for (String p : q.split("&")) {
            String[] a = p.split("=", 2);
            if (a.length == 2 && a[0].equals(k)) {
                try {
                    return URLDecoder.decode(a[1], StandardCharsets.UTF_8);
                } catch (Exception ignored) {
                    return a[1];
                }
            }
        }
        return "";
    }

    private static String jsonEsc(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\' -> sb.append("\\\\");
                case '"' -> sb.append("\\\"");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    /** Каталог публичной отдачи PNG: plugins/BeeSkin/served/. */
    public static Path servedDir(BeeSkinPlugin plugin) {
        return plugin.getDataFolder().toPath().resolve("served");
    }
}
