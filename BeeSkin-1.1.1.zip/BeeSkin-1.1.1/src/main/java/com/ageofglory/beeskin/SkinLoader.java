package com.ageofglory.beeskin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Загрузка ТЕКУЩЕГО скина игрока для предзагрузки в редактор.
 * <p>
 * Источники (по приоритету):
 * <ol>
 *   <li>СkinsRestorer: сохранённый SkinProperty игрока (кастомный скин).
 *       Его value — data-URL или Mojang-пейлоад; в типовом случае PNG
 *       декодируется локально, без сети.</li>
 *   <li>Профиль Paper: {@code player.getPlayerProfile().getTextures().getSkin()}
 *       — base64 PNG прямо из сессии, без HTTP-запроса.</li>
 * </ol>
 * Сетевые операции (download текстур) — только в async.
 */
final class SkinLoader {

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private static final Pattern SKIN_URL = Pattern.compile(
            "\"SKIN\"\\s*:\\s*\\{[^}]*?\"url\"\\s*:\\s*\"(https?://[^\"]+)\"", Pattern.CASE_INSENSITIVE);

    /** Вызывать на main thread: часть данных (профиль) читается из сессии игрока. */
    static void loadAsync(BeeSkinPlugin plugin, TokenStore.Session session, Player player) {
        if (session.png != null) {
            return;
        }
        String value = null;

        // 1) SkinsRestorer: сохранённый property игрока.
        SkinApplier.SR sr = SkinApplier.sr();
        if (sr != null) {
            value = readSrProperty(sr, player.getUniqueId(), player.getName());
        }

        // 2) Профиль Paper: URL текущей текстуры из сессии игрока.
        if (value == null) {
            try {
                var textures = player.getPlayerProfile().getTextures();
                if (textures != null && !textures.isEmpty()) {
                    if (textures.getSkinModel() == org.bukkit.profile.PlayerTextures.SkinModel.SLIM) {
                        session.model = "slim";
                    }
                    java.net.URL url = textures.getSkin();
                    if (url != null) {
                        value = url.toString();
                    }
                }
            } catch (Throwable ignored) {
                // профиль недоступен (offline-mode и т.п.)
            }
        }

        if (value == null || value.isBlank()) {
            plugin.getLogger().fine("Источник текстуры для " + player.getName() + " не найден — редактор стартует с демо-скина.");
            return;
        }

        final String finalValue = value;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                byte[] png = resolve(plugin, finalValue);
                if (png != null) {
                    session.png = png;
                }
            } catch (Exception e) {
                plugin.getLogger().fine("Не удалось получить текущий скин " + player.getName() + ": " + e.getMessage());
            }
        });
    }

    /** value из storage SR, либо null. */
    private static String readSrProperty(SkinApplier.SR sr, UUID uuid, String name) {
        try {
            Object storage = sr.api.getClass().getMethod("getPlayerStorage").invoke(sr.api);
            Object result;
            try {
                result = storage.getClass().getMethod("getSkinForPlayer", UUID.class, String.class)
                        .invoke(storage, uuid, name);
            } catch (NoSuchMethodException e) {
                result = storage.getClass().getMethod("getSkinForPlayer", UUID.class, String.class, boolean.class)
                        .invoke(storage, uuid, name, false);
            }
            if (!(result instanceof Optional<?> opt) || opt.isEmpty()) {
                return null;
            }
            Object property = opt.get();
            Object value = property.getClass().getMethod("getValue").invoke(property);
            return value == null ? null : value.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Разрешить value в PNG-байты:
     * data-URL → decode; http(s) → download; base64-PNG → decode;
     * base64-Mojang-JSON → извлечь url и download.
     */
    private static byte[] resolve(BeeSkinPlugin plugin, String value) throws Exception {
        byte[] png = null;
        if (value.startsWith("data:image/png;base64,")) {
            png = Base64.getDecoder().decode(value.substring("data:image/png;base64,".length()));
        } else if (value.startsWith("http://") || value.startsWith("https://")) {
            png = download(value);
        } else {
            try {
                png = Base64.getDecoder().decode(value);
            } catch (IllegalArgumentException notBase64) {
                return null;
            }
            if (png != null && !isPng(png) && looksLikeJson(png)) {
                String json = new String(png, java.nio.charset.StandardCharsets.UTF_8);
                Matcher m = SKIN_URL.matcher(json);
                if (m.find()) {
                    png = download(m.group(1));
                } else {
                    return null;
                }
            }
        }
        return png != null && isPng(png) && is64x64(png) ? png : null;
    }

    private static byte[] download(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("User-Agent", "BeeSkin/1.1 AgeOfGlory")
                .GET()
                .build();
        HttpResponse<byte[]> response = HTTP.send(request, HttpResponse.BodyHandlers.ofByteArray());
        return response.statusCode() == 200 ? response.body() : null;
    }

    private static boolean isPng(byte[] data) {
        return data != null && data.length >= 8
                && data[0] == (byte) 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G';
    }

    private static boolean looksLikeJson(byte[] data) {
        return data.length > 16 && (data[0] == '{' || data[0] == '"');
    }

    private static boolean is64x64(byte[] png) {
        try {
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(png));
            return image != null && image.getWidth() == 64 && image.getHeight() == 64;
        } catch (Exception e) {
            return false;
        }
    }
}
