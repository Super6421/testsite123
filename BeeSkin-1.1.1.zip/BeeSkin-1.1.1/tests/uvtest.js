'use strict';
/*
 * Верификация UV-раскладки BeeSkin:
 *  1) Сопоставление с эталонным рендерером daidr/minecraft-skin-renderer
 *     (createBoxUV + UV_SKIN face assignment).
 *  2) Проверка, что маппинг пикапа uvAt() согласован с UV меша pushBox().
 */

// ── Эталон: createBoxUV (standard layout) ──
function refBoxUV(x, y, w, h, d) {
  return {
    right:  [x, y + d, d, h],
    front:  [x + d, y + d, w, h],
    left:   [x + d + w, y + d, d, h],
    back:   [x + d + w + d, y + d, w, h],
    top:    [x + d, y, w, d],
    bottom: [x + d + w, y, d, d]
  };
}

// Привязка UV-ключей к мирным нормалям (UV_SKIN из BoxGeometry.ts):
// [Front(+Z), Back(-Z), Left(-X), Right(+X), Top(+Y), Bottom(-Y)] -> [front, back, right, left, top, bottom]
const REF_NORMAL_TO_KEY = { '+Z': 'front', '-Z': 'back', '-X': 'right', '+X': 'left', '+Y': 'top', '-Y': 'bottom' };

const REF_PARTS = {
  classic: {
    base:  { head: [0, 0], body: [16, 16], rightArm: [40, 16], leftArm: [32, 48], rightLeg: [0, 16], leftLeg: [16, 48] },
    outer: { head: [32, 0], body: [16, 32], rightArm: [40, 32], leftArm: [48, 48], rightLeg: [0, 32], leftLeg: [0, 48] }
  },
  slim: {
    base:  { head: [0, 0], body: [16, 16], rightArm: [40, 16, 3], leftArm: [32, 48, 3], rightLeg: [0, 16], leftLeg: [16, 48] },
    outer: { head: [32, 0], body: [16, 32], rightArm: [40, 32, 3], leftArm: [48, 48, 3], rightLeg: [0, 32], leftLeg: [0, 48] }
  }
};
const PART_DIMS = (model) => ({
  head: [8, 8, 8], body: [8, 12, 4],
  rightArm: [model === 'slim' ? 3 : 4, 12, 4], leftArm: [model === 'slim' ? 3 : 4, 12, 4],
  rightLeg: [4, 12, 4], leftLeg: [4, 12, 4]
});

// ── Мой код из app.js ──
function strip(x, y, frontW, sideW, h) {
  return {
    l: [x, y + sideW, sideW, h],
    f: [x + sideW, y + sideW, frontW, h],
    r: [x + sideW + frontW, y + sideW, sideW, h],
    b: [x + sideW + frontW + sideW, y + sideW, frontW, h],
    t: [x + sideW, y, frontW, sideW],
    d: [x + sideW + frontW, y, sideW, sideW]
  };
}
function rectsFor(model, layer) {
  const o = layer === 'outer';
  const armW = model === 'slim' ? 3 : 4;
  return {
    head:     o ? strip(32, 0, 8, 8, 8) : strip(0, 0, 8, 8, 8),
    body:     o ? strip(16, 32, 8, 4, 12) : strip(16, 16, 8, 4, 12),
    rightArm: o ? strip(40, 32, armW, 4, 12) : strip(40, 16, armW, 4, 12),
    leftArm:  o ? strip(48, 48, armW, 4, 12) : strip(32, 48, armW, 4, 12),
    rightLeg: o ? strip(0, 32, 4, 4, 12) : strip(0, 16, 4, 4, 12),
    leftLeg:  o ? strip(0, 48, 4, 4, 12) : strip(16, 48, 4, 4, 12)
  };
}
const MY_NORMAL_TO_KEY = { '+Z': 'f', '-Z': 'b', '-X': 'l', '+X': 'r', '+Y': 't', '-Y': 'd' };

// uvAt из app.js
function uvAt(b, rects, faceKey, px, py, pz) {
  const [rx, ry, rw, rh] = rects[faceKey];
  const X = b.w / 2, Y = b.h / 2, Z = b.d / 2;
  let u, row;
  switch (faceKey) {
    case 'f': u = (px - (b.x - X)) / b.w; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'b': u = 1 - (px - (b.x - X)) / b.w; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'l': u = (pz - (b.z - Z)) / b.d; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 'r': u = 1 - (pz - (b.z - Z)) / b.d; row = ry + (1 - (py - (b.y - Y)) / b.h) * rh; break;
    case 't': u = (px - (b.x - X)) / b.w; row = ry + ((pz - (b.z - Z)) / b.d) * rh; break;
    default:  u = (px - (b.x - X)) / b.w; row = ry + ((pz - (b.z - Z)) / b.d) * rh;
  }
  const f = Math.max(0, Math.min(0.999, (row - ry) / rh));
  return [
    Math.max(0, Math.min(63, Math.floor(rx + Math.max(0, Math.min(0.999, u)) * rw))),
    Math.max(0, Math.min(63, Math.floor(ry + f * rh)))
  ];
}

// ── 1) Сравнение с эталоном ──
let failures = 0, checks = 0;
function eq(a, b) { return a[0] === b[0] && a[1] === b[1] && a[2] === b[2] && a[3] === b[3]; }
for (const model of ['classic', 'slim']) {
  for (const layer of ['base', 'outer']) {
    const mine = rectsFor(model, layer);
    for (const part of Object.keys(PART_DIMS(model))) {
      const dims = PART_DIMS(model)[part];
      const origin = REF_PARTS[model][layer][part];
      const ref = refBoxUV(origin[0], origin[1], dims[0], dims[1], dims[2]);
      for (const normal of Object.keys(REF_NORMAL_TO_KEY)) {
        const rRect = ref[REF_NORMAL_TO_KEY[normal]];
        const mRect = mine[part][MY_NORMAL_TO_KEY[normal]];
        checks++;
        if (!eq(rRect, mRect)) {
          failures++;
          console.log(`MISMATCH ${model}/${layer}/${part} ${normal}: ref=${JSON.stringify(rRect)} mine=${JSON.stringify(mRect)}`);
        }
      }
    }
  }
}
console.log(`UV table vs reference: ${checks - failures}/${checks} OK`);

// ── 2) uvAt согласован с UV меша ──
// Параметризация граней: (s,t) ∈ [0,1]^2 → точка мира + ожидаемые mesh-UV.
// Для каждой грани: P(s,t) и tex(s,t), где tex вычисляется из per-vertex UV pushBox
// (паттерн [ (u0,vB),(u1,vB),(u1,vT),(u0,vT) ] на вершинах [v0,v1,v2,v3]).
function faceTests(model, layer, part, box, allRects) {
  const rects = allRects[part];
  const [w, h, d] = PART_DIMS(model)[part];
  const X = (w + (layer === 'outer' ? 1 : 0)) / 2, Y = (h + (layer === 'outer' ? 1 : 0)) / 2, Z = (d + (layer === 'outer' ? 1 : 0)) / 2;
  const x = box.x, y = box.y, z = box.z;
  const cL = [x - X, y - Y, z + Z], cR = [x + X, y - Y, z + Z];
  const tR = [x + X, y + Y, z + Z], tL = [x - X, y + Y, z + Z];
  const bL = [x - X, y - Y, z - Z], bR = [x + X, y - Y, z - Z];
  const hR = [x + X, y + Y, z - Z], hL = [x - X, y + Y, z - Z];
  const FACES = {
    f: { verts: [cL, cR, tR, tL] },   // s: x, t: y
    b: { verts: [bR, bL, hL, hR] },   // s: x (+->-), t: y
    l: { verts: [bL, cL, tL, hL] },   // s: z (-->+), t: y
    r: { verts: [cR, bR, hR, tR] },   // s: z (+->-), t: y
    t: { verts: [cL, cR, bR, bL] },   // s: x, t: z (+->-)
    d: { verts: [cR, cL, bL, bR] }    // s: x (+->-), t: z (+->-)
  };
  for (const [key, fc] of Object.entries(FACES)) {
    const [rx, ry, rw, rh] = rects[key];
    const u0 = rx / 64, u1 = (rx + rw) / 64;
    const vT = 1 - ry / 64, vB = 1 - (ry + rh) / 64;
    const uvPattern = key === 'd'
      ? [[u1, vB], [u0, vB], [u0, vT], [u1, vT]]
      : [[u0, vB], [u1, vB], [u1, vT], [u0, vT]];
    const [V0, V1, V2, V3] = fc.verts;
    // bilinear на плоской грани: P = (1-s)(1-t)V0 + s(1-t)V1 + st V2 + (1-s)t V3
    // UV  = то же билинейное от uvPattern
    const rectsFace = { [key]: rects[key] };
    for (const s of [0.25, 0.5, 0.75]) {
      for (const t of [0.25, 0.5, 0.75]) {
        const P = [0, 1, 2].map(i => (1 - s) * (1 - t) * V0[i] + s * (1 - t) * V1[i] + s * t * V2[i] + (1 - s) * t * V3[i]);
        const uE = (1 - s) * (1 - t) * uvPattern[0][0] + s * (1 - t) * uvPattern[1][0] + s * t * uvPattern[2][0] + (1 - s) * t * uvPattern[3][0];
        const vE = (1 - s) * (1 - t) * uvPattern[0][1] + s * (1 - t) * uvPattern[1][1] + s * t * uvPattern[2][1] + (1 - s) * t * uvPattern[3][1];
        const expPx = Math.floor(uE * 64), expPy = Math.floor((1 - vE) * 64);
        const got = uvAt(box, rectsFace, key, P[0], P[1], P[2]);
        checks++;
        if (Math.abs(got[0] - expPx) > 0 || Math.abs(got[1] - expPy) > 0) {
          failures++;
          console.log(`PICK MISMATCH ${model}/${layer}/${part}.${key} s=${s} t=${t}: exp=[${expPx},${expPy}] got=[${got}]`);
        }
      }
    }
  }
}

for (const model of ['classic', 'slim']) {
  for (const layer of ['base', 'outer']) {
    const armW = model === 'slim' ? 3 : 4;
    const shoulder = 4 + armW / 2;
    const inflate = layer === 'outer' ? 0.5 : 0;
    const mk = (name, x, y, z, w, h, d) => ({ name, x, y, z, w: w + inflate * 2, h: h + inflate * 2, d: d + inflate * 2 });
    const parts = {
      head: mk('head', 0, 10, 0, 8, 8, 8),
      body: mk('body', 0, 0, 0, 8, 12, 4),
      rightArm: mk('rightArm', -shoulder, 0, 0, armW, 12, 4),
      leftArm: mk('leftArm', shoulder, 0, 0, armW, 12, 4),
      rightLeg: mk('rightLeg', -2, -12, 0, 4, 12, 4),
      leftLeg: mk('leftLeg', 2, -12, 0, 4, 12, 4)
    };
    const rects = rectsFor(model, layer);
    for (const part of Object.keys(parts)) {
      faceTests(model, layer, part, parts[part], rects);
    }
  }
}
console.log(`Total checks: ${checks}, failures: ${failures}`);
process.exit(failures ? 1 : 0);
