'use strict';
/* Смоук-тест BeeSkin app.js: минимальный DOM-стаб + симуляция событий.
 * Проверяет: старт, рисование (все инструменты), undo/redo, слои,
 * загрузку PNG, apply, палитру. WebGL недоступен → проверяется fallback в 2D.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

// ── 2D-контекст с реальным пиксельным буфером 64x64 ──
function make2dCtx(canvas) {
  const DBG = process.env.DBG_CTX;
  const data = new Uint8ClampedArray(64 * 64 * 4);
  canvas.__buf = data;
  const ctx = {
    imageSmoothingEnabled: false,
    fillStyle: '#000000',
    clearRect(x, y, w, h) {
      for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) {
        const i = (yy * 64 + xx) * 4; data[i] = data[i+1] = data[i+2] = data[i+3] = 0;
      }
    },
    fillRect(x, y, w, h) {
      if (DBG) console.log('fillRect', canvas.id || 'anon', x, y, w, h);
      const c = parseColor(ctx.fillStyle);
      for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) {
        const i = (yy * 64 + xx) * 4;
        const a = c.a / 255;
        const ba = 1 - a;
        data[i] = Math.round(c.r * a + data[i] * ba);
        data[i+1] = Math.round(c.g * a + data[i+1] * ba);
        data[i+2] = Math.round(c.b * a + data[i+2] * ba);
        data[i+3] = Math.max(data[i+3], Math.round(c.a));
      }
    },
    getImageData(x, y, w, h) {
      const out = new Uint8ClampedArray(w * h * 4);
      for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) {
        const si = (yy * 64 + xx) * 4, di = ((yy - y) * w + (xx - x)) * 4;
        out[di] = data[si]; out[di+1] = data[si+1]; out[di+2] = data[si+2]; out[di+3] = data[si+3];
      }
      return { data: out, width: w, height: h };
    },
    putImageData(img, dx, dy) {
      for (let yy = 0; yy < img.height; yy++) for (let xx = 0; xx < img.width; xx++) {
        const si = (yy * img.width + xx) * 4, di = ((dy + yy) * 64 + (dx + xx)) * 4;
        data[di] = img.data[si]; data[di+1] = img.data[si+1]; data[di+2] = img.data[si+2]; data[di+3] = img.data[si+3];
      }
    },
    drawImage(src, x, y) {
      if (DBG) console.log('drawImage', canvas.id || 'anon', 'src=' + (src.id || 'anon-img'), 'buf=' + !!src.__buf);
      const s = src.__buf || src;
      // source-over композитинг, как в настоящем canvas2d
      for (let yy = 0; yy < 64; yy++) for (let xx = 0; xx < 64; xx++) {
        const si = (yy * 64 + xx) * 4, di = ((y + yy) * 64 + (x + xx)) * 4;
        const sa = s[si+3] / 255, da = data[di+3] / 255;
        const oa = sa + da * (1 - sa);
        if (oa > 0) {
          data[di]   = Math.round((s[si]   * sa + data[di]   * da * (1 - sa)) / oa);
          data[di+1] = Math.round((s[si+1] * sa + data[di+1] * da * (1 - sa)) / oa);
          data[di+2] = Math.round((s[si+2] * sa + data[di+2] * da * (1 - sa)) / oa);
        }
        data[di+3] = Math.round(oa * 255);
      }
      if (DBG) console.log('drawImage done', canvas.id, 'same=' + (data === canvas.__buf), 's0=' + s[0], 'data0=' + data[0]);
    }
  };
  return ctx;
}
function parseColor(str) {
  if (str.startsWith('#')) {
    return { r: parseInt(str.slice(1, 3), 16), g: parseInt(str.slice(3, 5), 16), b: parseInt(str.slice(5, 7), 16), a: 255 };
  }
  const m = str.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?\)/);
  return { r: +m[1], g: +m[2], b: +m[3], a: m[4] == null ? 255 : Math.round(m[4] * 255) };
}

// ── Фейковый DOM ──
class FakeEl {
  constructor(tag, id) {
    this.tagName = (tag || 'div').toUpperCase();
    this.id = id || '';
    this.children = [];
    this.dataset = {};
    this.style = {};
    this._listeners = {};
    this._classes = new Set();
    this.textContent = '';
    this.innerHTML = '';
    this.value = '';
    this.disabled = false;
    this.width = 0; this.height = 0;
    this.naturalWidth = 0; this.naturalHeight = 0;
    this.title = '';
    this.className = '';
    if (this.tagName === 'CANVAS') {
      this.width = 64; this.height = 64;
      this.__buf = null;
    }
  }
  get classList() {
    const self = this;
    return {
      add: (c) => self._classes.add(c),
      remove: (c) => self._classes.delete(c),
      toggle: (c, force) => {
        const has = self._classes.has(c);
        const want = force == null ? !has : !!force;
        if (want) self._classes.add(c); else self._classes.delete(c);
        return want;
      },
      contains: (c) => self._classes.has(c)
    };
  }
  addEventListener(type, fn) { (this._listeners[type] ||= []).push(fn); }
  dispatch(type, ev) {
    ev.preventDefault = ev.preventDefault || (() => {});
    ev.stopPropagation = ev.stopPropagation || (() => {});
    ev.target = ev.target || this;
    for (const fn of (this._listeners[type] || [])) fn(ev);
  }
  setPointerCapture() {}
  releasePointerCapture() {}
  getBoundingClientRect() {
    return { left: 0, top: 0, width: this.width || 430, height: this.height || 430 };
  }
  append(...els) { this.children.push(...els); }
  appendChild(el) { this.children.push(el); return el; }
  remove() {}
  getContext(kind, opts) {
    if (kind === '2d') {
      if (!this.__ctx2d) this.__ctx2d = make2dCtx(this);
      return this.__ctx2d;
    }
    return null; // webgl недоступен → fallback-ветка
  }
  toBlob(cb, type) { cb(new FakeBlob(this.__buf)); }
  toDataURL() { return 'data:image/png;base64,fake'; }
  onclick = null;
  querySelector() { return null; }
  querySelectorAll() { return []; }
}
class FakeBlob {
  constructor(buf) { this.buf = buf; this.size = buf ? buf.length : 0; this.type = 'image/png'; }
}

const byId = {};
const els = { all: [] };
function el(tag, id, extra) {
  const e = new FakeEl(tag, id);
  if (extra) Object.assign(e, extra);
  if (id) byId[id] = e;
  els.all.push(e);
  return e;
}

// элементы, на которые ссылается app.js
const textureCanvas = el('canvas', 'textureCanvas');
const glCanvas = el('canvas', 'glCanvas');
glCanvas.width = 800; glCanvas.height = 510;
const stage = el('div', 'stage');
const stageHint = el('div', 'stageHint');
const stageLoading = el('div', 'stageLoading');
const modelLabel = el('b', 'modelLabel');
const sessionText = el('span', 'sessionText');
const applyTop = el('button', 'applyTop');
const timeBtn = el('button', 'timeBtn');
const resetBtn = el('button', 'resetBtn');
const undoBtn = el('button', 'undo');
const redoBtn = el('button', 'redo');
const colorInput = el('input', 'color');
colorInput.value = '#f6c453';
const hexEl = el('strong', 'hex');
const paletteEl = el('div', 'palette');
const autoBtn = el('button', 'auto');
const animateBtn = el('button', 'animateBtn');
const gridBtn = el('button', 'gridBtn');
const zoomOut = el('button', 'zoomOut');
const zoomIn = el('button', 'zoomIn');
const zoomValue = el('span', 'zoomValue');
const fileInput = el('input', 'file');
const dropzone = el('label', 'dropzone');
const download = el('button', 'download');
const toasts = el('div', 'toasts');
const paintTab = el('div', 'paintTab');
const partsTab = el('div', 'partsTab');

const layerToggle = el('div', 'layerToggle'); layerToggle._classes.add('layer-toggle');
const viewToggle = el('div', 'viewToggle'); viewToggle._classes.add('view-toggle');
const tools = ['pencil', 'eraser', 'fill', 'picker', 'light', 'shadow', 'noise'].map(t => {
  const b = el('button', ''); b.dataset.tool = t; return b;
});
const views = ['3d', '2d'].map(v => { const b = el('button', ''); b.dataset.view = v; b.parent = viewToggle; return b; });
const layers = ['base', 'outer'].map(l => { const b = el('button', ''); b.dataset.layer = l; b.parent = layerToggle; return b; });
const parts = ['head', 'body', 'leftArm', 'rightArm', 'leftLeg', 'rightLeg'].map(p => { const b = el('button', ''); b.dataset.part = p; return b; });
const models = ['classic', 'slim'].map(m => { const b = el('button', ''); b.dataset.model = m; return b; });
const tabs = ['paint', 'parts'].map(t => { const b = el('button', ''); b.dataset.tab = t; return b; });
const presets = ['front', 'side', 'back'].map(p => { const b = el('button', ''); b.dataset.preset = p; return b; });

// document.querySelector по id / по data-*
function qs(sel) {
  if (sel.startsWith('#')) return byId[sel.slice(1)] || null;
  return qsa(sel)[0] || null;
}
function qsa(sel) {
  if (sel.startsWith('#')) { const e = byId[sel.slice(1)]; return e ? [e] : []; }
  const dm = sel.match(/\[data-([a-z]+)=?"?([a-z0-9-]+)"?\]/);
  if (dm) {
    const key = dm[1], val = dm[2] || null;
    return els.all.filter(e => (val == null ? e.dataset[key] !== undefined : e.dataset[key] === val));
  }
  const m = sel.match(/^\.([a-z0-9-]+)$/);
  if (m) return els.all.filter(e => e._classes.has(m[1]));
  const cm = sel.match(/^\.([a-z0-9-]+) ([a-z]+)$/);
  if (cm) {
    const want = cm[2].toUpperCase();
    return els.all.filter(e => e.tagName === want && hasAncestorClass(e, cm[1]));
  }
  return [];
}
function hasAncestorClass(e, cls) {
  let p = e.parent;
  while (p) { if (p._classes && p._classes.has(cls)) return true; p = p.parent; }
  return false;
}

const documentStub = {
  querySelector: qs,
  querySelectorAll: qsa,
  createElement: (tag) => new FakeEl(tag, ''),
  body: new FakeEl('body', ''),
  addEventListener: () => {}
};
const windowStub = { devicePixelRatio: 1, addEventListener: () => {} };
let rafQueue = [];
const sandbox = {
  console,
  document: documentStub,
  window: windowStub,
  location: { search: '?token=test123' },
  URLSearchParams: URLSearchParams,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Image: class {
    set src(v) {
      this.__src = v;
      const buf = new Uint8ClampedArray(64 * 64 * 4);
      for (let yy = 0; yy < 64; yy++) for (let xx = 0; xx < 64; xx++) {
        if (xx > 40 && yy > 40) continue; // прозрачный квадрант
        const i = (yy * 64 + xx) * 4;
        buf[i] = 246; buf[i+1] = 196; buf[i+2] = 83; buf[i+3] = 255;
      }
      this.__buf = buf;
      this.width = 64; this.height = 64; this.naturalWidth = 64; this.naturalHeight = 64;
      setTimeout(() => { if (this.onload) this.onload(); }, 0);
    }
  },
  createImageBitmap: () => Promise.reject(new Error('no canvas')),
  ImageData: class { constructor(buf, w, h) { this.data = buf; this.width = w; this.height = h; } },
  requestAnimationFrame: (fn) => { rafQueue.push(fn); return rafQueue.length; },
  cancelAnimationFrame: () => {},
  confirm: () => true,
  alert: () => {},
  fetch: async (url) => {
    if (String(url).includes('/api/session')) {
      return { ok: true, status: 200, json: async () => ({ player: 'Steve', expiresAt: Date.now() + 600000, skinReady: false, model: 'classic' }) };
    }
    return { ok: true, status: 200, json: async () => ({ ok: true }), blob: async () => new FakeBlob(null) };
  },
  setTimeout, clearTimeout, setInterval, clearInterval, Blob,
  Math, JSON, Promise, Map, Set, Uint8ClampedArray, Int32Array, Float32Array,
  devicePixelRatio: 1,
  navigator: {}
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

const appJsCandidates = [
    path.join(__dirname, '..', '..', 'src/main/resources/web/app.js'), // в дереве проекта
    path.join(__dirname, '..', 'BeeSkin/src/main/resources/web/app.js') // /home/user/smoke
  ];
  const appJsPath = appJsCandidates.find(p => fs.existsSync(p));
  if (!appJsPath) { console.error('app.js не найден'); process.exit(2); }
  const src = fs.readFileSync(appJsPath, 'utf8');
vm.runInContext(src, sandbox, { filename: 'app.js' });
console.log('DEBUG after-load: comp0=', textureCanvas.__buf ? textureCanvas.__buf[0] : 'NOBUF', 'els=', els.all.length, 'toasts?', !!byId.toasts);

process.on('unhandledRejection', e => console.error('REJ:', e && e.stack || e));
process.on('uncaughtException', e => console.error('UNCAUGHT:', e && e.stack || e));
const paint2d = (el, x, y, extra) => {
  el.dispatch('pointerdown', Object.assign({ button: 0, clientX: x, clientY: y, pointerId: 1 }, extra));
  el.dispatch('pointerup', Object.assign({ button: 0, clientX: x, clientY: y, pointerId: 1 }, extra));
};
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
(async () => {
  await sleep(20);

  // 1. Старт: demo-скин в base-слое, outer с hat, GL-fallback в 2D
  const comp = textureCanvas.__buf;
  assert(comp[0] > 0, 'демо-скин должен быть нарисован');
  assert(sessionText.textContent.includes('Steve'), 'сессия игрока подгружена: ' + sessionText.textContent);
  console.log('✓ старт, demo-скин, GL-fallback');

  // 2. Пипетка: цвет из композита
  sandbox.setTool('picker');
  paint2d(textureCanvas, 4, 4);
  assert(/#[0-9a-f]{6}/i.test(hexEl.textContent), 'пипетка установила цвет: ' + hexEl.textContent);
  const picked = hexEl.textContent.toLowerCase();
  console.log('✓ пипетка:', picked);

  // 3. Кисть: рисуем в base-слое пиксель (32,32)
  sandbox.setColor('#ff0000');
  sandbox.setTool('pencil');
  paint2d(textureCanvas, 10, 30);
  const i32 = (30 * 64 + 10) * 4;
  assert(comp[i32] === 255 && comp[i32 + 1] === 0 && comp[i32 + 2] === 0, 'кисть нарисовала #ff0000 в композите');
  console.log('✓ кисть (композит)');

  // 4. undo/redo
  sandbox.undo();
  const i32b = (30 * 64 + 10) * 4;
  assert(!(comp[i32b] === 255 && comp[i32b + 1] === 0 && comp[i32b + 2] === 0), 'undo отменил пиксель');
  sandbox.redo();
  assert(comp[i32b] === 255 && comp[i32b + 1] === 0, 'redo вернул пиксель');
  sandbox.undo();
  console.log('✓ undo/redo');

  // 5. Слои: рисуем в outer, base не меняется
  const baseBefore = [...textureCanvas.__buf];
  // baseLayer-канвас недоступен напрямую (.createElement внутри app.js) — проверяем через композит:
  // рисуем пиксель в outer (10,10) — там demo hat; потом в base тот же — композит тот же цвет?
  sandbox.setColor('#00ff00');
  layers[1].onclick(); // outer
  sandbox.setTool('pencil');
  // точка (2,2) — в demo hat (outer) не прозрачна
  paint2d(textureCanvas, 2, 2);
  const i2 = (2 * 64 + 2) * 4;
  assert(comp[i2 + 1] === 255 && comp[i2] === 0 && comp[i2 + 2] === 0, 'outer-слой записан поверх');
  // base-слой под (2,2) остался как был (demo base head-фон)
  layers[0].onclick(); // base
  // пипетка в (2,2) должна вернуть зелёный (видимый = outer)
  sandbox.setTool('picker');
  paint2d(textureCanvas, 2, 2);
  assert(hexEl.textContent.toLowerCase() === '#00ff00', 'пипетка берёт видимый (outer) цвет, got ' + hexEl.textContent);
  console.log('✓ слои + пипетка по композиту');

  // 6. Ластик в outer: открывает base
  sandbox.setTool('eraser');
  layers[1].onclick();
  paint2d(textureCanvas, 2, 2);
  const i2b = (2 * 64 + 2) * 4;
  assert(!(comp[i2b + 1] === 255 && comp[i2b] === 0), 'ластик outer открыл base');
  layers[0].onclick();
  console.log('✓ ластик outer → base виден');

  // 7. Заливка
  sandbox.setTool('fill');
  sandbox.setColor('#0000ff');
  // прозрачная зона: (50,50) — в demo прозрачно
  const i50 = (50 * 64 + 50) * 4;
  assert(comp[i50 + 3] === 0, 'зона (50,50) прозрачна');
  paint2d(textureCanvas, 50, 50);
  assert(comp[i50 + 2] === 255 && comp[i50] === 0, 'заливка окрасила зону');
  // соседние пиксели той же «воды»
  const i51 = (50 * 64 + 51) * 4;
  assert(comp[i51 + 2] === 255, 'заливка затопила область');
  console.log('✓ заливка');

  // 8. Свет/тень: осветляем и затемняем реальный пиксель
  const iHead = (10 * 64 + 10) * 4;
  const r0 = comp[iHead], g0 = comp[iHead + 1], b0 = comp[iHead + 2];
  sandbox.setTool('light');
  paint2d(textureCanvas, 10, 10);
  const r1 = comp[iHead], g1 = comp[iHead + 1], b1 = comp[iHead + 2];
  assert(r1 >= r0 && g1 >= g0 && b1 >= b0 && (r1 !== r0 || g1 !== g0 || b1 !== b0), 'свет осветлил: ' + [r0, g0, b0] + ' -> ' + [r1, g1, b1]);
  sandbox.setTool('shadow');
  paint2d(textureCanvas, 10, 10);
  const r2 = comp[iHead], g2 = comp[iHead + 1], b2 = comp[iHead + 2];
  assert(r2 <= r1 && g2 <= g1 && b2 <= b1, 'тень затемнила');
  console.log('✓ свет/тень');

  // 9. Шум
  sandbox.setTool('noise');
  for (let k = 0; k < 5; k++) textureCanvas.dispatch('pointerdown', { button: 0, clientX: 45 + k, clientY: 55, pointerId: 1 });
  console.log('✓ шум');

  // 10. Палитра: авто-палитра строится из скина
  autoBtn.onclick();
  assert(paletteEl.children.length > 0, 'палитра заполнена');
  console.log('✓ авто-палитра (' + paletteEl.children.length + ' цветов)');

  // 11. Apply: fetch gets raw PNG blob
  let applyBody = null, applyUrl = null;
  sandbox.fetch = async (url, opts) => { applyUrl = url; applyBody = opts.body; return { ok: true, status: 200, json: async () => ({ ok: true }) }; };
  applyTop.onclick();
  await sleep(30);
  assert(applyUrl && applyUrl.startsWith('/api/apply?token=test123'), 'apply → /api/apply, got ' + applyUrl);
  assert(applyUrl.includes('model=classic'), 'model в URL: ' + applyUrl);
  assert(applyBody && applyBody.type === 'image/png', 'body = raw PNG blob');
  assert(sessionText.textContent.includes('отправлен'), 'статус "отправлен"');
  console.log('✓ apply (raw PNG):', applyUrl);

  // 12. Reset
  resetBtn.onclick();
  assert(toasts.children.length > 0, 'тост при сбросе');
  console.log('✓ reset + тосты');

  console.log('\nALL SMOKE TESTS PASSED');
  process.exit(0);
})().catch(e => { console.error('FAIL:', e.message); console.error(e.stack); process.exit(1); });
