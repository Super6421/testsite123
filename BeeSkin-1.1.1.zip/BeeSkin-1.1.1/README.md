# BeeSkin 1.1.0

Веб-редактор скинов для Paper 1.21.4 (AgeOfGlory). Игрок в игре вводит
`/skineditor open` (оператор) и получает ссылку на редактор: 3D-превью
(чистый WebGL), два слоя (base + outer-hat), инструменты (кисть, ластик,
заливка, пипетка, свет, тень, шум), undo/redo, загрузка PNG, модель
classic/slim. Применение скина — через SkinsRestorer (подпись MineSkin,
live-обновление без реджайна, персистентность).

## Установка
1. `plugins/SkinsRestorer.jar` (v15.x) и `plugins/BeeSkin-1.1.0.jar`.
2. При необходимости — `plugins/BeeSkin/config.yml` (порт, public-url, TTL).
3. `/restart`, затем в игре: `/skineditor open`.

## Сборка
```
JAVA_HOME=jdk21 gradle shadowJar     # → build/libs/BeeSkin-1.1.0.jar
```
Платформа: Paper 1.21.4, Java 21. SR подтягивается в runtime (compileOnly-рефлексия,
без compile-зависимости — плагин не ломается при отсутствии/обновлении SR).

## Тесты
```
node tests/uvtest.js          # UV-раскладка vs эталон (1440 проверок)
node tests/smoke/dom-test.js  # смоук-тест фронта (12 сценариев)
```

Подробности аудита и список из 29 исправленных дефектов — в `AUDIT.md`.
