const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/command/CommandPolicyEngine.java","utf8");
console.log("lines=" + t.split("\n").length);
console.log(t);