const fs = require("fs");
const file = "dmc-plugin/src/test/java/ru/zigono/dmc/plugin/config/PluginConfigResourceTest.java";
const t = fs.readFileSync(file, "utf8");
const anchor = `    @Test
    void bypassesNothingByDefaultButStillRefusesTheLiteralBackslashX(@TempDir Path directory) {`;
if (!t.includes(anchor)) throw new Error("якорь не найден");
const addition = `    @Test
    void theShippedConfigurationCarriesReadyPermissionsForEveryRole() {
        final PluginConfig config = PluginConfig.of(YamlConfig.load(SHIPPED, false), null);
        final Map<String, Object> permissions = config.embedded().permissions();

        // Плагин переносит раздел в сгенерированные gateway.yml и bot.yml без изменений.
        final PermissionConfig acl = PermissionConfig.from(
                YamlConfig.of(Map.of("permissions", permissions), "config.yml#embedded.permissions"), Set.of());

        final PermissionSet helper = acl.resolve(null, List.of("1313262203415040111"), "0");
        assertTrue(helper.allows("console.execute"), "хелпер выполняет разрешённые ему команды");
        assertTrue(helper.allows("console.command.kick.steve"), "запись kick разрешает команду с игроком");
        assertTrue(helper.allows("console.command.mute.steve"), "и запись mute тоже");
        assertTrue(helper.allows("console.server.lobby"), "server:* открывает всю сеть");
        assertFalse(helper.allows("console.command.stop"), "опасные команды хелперу не выданы");
        assertFalse(helper.allows("console.admin.reload"), "административные действия хелперу не выданы");

        final PermissionSet director = acl.resolve(null, List.of("1312150264568090725"), "0");
        assertTrue(director.allows("console.command.stop"), "у директора полный доступ к консоли");
        assertTrue(director.allows("console.admin.reload"));

        assertTrue(config.staff().rank("kurator").isPresent(), "куратор объявлен среди привилегий");
        assertFalse(config.staff().allows(List.of("1312150613726859264"), "helper"),
                "администратор привилегий не выдаёт: его роль в access не указана");
        assertTrue(config.staff().allows(List.of("1318649917299753070"), "sr_moderator"));
        assertFalse(config.staff().allows(List.of("1318649917299753070"), "administrator"),
                "гл. администратор выдаёт только до ст. модератора");
        assertTrue(config.staff().allows(List.of("1313262901301215323"), "sr_administrator"));
        assertFalse(config.staff().allows(List.of("1313262901301215323"), "chief_administrator"));
        assertTrue(config.staff().allows(List.of("1483533660782198876"), "chief_administrator"));
        assertFalse(config.staff().allows(List.of("1483533660782198876"), "supervisor"));
        assertTrue(config.staff().allows(List.of("1312150264568090725"), "supervisor"));
        assertFalse(config.staff().allows(List.of("1312150264568090725"), "director"));
        assertTrue(config.staff().allows(List.of("1390285875169988638"), "director"));
    }

    @Test
    void bypassesNothingByDefaultButStillRefusesTheLiteralBackslashX(@TempDir Path directory) {`;
let out = t.replace(anchor, addition);
// добавить нужные импорты
out = out.replace("import ru.zigono.dmc.common.errors.CommandException;",
    "import ru.zigono.dmc.common.errors.CommandException;\nimport ru.zigono.dmc.common.perm.PermissionConfig;\nimport ru.zigono.dmc.common.perm.PermissionSet;");
out = out.replace("import java.nio.file.Path;", "import java.nio.file.Path;\nimport java.util.List;\nimport java.util.Map;\nimport java.util.Set;");
out = out.replace("import static org.junit.jupiter.api.Assertions.assertEquals;",
    "import static org.junit.jupiter.api.Assertions.assertEquals;\nimport static org.junit.jupiter.api.Assertions.assertFalse;");
fs.writeFileSync(file, out, "utf8");
console.log("готово");