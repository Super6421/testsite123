const fs = require("fs");
const content = `# =============================================================================
#  Discord Minecraft Console — консоль Minecraft прямо из Discord
#  Автор: Zigono
#
#  ЗАПУСК В ТРИ ШАГА
#   1. Проверьте раздел embedded.discord: токен бота, id гильдии, канал команд.
#   2. Посмотрите раздел embedded.permissions.roles: там готовые строки для всех
#      ролей сервера — уберите лишнее или добавьте свои команды.
#   3. Перезапустите сервер. Больше ничего править не нужно: шлюз и Discord-бот
#      работают внутри этого плагина, наружу не открывается ни один порт.
#      Проверка: /discordconsole status в консоли сервера.
#
#  КАК ЗАПИСЫВАЮТСЯ ПРАВА (через запятую, без квадратных скобок)
#   *                        всё сразу
#   console.read             видеть консоль в Discord
#   console.execute          выполнять команды
#   console.status           /servers — состояние серверов
#   console.history          своя история команд (console.history.all — всех)
#   console.dryrun           проверка команды без выполнения
#   console.broadcast        команда сразу на несколько серверов
#   console.*                всё, включая административные действия
#   server:main              доступ к серверу main (server:* — ко всем)
#   group:all                доступ к группе серверов all
#   kick                     команда Minecraft с любыми аргументами
#   cmd:ban %player% 5d      то же самое, если хочется написать с аргументами
#   essentials.heal          право в стиле LuckPerms: разрешает команду heal
#   console.command.kick.*   полная форма той же записи
#  Запрет сильнее разрешения: deny: "kick" заберёт команду, даже если она выдана.
#  Права ролей складываются: у человека с двумя ролями складываются обе строки.
#
#  ОСТАЛЬНЫЕ НАСТРОЙКИ (захват вывода, политика команд, LuckPerms, метрики,
#  таймауты) имеют безопасные значения по умолчанию и описаны в docs/CONFIGURATION.md.
# =============================================================================

# Язык сообщений бота и плагина: ru или en.
language: ru

# =============================================================================
#  СЕРВЕРЫ
# =============================================================================

# Этот сервер: id латиницей попадает в историю и в команды, имя видно в Discord.
server:
  id: "main"
  name: "Мой сервер"
  description: "Управление сервером из Discord"

# Все серверы сети. Псевдонимы — как ещё можно назвать сервер в команде.
servers:
  main:
    aliases: "smp, survival"

# Группы серверов: в команде можно указать группу целиком. Пример:
#   groups:
#     all: "main, lobby"
groups: {}

# Режим работы single/multi определяется сам по числу включённых серверов.
# mode: multi

# -----------------------------------------------------------------------------
#  СЕТЬ ИЗ НЕСКОЛЬКИХ СЕРВЕРОВ (когда докупите ещё)
# -----------------------------------------------------------------------------
# Роли такие: один сервер держит шлюз и бота, остальные подключаются к нему.
#
# 1. На главном сервере добавьте остальные в раздел servers выше и общую группу:
#
#      servers:
#        main:
#          aliases: "smp, survival"
#        lobby:
#          name: "Лобби"
#          aliases: "hub"
#        skyblock:
#          name: "Скайблок"
#      groups:
#        all: "main, lobby, skyblock"
#
# 2. Там же откройте приём подключений (порт — постоянный, откройте его в панели):
#
#      embedded:
#        network:
#          host: 0.0.0.0
#          port: 8443
#
# 3. Запустите сервер: плагин сам создаст секреты новых серверов —
#    embedded/server-lobby.secret и embedded/server-skyblock.secret, а их значения
#    и адрес для подключения напечатает в консоли.
#
# 4. На каждом дополнительном сервере положите тот же jar и такой config.yml:
#
#      language: ru
#      server:
#        id: "lobby"                     # id из раздела servers главного сервера
#        name: "Лобби"
#      security:
#        server_secret: "строка из embedded/server-lobby.secret"
#      network:
#        host: "адрес главного сервера"  # тот же, что в embedded.network
#        port: 8443
#      tls:
#        enabled: false                  # встроенный шлюз работает без TLS
#      embedded:
#        enabled: false                  # шлюз и бот живут только на главном
#        discord:
#          token: ""                     # токен нужен только главному серверу
#
# Права ролей настраиваются один раз — на главном сервере. В /servers видно всю
# сеть, а server:* и group:all разрешают управлять всеми серверами сразу.

# =============================================================================
#  DISCORD: БОТ, КАНАЛЫ, ПРАВА РОЛЕЙ
# =============================================================================
embedded:
  # true — шлюз и бот работают внутри этого сервера (режим для панельного хостинга).
  enabled: true

  # Как встроенный шлюз принимает другие серверы сети. Значения по умолчанию
  # (127.0.0.1 и порт 0) означают «только этот же процесс» — см. раздел о сети выше.
  network:
    host: 127.0.0.1
    port: 0

  discord:
    # Токен бота: Discord Developer Portal -> приложение -> Bot -> Reset Token.
    # Можно вместо токена указать переменную окружения панели DISCORD_TOKEN.
    token: "MTU0NDQ1ODkxODUyMzMxMDI4MQ.GG7iCb.2Y5caj8NcYRR3IztseiKTD5BhNBPhHrTmvUXTA"
    # Гильдии бота: одна или несколько через запятую. Пусто — в любой гильдии.
    guilds: "1289611519578869781"
    # Текст активности и статус бота: ONLINE, IDLE, DND или INVISIBLE.
    activity: "Консоль сервера"
    status: ONLINE
    # Канал журнала: сюда бот пишет, кто что выполнил и чем это закончилось.
    # Меняется командой /logs channel прямо в Discord; здесь — стартовое значение.
    audit_channel_id: "1549248345615245352"
    channels:
      # Каналы, где работают команды консоли. Пусто — во всех каналах гильдии.
      allowed: "1549232811741806723"
      # Каналы, где команды запрещены. Запрет важнее разрешения.
      denied: ""

  # ---------------------------------------------------------------------------
  #  ПРАВА РОЛЕЙ: одна строка = одна роль (id роли: права через запятую)
  # ---------------------------------------------------------------------------
  # Ниже готовые строки для всех ролей сервера. Команды перечислены в стиле
  # EssentialsX — сверьтесь со своими плагинами и замените имена на нужные.
  permissions:
    roles:
      # Helper — следит за порядком: смотрит состояние, кикает, мутит.
      "1313262203415040111": "console.read, console.status, console.history, console.execute, server:*, kick, mute, warn"
      # Moderator — то же плюс баны и снятие мута.
      "1312150888550498404": "console.read, console.status, console.history, console.execute, server:*, kick, mute, unmute, warn, ban, tempban"
      # Sr. Moderator — работа на всей сети, история всех команд, тюрьма.
      "1547940785880698960": "console.read, console.status, console.history.all, console.execute, console.dryrun, console.broadcast, server:*, group:*, kick, mute, unmute, warn, ban, tempban, unban, jail, unjail"
      # Administrator — игровые команды администратора.
      "1312150613726859264": "console.read, console.status, console.history.all, console.execute, console.dryrun, console.broadcast, server:*, group:*, kick, mute, unmute, warn, ban, tempban, unban, jail, unjail, gamemode, tp, tphere, give, heal, fly, god, clear"
      # Sr. Administrator — то же плюс управление миром и игроками.
      "1547941571171975328": "console.read, console.status, console.history.all, console.execute, console.dryrun, console.broadcast, server:*, group:*, kick, mute, unmute, warn, ban, tempban, unban, jail, unjail, gamemode, tp, tphere, give, heal, fly, god, clear, vanish, time, weather, speed, feed, spawn, setspawn, kit"
      # Cf. Administrator (гл. администратор) — всё, кроме stop/restart/op: они
      # остаются только у роли полного доступа. Команды LuckPerms (lp) — здесь.
      "1318649917299753070": "console.read, console.status, console.history.all, console.execute, console.dryrun, console.broadcast, server:*, group:*, lp, kick, mute, unmute, warn, ban, tempban, unban, jail, unjail, gamemode, tp, tphere, give, heal, fly, god, clear, vanish, time, weather, speed, feed, spawn, setspawn, kit, whitelist"
      # Kurator — полный доступ к консоли.
      "1313262901301215323": "console.*"
      # Supervisor — полный доступ к консоли.
      "1483533660782198876": "console.*"
      # Director — полный доступ к консоли.
      "1312150264568090725": "console.*"
      # Роль полного доступа (владелец): всё, включая stop, restart, op и аварийный режим.
      "1390285875169988638": "console.*"

    # Права можно выдать и лично, без роли — той же записью:
    # users:
    #   "123456789012345678": "console.read, console.status"

  # Ответы бота обычным игрокам не показывают технических полей. Вернуть их
  # (длительность, ревизию конфигурации, шлюз, подробности ошибки) можно здесь:
  #
  # bot_overrides:
  #   ui:
  #     show_diagnostics: true
  #     show_request_id: true
  #   embeds:
  #     footer: "Мой сервер · консоль"

# =============================================================================
#  ПЕРСОНАЛ: выдача и снятие привилегий из Discord
# =============================================================================
# В Discord добавляются две команды:
#
#   /персонал-выдать ник:<ник> привилегия:<ключ> причина:<текст>
#   /персонал-снять  ник:<ник> привилегия:<ключ> причина:<текст>
#
# Они меняют группы LuckPerms. Кто что может выдавать, задаётся одной строкой на
# роль Discord в разделе access ниже: значение — список привилегий из ranks.
# «*» означает все настроенные привилегии. Права нигде не дублируются.
#
# Группы из ranks должны существовать в LuckPerms (/lp creategroup helper): если
# группы нет или игрок неизвестен LuckPerms, бот назовёт причину и ничего не
# изменит. Все выдачи и снятия, включая отклонённые, попадают в канал журнала —
# он включается и выключается командой /logs channel прямо в Discord.
staff:
  enabled: true

  # add — привилегия добавляется к текущим группам (ничего не отнимаем);
  # set — у игрока остаётся ровно эта привилегия (ступени персонала).
  mode: add

  # Куда вернуть игрока, если в режиме set снять его основную группу.
  default_group: "default"

  # Имена команд Discord: строчные буквы, цифры, дефис, подчёркивание (пробелы
  # Discord не принимает). Меняйте, если такие имена уже заняты другими ботами.
  commands:
    grant: "персонал-выдать"
    remove: "персонал-снять"

  # Привилегии: ключ подставляется в команду, name — подпись в Discord,
  # group — группа LuckPerms (можно писать словарём в одну строку).
  ranks:
    helper: { name: "Хелпер", group: "helper", emoji: "🟢" }
    moderator: { name: "Модератор", group: "moderator", emoji: "🔵" }
    sr_moderator: { name: "Ст. модератор", group: "sr_moderator", emoji: "🟣" }
    administrator: { name: "Администратор", group: "administrator", emoji: "🟠" }
    sr_administrator: { name: "Ст. администратор", group: "sr_administrator", emoji: "🔴" }
    chief_administrator: { name: "Гл. администратор", group: "chief_administrator", emoji: "⭐" }
    kurator: { name: "Куратор", group: "kurator", emoji: "🧭" }
    supervisor: { name: "Супервайзер", group: "supervisor", emoji: "💎" }
    director: { name: "Директор", group: "director", emoji: "👑" }

  # Кто что выдаёт и снимает. Ключ — id роли Discord, значение — привилегии.
  #   Гл. администратор выдаёт хелпера, модератора и ст. модератора
  #   Куратор          — плюс администратора и ст. администратора
  #   Супервайзер      — плюс гл. администратора
  #   Директор         — всё, кроме директора
  #   Роль полного доступа — всё
  access:
    "1318649917299753070": "helper, moderator, sr_moderator"
    "1313262901301215323": "helper, moderator, sr_moderator, administrator, sr_administrator"
    "1483533660782198876": "helper, moderator, sr_moderator, administrator, sr_administrator, chief_administrator"
    "1312150264568090725": "helper, moderator, sr_moderator, administrator, sr_administrator, chief_administrator, kurator, supervisor"
    "1390285875169988638": "*"

# =============================================================================
#  ЧТО ДАЛЬШЕ
# =============================================================================
# Полное описание всех разделов и тонкой настройки — docs/CONFIGURATION.md.
# Перезагрузить конфигурацию без перезапуска: /discordconsole reload.
# Сломанный YAML (табуляция, сбитый отступ) не роняет сервер: файл сохраняется
# как config.yml.broken-<дата>, подставляются стандартные значения, плагин
# продолжает работать, а ваши строки можно перенести обратно.
`;
if (content.includes("`") || content.includes("${")) throw new Error("недопустимые символы");
fs.writeFileSync("dmc-plugin/src/main/resources/config.yml", content.replace(/\n/g, "\r\n"), "utf8");
console.log("записано строк: " + content.split("\n").length);