#!/usr/bin/env bash
# ============================================================================
#  Discord Minecraft Console Gateway - entrypoint образа
#  Автор: Zigono
#
#  Первый аргумент выбирает, что запускать:
#    run     (по умолчанию) - шлюз:  java -jar gateway.jar run --config ...
#    bot                    - Discord-бот: java -jar bot.jar --config ...
#    certs                  - генерация TLS-материала
#    version | help         - справка шлюза
#  Всё, что идёт после, передаётся соответствующему jar-файлу.
# ============================================================================
set -euo pipefail

MODE="${1:-run}"
shift || true

GATEWAY_JAR="${DMC_GATEWAY_JAR:-/opt/dmc/gateway.jar}"
BOT_JAR="${DMC_BOT_JAR:-/opt/dmc/bot.jar}"
GATEWAY_CONFIG="${DMC_CONFIG:-/opt/dmc/config/gateway.yml}"
BOT_CONFIG="${DMC_BOT_CONFIG:-/opt/dmc/config/bot.yml}"
JAVA_OPTS="${JAVA_OPTS:--XX:MaxRAMPercentage=75 -XX:+ExitOnOutOfMemoryError -Dfile.encoding=UTF-8}"

export JAVA_OPTS

# Диагностика прав: контейнер работает непривилегированным пользователем.
if [ ! -d "$(dirname "${GATEWAY_CONFIG}")" ]; then
  echo "entrypoint: config directory $(dirname "${GATEWAY_CONFIG}") does not exist" >&2
fi

# shellcheck disable=SC2086
case "${MODE}" in
  run)
    exec java ${JAVA_OPTS} -jar "${GATEWAY_JAR}" run --config "${GATEWAY_CONFIG}" "$@"
    ;;
  bot)
    exec java ${JAVA_OPTS} -jar "${BOT_JAR}" --config "${BOT_CONFIG}" "$@"
    ;;
  certs)
    exec java ${JAVA_OPTS} -jar "${GATEWAY_JAR}" certs "$@"
    ;;
  version|help|--help|-h)
    exec java ${JAVA_OPTS} -jar "${GATEWAY_JAR}" "${MODE}"
    ;;
  *)
    # Произвольная команда (например, bash для отладки).
    exec "$MODE" "$@"
    ;;
esac