const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/java/ru/zigono/dmc/plugin/embedded/EmbeddedConfigWriter.java","utf8").split("\n");
console.log(t.slice(100, 165).map((l,i)=>(101+i)+": "+l).join("\n"));