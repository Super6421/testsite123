const fs = require("fs");
const t = fs.readFileSync("config/plugin-embedded.example.yml","utf8").split("\n");
console.log("lines=" + t.length);
console.log(t.slice(0, 130).map((l,i)=>(i+1)+": "+l).join("\n"));