const fs = require("fs");
const file = "dmc-common/src/main/java/ru/zigono/dmc/common/perm/PermissionConfig.java";
const text = fs.readFileSync(file, "utf8");
const crlf = text.includes("\r\n");
const t = text.replace(/\r\n/g, "\n");

const oldJavadoc = ` * Parsed Discord ACL configuration.
 * <pre>
 * permissions:
 *   roles:
 *     123456789: console.*
 *   users:
 *     987654321: console.read, console.status
 *
 * guilds:
 *   111111:
 *     permissions:
 *       roles:
 *         222222: console.command.cmi.*
 * </pre>
 * A single line without brackets is the short form; a list, or one line with commas, spaces, semicolons
 * or vertical bars, grants several nodes at once.
 * Guild assignments are additive: a role never inherits permissions of another guild because role ids are
 * guild scoped.
 *
 * @author Zigono
 */`;
const newJavadoc = ` * Parsed Discord ACL configuration.
 * <pre>
 * permissions:
 *   roles:
 *     123456789: console.*
 *   users:
 *     987654321: console.read, console.status
 *
 * guilds:
 *   111111:
 *     permissions:
 *       roles:
 *         222222: console.command.cmi.*
 * </pre>
 * A single line without brackets is the short form; a list, or one line with commas, spaces, semicolons
 * or vertical bars, grants several nodes at once.
 * Guild assignments are additive: a role never inherits permissions of another guild because role ids are
 * guild scoped.
 * <p>Besides raw nodes the same lists accept the friendly forms an administrator actually thinks in
 * (see {@link #addEntry}):</p>
 * <pre>
 * kick                  # команда Minecraft: console.command.kick.* — с любыми аргументами
 * cmd:kick %player%     # то же самое, но записано целиком
 * essentials.heal       # право в стиле LuckPerms: оно само и команда heal в его конце
 * perm:essentials.heal  # то же самое, явная форма
 * server:survival       # console.server.survival
 * group:all             # console.group.all
 * </pre>
 *
 * @author Zigono
 */`;

const oldNodes = `    /**
     * Reads one permission assignment. Every documented shape ends up in the same set:
     * <pre>
     * allow: console.*                         # одна строка, без скобок
     * allow: [ "console.*", "console.status" ] # список
     * allow: "console.read, console.status"    # строка с разделителями
     * </pre>
     */
    private static Set<String> nodes(YamlConfig entry, String key) {
        final Set<String> result = new LinkedHashSet<>();
        for (String value : entry.stringList(key, List.of())) {
            for (String node : value.split("[,;|\\\\s]+")) {
                final String trimmed = node.trim();
                if (!trimmed.isEmpty()) {
                    result.add(trimmed);
                }
            }
        }
        return result;
    }`;

const newNodes = `    /**
     * Reads one permission assignment. Every documented shape ends up in the same set:
     * <pre>
     * allow: console.*                         # одна строка, без скобок
     * allow: [ "console.*", "console.status" ] # список
     * allow: "console.read, console.status"    # строка с разделителями
     * allow: "kick, mute, essentials.heal"     # команды и права в стиле LuckPerms
     * allow: "server:survival, group:all"      # доступ к серверам и группам
     * </pre>
     */
    private static Set<String> nodes(YamlConfig entry, String key) {
        final Set<String> result = new LinkedHashSet<>();
        for (String value : entry.stringList(key, List.of())) {
            for (String chunk : value.split("[,;|]+")) {
                addChunk(result, chunk.trim());
            }
        }
        return result;
    }

    /**
     * Разбирает одну запись списка. Запись может быть набором прав через пробел
     * ({@code console.read console.status}) или командой с аргументами ({@code kick %player%}),
     * поэтому пробел разделяет записи только там, где не начинается команда.
     */
    private static void addChunk(Set<String> target, String chunk) {
        if (chunk.isEmpty()) {
            return;
        }
        final String[] words = chunk.split("\\\\s+");
        if (words.length > 1 && (isCommandEntry(words[0]) || (!isMarked(words[0]) && !words[0].contains(".")))) {
            addEntry(target, chunk);
            return;
        }
        for (String word : words) {
            addEntry(target, word);
        }
    }

    /**
     * Одна запись: право консоли, команда Minecraft, право в стиле LuckPerms, сервер или группа серверов.
     * Разбор намеренно прощающий: {@code kick}, {@code /kick} и {@code cmd:kick} дают одно и то же право,
     * а {@code essentials.heal} разрешает команду {@code heal}.
     */
    private static void addEntry(Set<String> target, String text) {
        final String value = text.trim();
        if (value.isEmpty()) {
            return;
        }
        if (Permissions.GLOBAL_WILDCARD.equals(value)) {
            target.add(value);
            return;
        }
        if (value.startsWith("server:") || value.startsWith("srv:")) {
            target.add(Permission.server(after(value)));
            return;
        }
        if (value.startsWith("group:") || value.startsWith("grp:")) {
            target.add(Permission.group(after(value)));
            return;
        }
        if (value.startsWith("perm:") || value.startsWith("luckperms:")) {
            addPermission(target, after(value));
            return;
        }
        if (isCommandEntry(value)) {
            addCommand(target, strip(value));
            return;
        }
        if (value.startsWith("console.")) {
            target.add(value);
            return;
        }
        if (value.contains(".")) {
            addPermission(target, value);
            return;
        }
        addCommand(target, value);
    }

    /** Право в стиле LuckPerms: берётся как есть, а команда — последнее слово права. */
    private static void addPermission(Set<String> target, String node) {
        if (node.isEmpty()) {
            return;
        }
        target.add(node);
        addCommand(target, node.substring(node.lastIndexOf('.') + 1));
    }

    /**
     * Запись команды разрешает команду целиком, вместе с аргументами: {@code kick} даёт право
     * {@code console.command.kick.*}, которое покрывает и {@code kick <игрок>}.
     */
    private static void addCommand(Set<String> target, String text) {
        final String[] words = text.trim().split("\\\\s+");
        if (words.length == 0) {
            return;
        }
        final String root = sanitizeNode(words[0]);
        if (!root.isEmpty()) {
            target.add(Permission.command(root) + ".*");
        }
    }

    private static boolean isCommandEntry(String word) {
        return word.startsWith("/") || word.startsWith("cmd:") || word.startsWith("command:");
    }

    private static boolean isMarked(String word) {
        return word.startsWith("console.") || isCommandEntry(word) || word.startsWith("server:")
                || word.startsWith("srv:") || word.startsWith("group:") || word.startsWith("grp:")
                || word.startsWith("perm:") || word.startsWith("luckperms:");
    }

    private static String after(String value) {
        return value.substring(value.indexOf(':') + 1).trim();
    }

    private static String strip(String value) {
        if (value.startsWith("cmd:")) {
            return value.substring(4).trim();
        }
        if (value.startsWith("command:")) {
            return value.substring(8).trim();
        }
        return value.startsWith("/") ? value.substring(1).trim() : value;
    }

    /** Приводит имя команды к тому же виду, в котором его выводит {@code CommandPolicyEngine}. */
    private static String sanitizeNode(String token) {
        final StringBuilder out = new StringBuilder(token.length());
        for (int index = 0; index < token.length(); index++) {
            final char character = Character.toLowerCase(token.charAt(index));
            if ((character >= 'a' && character <= 'z') || (character >= '0' && character <= '9')
                    || character == '_' || character == '-') {
                out.append(character);
            } else if (character == '.' || character == ':') {
                out.append('_');
            }
        }
        return out.toString();
    }`;

for (const [from, to] of [[oldJavadoc, newJavadoc], [oldNodes, newNodes]]) {
  if (!t.includes(from)) throw new Error("не найден фрагмент:\n" + from.slice(0, 120));
  if (t.split(from).length !== 2) throw new Error("фрагмент не уникален");
}
let out = t.replace(oldJavadoc, newJavadoc).replace(oldNodes, newNodes);
fs.writeFileSync(file, crlf ? out.replace(/\n/g, "\r\n") : out, "utf8");
console.log("готово, crlf=" + crlf + ", строк=" + out.split("\n").length);