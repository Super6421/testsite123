const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/perm/Permissions.java","utf8");
console.log(t);