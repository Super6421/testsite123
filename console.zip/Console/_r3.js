const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/resources/config.yml","utf8").split("\n");
console.log(t.slice(59,138).map((l,i)=>(60+i)+": "+l).join("\n"));