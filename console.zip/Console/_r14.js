const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/java/ru/zigono/dmc/plugin/config/EmbeddedSettings.java","utf8").split("\n");
t.forEach((l,i)=>{ if (/permissions|raw\(|Map<String, Object>/.test(l)) console.log((i+1)+": "+l.replace(/\s+$/,"")); });
console.log("=== PermissionSet API ===");
const p = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/perm/PermissionSet.java","utf8").split("\n");
p.forEach((l,i)=>{ if (/public |static |record /.test(l)) console.log((i+1)+": "+l.replace(/\s+$/,"")); });