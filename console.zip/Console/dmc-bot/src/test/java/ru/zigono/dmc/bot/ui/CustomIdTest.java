package ru.zigono.dmc.bot.ui;

import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Encoding and decoding of the interactive component identifiers.
 *
 * @author Zigono
 */
class CustomIdTest {

    @Test
    void roundTripsThePanelControls() {
        assertEquals(new CustomId.Parsed(CustomId.ACTION_PANEL_TARGET, "abc", 0),
                CustomId.parse(CustomId.panelTarget("abc")).orElseThrow());
        assertEquals(new CustomId.Parsed(CustomId.ACTION_PANEL_EXECUTE, "abc", 0),
                CustomId.parse(CustomId.panelExecute("abc")).orElseThrow());
        assertEquals(new CustomId.Parsed(CustomId.ACTION_PANEL_MODAL, "abc", 0),
                CustomId.parse(CustomId.panelModal("abc")).orElseThrow());
    }

    @Test
    void roundTripsTheConfirmationControls() {
        assertEquals(new CustomId.Parsed(CustomId.ACTION_CONFIRM, "nonce-1", 0),
                CustomId.parse(CustomId.confirm("nonce-1")).orElseThrow());
        assertEquals(new CustomId.Parsed(CustomId.ACTION_CANCEL, "nonce-1", 0),
                CustomId.parse(CustomId.cancel("nonce-1")).orElseThrow());
    }

    @Test
    void roundTripsTheHistoryPagination() {
        assertEquals(new CustomId.Parsed(CustomId.ACTION_HISTORY, "nonce", 15),
                CustomId.parse(CustomId.historyPage("nonce", 15)).orElseThrow());
        assertEquals(0, CustomId.parse(CustomId.historyPage("nonce", -5)).orElseThrow().offset());
    }

    @Test
    void rejectsIdentifiersOfOtherApplications() {
        assertTrue(CustomId.parse(null).isEmpty());
        assertTrue(CustomId.parse("").isEmpty());
        assertTrue(CustomId.parse("   ").isEmpty());
        assertTrue(CustomId.parse("other:confirm:abc").isEmpty());
        assertTrue(CustomId.parse("dmc:confirm").isEmpty());
        assertTrue(CustomId.parse("dmc:panel:unknown:abc").isEmpty());
        assertTrue(CustomId.parse("dmc:history:abc:not-a-number").isEmpty());
    }

    @Test
    void recognisesTheIdentifiersOwnedByTheBot() {
        assertTrue(CustomId.isComponent(CustomId.confirm("abc")));
        assertFalse(CustomId.isComponent("dmc"));
        assertFalse(CustomId.isComponent(null));
        assertFalse(CustomId.isComponent("other:dmc:abc"));
    }

    @Test
    void keepsTheNonceFromTheIdentifier() {
        final Optional<CustomId.Parsed> parsed = CustomId.parse("dmc:panel:target:1234567890abcdef");

        assertEquals("1234567890abcdef", parsed.orElseThrow().nonce());
    }
}
