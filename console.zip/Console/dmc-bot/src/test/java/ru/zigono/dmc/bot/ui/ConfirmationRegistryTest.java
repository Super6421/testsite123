package ru.zigono.dmc.bot.ui;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.support.TestClock;
import ru.zigono.dmc.protocol.dto.TargetSelection;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The dangerous command confirmation flow: a confirmation belongs to one user, one command and one moment.
 *
 * @author Zigono
 */
class ConfirmationRegistryTest {

    private static final Duration TTL = Duration.ofSeconds(30);

    @Test
    void claimsTheConfirmationExactlyOnce() {
        final ConfirmationRegistry registry = registry();
        final ConfirmationRegistry.Pending pending = registry.register(draft("user-1"));

        final ConfirmationRegistry.Claim claim = registry.claim(pending.nonce(), "user-1", "stop");

        assertTrue(claim.ok());
        assertEquals(ConfirmationRegistry.Result.OK, claim.result());
        assertEquals("stop", claim.pending().command());
        assertEquals("survival", claim.pending().target().server());
        assertEquals(0, registry.size());
        assertEquals(ConfirmationRegistry.Result.UNKNOWN,
                registry.claim(pending.nonce(), "user-1", "stop").result());
    }

    @Test
    void rejectsAConfirmationOfAnotherUserButKeepsIt() {
        final ConfirmationRegistry registry = registry();
        final ConfirmationRegistry.Pending pending = registry.register(draft("user-1"));

        final ConfirmationRegistry.Claim foreign = registry.claim(pending.nonce(), "user-2", "stop");

        assertEquals(ConfirmationRegistry.Result.FOREIGN_USER, foreign.result());
        assertFalse(foreign.ok());
        assertTrue(registry.isPending(pending.nonce()));
        assertTrue(registry.claim(pending.nonce(), "user-1", "stop").ok());
    }

    @Test
    void rejectsAnUnknownConfirmation() {
        final ConfirmationRegistry registry = registry();

        assertEquals(ConfirmationRegistry.Result.UNKNOWN, registry.claim("missing", "user-1", "stop").result());
    }

    @Test
    void rejectsAModifiedCommandAndDropsTheConfirmation() {
        final ConfirmationRegistry registry = registry();
        final ConfirmationRegistry.Pending pending = registry.register(draft("user-1"));

        final ConfirmationRegistry.Claim claim = registry.claim(pending.nonce(), "user-1", "stop --force");

        assertEquals(ConfirmationRegistry.Result.COMMAND_MISMATCH, claim.result());
        assertFalse(registry.isPending(pending.nonce()));
    }

    @Test
    void acceptsTheConfirmationWhenTheCommandIsNotRepeated() {
        final ConfirmationRegistry registry = registry();

        final ConfirmationRegistry.Pending pending = registry.register(draft("user-1"));

        assertTrue(registry.claim(pending.nonce(), "user-1", null).ok());
    }

    @Test
    void expiresAConfirmationAfterTheConfiguredTimeout() {
        final TestClock clock = clock();
        final ConfirmationRegistry registry = new ConfirmationRegistry(TTL, 10, clock);
        final ConfirmationRegistry.Pending pending = registry.register(draft("user-1"));

        clock.advance(TTL.minusSeconds(1));
        assertTrue(registry.isPending(pending.nonce()));

        clock.advance(Duration.ofSeconds(2));

        assertEquals(ConfirmationRegistry.Result.EXPIRED, registry.claim(pending.nonce(), "user-1", "stop").result());
        assertEquals(0, registry.size());
        assertEquals(Duration.ofSeconds(30), registry.ttl());
    }

    @Test
    void keepsTheNumberOfPendingConfirmationsBounded() {
        final ConfirmationRegistry registry = new ConfirmationRegistry(TTL, 2, clock());

        final ConfirmationRegistry.Pending first = registry.register(draft("user-1"));
        final ConfirmationRegistry.Pending second = registry.register(draft("user-1"));
        final ConfirmationRegistry.Pending third = registry.register(draft("user-1"));

        assertEquals(2, registry.size());
        assertTrue(registry.isPending(first.nonce()) && registry.isPending(second.nonce())
                        || registry.isPending(first.nonce()) && registry.isPending(third.nonce())
                        || registry.isPending(second.nonce()) && registry.isPending(third.nonce()),
                "the newest confirmations must survive the eviction");
        assertEquals(0, registry.purgeExpired());
    }

    @Test
    void clearsEveryPendingConfirmation() {
        final ConfirmationRegistry registry = registry();
        registry.register(draft("user-1"));

        registry.clear();

        assertEquals(0, registry.size());
    }

    private static ConfirmationRegistry registry() {
        return new ConfirmationRegistry(TTL, 10, clock());
    }

    private static TestClock clock() {
        return new TestClock(Instant.parse("2026-01-01T00:00:00Z"), ZoneOffset.UTC);
    }

    private static ConfirmationRegistry.Draft draft(String userId) {
        return new ConfirmationRegistry.Draft(userId, "Operator", "guild-a", "channel-1", "server:survival",
                new TargetSelection("survival", java.util.List.of(), null, false), "stop", "stop", false,
                "confirmation-1");
    }
}
