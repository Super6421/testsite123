package ru.zigono.dmc.bot.ui;

import net.dv8tion.jda.api.entities.MessageEmbed;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.audit.AuditEntry;
import ru.zigono.dmc.bot.audit.StaffAuditEntry;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Имена полей эмбедов берутся из языковых файлов. Раньше ключ подставлялся в эмбед дословно, и в Discord были
 * видны строки вида {@code embed.field.user}: этот тест не даёт такому вернуться и заодно проверяет, что все
 * ключи, которые использует фабрика, действительно есть в каталоге.
 *
 * @author Zigono
 */
class EmbedFactoryTest {

    private static final Messages MESSAGES = Messages.load("ru", null, "bot-lang");

    private static final BotConfig.EmbedSettings SETTINGS = new BotConfig.EmbedSettings("Discord Minecraft Console · Zigono",
            false, new BotConfig.EmbedSettings.Palette(0x5865F2, 0x57F287, 0xFEE75F, 0xED4245, 0xEB459E, 0x99AAB5));

    private static EmbedFactory embeds() {
        return new EmbedFactory(() -> MESSAGES, () -> SETTINGS, () -> Boolean.FALSE);
    }

    @Test
    void everyFieldNameOfTheAuditEmbedIsTranslated() {
        final AuditEntry entry = AuditEntry.failure("req-1", user(), "Сервер #1", "say привет",
                "PERMISSION_DENIED", "нет права");
        final MessageEmbed embed = embeds().audit(entry, true, true);

        assertFalse(embed.getFields().isEmpty());
        for (MessageEmbed.Field field : embed.getFields()) {
            assertFalse(field.getName().startsWith("embed."), "ключ вместо перевода: " + field.getName());
        }
        assertEquals("Иван (`" + "1" + "`)", field(embed, "embed.field.user").getValue());
        assertEquals("Причина", MESSAGES.format("embed.field.reason"));
        assertFalse(field(embed, "embed.field.error").getValue().isBlank());
    }

    @Test
    void everyFieldNameOfTheStaffEmbedIsTranslated() {
        final StaffService.Request request = new StaffService.Request(StaffService.Action.GRANT, "Notch", "helper",
                "Набор в персонал", List.of("100"), "1", "Иван", "2", "3");
        final StaffService.Result result = StaffService.Result.success(request, "Хелпер", "helper", true, null, null);

        final MessageEmbed reply = embeds().staffResult(request, result, null);
        assertFalse(reply.getFields().isEmpty());
        for (MessageEmbed.Field field : reply.getFields()) {
            assertFalse(field.getName().startsWith("embed."), "ключ вместо перевода: " + field.getName());
        }
        assertEquals("Хелпер", reply.getFields().get(1).getValue());
        assertTrue(reply.getTitle().contains("Привилегия выдана"));

        final MessageEmbed audit = embeds().staffAudit(StaffAuditEntry.of("req-2", request, result));
        assertFalse(audit.getFields().isEmpty());
        for (MessageEmbed.Field field : audit.getFields()) {
            assertFalse(field.getName().startsWith("embed."), "ключ вместо перевода: " + field.getName());
        }
        assertEquals("Иван (1)", audit.getFields().get(0).getValue());
    }

    @Test
    void teamNamesCannotMentionAnybody() {
        final StaffService.Request request = new StaffService.Request(StaffService.Action.REMOVE, "Notch", "helper",
                "@everyone увольняем", List.of("100"), "1", "Иван", "2", "3");
        final MessageEmbed embed = embeds().staffResult(request, StaffService.Result.failure(request,
                ru.zigono.dmc.common.errors.ErrorCode.PERMISSION_DENIED, "@here нельзя"), null);

        assertFalse(embed.getFields().toString().contains("@everyone"));
        assertTrue(embed.getDescription().contains("@\u200Bhere"));
    }

    private static MessageEmbed.Field field(MessageEmbed embed, String key) {
        final String translated = MESSAGES.format(key);
        for (MessageEmbed.Field field : embed.getFields()) {
            if (field.getName().equals(translated)) {
                return field;
            }
        }
        throw new AssertionError("нет поля " + translated + " в " + embed.getFields());
    }

    private static UserContext user() {
        return new UserContext("1", "Иван", "2", "3", null, "i-1", List.of("100"), List.of("console.*"),
                List.of());
    }
}