package ru.zigono.dmc.bot.audit;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The audit record of a console action: every field the specification requires for every command.
 *
 * @author Zigono
 */
class AuditEntryTest {

    private static final UserContext USER = new UserContext("user-1", "Operator", "guild-a", "channel-1",
            "message-1", "interaction-1", List.of("role-1"), List.of("console.execute"), List.of());

    @Test
    void recordsAnAnsweredExecution() {
        final ControlMessages.ExecuteResponse response = response();
        response.outcomes = List.of(ServerOutcome.success("survival", List.of("hello"), 12L, "req-1"));

        final AuditEntry entry = AuditEntry.of(response, USER, "hello");

        assertEquals("req-1", entry.requestId());
        assertEquals("user-1", entry.userId());
        assertEquals("Operator", entry.username());
        assertEquals("guild-a", entry.guildId());
        assertEquals("channel-1", entry.channelId());
        assertEquals("server:survival", entry.target());
        assertEquals("say hello", entry.command());
        assertEquals(ExecutionStatus.SUCCESS.name(), entry.status());
        assertEquals(12L, entry.durationMillis());
        assertEquals(List.of("role-1"), entry.roleIds());
        assertEquals("hello", entry.response());
        assertFalse(entry.failed());
        assertTrue(entry.timestamp() > 0L);
    }

    @Test
    void marksAPartialExecutionAsPartial() {
        final ControlMessages.ExecuteResponse response = response();
        response.outcomes = List.of(ServerOutcome.success("survival", List.of("ok"), 1L, "req-1"),
                ServerOutcome.failure("lobby", ExecutionStatus.OFFLINE, "SERVER_OFFLINE", "down"));

        final AuditEntry entry = AuditEntry.of(response, USER, "ok");

        assertEquals(AuditEntry.STATUS_PARTIAL, entry.status());
        assertTrue(entry.failed());
    }

    @Test
    void reportsTheStatusOfTheFirstFailureWhenNothingSucceeded() {
        assertEquals(ExecutionStatus.TIMEOUT.name(), AuditEntry.statusOf(List.of(
                ServerOutcome.failure("survival", ExecutionStatus.TIMEOUT, "TIMEOUT", "slow"),
                ServerOutcome.failure("lobby", ExecutionStatus.OFFLINE, "SERVER_OFFLINE", "down"))));
        assertEquals(ExecutionStatus.FAILED.name(), AuditEntry.statusOf(List.of()));
        assertEquals(ExecutionStatus.FAILED.name(), AuditEntry.statusOf(null));
    }

    @Test
    void recordsARequestThatNeverReachedAMinecraftServer() {
        final AuditEntry entry = AuditEntry.failure("req-9", USER, "server:survival", "say hello",
                "CONNECTION_LOST", "the gateway is unreachable");

        assertEquals("req-9", entry.requestId());
        assertEquals("CONNECTION_LOST", entry.status());
        assertEquals("CONNECTION_LOST", entry.errorCode());
        assertEquals("the gateway is unreachable", entry.errorDetail());
        assertEquals("", entry.response());
        assertEquals(List.of(), entry.outcomes());
        assertTrue(entry.failed());
    }

    @Test
    void defaultsToFailedWhenTheErrorCodeIsMissing() {
        assertEquals(ExecutionStatus.FAILED.name(),
                AuditEntry.failure(null, null, null, null, null, null).status());
    }

    @Test
    void toleratesAnEmptyResponse() {
        final AuditEntry entry = AuditEntry.of(null, null, null);

        assertNullFields(entry);
        assertTrue(entry.failed());
    }

    private static void assertNullFields(AuditEntry entry) {
        assertNull(entry.requestId());
        assertNull(entry.userId());
        assertEquals(List.of(), entry.roleIds());
        assertEquals("", entry.response());
        assertEquals(0L, entry.durationMillis());
    }

    private static ControlMessages.ExecuteResponse response() {
        final ControlMessages.ExecuteResponse response = new ControlMessages.ExecuteResponse();
        response.setRequestId("req-1");
        response.targetDescription = "server:survival";
        response.command = "say hello";
        response.responseMode = "per_server";
        response.durationMillis = 12L;
        return response;
    }
}
