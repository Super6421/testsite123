package ru.zigono.dmc.bot.command;

import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.i18n.Messages;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Имена слэш-команд задаются конфигурацией и попадают в Discord как есть: кириллица допустима, пробелы — нет.
 * Этот тест держит оба требования и проверяет, что команды персонала действительно регистрируются.
 *
 * @author Zigono
 */
class SlashCommandsTest {

    private static final Messages MESSAGES = Messages.load("ru", null, "bot-lang");

    @Test
    void keepsCyrillicNamesAndReplacesImpossibleOnes() {
        assertEquals("персонал-выдать", SlashCommands.sanitizeName("персонал-выдать", "staff-grant"));
        assertEquals("персонал-снять", SlashCommands.sanitizeName("  Персонал-Снять ", "staff-remove"));
        assertEquals("staff-grant", SlashCommands.sanitizeName("персонал выдать", "staff-grant"));
        assertEquals("staff-grant", SlashCommands.sanitizeName("", "staff-grant"));
        assertEquals("staff-grant", SlashCommands.sanitizeName("a".repeat(40), "staff-grant"));
    }

    @Test
    void registersTheStaffCommandsFromTheConfiguration() {
        final BotConfig config = config(true);
        final List<String> names = SlashCommands.definitions(MESSAGES, config,
                        SlashCommands.CommandNames.of(config.staff())).stream()
                .map(CommandData::getName).toList();

        assertTrue(names.contains(SlashCommands.CONSOLE));
        assertTrue(names.contains(SlashCommands.LOGS));
        assertTrue(names.contains("персонал-выдать"));
        assertTrue(names.contains("персонал-снять"));
    }

    @Test
    void hidesTheStaffCommandsWhenTheSectionIsOff() {
        final BotConfig config = config(false);
        final List<String> names = SlashCommands.definitions(MESSAGES, config,
                        SlashCommands.CommandNames.of(config.staff())).stream()
                .map(CommandData::getName).toList();

        assertFalse(names.contains("персонал-выдать"));
        assertTrue(names.contains(SlashCommands.LOGS));
    }

    private static BotConfig config(boolean enabled) {
        return BotConfig.of(YamlConfig.parse("""
                discord:
                  token: "test-token"
                control:
                  client_id: discord-bot
                  secret: "0123456789abcdef"
                staff:
                  enabled: BOOL
                  ranks:
                    helper:
                      name: "Хелпер"
                      group: "helper"
                  access:
                    "100": "helper"
                """.replace("BOOL", String.valueOf(enabled)), "test.yml", false), Path.of("."));
    }
}