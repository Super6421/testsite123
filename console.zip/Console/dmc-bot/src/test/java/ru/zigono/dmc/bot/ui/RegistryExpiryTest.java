package ru.zigono.dmc.bot.ui;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.support.TestClock;
import ru.zigono.dmc.protocol.dto.TargetSelection;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Interaction state of the panel and of the history pagination: it belongs to one user and it expires.
 *
 * @author Zigono
 */
class RegistryExpiryTest {

    private static final Duration TTL = Duration.ofMinutes(10);
    private static final TargetSelection TARGET = new TargetSelection("survival", List.of(), null, false);

    @Test
    void returnsThePanelToItsOwnerOnly() {
        final PanelRegistry registry = new PanelRegistry(TTL, 10, clock());
        final PanelRegistry.Panel panel = registry.register("user-1", "guild-a", "channel-1", TARGET, "Survival");

        assertTrue(registry.find(panel.nonce(), "user-1").isPresent());
        assertTrue(registry.find(panel.nonce(), "user-2").isEmpty());
        assertTrue(registry.find("missing", "user-1").isEmpty());

        registry.remove(panel.nonce());
        assertEquals(0, registry.size());
    }

    @Test
    void expiresThePanel() {
        final TestClock clock = clock();
        final PanelRegistry registry = new PanelRegistry(TTL, 10, clock);
        final PanelRegistry.Panel panel = registry.register("user-1", "guild-a", "channel-1", TARGET, "Survival");

        clock.advance(TTL.plusSeconds(1));

        assertEquals(1, registry.purgeExpired());
        assertTrue(registry.find(panel.nonce(), "user-1").isEmpty());
        assertEquals(0, registry.size());
    }

    @Test
    void keepsTheHistoryQueryOfItsOwner() {
        final HistoryRegistry registry = new HistoryRegistry(TTL, 10, clock());
        final HistoryRegistry.Query query = registry.register("user-1", "guild-a", "channel-1", "survival",
                "Operator", "say", "SUCCESS", 5);

        final HistoryRegistry.Query found = registry.find(query.nonce(), "user-1").orElseThrow();
        assertEquals("say", found.commandFragment());
        assertEquals("SUCCESS", found.status());
        assertEquals(5, found.limit());
        assertTrue(registry.find(query.nonce(), "user-2").isEmpty());
    }

    @Test
    void expiresTheHistoryQuery() {
        final TestClock clock = clock();
        final HistoryRegistry registry = new HistoryRegistry(TTL, 10, clock);
        final HistoryRegistry.Query query = registry.register("user-1", "guild-a", "channel-1", null, null, null,
                null, 5);

        clock.advance(Duration.ofMinutes(11));

        assertEquals(1, registry.purgeExpired());
        assertTrue(registry.find(query.nonce(), "user-1").isEmpty());
        registry.clear();
        assertEquals(0, registry.size());
    }

    private static TestClock clock() {
        return new TestClock(Instant.parse("2026-01-01T00:00:00Z"), ZoneOffset.UTC);
    }
}
