package ru.zigono.dmc.bot.i18n;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.bot.BotBuild;
import ru.zigono.dmc.bot.config.BotBootstrap;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.i18n.Messages;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Consistency of the language files: the same keys in every language, the same placeholders per key and no
 * message key used by the bot source that the language files do not define.
 *
 * @author Zigono
 */
class BotMessagesTest {

    private static final Path LANGUAGE_DIRECTORY = Path.of("src", "main", "resources", "bot-lang");
    private static final Pattern MESSAGE_KEY = Pattern.compile("""
            "([a-z][a-z0-9_]*(?:[.][A-Za-z0-9_]+)+)"
            """.strip());
    private static final Pattern PLACEHOLDER = Pattern.compile("[{]([0-9]+)[^}]*[}]");
    private static final List<String> KEY_PREFIXES = List.of("status.", "command.", "ui.", "embed.", "response.",
            "error.", "panel.", "audit.", "common.");

    @Test
    void definesTheSameKeysInEveryLanguage() {
        final Set<String> russian = keys("ru.yml").keySet();
        final Set<String> english = keys("en.yml").keySet();

        assertEquals(new TreeSet<>(english), new TreeSet<>(russian));
        assertTrue(russian.size() > 60, "the bot messages must not be trimmed down to " + russian.size() + " keys");
    }

    @Test
    void usesTheSamePlaceholdersInEveryLanguage() {
        final Map<String, String> russian = keys("ru.yml");
        final Map<String, String> english = keys("en.yml");

        for (Map.Entry<String, String> entry : russian.entrySet()) {
            assertEquals(placeholders(english.get(entry.getKey())), placeholders(entry.getValue()),
                    "placeholders of " + entry.getKey());
        }
    }

    @Test
    void resolvesEveryMessageKeyUsedByTheBot() {
        final Messages messages = Messages.load("ru", LANGUAGE_DIRECTORY);
        final Set<String> used = usedMessageKeys();

        assertTrue(used.size() > 100, "the source scan found only " + used.size() + " message keys");

        final Set<String> missing = new TreeSet<>();
        for (String key : used) {
            if (!messages.has(key)) {
                missing.add(key);
            }
        }

        assertEquals(Set.of(), missing, "message keys without a translation");
        assertFalse(messages.format("status.label.UNKNOWN").isBlank());
    }

    @Test
    void resolvesTheBundledCatalogWithoutTheExternalFiles(@TempDir Path directory) {
        // A read only configuration directory must not degrade the bot to raw message keys.
        final Messages messages = Messages.load("ru", directory.resolve("absent"),
                BotBootstrap.LANGUAGE_RESOURCE_DIRECTORY);

        assertTrue(messages.has("status.label.UNKNOWN"));
        assertTrue(messages.entries().size() > 60,
                "the bundled catalog must be merged without the external files, only "
                        + messages.entries().size() + " messages were resolved");
        assertFalse(messages.format("status.label.UNKNOWN").isBlank());
    }


    @Test
    void bundlesTheLanguageFilesInsideTheJar() throws IOException {
        for (String language : List.of("en.yml", "ru.yml")) {
            try (var stream = BotBuild.class.getClassLoader()
                    .getResourceAsStream("bot-lang/" + language)) {
                assertTrue(stream != null, "bot-lang/" + language + " must be bundled in the bot jar");
            }
        }
    }

    private static Set<String> usedMessageKeys() {
        final Set<String> keys = new LinkedHashSet<>();
        try (Stream<Path> files = Files.walk(Path.of("src", "main", "java"))) {
            for (Path file : files.filter(path -> path.toString().endsWith(".java")).toList()) {
                final Matcher matcher = MESSAGE_KEY.matcher(Files.readString(file));
                while (matcher.find()) {
                    final String candidate = matcher.group(1);
                    if (KEY_PREFIXES.stream().anyMatch(candidate::startsWith) && !candidate.endsWith(".")) {
                        keys.add(candidate);
                    }
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return keys;
    }

    private static Map<String, String> keys(String language) {
        final Path file = LANGUAGE_DIRECTORY.resolve(language);
        assertTrue(Files.isRegularFile(file), file + " must exist");
        final Map<String, String> result = new LinkedHashMap<>();
        flatten("", YamlConfig.load(file, false).asMap(), result);
        return result;
    }

    private static void flatten(String prefix, Map<String, Object> values, Map<String, String> target) {
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            final String key = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            if (entry.getValue() instanceof Map<?, ?> nested) {
                final Map<String, Object> copy = new LinkedHashMap<>();
                nested.forEach((name, value) -> copy.put(String.valueOf(name), value));
                flatten(key, copy, target);
            } else if (entry.getValue() != null) {
                target.put(key, String.valueOf(entry.getValue()));
            }
        }
    }

    private static Set<String> placeholders(String value) {
        final Set<String> result = new TreeSet<>();
        final Matcher matcher = PLACEHOLDER.matcher(value == null ? "" : value);
        while (matcher.find()) {
            result.add(matcher.group(1));
        }
        return result;
    }
}
