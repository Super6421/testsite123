package ru.zigono.dmc.bot.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Channel restrictions: deny always wins and a per guild allow list replaces the global one.
 *
 * @author Zigono
 */
class ChannelPolicyTest {

    private static final Set<String> GUILDS = Set.of("guild-a", "guild-b");

    @Test
    void allowsEveryChannelWhenNothingIsConfigured() {
        final ChannelPolicy policy = policy("");

        assertTrue(policy.allows("guild-a", "42"));
        assertFalse(policy.restricted());
        assertEquals(Set.of(), policy.allowedChannels("guild-a"));
    }

    @Test
    void allowsOnlyTheConfiguredGlobalChannels() {
        final ChannelPolicy policy = policy("""
                channels:
                  allowed: [ "1", "2" ]
                """);

        assertTrue(policy.allows("guild-a", "1"));
        assertFalse(policy.allows("guild-a", "3"));
        assertTrue(policy.restricted());
    }

    @Test
    void denyWinsOverAllow() {
        final ChannelPolicy policy = policy("""
                channels:
                  allowed: [ "1" ]
                  denied: [ "1" ]
                """);

        assertFalse(policy.allows("guild-a", "1"));
    }

    @Test
    void guildAllowListReplacesTheGlobalOne() {
        final ChannelPolicy policy = policy("""
                channels:
                  allowed: [ "1" ]
                guilds:
                  "guild-a":
                    channels:
                      allowed: [ "9" ]
                """);

        assertTrue(policy.allows("guild-a", "9"));
        assertFalse(policy.allows("guild-a", "1"));
        assertTrue(policy.allows("guild-b", "1"));
        assertEquals(Set.of("9"), policy.allowedChannels("guild-a"));
        assertEquals(Set.of("1"), policy.allowedChannels("guild-b"));
    }

    @Test
    void guildDenyListAddsToTheGlobalDenyList() {
        final ChannelPolicy policy = policy("""
                channels:
                  denied: [ "1" ]
                guilds:
                  "guild-a":
                    channels:
                      denied: [ "9" ]
                """);

        assertFalse(policy.allows("guild-a", "1"));
        assertFalse(policy.allows("guild-a", "9"));
        assertTrue(policy.allows("guild-a", "5"));
        assertEquals(Set.of("1", "9"), policy.deniedChannels("guild-a"));
        assertEquals(Set.of("1"), policy.deniedChannels("guild-b"));
    }

    @Test
    void rejectsAnUnknownChannelWhenAnAllowListExists() {
        final ChannelPolicy policy = policy("""
                channels:
                  allowed: [ "1" ]
                """);

        assertFalse(policy.allows("guild-a", null));
        assertFalse(policy.allows("guild-a", ""));
    }

    private static ChannelPolicy policy(String yaml) {
        return ChannelPolicy.from(YamlConfig.parse(yaml, "test-config", false), GUILDS);
    }
}
