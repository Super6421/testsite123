package ru.zigono.dmc.bot.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.EnvSubstitutor;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Parsing, defaults and validation of {@code bot.yml}.
 *
 * @author Zigono
 */
class BotConfigTest {

    /**
     * The smallest document the bot accepts: it only has to name the Discord token and the control identity.
     */
    private static final String MINIMAL = """
            discord:
              token: "test-token"
            control:
              client_id: discord-bot
              secret: "0123456789abcdef"
            """;

    @Test
    void appliesTheDocumentedDefaults() {
        final BotConfig config = config(MINIMAL);

        assertEquals("ru", config.language());
        assertTrue(config.languageDirectory().toString().endsWith("lang"));
        assertEquals("discord-bot", config.control().clientId());
        assertEquals(Duration.ofSeconds(30), config.control().requestTimeout());
        assertEquals(Duration.ofSeconds(60), config.discord().readyTimeout());
        assertEquals("ONLINE", config.discord().status());
        assertTrue(config.discord().registerGuildCommands());
        assertEquals(1900, config.responses().maxMessageLength());
        assertFalse(config.responses().attachmentMode());
        assertEquals(8, config.responses().maxMessages());
        assertTrue(config.confirmation().enabled());
        assertEquals(Duration.ofSeconds(30), config.confirmation().timeout());
        assertEquals(500, config.confirmation().maxPending());
        assertTrue(config.ui().ephemeral());
        assertEquals(5, config.ui().historyPageSize());
        assertEquals(Duration.ofMinutes(10), config.ui().panelTimeout());
        assertEquals(Duration.ofSeconds(15), config.ui().viewCacheTtl());
        assertEquals(0x5865F2, config.embeds().palette().info());
        assertEquals(0xEB459E, config.embeds().palette().audit());
        assertFalse(config.audit().enabled());
        assertEquals(8443, config.transport().port());
        assertTrue(config.transport().tlsEnabled());
    }

    @Test
    void readsEveryOverriddenValue() {
        final BotConfig config = config("""
                language: en
                discord:
                  token: "test-token"
                  activity: "Custom activity"
                  status: dnd
                  ready_timeout: 5s
                  register_guild_commands: false
                control:
                  client_id: discord-bot
                  secret: "0123456789abcdef"
                  request_timeout: 45s
                responses:
                  max_message_length: 2000
                  large_output:
                    mode: attachment
                    attachment_threshold: 500
                    max_messages: 3
                  embed_description_limit: 1000
                confirmation:
                  enabled: false
                  timeout_seconds: 2m
                  max_pending: 7
                ui:
                  ephemeral: false
                  show_request_id: false
                  autocomplete_limit: 10
                  history_page_size: 10
                  history_max_limit: 10
                  panel_timeout_seconds: 30s
                  view_cache_seconds: 5s
                logging:
                  discord:
                    channel_id: "123456789"
                    include_output: true
                embeds:
                  color:
                    info: "0x112233"
                network:
                  host: "10.0.0.5"
                  port: 9000
                """);

        assertEquals("en", config.language());
        assertEquals("Custom activity", config.discord().activity());
        assertEquals("DND", config.discord().status());
        assertEquals(Duration.ofSeconds(5), config.discord().readyTimeout());
        assertFalse(config.discord().registerGuildCommands());
        assertEquals(Duration.ofSeconds(45), config.control().requestTimeout());
        assertTrue(config.responses().attachmentMode());
        assertEquals(500, config.responses().attachmentThreshold());
        assertEquals(3, config.responses().maxMessages());
        assertEquals(1000, config.responses().embedDescriptionLimit());
        assertFalse(config.confirmation().enabled());
        assertEquals(Duration.ofMinutes(2), config.confirmation().timeout());
        assertEquals(7, config.confirmation().maxPending());
        assertFalse(config.ui().ephemeral());
        assertFalse(config.ui().showRequestId());
        assertEquals(Duration.ofSeconds(5), config.ui().viewCacheTtl());
        assertTrue(config.audit().enabled());
        assertTrue(config.audit().includeOutput());
        assertEquals(0x112233, config.embeds().palette().info());
        assertEquals("10.0.0.5", config.transport().host());
        assertEquals(9000, config.transport().port());
    }

    @Test
    void resolvesEnvironmentPlaceholdersInSecrets() {
        final BotConfig config = config("""
                discord:
                  token: "${DMC_TEST_TOKEN:resolved-token}"
                control:
                  client_id: discord-bot
                  secret: "hex:00112233445566778899aabbccddeeff"
                """);

        assertEquals("resolved-token", config.discord().token());
        assertEquals(16, config.controlSecret().length);
        assertArrayEquals(new byte[]{0x00, 0x11, 0x22, 0x33}, Arrays.copyOf(config.controlSecret(), 4));
        assertTrue(config.secretValues().contains("resolved-token"));
        assertTrue(config.secretValues().contains("hex:00112233445566778899aabbccddeeff"));
    }

    @Test
    void rejectsAMissingToken() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> config("""
                control:
                  client_id: discord-bot
                  secret: "0123456789abcdef"
                """));

        assertTrue(failure.getMessage().contains("discord.token"), failure.getMessage());
    }

    @Test
    void rejectsAMissingControlClient() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> config("""
                discord:
                  token: "test-token"
                control:
                  secret: "0123456789abcdef"
                """));

        assertTrue(failure.getMessage().contains("control.client_id"), failure.getMessage());
    }

    @Test
    void rejectsAMissingControlSecret() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> config("""
                discord:
                  token: "test-token"
                control:
                  client_id: discord-bot
                """));

        assertTrue(failure.getMessage().contains("control.secret"), failure.getMessage());
    }

    @Test
    void rejectsAnUnsupportedDiscordStatus() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> config("""
                discord:
                  token: "test-token"
                  status: SLEEPING
                control:
                  client_id: discord-bot
                  secret: "0123456789abcdef"
                """));

        assertTrue(failure.getMessage().contains("discord.status"), failure.getMessage());
    }

    @Test
    void rejectsAnUnknownLargeOutputMode() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "responses:\n  large_output:\n    mode: everything\n"));

        assertTrue(failure.getMessage().contains("responses.large_output.mode"), failure.getMessage());
    }

    @Test
    void rejectsAnAutocompleteLimitAboveTheDiscordMaximum() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "ui:\n  autocomplete_limit: 26\n"));

        assertTrue(failure.getMessage().contains("ui.autocomplete_limit"), failure.getMessage());
    }

    @Test
    void rejectsAHistoryLimitBelowThePageSize() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "ui:\n  history_page_size: 10\n  history_max_limit: 5\n"));

        assertTrue(failure.getMessage().contains("ui.history_max_limit"), failure.getMessage());
    }

    @Test
    void rejectsAnInvalidEmbedColour() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "embeds:\n  color:\n    error: red\n"));

        assertTrue(failure.getMessage().contains("embeds.color.error"), failure.getMessage());
    }

    @Test
    void rejectsAMessageLimitBelowTheDiscordMinimum() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "responses:\n  max_message_length: 100\n"));

        assertTrue(failure.getMessage().contains("responses.max_message_length"), failure.getMessage());
    }

    @Test
    void rejectsAnInvalidTcpPort() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "network:\n  port: 70000\n"));

        assertTrue(failure.getMessage().contains("network.port"), failure.getMessage());
    }

    @Test
    void rejectsUnencryptedTransportWithoutAnExplicitOptIn() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> config(MINIMAL + "tls:\n  enabled: false\n"));

        assertTrue(failure.getMessage().contains("tls.allow_insecure_transport"), failure.getMessage());
    }

    @Test
    void fingerprintsIdenticalDocumentsEqually() {
        assertEquals(config(MINIMAL).revision(), config(MINIMAL).revision());
        assertNotEquals(config(MINIMAL).revision(), config(MINIMAL + "language: en\n").revision());
    }

    @Test
    void loadsTheConfigurationFileShippedInsideTheJar() {
        final Path shipped = Path.of("src", "main", "resources", "bot.yml");
        assertTrue(Files.isRegularFile(shipped), "the bot must ship a default bot.yml");

        final BotConfig config = BotConfig.of(YamlConfig.of(resolved(shipped), shipped.toString()),
                shipped.toAbsolutePath().getParent());

        assertEquals("ru", config.language());
        assertEquals("discord-bot", config.control().clientId());
        assertEquals("Minecraft Console", config.discord().activity());
        assertEquals(Path.of("lang"), config.languageDirectory().getFileName());
        assertEquals(Duration.ofSeconds(60), config.discord().readyTimeout());
        assertEquals(Duration.ofSeconds(15), config.ui().viewCacheTtl());
        assertEquals(9000, config.transport().port());
        assertThrows(CommandException.class, () -> config.normalizer().normalize("say \\x"),
                "the shipped blocked sequences must reject the literal backslash-x");
        assertEquals("say hello", config.normalizer().normalize("say hello").normalized());
    }

    /**
     * Applies the environment of a production start to the shipped document, so the test verifies the real
     * file with the placeholders resolved.
     */
    private static Map<String, Object> resolved(Path file) {
        final YamlConfig document = YamlConfig.load(file, false);
        final Map<String, String> environment = Map.of(
                "DISCORD_TOKEN", "token",
                "DMC_CONTROL_SECRET", "0123456789abcdef",
                "DMC_GATEWAY_PORT", "9000");
        final Map<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : document.asMap().entrySet()) {
            result.put(entry.getKey(),
                    EnvSubstitutor.apply(entry.getValue(), environment, document.source(), false));
        }
        return result;
    }

    private static BotConfig config(String yaml) {
        return BotConfig.of(YamlConfig.parse(yaml, "test-config", true), Path.of("."));
    }
}
