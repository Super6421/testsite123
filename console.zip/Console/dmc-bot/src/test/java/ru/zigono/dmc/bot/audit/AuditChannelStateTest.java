package ru.zigono.dmc.bot.audit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Команда {@code /logs channel} включает журнал, повторный вызов с тем же каналом его выключает, а другой канал
 * переводит журнал туда. Выбор должен переживать перезапуск сервера, иначе администратор будет включать журнал
 * после каждого обновления.
 *
 * @author Zigono
 */
class AuditChannelStateTest {

    @TempDir
    Path directory;

    @Test
    void remembersTheChannelBetweenRestarts() {
        final Path file = directory.resolve("logs-channel.yml");
        final AuditChannelState state = AuditChannelState.load(file, false, null);
        assertFalse(state.enabled());

        assertEquals(AuditChannelState.Outcome.ENABLED, state.toggle("111"));
        assertTrue(state.enabled());

        final AuditChannelState restarted = AuditChannelState.load(file, false, null);
        assertTrue(restarted.enabled(), "включённый журнал должен пережить перезапуск");
        assertEquals("111", restarted.channelId());

        assertEquals(AuditChannelState.Outcome.DISABLED, restarted.toggle("111"));
        assertFalse(restarted.enabled());
        assertEquals(AuditChannelState.Outcome.ENABLED, restarted.toggle(null), "повтор команды включает журнал");
        assertEquals(AuditChannelState.Outcome.SWITCHED, restarted.toggle("222"));
        assertEquals("222", restarted.channelId());
        assertEquals(AuditChannelState.Outcome.ENABLED, AuditChannelState.load(file, false, null).channelId() != null
                ? AuditChannelState.Outcome.ENABLED : AuditChannelState.Outcome.DISABLED);
    }

    @Test
    void fallsBackToTheConfiguredChannel() {
        final AuditChannelState state = AuditChannelState.load(directory.resolve("missing.yml"), true, "999");
        assertTrue(state.enabled());
        assertEquals("999", state.channelId());
    }

    @Test
    void ignoresAChannelFromABrokenStateFile() throws Exception {
        final Path file = directory.resolve("logs-channel.yml");
        Files.writeString(file, "logging: [ это не словарь");
        final AuditChannelState state = AuditChannelState.load(file, true, "999");
        assertTrue(state.enabled());
        assertEquals("999", state.channelId());
    }

    @Test
    void refusesToToggleWithoutAnyChannel() {
        final AuditChannelState state = AuditChannelState.load(directory.resolve("nothing.yml"), false, "");
        assertThrows(IllegalArgumentException.class, () -> state.toggle(null));
    }
}