package ru.zigono.dmc.bot.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.config.EnvSubstitutor;
import ru.zigono.dmc.common.config.YamlConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Guards the production example {@code config/bot.example.yml}: the file the documentation points at must load
 * through exactly the code path a real start uses, so a stale example cannot survive a change of the parser.
 *
 * @author Zigono
 */
class ExampleConfigTest {

    private static final String BACKSLASH = String.valueOf((char) 92);

    @Test
    void loadsTheDocumentedProductionExample() {
        final Path file = example("bot.example.yml");
        final BotConfig config = BotConfig.of(resolved(file, Map.of(
                "DISCORD_TOKEN", "example-token",
                "DMC_CONTROL_SECRET", "0123456789abcdef0123456789abcdef",
                "DISCORD_GUILD_ID", "111111111111111111",
                "DISCORD_CONSOLE_CHANNEL_ID", "111111111111111199",
                "DMC_AUDIT_CHANNEL_ID", "999999999999999999")), file.getParent());

        assertEquals("ru", config.language());
        assertEquals("discord-bot", config.control().clientId());
        assertEquals(Duration.ofSeconds(30), config.control().requestTimeout());
        assertEquals(Duration.ofSeconds(20), config.control().readyTimeout());
        assertEquals(Duration.ofSeconds(5), config.control().reconnectGrace());
        assertEquals(Duration.ofSeconds(60), config.discord().readyTimeout());
        assertEquals("ONLINE", config.discord().status());
        assertEquals(List.of("111111111111111111"), config.discord().guildIds());
        assertTrue(config.discord().guildScopedCommands());
        assertEquals(Duration.ofSeconds(15), config.ui().viewCacheTtl());
        assertEquals(Duration.ofMinutes(10), config.ui().panelTimeout());
        assertEquals(1900, config.responses().maxMessageLength());
        assertTrue(config.confirmation().enabled());
        assertEquals(500, config.confirmation().maxPending());
        assertTrue(config.audit().enabled());
        assertEquals("999999999999999999", config.audit().channelId());
        assertEquals(8443, config.transport().port());
        assertTrue(config.secretValues().contains("example-token"));
        assertTrue(config.secretValues().contains("0123456789abcdef0123456789abcdef"));
        assertTrue(config.shortcuts().aliasNames().contains("heal"));
        assertTrue(config.shortcuts().templateNames().contains("give"));
        assertEquals("say hello", config.normalizer().normalize("say hello").normalized());
        assertThrows(CommandException.class, () -> config.normalizer().normalize("say " + BACKSLASH + "x"),
                "the documented blocked sequences must reject the literal backslash-x");
        assertThrows(CommandException.class, () -> config.normalizer().normalize("say a && b"),
                "the documented blocked sequences must reject command chaining");
    }

    /**
     * @return the example from the repository root, walking up from the module directory
     */
    private static Path example(String name) {
        Path directory = Path.of("").toAbsolutePath();
        while (directory != null) {
            final Path candidate = directory.resolve("config").resolve(name);
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
            directory = directory.getParent();
        }
        assumeTrue(false, "config/" + name + " is not part of this checkout");
        throw new IllegalStateException("config/" + name + " is missing");
    }

    /**
     * Applies a deterministic environment to the example, the way a production start resolves it.
     */
    private static YamlConfig resolved(Path file, Map<String, String> environment) {
        final YamlConfig document = YamlConfig.load(file, false);
        final Map<String, Object> values = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : document.asMap().entrySet()) {
            values.put(entry.getKey(),
                    EnvSubstitutor.apply(entry.getValue(), environment, document.source(), false));
        }
        return YamlConfig.of(values, document.source());
    }
}
