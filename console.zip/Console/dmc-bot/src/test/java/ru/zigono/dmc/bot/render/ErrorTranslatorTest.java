package ru.zigono.dmc.bot.render;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.i18n.Messages;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * User facing error texts: the message of the error code, the specific message of a command failure and the
 * retry hint.
 *
 * @author Zigono
 */
class ErrorTranslatorTest {

    private static final Messages MESSAGES = Messages.of(Map.of(
            "error.TIMEOUT", "timed out",
            "error.retry_hint.TIMEOUT", "try again",
            "error.PERMISSION_DENIED", "denied",
            "error.group_unavailable", "group is unavailable"));

    private final ErrorTranslator translator = new ErrorTranslator(() -> MESSAGES);

    @Test
    void describesAnErrorCodeWithItsMessage() {
        assertEquals("timed out", translator.describe(ErrorCode.TIMEOUT));
        assertEquals("denied", translator.describe(ErrorCode.PERMISSION_DENIED));
    }

    @Test
    void fallsBackToTheErrorNameWhenNoMessageIsConfigured() {
        assertEquals("INTERNAL_ERROR", translator.describe(ErrorCode.INTERNAL_ERROR));
        assertEquals("INTERNAL_ERROR", translator.describe((ErrorCode) null));
        assertEquals("timed out", translator.describe("timeout"));
        assertEquals("INTERNAL_ERROR", translator.describe("nonsense"));
    }

    @Test
    void prefersTheSpecificMessageOfACommandFailure() {
        final CommandException exception = new CommandException(ErrorCode.INVALID_TARGET, "detail",
                Map.of("key", "error.group_unavailable"));

        assertEquals("group is unavailable", translator.describe(exception));
        assertEquals("denied", translator.describe(new CommandException(ErrorCode.PERMISSION_DENIED, "detail")));
        assertEquals("INTERNAL_ERROR", translator.describe(new IllegalStateException("boom")));
    }

    @Test
    void onlyHintsForRetryableErrors() {
        assertEquals("try again", translator.hint(ErrorCode.TIMEOUT));
        assertEquals("", translator.hint(null));
        assertEquals("", translator.hint(ErrorCode.PERMISSION_DENIED));
        assertEquals("", translator.hint(ErrorCode.INVALID_COMMAND));
    }

    @Test
    void mapsNamesToErrorCodes() {
        assertEquals(ErrorCode.TIMEOUT, ErrorTranslator.codeOf("timeout"));
        assertEquals(ErrorCode.TIMEOUT, ErrorTranslator.codeOf("TIMEOUT"));
        assertEquals(ErrorCode.INTERNAL_ERROR, ErrorTranslator.codeOf("nonsense"));
        assertNull(ErrorTranslator.codeOf(null));
        assertNull(ErrorTranslator.codeOf(" "));
    }
}
