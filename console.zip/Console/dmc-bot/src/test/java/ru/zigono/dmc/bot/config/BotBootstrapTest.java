package ru.zigono.dmc.bot.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.config.YamlConfig;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Installation of the files the bot owns: the default configuration and the language files.
 *
 * @author Zigono
 */
class BotBootstrapTest {

    @Test
    void installsTheDefaultConfigurationAndTheLanguageFiles(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("config").resolve("bot.yml");
        final BotBootstrap bootstrap = bootstrap(configFile);

        bootstrap.install();

        assertTrue(Files.isRegularFile(configFile));
        assertEquals(directory.resolve("config").resolve("lang").toAbsolutePath(), bootstrap.languageDirectory());
        assertEquals(bundled("bot-lang/ru.yml"),
                Files.readString(directory.resolve("config").resolve("lang").resolve("ru.yml")));
        assertEquals(bundled("bot-lang/en.yml"),
                Files.readString(directory.resolve("config").resolve("lang").resolve("en.yml")));
    }

    @Test
    void installsAConfigurationThatOnlyNeedsTheSecrets(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("bot.yml");

        bootstrap(configFile).install();

        final YamlConfig document = YamlConfig.load(configFile, false);
        assertEquals("ru", document.string("language", null));
        assertEquals("lang", document.string("language_directory", null));
        assertEquals("discord-bot", document.string("control.client_id", null));
        assertEquals("${DISCORD_TOKEN}", document.string("discord.token", null));
        assertEquals("${DMC_CONTROL_SECRET}", document.string("control.secret", null));
        assertEquals("Minecraft Console", document.string("discord.activity", null));
    }

    @Test
    void keepsAdministratorEdits(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("bot.yml");
        final BotBootstrap bootstrap = bootstrap(configFile);
        bootstrap.install();

        final String edited = "# edited by the administrator\nlanguage_directory: custom-lang\n";
        Files.writeString(configFile, edited, StandardCharsets.UTF_8);
        final Path languageFile = bootstrap.languageDirectory().resolve("ru.yml");
        Files.writeString(languageFile, "# edited\n", StandardCharsets.UTF_8);

        final BotBootstrap second = bootstrap(configFile);
        second.install();

        assertEquals(edited, Files.readString(configFile));
        assertEquals("# edited\n", Files.readString(languageFile));
        assertEquals(directory.resolve("custom-lang").toAbsolutePath(), second.languageDirectory());
        assertTrue(Files.isRegularFile(directory.resolve("custom-lang").resolve("en.yml")));
    }

    @Test
    void createsTheConfiguredLanguageDirectoryOnly(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("bot.yml");
        Files.writeString(configFile, "language_directory: messages\n", StandardCharsets.UTF_8);

        bootstrap(configFile).install();

        assertTrue(Files.isRegularFile(directory.resolve("messages").resolve("ru.yml")));
        assertFalse(Files.exists(directory.resolve("lang")));
    }

    @Test
    void keepsTheDefaultLanguageDirectoryWhenTheValueIsBlank(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("bot.yml");
        Files.writeString(configFile, "language_directory: \"\"\n", StandardCharsets.UTF_8);

        final BotBootstrap bootstrap = bootstrap(configFile);
        bootstrap.install();

        assertEquals(directory.resolve("lang").toAbsolutePath(), bootstrap.languageDirectory());
    }

    @Test
    void keepsRunningWhenTheLanguageDirectoryCannotBeCreated(@TempDir Path directory) throws IOException {
        final Path configFile = directory.resolve("bot.yml");
        Files.writeString(configFile, "language_directory: lang\n", StandardCharsets.UTF_8);
        // A read only container mount or a stray file makes the directory unusable; the bot must still start.
        Files.writeString(directory.resolve("lang"), "not a directory\n", StandardCharsets.UTF_8);

        final BotBootstrap bootstrap = bootstrap(configFile);
        bootstrap.install();

        assertEquals(directory.resolve("lang").toAbsolutePath(), bootstrap.languageDirectory());
        assertFalse(Files.isRegularFile(directory.resolve("lang").resolve("ru.yml")));
    }


    private static BotBootstrap bootstrap(Path configFile) {
        return new BotBootstrap(configFile, LoggerFactory.getLogger(BotBootstrapTest.class));
    }

    private static String bundled(String resource) throws IOException {
        try (InputStream stream = BotBootstrap.class.getClassLoader().getResourceAsStream(resource)) {
            assertTrue(stream != null, resource + " must be bundled in the bot jar");
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
