package ru.zigono.dmc.bot.perm;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.config.ChannelPolicy;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.PermissionConfig;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.dto.TargetsView;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Guild isolation, channel restrictions and ACL resolution of the bot.
 *
 * @author Zigono
 */
class PermissionFilterTest {

    private static final String GUILD = "guild-a";

    @Test
    void servesEveryGuildWhenNoGuildIsConfigured() {
        final PermissionFilter filter = new PermissionFilter(ChannelPolicy.unrestricted(), Set.of(), false);

        assertTrue(filter.allowsGuild(GUILD));
        assertTrue(filter.check(true, GUILD, "1").allowed());
    }

    @Test
    void rejectsAGuildTheBotDoesNotServe() {
        final PermissionFilter filter = new PermissionFilter(ChannelPolicy.unrestricted(), Set.of(GUILD), false);

        assertTrue(filter.check(true, GUILD, "1").allowed());

        final PermissionFilter.GuildCheck check = filter.check(true, "guild-b", "1");
        assertTrue(check.denied());
        assertEquals(ErrorCode.PERMISSION_DENIED, check.error());
        assertEquals("error.guild_not_allowed", check.messageKey());
        assertFalse(filter.allowsGuild(null));
    }

    @Test
    void rejectsDirectMessagesByDefault() {
        final PermissionFilter filter = new PermissionFilter(ChannelPolicy.unrestricted(), Set.of(), false);

        final PermissionFilter.GuildCheck check = filter.check(false, null, "1");
        assertTrue(check.denied());
        assertEquals(ErrorCode.AUTHENTICATION_FAILED, check.error());
        assertEquals("error.direct_message", check.messageKey());
    }

    @Test
    void allowsDirectMessagesWhenTheyAreEnabled() {
        final PermissionFilter filter = new PermissionFilter(ChannelPolicy.unrestricted(), Set.of(), true);

        assertTrue(filter.check(false, null, "1").allowed());
    }

    @Test
    void rejectsAChannelThatIsNotAllowed() {
        final ChannelPolicy channels = ChannelPolicy.from(YamlConfig.parse("""
                channels:
                  allowed: [ "42" ]
                """, "test-config", false), Set.of(GUILD));
        final PermissionFilter filter = new PermissionFilter(channels, Set.of(GUILD), false);

        assertTrue(filter.check(true, GUILD, "42").allowed());

        final PermissionFilter.GuildCheck check = filter.check(true, GUILD, "7");
        assertTrue(check.denied());
        assertEquals("error.channel_not_allowed", check.messageKey());
    }

    @Test
    void hidesServersTheGatewayDidNotEnable() {
        final TargetsView view = view();

        assertEquals(List.of("survival", "lobby"),
                PermissionFilter.accessibleServers(view).stream().map(TargetsView.ServerOption::id).toList());
    }

    @Test
    void hidesGroupsWithoutAccessibleServers() {
        final TargetsView view = view();

        assertEquals(List.of("network"),
                PermissionFilter.accessibleGroups(view).stream().map(TargetsView.GroupOption::name).toList());
    }

    @Test
    void resolvesTheEffectiveAclWithDenyPriority() {
        final PermissionConfig permissions = PermissionConfig.from(YamlConfig.parse("""
                permissions:
                  roles:
                    "111":
                      allow: [ "console.*" ]
                  users:
                    "222":
                      deny: [ "console.execute" ]
                guilds:
                  "guild-a":
                    permissions:
                      users:
                        "333":
                          allow: [ "console.history" ]
                """, "test-config", false), Set.of(GUILD));
        final PermissionFilter filter = new PermissionFilter(ChannelPolicy.unrestricted(), Set.of(GUILD), false);

        final PermissionSet admin = filter.resolve(permissions, GUILD, List.of("111"), "999");
        assertTrue(admin.allows("console.status"));
        assertTrue(admin.allows("console.execute"));

        final PermissionSet restricted = filter.resolve(permissions, GUILD, List.of("111"), "222");
        assertTrue(restricted.denies("console.execute"));
        assertFalse(restricted.allows("console.execute"));

        final PermissionSet guildScoped = filter.resolve(permissions, GUILD, List.of(), "333");
        assertTrue(guildScoped.allows("console.history"));
        assertFalse(filter.resolve(permissions, "guild-b", List.of(), "333").allows("console.history"));
    }

    private static TargetsView view() {
        return new TargetsView(true, "survival",
                List.of(new TargetsView.ServerOption("survival", "Survival", ServerStatus.ONLINE, true),
                        new TargetsView.ServerOption("lobby", "Lobby", ServerStatus.ONLINE, true),
                        new TargetsView.ServerOption("hidden", "Hidden", ServerStatus.ONLINE, false)),
                List.of(new TargetsView.GroupOption("network", List.of("survival", "lobby")),
                        new TargetsView.GroupOption("unreachable", List.of("hidden"))),
                new TargetsView.Capabilities(true, true, true, true, true, true, true, false, false),
                "rev-1", 1L);
    }
}
