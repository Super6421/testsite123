package ru.zigono.dmc.bot.render;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Rendering of real Minecraft output into Discord: sanitising, splitting and attachments.
 *
 * @author Zigono
 */
class ResponseRendererTest {

    private static final Messages MESSAGES = Messages.of(Map.of(
            "response.empty", "(empty)",
            "response.summary_line", "{0} | {1} | {2}ms",
            "response.section_header", "== {0} [{1}] {2}ms",
            "response.attachment_summary", "{0} chars, {1} lines, file {2}"));

    @Test
    void removesFormattingAnsiEscapesAndTrailingWhitespace() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final String sanitized = renderer.sanitize("\u00A7aHello \u00A7lworld\u00A7r\u001B[0m  \r\nNext\t \n");
        assertEquals("Hello world\nNext", sanitized);
    }

    @Test
    void answersEmptyOutputWithTheLocalizedPlaceholder() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final RenderedResponse response = renderer.render("   \n  ");

        assertTrue(response.empty());
        assertEquals("(empty)", response.text());
        assertFalse(response.hasAttachment());
    }

    @Test
    void keepsShortOutputInsideASingleEmbed() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final RenderedResponse response = renderer.render("Server is running");

        assertTrue(response.embeddable());
        assertTrue(response.singleMessage());
        assertEquals("Server is running", response.text());
        assertEquals(1, response.lineCount());
    }

    @Test
    void splitsOutputThatDoesNotFitIntoOneEmbed() {
        final ResponseRenderer renderer = renderer(200, "split", 100_000, 8, 100);

        final RenderedResponse response = renderer.render("x".repeat(100) + "\n" + "y".repeat(100) + "\n"
                + "z".repeat(100));

        assertFalse(response.embeddable());
        assertFalse(response.hasAttachment());
        assertEquals(3, response.chunks().size());
        assertEquals(302, response.text().length());
    }

    @Test
    void attachesOutputThatNeedsMoreMessagesThanAllowed() {
        final ResponseRenderer renderer = renderer(200, "split", 100_000, 2, 100);

        final RenderedResponse response = renderer.render("a".repeat(600));

        assertTrue(response.hasAttachment());
        assertEquals(ResponseRenderer.DEFAULT_FILE_NAME, response.attachmentName());
    }

    @Test
    void attachesVeryLongOutputInAttachmentMode() {
        final ResponseRenderer renderer = renderer(1900, "attachment", 100, 8, 3900);

        final RenderedResponse response = renderer.render("a".repeat(150));

        assertTrue(response.hasAttachment());
        assertFalse(response.embeddable());
        final byte[] attachment = response.attachment();
        assertEquals(0xEF, attachment[0] & 0xFF);
        assertEquals(0xBB, attachment[1] & 0xFF);
        assertEquals(0xBF, attachment[2] & 0xFF);
        assertEquals("a".repeat(150), new String(attachment, 3, attachment.length - 3, StandardCharsets.UTF_8));
        assertTrue(response.chunks().get(0).contains("150"), response.chunks().get(0));
    }

    @Test
    void namesTheAttachmentAfterTheRequest() {
        final ControlMessages.ExecuteResponse response = new ControlMessages.ExecuteResponse();
        response.setRequestId("req-7");
        response.responseMode = "per_server";
        response.outcomes = List.of(ServerOutcome.success("survival", List.of("a".repeat(150)), 3L, "req-7"));

        final RenderedResponse rendered = renderer(1900, "attachment", 100, 8, 3900).render(response);

        assertEquals("console-req-7.txt", rendered.attachmentName());
    }

    @Test
    void rendersTheDefaultModeFromTheResponse() {
        final ControlMessages.ExecuteResponse response = new ControlMessages.ExecuteResponse();
        response.setRequestId("req-1");
        response.outcomes = List.of(ServerOutcome.success("survival", List.of("hello"), 5L, "req-1"));

        final RenderedResponse rendered = renderer(1900, "split", 10_000, 8, 3900).render(response);

        assertTrue(rendered.text().contains("== survival [SUCCESS] 5ms"), rendered.text());
        assertTrue(rendered.text().contains("hello"));
    }

    @Test
    void summarisesEveryServerInSummaryMode() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final String aggregated = renderer.aggregate(List.of(
                ServerOutcome.success("survival", List.of("body"), 5L, "req-1"),
                ServerOutcome.failure("lobby", ExecutionStatus.OFFLINE, "SERVER_OFFLINE", "down")), "summary");

        assertEquals("survival | SUCCESS | 5ms\nlobby | OFFLINE | 0ms", aggregated);
    }

    @Test
    void mergesTheOutputOfEveryServerInCombinedMode() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final String aggregated = renderer.aggregate(List.of(
                ServerOutcome.success("survival", List.of("first"), 5L, "req-1"),
                ServerOutcome.success("lobby", List.of("second"), 6L, "req-1")), "combined");

        assertEquals("first\nsecond", aggregated);
    }

    @Test
    void reportsTheFailingServerInPerServerMode() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        final String aggregated = renderer.aggregate(List.of(
                ServerOutcome.failure("lobby", ExecutionStatus.OFFLINE, "SERVER_OFFLINE", "server is down")),
                "per_server");

        assertTrue(aggregated.contains("== lobby [OFFLINE] 0ms"), aggregated);
        assertTrue(aggregated.contains("server is down"), aggregated);
    }

    @Test
    void answersNothingWhenThereIsNoOutcome() {
        final ResponseRenderer renderer = renderer(1900, "split", 10_000, 8, 3900);

        assertEquals("", renderer.aggregate(List.of(), "per_server"));
        assertTrue(renderer.render(List.of(), "per_server").empty());
    }

    @Test
    void decidesAttachmentsFromTheConfiguredThreshold() {
        final ResponseRenderer renderer = renderer(1900, "attachment", 100, 8, 3900);

        assertFalse(renderer.shouldAttach(99));
        assertTrue(renderer.shouldAttach(100));
        assertFalse(renderer(1900, "split", 10, 8, 3900).shouldAttach(100));
    }

    private static ResponseRenderer renderer(int maxMessageLength, String mode, int attachmentThreshold,
                                             int maxMessages, int embedDescriptionLimit) {
        return new ResponseRenderer(new BotConfig.ResponseSettings(maxMessageLength, mode, attachmentThreshold,
                maxMessages, embedDescriptionLimit), () -> MESSAGES);
    }
}
