package ru.zigono.dmc.bot.support;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Clock the tests advance by hand so expiry can be verified without sleeping.
 *
 * @author Zigono
 */
public final class TestClock extends Clock {

    private final AtomicLong millis;
    private final ZoneId zone;

    public TestClock(Instant start, ZoneId zone) {
        this.millis = new AtomicLong(start.toEpochMilli());
        this.zone = zone;
    }

    public void advance(Duration duration) {
        millis.addAndGet(duration.toMillis());
    }

    @Override
    public ZoneId getZone() {
        return zone;
    }

    @Override
    public Clock withZone(ZoneId value) {
        final TestClock other = new TestClock(Instant.ofEpochMilli(millis.get()), value);
        return other;
    }

    @Override
    public Instant instant() {
        return Instant.ofEpochMilli(millis.get());
    }

    @Override
    public long millis() {
        return millis.get();
    }
}
