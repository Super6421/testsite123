package ru.zigono.dmc.bot.ui;

import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.dto.TargetSelection;

import java.time.Clock;
import java.time.Duration;
import java.util.Objects;
import java.util.Optional;

/**
 * Pending dangerous command confirmations. An entry is bound to the initiating user, to the exact command and
 * to a time to live; it can be consumed exactly once, and a stranger clicking the buttons cannot invalidate the
 * action, so the initiator can still confirm it.
 *
 * @author Zigono
 */
public final class ConfirmationRegistry {

    /** Outcome of a confirmation or cancellation click. */
    public enum Result {
        OK,
        UNKNOWN,
        EXPIRED,
        FOREIGN_USER,
        COMMAND_MISMATCH
    }

    /** Everything the bot knows about the action that has to be confirmed. */
    public record Draft(String userId, String username, String guildId, String channelId, String targetDescription,
                        TargetSelection target, String command, String normalizedCommand, boolean dryRun,
                        String confirmationId) {
    }

    /** A registered, still pending confirmation. */
    public record Pending(String nonce, String userId, String username, String guildId, String channelId,
                          String targetDescription, TargetSelection target, String command, String normalizedCommand,
                          boolean dryRun, String confirmationId, long createdAt, long expiresAt) {
    }

    /** Result of consuming a pending confirmation. */
    public record Claim(Pending pending, Result result) {

        public static Claim rejected(Result result) {
            return new Claim(null, result);
        }

        public boolean ok() {
            return result == Result.OK;
        }
    }

    private final ExpiringStore<Pending> store;

    public ConfirmationRegistry(Duration ttl, int maxPending) {
        this(ttl, maxPending, Clock.systemUTC());
    }

    public ConfirmationRegistry(Duration ttl, int maxPending, Clock clock) {
        this.store = new ExpiringStore<>(clock, ttl, maxPending, Pending::expiresAt);
    }

    /** Registers a new pending confirmation and returns it with its generated nonce. */
    public Pending register(Draft draft) {
        Objects.requireNonNull(draft, "draft");
        final String nonce = Ids.nonce(16);
        final long createdAt = store.now();
        final Pending pending = new Pending(nonce, draft.userId(), draft.username(), draft.guildId(),
                draft.channelId(), draft.targetDescription(), draft.target(), draft.command(),
                draft.normalizedCommand(), draft.dryRun(), draft.confirmationId(), createdAt,
                store.expiresAt(createdAt));
        store.put(nonce, pending);
        return pending;
    }

    /**
     * Consumes a pending confirmation.
     *
     * @param normalizedCommand command the user actually confirmed; it must match the registered one
     */
    public Claim claim(String nonce, String userId, String normalizedCommand) {
        final Optional<Pending> candidate = store.peek(nonce);
        if (candidate.isEmpty()) {
            return Claim.rejected(Result.UNKNOWN);
        }
        final Pending pending = candidate.get();
        if (store.expired(pending)) {
            store.remove(nonce);
            return Claim.rejected(Result.EXPIRED);
        }
        if (!Objects.equals(pending.userId(), userId)) {
            return Claim.rejected(Result.FOREIGN_USER);
        }
        if (normalizedCommand != null && !normalizedCommand.isBlank()
                && !normalizedCommand.equals(pending.normalizedCommand())) {
            store.remove(nonce);
            return Claim.rejected(Result.COMMAND_MISMATCH);
        }
        store.remove(nonce);
        return new Claim(pending, Result.OK);
    }

    public Optional<Pending> peek(String nonce) {
        return store.peek(nonce);
    }

    public boolean isPending(String nonce) {
        return store.get(nonce).isPresent();
    }

    public int size() {
        return store.size();
    }

    public int purgeExpired() {
        return store.purgeExpired();
    }

    public void clear() {
        store.clear();
    }

    public Duration ttl() {
        return store.ttl();
    }
}
