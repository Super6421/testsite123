package ru.zigono.dmc.bot.config;

import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.CommandShortcuts;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.perm.PermissionConfig;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.protocol.Secrets;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Typed view over {@code bot.yml}: the Discord bot side of the configuration.
 * <p>Nothing in this class reaches the runtime as a hardcoded value: every limit, colour, timeout and message
 * key is configurable, secrets are only ever read through environment placeholders and the whole document can
 * be reloaded while the bot is running.</p>
 *
 * @author Zigono
 */
public final class BotConfig {

    /** Supported values of {@code responses.large_output.mode}. */
    public static final Set<String> LARGE_OUTPUT_MODES = Set.of("split", "attachment");

    /** Supported values of {@code discord.status}. */
    public static final Set<String> DISCORD_STATUSES = Set.of("ONLINE", "IDLE", "DND", "INVISIBLE");

    private final YamlConfig root;
    private final Path file;
    private final Path baseDirectory;
    private final String language;
    private final Path languageDirectory;
    private final DiscordSettings discord;
    private final ChannelPolicy channels;
    private final PermissionConfig permissions;
    private final ControlSettings control;
    private final CommandNormalizer normalizer;
    private final CommandPolicyEngine policy;
    private final CommandShortcuts shortcuts;
    private final ResponseSettings responses;
    private final ConfirmationSettings confirmation;
    private final UiSettings ui;
    private final EmbedSettings embeds;
    private final AuditSettings audit;
    private final StaffConfig staff;
    private final TransportSettings transport;

    private BotConfig(YamlConfig root, Path file, Path baseDirectory) {
        this.root = Objects.requireNonNull(root, "root");
        this.file = file;
        this.baseDirectory = Objects.requireNonNull(baseDirectory, "baseDirectory");
        this.language = root.string("language", "ru").trim().toLowerCase(Locale.ROOT);
        this.languageDirectory = baseDirectory.resolve(root.string("language_directory", "lang"));
        this.discord = DiscordSettings.from(root);
        final Set<String> guildIds = new LinkedHashSet<>(discord.guildIds());
        this.channels = ChannelPolicy.from(root, guildIds);
        this.permissions = PermissionConfig.from(root, guildIds);
        this.control = ControlSettings.from(root);
        this.normalizer = new CommandNormalizer(
                root.integer("security.max_command_length", CommandNormalizer.DEFAULT_MAX_LENGTH),
                root.stringList("security.blocked_sequences", CommandNormalizer.DEFAULT_BLOCKED_SEQUENCES));
        this.policy = CommandPolicyEngine.from(root);
        this.shortcuts = CommandShortcuts.from(root, normalizer);
        this.responses = ResponseSettings.from(root.section("responses"));
        this.confirmation = ConfirmationSettings.from(root.section("confirmation"));
        this.ui = UiSettings.from(root.section("ui"));
        this.embeds = EmbedSettings.from(root.section("embeds"));
        this.audit = AuditSettings.from(root.section("logging"));
        this.staff = StaffConfig.from(root);
        this.transport = TransportSettings.from(root.section("network"), root.section("tls"), baseDirectory,
                control.clientId(), "control");
    }

    /**
     * Loads and validates {@code bot.yml}. Missing required values fail fast at startup.
     */
    public static BotConfig load(Path file) {
        final Path absolute = file.toAbsolutePath();
        return new BotConfig(YamlConfig.load(absolute), absolute,
                absolute.getParent() == null ? Path.of(".") : absolute.getParent());
    }

    public static BotConfig of(YamlConfig config, Path baseDirectory) {
        return new BotConfig(config, null, baseDirectory == null ? Path.of(".") : baseDirectory);
    }

    public YamlConfig root() {
        return root;
    }

    /**
     * @return the configuration file, when the configuration was read from disk
     */
    public Optional<Path> file() {
        return Optional.ofNullable(file);
    }

    public String source() {
        return root.source();
    }

    /** Stable fingerprint of the configuration, used by the hot reload and by audit records. */
    public String revision() {
        return root.fingerprint();
    }

    public String language() {
        return language;
    }

    public Path languageDirectory() {
        return languageDirectory;
    }

    public Path baseDirectory() {
        return baseDirectory;
    }

    public DiscordSettings discord() {
        return discord;
    }

    public ChannelPolicy channels() {
        return channels;
    }

    public PermissionConfig permissions() {
        return permissions;
    }

    public ControlSettings control() {
        return control;
    }

    public CommandNormalizer normalizer() {
        return normalizer;
    }

    public CommandPolicyEngine policy() {
        return policy;
    }

    public CommandShortcuts shortcuts() {
        return shortcuts;
    }

    public ResponseSettings responses() {
        return responses;
    }

    public ConfirmationSettings confirmation() {
        return confirmation;
    }

    public UiSettings ui() {
        return ui;
    }

    public EmbedSettings embeds() {
        return embeds;
    }

    public AuditSettings audit() {
        return audit;
    }

    /** Привилегии и иерархия выдачи: раздел {@code staff} конфигурации. */
    public StaffConfig staff() {
        return staff;
    }

    public TransportSettings transport() {
        return transport;
    }

    /** Decodes the shared secret of the control client. */
    public byte[] controlSecret() {
        return Secrets.decode(control.secret(), "control.client_id " + control.clientId());
    }

    /**
     * @return every configured secret value, so it can be redacted from logs and error messages
     */
    public List<String> secretValues() {
        final List<String> values = new ArrayList<>();
        values.add(discord.token());
        values.add(control.secret());
        addSecret(values, transport.keyStorePassword());
        addSecret(values, transport.keyPassword());
        addSecret(values, transport.trustStorePassword());
        return List.copyOf(values);
    }

    private static void addSecret(List<String> target, String value) {
        if (value != null && !value.isBlank()) {
            target.add(value);
        }
    }

    /** Discord application settings. */
    public record DiscordSettings(String token, List<String> guildIds, boolean registerGuildCommands,
                                  String activity, String status, Duration readyTimeout) {

        public DiscordSettings {
            guildIds = guildIds == null ? List.of() : List.copyOf(guildIds);
        }

        /** @return {@code true} when commands should be registered per guild instead of globally */
        public boolean guildScopedCommands() {
            return registerGuildCommands && !guildIds.isEmpty();
        }

        static DiscordSettings from(YamlConfig root) {
            final String token = root.string("discord.token", null);
            if (token == null || token.isBlank()) {
                throw new ConfigException("нужно задать discord.token; используйте плейсхолдер "
                        + "${DISCORD_TOKEN}, чтобы взять его из переменной окружения");
            }
            final String status = root.string("discord.status", "ONLINE").trim().toUpperCase(Locale.ROOT);
            root.requireEnum("discord.status", status, DISCORD_STATUSES);
            return new DiscordSettings(token.trim(), root.stringList("discord.guilds", List.of()),
                    root.bool("discord.register_guild_commands", true),
                    root.string("discord.activity", "Minecraft Console"), status,
                    positive(root.duration("discord.ready_timeout", Duration.ofSeconds(60)),
                            "discord.ready_timeout"));
        }
    }

    /** Gateway connection settings of the control client. */
    public record ControlSettings(String clientId, String secret, Duration requestTimeout, Duration handshakeTimeout,
                                  Duration readyTimeout, Duration reconnectGrace) {

        static ControlSettings from(YamlConfig root) {
            final String clientId = root.string("control.client_id", null);
            if (clientId == null || clientId.isBlank()) {
                throw new ConfigException("нужно задать control.client_id");
            }
            final String secret = root.string("control.secret", null);
            if (secret == null || secret.isBlank()) {
                throw new ConfigException("нужно задать control.secret; используйте плейсхолдер "
                        + "${DMC_CONTROL_SECRET}, чтобы взять его из переменной окружения");
            }
            return new ControlSettings(clientId.trim(), secret.trim(),
                    positive(root.duration("control.request_timeout", Duration.ofSeconds(30)), "control.request_timeout"),
                    positive(root.duration("control.handshake_timeout", Duration.ofSeconds(15)), "control.handshake_timeout"),
                    positive(root.duration("control.ready_timeout", Duration.ofSeconds(20)), "control.ready_timeout"),
                    positive(root.duration("control.reconnect_grace", Duration.ofSeconds(5)), "control.reconnect_grace"));
        }
    }

    /** Rendering limits of Minecraft output inside Discord. */
    public record ResponseSettings(int maxMessageLength, String largeOutputMode, int attachmentThreshold,
                                   int maxMessages, int embedDescriptionLimit) {

        static ResponseSettings from(YamlConfig section) {
            final int maxMessageLength = section.integer("max_message_length", 1900);
            if (maxMessageLength < 200 || maxMessageLength > 2000) {
                throw new ConfigException("responses.max_message_length должен быть от 200 до 2000");
            }
            final String mode = section.string("large_output.mode", "split").trim().toLowerCase(Locale.ROOT);
            section.requireEnum("responses.large_output.mode", mode, LARGE_OUTPUT_MODES);
            final int attachmentThreshold = section.integer("large_output.attachment_threshold", 10_000);
            if (attachmentThreshold < 100) {
                throw new ConfigException("responses.large_output.attachment_threshold должен быть не меньше 100 символов");
            }
            final int maxMessages = section.integer("large_output.max_messages", 8);
            if (maxMessages < 1 || maxMessages > 50) {
                throw new ConfigException("responses.large_output.max_messages должен быть от 1 до 50");
            }
            final int embedDescriptionLimit = section.integer("embed_description_limit", 3900);
            if (embedDescriptionLimit < 200 || embedDescriptionLimit > 4096) {
                throw new ConfigException("responses.embed_description_limit должен быть от 200 до 4096");
            }
            return new ResponseSettings(maxMessageLength, mode, attachmentThreshold, maxMessages, embedDescriptionLimit);
        }

        /** @return {@code true} when large output is uploaded as a file instead of being split */
        public boolean attachmentMode() {
            return "attachment".equals(largeOutputMode);
        }
    }

    /** Dangerous command confirmation flow. */
    public record ConfirmationSettings(boolean enabled, Duration timeout, int maxPending) {

        static ConfirmationSettings from(YamlConfig section) {
            final Duration timeout = section.duration("timeout_seconds", Duration.ofSeconds(30));
            if (timeout.isZero() || timeout.isNegative()) {
                throw new ConfigException("confirmation.timeout_seconds должен быть положительным");
            }
            final int maxPending = section.integer("max_pending", 500);
            if (maxPending < 1) {
                throw new ConfigException("confirmation.max_pending должен быть положительным");
            }
            return new ConfirmationSettings(section.bool("enabled", true), timeout, maxPending);
        }
    }

    /** Discord user interface behaviour. */
    public record UiSettings(boolean ephemeral, boolean showRequestId, boolean showDiagnostics, int autocompleteLimit,
                             int historyPageSize, int historyMaxLimit, Duration panelTimeout, Duration viewCacheTtl) {

        static UiSettings from(YamlConfig section) {
            final int autocompleteLimit = section.integer("autocomplete_limit", 25);
            if (autocompleteLimit < 1 || autocompleteLimit > 25) {
                throw new ConfigException("ui.autocomplete_limit должен быть от 1 до 25");
            }
            final int historyPageSize = section.integer("history_page_size", 5);
            if (historyPageSize < 1 || historyPageSize > 25) {
                throw new ConfigException("ui.history_page_size должен быть от 1 до 25");
            }
            final int historyMaxLimit = section.integer("history_max_limit", 25);
            if (historyMaxLimit < historyPageSize || historyMaxLimit > 100) {
                throw new ConfigException("ui.history_max_limit должен быть от ui.history_page_size до 100");
            }
            final Duration panelTimeout = section.duration("panel_timeout_seconds", Duration.ofMinutes(10));
            if (panelTimeout.isZero() || panelTimeout.isNegative()) {
                throw new ConfigException("ui.panel_timeout_seconds должен быть положительным");
            }
            final Duration viewCacheTtl = section.duration("view_cache_seconds", Duration.ofSeconds(15));
            if (viewCacheTtl.isZero() || viewCacheTtl.isNegative()) {
                throw new ConfigException("ui.view_cache_seconds должен быть положительным");
            }
            return new UiSettings(section.bool("ephemeral", true), section.bool("show_request_id", false),
                    section.bool("show_diagnostics", false),
                    autocompleteLimit, historyPageSize, historyMaxLimit, panelTimeout, viewCacheTtl);
        }
    }

    /** Colours, footer and timestamp of every embed. */
    public record EmbedSettings(String footer, boolean timestamp, Palette palette) {

        /** Resolved embed colours. */
        public record Palette(int info, int success, int warning, int error, int audit, int neutral) {
        }

        static EmbedSettings from(YamlConfig section) {
            final YamlConfig colors = section.section("color");
            final Palette palette = new Palette(
                    color(colors.string("info", "#5865F2"), "embeds.color.info"),
                    color(colors.string("success", "#57F287"), "embeds.color.success"),
                    color(colors.string("warning", "#FEE75F"), "embeds.color.warning"),
                    color(colors.string("error", "#ED4245"), "embeds.color.error"),
                    color(colors.string("audit", "#EB459E"), "embeds.color.audit"),
                    color(colors.string("neutral", "#99AAB5"), "embeds.color.neutral"));
            return new EmbedSettings(section.string("footer", "Discord Minecraft Console · Zigono"),
                    section.bool("timestamp", true), palette);
        }

        static int color(String value, String path) {
            final String trimmed = value == null ? "" : value.trim();
            final String digits = trimmed.startsWith("#") ? trimmed.substring(1)
                    : trimmed.toLowerCase(Locale.ROOT).startsWith("0x") ? trimmed.substring(2) : trimmed;
            try {
                final int parsed = Integer.parseInt(digits, 16);
                if (parsed < 0 || parsed > 0xFFFFFF) {
                    throw new NumberFormatException("вне допустимого диапазона");
                }
                return parsed;
            } catch (NumberFormatException e) {
                throw new ConfigException(path + " должен быть цветом RGB в hex, например #5865F2, но было '" + value + "'");
            }
        }
    }

    /** Discord audit channel of the bot. */
    public record AuditSettings(boolean enabled, String channelId, boolean includeOutput, boolean includeRoles) {

        static AuditSettings from(YamlConfig logging) {
            final YamlConfig section = logging.section("discord");
            final String channelId = section.string("channel_id", "").trim();
            final boolean enabled = section.bool("enabled", true) && !channelId.isEmpty();
            return new AuditSettings(enabled, channelId.isEmpty() ? null : channelId,
                    section.bool("include_output", false), section.bool("include_roles", false));
        }
    }

    private static Duration positive(Duration value, String path) {
        if (value == null || value.isZero() || value.isNegative()) {
            throw new ConfigException(path + " должен быть положительной длительностью");
        }
        return value;
    }
}
