package ru.zigono.dmc.bot.ui;

import ru.zigono.dmc.bot.audit.AuditEntry;
import ru.zigono.dmc.bot.render.RenderedResponse;
import ru.zigono.dmc.protocol.dto.ServerOutcome;

import java.util.List;

/**
 * Everything an embed needs to describe one execution result, detached from the JDA interaction so the rendering
 * can be unit tested and reused by the audit channel.
 *
 * @author Zigono
 */
public record ResultView(String status, String target, String command, long durationMillis, String requestId,
                         RenderedResponse output, List<ServerOutcome> outcomes, boolean dryRun, String errorCode,
                         String errorDetail, String dryRunSummary, List<String> dryRunChecks) {

    public ResultView {
        outcomes = outcomes == null ? List.of() : List.copyOf(outcomes);
        dryRunChecks = dryRunChecks == null ? List.of() : List.copyOf(dryRunChecks);
    }

    public static ResultView of(ru.zigono.dmc.protocol.message.ControlMessages.ExecuteResponse response,
                                RenderedResponse output) {
        return new ResultView(AuditEntry.statusOf(response == null ? List.of() : response.outcomes),
                response == null ? null : response.targetDescription,
                response == null ? null : response.command,
                response == null ? 0L : response.durationMillis,
                response == null ? null : response.getRequestId(),
                output,
                response == null ? List.of() : response.outcomes,
                response != null && response.dryRun,
                response == null ? null : response.errorCode,
                response == null ? null : response.errorDetail,
                response == null ? null : response.dryRunSummary,
                response == null ? List.of() : response.dryRunChecks);
    }

    public boolean failed() {
        return !"SUCCESS".equals(status) && !"DRY_RUN".equals(status);
    }

    public boolean partial() {
        return AuditEntry.STATUS_PARTIAL.equals(status);
    }
}
