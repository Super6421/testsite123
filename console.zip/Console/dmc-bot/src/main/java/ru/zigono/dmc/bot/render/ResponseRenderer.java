package ru.zigono.dmc.bot.render;

import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.common.text.Text;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Renders real Minecraft output for Discord: Minecraft formatting codes and ANSI escapes are removed, lines are
 * sanitized, long output is split at the configured message length and, depending on the configuration, either
 * split across several messages or uploaded as a file.
 *
 * @author Zigono
 */
public final class ResponseRenderer {

    public static final String MODE_PER_SERVER = "per_server";
    public static final String MODE_SUMMARY = "summary";
    public static final String MODE_COMBINED = "combined";
    public static final String DEFAULT_FILE_NAME = "console-output.txt";

    private final BotConfig.ResponseSettings settings;
    private final Supplier<Messages> messages;

    public ResponseRenderer(BotConfig.ResponseSettings settings, Supplier<Messages> messages) {
        this.settings = Objects.requireNonNull(settings, "settings");
        this.messages = Objects.requireNonNull(messages, "messages");
    }

    public BotConfig.ResponseSettings settings() {
        return settings;
    }

    /** Renders the outcome of an execution request. */
    public RenderedResponse render(ControlMessages.ExecuteResponse response) {
        final String mode = response == null || response.responseMode == null
                ? MODE_PER_SERVER
                : response.responseMode.toLowerCase(Locale.ROOT);
        final List<ServerOutcome> outcomes = response == null ? List.of() : response.outcomes;
        return render(aggregate(outcomes, mode), fileName(response));
    }

    public RenderedResponse render(List<ServerOutcome> outcomes, String responseMode) {
        return render(aggregate(outcomes, responseMode), DEFAULT_FILE_NAME);
    }

    public RenderedResponse render(String rawOutput) {
        return render(rawOutput, DEFAULT_FILE_NAME);
    }

    /**
     * @param rawOutput raw Minecraft console output
     * @param fileName  name of the attachment when the output has to be uploaded
     */
    public RenderedResponse render(String rawOutput, String fileName) {
        final String cleaned = sanitize(rawOutput);
        if (cleaned.isEmpty()) {
            return RenderedResponse.empty(messages.get().format("response.empty"));
        }
        if (shouldAttach(cleaned.length())) {
            return attach(cleaned, fileName);
        }
        final List<String> chunks = Text.split(cleaned, settings.maxMessageLength());
        if (chunks.size() > settings.maxMessages()) {
            return attach(cleaned, fileName);
        }
        if (cleaned.length() <= settings.embedDescriptionLimit()) {
            return new RenderedResponse(cleaned, List.of(), null, "", false);
        }
        return new RenderedResponse(cleaned, chunks, null, "", false);
    }

    /**
     * @return {@code true} when the output has to be uploaded instead of being rendered inline
     */
    public boolean shouldAttach(int length) {
        return settings.attachmentMode() && length >= settings.attachmentThreshold();
    }

    /** Aggregates the per server outcomes according to the response mode of the gateway. */
    public String aggregate(List<ServerOutcome> outcomes, String responseMode) {
        if (outcomes == null || outcomes.isEmpty()) {
            return "";
        }
        final String mode = responseMode == null ? MODE_PER_SERVER : responseMode.toLowerCase(Locale.ROOT);
        final StringBuilder out = new StringBuilder();
        for (ServerOutcome outcome : outcomes) {
            final String body = sanitize(outcome.outputAsText());
            switch (mode) {
                case MODE_SUMMARY -> appendLine(out, messages.get().format("response.summary_line", outcome.serverId(),
                        outcome.status().name(), outcome.durationMillis()));
                case MODE_COMBINED -> {
                    if (!body.isEmpty()) {
                        if (!out.isEmpty()) {
                            out.append('\n');
                        }
                        out.append(body);
                    }
                }
                default -> {
                    appendLine(out, messages.get().format("response.section_header", outcome.serverId(),
                            outcome.status().name(), outcome.durationMillis()));
                    if (!body.isEmpty()) {
                        out.append(body).append('\n');
                    }
                    if (outcome.errorDetail() != null && !outcome.errorDetail().isBlank()) {
                        appendLine(out, outcome.errorDetail());
                    }
                }
            }
        }
        return out.toString().strip();
    }

    /** Removes Minecraft formatting, ANSI escapes, control characters and trailing whitespace. */
    public String sanitize(String value) {
        if (value == null) {
            return "";
        }
        final String normalized = value.replace("\r\n", "\n").replace('\r', '\n');
        final String stripped = Text.sanitizeForDiscord(Text.stripFormatting(normalized));
        final StringBuilder out = new StringBuilder(stripped.length());
        for (String line : stripped.split("\n", -1)) {
            out.append(stripTrailingWhitespace(line)).append('\n');
        }
        return out.toString().strip();
    }

    private static String stripTrailingWhitespace(String line) {
        int end = line.length();
        while (end > 0 && Character.isWhitespace(line.charAt(end - 1))) {
            end--;
        }
        return line.substring(0, end);
    }

    private static void appendLine(StringBuilder target, String line) {
        if (line == null || line.isEmpty()) {
            return;
        }
        if (!target.isEmpty()) {
            target.append('\n');
        }
        target.append(line);
    }

    private RenderedResponse attach(String text, String fileName) {
        final String name = fileName == null || fileName.isBlank() ? DEFAULT_FILE_NAME : fileName;
        final String summary = messages.get().format("response.attachment_summary", text.length(), countLines(text), name);
        final byte[] content = ("\uFEFF" + text).getBytes(StandardCharsets.UTF_8);
        return new RenderedResponse(text, List.of(summary), content, name, false);
    }

    private static String fileName(ControlMessages.ExecuteResponse response) {
        final String requestId = response == null ? null : response.getRequestId();
        if (requestId == null || requestId.isBlank()) {
            return DEFAULT_FILE_NAME;
        }
        return "console-" + requestId + ".txt";
    }

    private static int countLines(String value) {
        if (value.isEmpty()) {
            return 0;
        }
        int lines = 1;
        for (int index = 0; index < value.length(); index++) {
            if (value.charAt(index) == '\n') {
                lines++;
            }
        }
        return lines;
    }
}