package ru.zigono.dmc.bot.audit;

import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.util.List;

/**
 * One audited console action. The record carries everything the specification requires to be stored for every
 * command: request id, Discord identity, target, command, status, duration, response and error.
 *
 * @author Zigono
 */
public record AuditEntry(String requestId, String userId, String username, String guildId, String channelId,
                         String target, String command, String status, long durationMillis, String errorCode,
                         String errorDetail, boolean dryRun, List<ServerOutcome> outcomes, List<String> roleIds,
                         String response, long timestamp) {

    public static final String STATUS_PARTIAL = "PARTIAL";

    public AuditEntry {
        outcomes = outcomes == null ? List.of() : List.copyOf(outcomes);
        roleIds = roleIds == null ? List.of() : List.copyOf(roleIds);
        response = response == null ? "" : response;
    }

    /** Builds the audit record of an answered execution request. */
    public static AuditEntry of(ControlMessages.ExecuteResponse response, UserContext user, String responseText) {
        final List<ServerOutcome> outcomes = response == null ? List.of() : response.outcomes;
        return new AuditEntry(response == null ? null : response.getRequestId(),
                user == null ? null : user.userId(),
                user == null ? null : user.username(),
                user == null ? null : user.guildId(),
                user == null ? null : user.channelId(),
                response == null ? null : response.targetDescription,
                response == null ? null : response.command,
                statusOf(outcomes),
                response == null ? 0L : response.durationMillis,
                response == null ? null : response.errorCode,
                response == null ? null : response.errorDetail,
                response != null && response.dryRun,
                outcomes,
                user == null ? List.of() : user.roleIds(),
                responseText,
                System.currentTimeMillis());
    }

    /** Builds the audit record of a request that never reached a Minecraft server. */
    public static AuditEntry failure(String requestId, UserContext user, String target, String command,
                                     String errorCode, String errorDetail) {
        return new AuditEntry(requestId,
                user == null ? null : user.userId(),
                user == null ? null : user.username(),
                user == null ? null : user.guildId(),
                user == null ? null : user.channelId(),
                target, command, errorCode == null ? ExecutionStatus.FAILED.name() : errorCode,
                0L, errorCode, errorDetail, false, List.of(),
                user == null ? List.of() : user.roleIds(), "", System.currentTimeMillis());
    }

    public static String statusOf(List<ServerOutcome> outcomes) {
        if (outcomes == null || outcomes.isEmpty()) {
            return ExecutionStatus.FAILED.name();
        }
        final boolean allSuccessful = outcomes.stream().allMatch(outcome -> outcome.status().successful());
        if (allSuccessful) {
            return ExecutionStatus.SUCCESS.name();
        }
        final boolean anySuccessful = outcomes.stream().anyMatch(outcome -> outcome.status().successful());
        return anySuccessful ? STATUS_PARTIAL : outcomes.get(0).status().name();
    }

    public boolean failed() {
        return !ExecutionStatus.SUCCESS.name().equals(status);
    }
}
