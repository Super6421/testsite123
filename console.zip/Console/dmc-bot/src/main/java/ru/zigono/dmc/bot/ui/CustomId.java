package ru.zigono.dmc.bot.ui;

import java.util.Locale;
import java.util.Optional;

/**
 * Custom identifiers of the interactive components. Every component carries only a random nonce, never user
 * input, so a forged identifier cannot be used to execute anything: the nonce must exist in the registry and
 * must belong to the user that invokes the component.
 *
 * @author Zigono
 */
public final class CustomId {

    public static final String PREFIX = "dmc";

    public static final String ACTION_PANEL_TARGET = "panel_target";
    public static final String ACTION_PANEL_EXECUTE = "panel_execute";
    public static final String ACTION_PANEL_MODAL = "panel_modal";
    public static final String ACTION_CONFIRM = "confirm";
    public static final String ACTION_CANCEL = "cancel";
    public static final String ACTION_HISTORY = "history";

    private CustomId() {
    }

    public static String panelTarget(String nonce) {
        return PREFIX + ":panel:target:" + nonce;
    }

    public static String panelExecute(String nonce) {
        return PREFIX + ":panel:execute:" + nonce;
    }

    public static String panelModal(String nonce) {
        return PREFIX + ":panel:modal:" + nonce;
    }

    public static String confirm(String nonce) {
        return PREFIX + ":" + ACTION_CONFIRM + ":" + nonce;
    }

    public static String cancel(String nonce) {
        return PREFIX + ":" + ACTION_CANCEL + ":" + nonce;
    }

    public static String historyPage(String nonce, int offset) {
        return PREFIX + ":history:" + nonce + ":" + Math.max(0, offset);
    }

    /** Parsed representation of a component identifier. */
    public record Parsed(String action, String nonce, int offset) {
    }

    public static Optional<Parsed> parse(String customId) {
        if (customId == null || customId.isBlank()) {
            return Optional.empty();
        }
        final String[] parts = customId.split(":", 4);
        if (parts.length < 3 || !PREFIX.equals(parts[0])) {
            return Optional.empty();
        }
        final String action = parts[1].toLowerCase(Locale.ROOT);
        if ("panel".equals(action) && parts.length == 4) {
            final String kind = parts[2].toLowerCase(Locale.ROOT);
            return switch (kind) {
                case "target" -> Optional.of(new Parsed(ACTION_PANEL_TARGET, parts[3], 0));
                case "execute" -> Optional.of(new Parsed(ACTION_PANEL_EXECUTE, parts[3], 0));
                case "modal" -> Optional.of(new Parsed(ACTION_PANEL_MODAL, parts[3], 0));
                default -> Optional.empty();
            };
        }
        if (ACTION_CONFIRM.equals(action) && parts.length == 3) {
            return Optional.of(new Parsed(ACTION_CONFIRM, parts[2], 0));
        }
        if (ACTION_CANCEL.equals(action) && parts.length == 3) {
            return Optional.of(new Parsed(ACTION_CANCEL, parts[2], 0));
        }
        if (ACTION_HISTORY.equals(action) && parts.length == 4) {
            try {
                return Optional.of(new Parsed(ACTION_HISTORY, parts[2], Math.max(0, Integer.parseInt(parts[3]))));
            } catch (NumberFormatException e) {
                return Optional.empty();
            }
        }
        return Optional.empty();
    }

    public static boolean isComponent(String customId) {
        return customId != null && customId.startsWith(PREFIX + ":");
    }
}
