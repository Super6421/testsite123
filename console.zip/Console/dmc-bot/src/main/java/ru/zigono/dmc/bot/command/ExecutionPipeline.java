package ru.zigono.dmc.bot.command;

import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.interactions.components.LayoutComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.BotRuntime;
import ru.zigono.dmc.bot.audit.AuditEntry;
import ru.zigono.dmc.bot.gateway.GatewayClient;
import ru.zigono.dmc.bot.interaction.InteractionTarget;
import ru.zigono.dmc.bot.render.RenderedResponse;
import ru.zigono.dmc.bot.target.TargetOptions;
import ru.zigono.dmc.bot.target.TargetSelectionParser;
import ru.zigono.dmc.bot.ui.ConfirmationRegistry;
import ru.zigono.dmc.bot.ui.DiscordComponents;
import ru.zigono.dmc.bot.ui.ResultView;
import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.CommandShortcuts;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.Permission;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The execution pipeline of the console: capability check, target resolution, command normalization, alias
 * expansion, secure dispatch to the gateway and rendering of the real answer.
 * <p>The bot never authorizes a command on its own: the gateway validates permissions, policies, rate limits and
 * the emergency switch again. This pipeline decides what the user is allowed to see and to select, normalizes the
 * input so no injection can leave Discord, and reports exactly what the Minecraft servers answered.</p>
 *
 * @author Zigono
 */
public final class ExecutionPipeline {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExecutionPipeline.class);

    private final BotRuntime runtime;

    public ExecutionPipeline(BotRuntime runtime) {
        this.runtime = runtime;
    }

    /** A console request built from a slash command or from the interactive panel. */
    public record Request(TargetsView view, TargetOptions options, String command, boolean dryRun) {

        public static Request of(TargetsView view, TargetOptions options, String command, boolean dryRun) {
            return new Request(view, options, command, dryRun);
        }
    }

    /** Runs the whole pipeline and answers the interaction with the real result. */
    public void run(InteractionTarget target, Request request) {
        final UserContext user = target.user();
        try {
            final PermissionSet permissions = PermissionSet.of(user.permissions(), user.deniedPermissions());
            final TargetsView.Capabilities capabilities = request.view().capabilities();
            if (request.dryRun() ? !capabilities.dryRun() : !capabilities.execute()) {
                reject(target, user, ErrorCode.PERMISSION_DENIED, "нет права "
                        + (request.dryRun() ? Permission.DRY_RUN : Permission.EXECUTE) + " для "
                        + (request.dryRun() ? "пробного запуска" : "выполнения команд"));
                return;
            }
            final TargetSelection selection = TargetSelectionParser.parse(request.view(), request.options());
            final NormalizedCommand normalized = normalize(permissions, request.command());
            dispatch(target, user, selection, selection.describe(), normalized, request.dryRun(), false, null);
        } catch (CommandException e) {
            LOGGER.info("Запрос консоли от {} отклонён: {} ({})", user.userId(), e.code(), e.getMessage());
            auditFailure(user, null, e);
            target.send(runtime.embeds().error(e.code().name(), e.getMessage(), null, showRequestId()), List.of());
        } catch (RuntimeException e) {
            LOGGER.error("Запрос консоли от {} не удался", user.userId(), e);
            target.send(runtime.embeds().error(ErrorCode.INTERNAL_ERROR.name(), e.getMessage(), null, showRequestId()),
                    List.of());
        }
    }

    /**
     * Handles a confirmation click: only the initiator may confirm, the action is single use and the stored
     * command is re-validated before it is sent again.
     */
    public void confirm(InteractionTarget target, String nonce) {
        final ConfirmationRegistry.Claim claim = runtime.confirmations().claim(nonce, target.user().userId(), null);
        target.acknowledgeReply();
        switch (claim.result()) {
            case OK -> {
                target.editMessage(runtime.embeds().notice("embed.confirm.title", "embed.confirm.confirmed",
                        runtime.config().embeds().palette().success()), List.of());
                runConfirmed(target, claim.pending());
            }
            case FOREIGN_USER -> target.send(runtime.embeds().notice("embed.confirm.title", "embed.confirm.foreign_user",
                    runtime.config().embeds().palette().error()), List.of());
            case EXPIRED -> target.editMessage(runtime.embeds().notice("embed.confirm.title", "embed.confirm.expired",
                    runtime.config().embeds().palette().warning()), List.of());
            case COMMAND_MISMATCH -> target.editMessage(runtime.embeds().notice("embed.confirm.title",
                    "embed.confirm.mismatch", runtime.config().embeds().palette().error()), List.of());
            default -> target.send(runtime.embeds().notice("embed.confirm.title", "embed.confirm.unknown",
                    runtime.config().embeds().palette().warning()), List.of());
        }
    }

    /** Cancels a pending confirmation. Only the initiator may do that. */
    public void cancel(InteractionTarget target, String nonce) {
        final ConfirmationRegistry.Claim claim = runtime.confirmations().claim(nonce, target.user().userId(), null);
        target.acknowledgeReply();
        switch (claim.result()) {
            case OK, EXPIRED, UNKNOWN -> target.editMessage(runtime.embeds().notice("embed.confirm.title",
                    "embed.confirm.cancelled", runtime.config().embeds().palette().neutral()), List.of());
            default -> target.send(runtime.embeds().notice("embed.confirm.title", "embed.confirm.foreign_user",
                    runtime.config().embeds().palette().error()), List.of());
        }
    }

    private void runConfirmed(InteractionTarget target, ConfirmationRegistry.Pending pending) {
        final UserContext user = target.user();
        try {
            final NormalizedCommand normalized = runtime.config().normalizer().normalize(pending.command());
            if (!normalized.normalized().equals(pending.normalizedCommand())) {
                target.send(runtime.embeds().notice("embed.confirm.title", "embed.confirm.mismatch",
                        runtime.config().embeds().palette().error()), List.of());
                return;
            }
            dispatch(target, user, pending.target(), pending.targetDescription(), normalized, pending.dryRun(), true,
                    pending.confirmationId());
        } catch (CommandException e) {
            target.send(runtime.embeds().error(e.code().name(), e.getMessage(), null, showRequestId()), List.of());
        }
    }

    private void dispatch(InteractionTarget target, UserContext user, TargetSelection selection, String description,
                          NormalizedCommand normalized, boolean dryRun, boolean confirmed, String confirmationId) {
        final ControlMessages.ExecuteRequest request = new ControlMessages.ExecuteRequest();
        request.user = user;
        request.target = selection;
        request.command = normalized.normalized();
        request.normalizedCommand = normalized.normalized();
        request.requiredPermission = CommandPolicyEngine.qualified(normalized);
        request.dryRun = dryRun;
        request.confirmed = confirmed;
        request.confirmationId = confirmationId;
        request.issuedAt = System.currentTimeMillis();
        request.timeoutMillis = runtime.config().control().requestTimeout().toMillis();
        final ControlMessages.ExecuteResponse response = GatewayClient.join(runtime.gateway().execute(request),
                runtime.config().control().requestTimeout());
        handle(target, user, response, selection, description, normalized.normalized());
    }

    private void handle(InteractionTarget target, UserContext user, ControlMessages.ExecuteResponse response,
                        TargetSelection selection, String description, String normalizedCommand) {
        final String errorCode = response.errorCode == null || response.errorCode.isBlank() ? null : response.errorCode;
        if (errorCode != null) {
            if (ErrorCode.CONFIRMATION_REQUIRED.name().equals(errorCode) && confirmationPossible(response)) {
                requestConfirmation(target, user, response, selection, description, normalizedCommand);
                return;
            }
            LOGGER.info("Шлюз отклонил запрос консоли {}: {} ({})", response.getRequestId(), errorCode,
                    response.errorDetail);
            runtime.auditChannel().publish(AuditEntry.failure(response.getRequestId(), user, description,
                    normalizedCommand, errorCode, response.errorDetail));
            target.send(runtime.embeds().error(errorCode, response.errorDetail, response.getRequestId(), showRequestId()),
                    List.of());
            return;
        }
        final RenderedResponse rendered = runtime.renderer().render(response);
        runtime.auditChannel().publish(AuditEntry.of(response, user, rendered.text()));
        if (response.dryRun) {
            target.send(runtime.embeds().dryRun(ResultView.of(response, rendered), showRequestId()), List.of());
            return;
        }
        final MessageEmbed embed = runtime.embeds().result(ResultView.of(response, rendered), showRequestId());
        if (rendered.hasAttachment()) {
            target.sendAttachment(rendered.attachment(), rendered.attachmentName(), embed);
            return;
        }
        target.send(embed, List.of());
        for (String chunk : rendered.chunks()) {
            target.send(chunk);
        }
    }

    private boolean confirmationPossible(ControlMessages.ExecuteResponse response) {
        return runtime.config().confirmation().enabled()
                && response.confirmationId != null && !response.confirmationId.isBlank();
    }

    private void requestConfirmation(InteractionTarget target, UserContext user,
                                     ControlMessages.ExecuteResponse response, TargetSelection selection,
                                     String description, String normalizedCommand) {
        final ConfirmationRegistry.Pending pending = runtime.confirmations().register(
                new ConfirmationRegistry.Draft(user.userId(), user.username(), user.guildId(), user.channelId(),
                        description, selection, normalizedCommand, normalizedCommand, response.dryRun,
                        response.confirmationId));
        target.send(runtime.embeds().confirmation(pending),
                List.of(DiscordComponents.confirmationRow(runtime::messages, pending.nonce())));
    }

    private NormalizedCommand normalize(PermissionSet permissions, String rawCommand) {
        final CommandNormalizer normalizer = runtime.config().normalizer();
        final CommandShortcuts shortcuts = runtime.config().shortcuts();
        final NormalizedCommand parsed = normalizer.normalize(rawCommand);
        final String first = parsed.tokens().isEmpty() ? "" : parsed.tokens().get(0);
        final CommandShortcuts.Shortcut shortcut = shortcuts.alias(first)
                .or(() -> shortcuts.template(first))
                .orElse(null);
        if (shortcut == null) {
            return parsed;
        }
        if (!permissions.allows(shortcut.permission())) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED,
                    "нет права " + shortcut.permission() + " для " + shortcut.name());
        }
        final Map<String, String> values = new LinkedHashMap<>();
        int index = 1;
        for (String placeholder : shortcut.rules().keySet()) {
            values.put(placeholder, index < parsed.tokens().size() ? parsed.tokens().get(index) : null);
            index++;
        }
        return normalizer.normalize(shortcuts.render(shortcut, values));
    }

    private void reject(InteractionTarget target, UserContext user, ErrorCode code, String detail) {
        LOGGER.info("Запрос консоли от {} запрещён: {} ({})", user.userId(), code, detail);
        auditFailure(user, null, new CommandException(code, detail));
        target.send(runtime.embeds().error(code.name(), detail, null, showRequestId()), List.of());
    }

    private void auditFailure(UserContext user, String target, CommandException error) {
        runtime.auditChannel().publish(AuditEntry.failure(null, user, target, null, error.code().name(),
                error.getMessage()));
    }

    private boolean showRequestId() {
        return runtime.config().ui().showRequestId();
    }
}
