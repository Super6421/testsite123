package ru.zigono.dmc.bot.audit;

import ru.zigono.dmc.bot.staff.StaffService;

/**
 * Запись аудита выдачи или снятия привилегии: кто, кого, когда, по какой причине и с каким результатом.
 * Публикуется в тот же канал логов, что и аудит команд консоли.
 *
 * @author Zigono
 */
public record StaffAuditEntry(String requestId, long timestamp, String actorId, String actorName, String guildId,
                              String channelId, StaffService.Action action, String target, String rankName,
                              String group, String reason, boolean success, String errorCode, String errorDetail,
                              boolean changed) {

    public StaffAuditEntry {
        reason = reason == null ? "" : reason;
        errorCode = errorCode == null ? "" : errorCode;
        errorDetail = errorDetail == null ? "" : errorDetail;
    }

    /** @return запись об успешно применённой привилегии */
    public static StaffAuditEntry of(String requestId, StaffService.Request request, StaffService.Result result) {
        return new StaffAuditEntry(requestId, System.currentTimeMillis(), request.actorId(), request.actorName(),
                request.guildId(), request.channelId(), request.action(), result.target(), result.rankName(),
                result.group(), request.reason(), result.success(), null, null, result.changed());
    }

    /** @return запись об отказе: привилегию не тронули, но попытка должна быть видна в журнале */
    public static StaffAuditEntry denied(String requestId, StaffService.Request request, String errorCode,
                                         String errorDetail) {
        return new StaffAuditEntry(requestId, System.currentTimeMillis(), request.actorId(), request.actorName(),
                request.guildId(), request.channelId(), request.action(), request.target(), null, null,
                request.reason(), false, errorCode, errorDetail, false);
    }
}