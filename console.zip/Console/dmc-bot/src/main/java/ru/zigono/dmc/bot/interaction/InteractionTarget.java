package ru.zigono.dmc.bot.interaction;

import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.interactions.components.LayoutComponent;
import net.dv8tion.jda.api.interactions.modals.Modal;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.List;

/**
 * Transport independent view of a Discord interaction. It lets the execution pipeline answer a slash command,
 * a button, a select menu and a modal without knowing which one it is talking to.
 *
 * @author Zigono
 */
public interface InteractionTarget {

    /** Identity of the invoking user, as it is sent to the gateway. */
    UserContext user();

    /** @return {@code true} when the answer must only be visible to the invoking user */
    boolean ephemeral();

    /** Correlation id of the interaction, shown in errors and stored in the audit trail. */
    String interactionId();

    /** Acknowledges the interaction with a deferred reply. */
    void acknowledgeReply();

    /** Acknowledges the interaction by deferring the edit of the message the component belongs to. */
    void acknowledgeEdit();

    /** Sends a message through the interaction hook. */
    void send(MessageEmbed embed, List<LayoutComponent> components);

    void send(String content);

    /** Sends the output as a file attachment. */
    void sendAttachment(byte[] content, String fileName, MessageEmbed embed);

    /** Replaces the message that carried the invoked component. */
    void editMessage(MessageEmbed embed, List<LayoutComponent> components);

    /**
     * Answers the interaction with a modal. Discord only allows this before the interaction was acknowledged,
     * so it is used for components that ask the user for text instead of executing straight away.
     */
    void replyModal(Modal modal);

    /** Logs a failed Discord call; the user already got an answer, so nothing is retried blindly. */
    void logFailure(String what, Throwable error);
}
