package ru.zigono.dmc.bot;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.audit.AuditChannelState;
import ru.zigono.dmc.bot.audit.DiscordAuditChannel;
import ru.zigono.dmc.bot.command.BotListener;
import ru.zigono.dmc.bot.command.ExecutionPipeline;
import ru.zigono.dmc.bot.command.SlashCommands;
import ru.zigono.dmc.bot.config.BotBootstrap;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.bot.gateway.GatewayClient;
import ru.zigono.dmc.bot.gateway.TargetsViewCache;
import ru.zigono.dmc.bot.interaction.UserContextFactory;
import ru.zigono.dmc.bot.perm.PermissionFilter;
import ru.zigono.dmc.bot.render.ErrorTranslator;
import ru.zigono.dmc.bot.render.ResponseRenderer;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.bot.ui.ConfirmationRegistry;
import ru.zigono.dmc.bot.ui.EmbedFactory;
import ru.zigono.dmc.bot.ui.HistoryRegistry;
import ru.zigono.dmc.bot.ui.PanelRegistry;
import ru.zigono.dmc.common.config.ConfigWatcher;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.common.security.SecretRedactor;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Everything the bot owns at runtime: configuration, localization, the gateway control connection, the Discord
 * client, the interaction state and the hot reload. Components never reach into each other directly, they all go
 * through this holder, which makes a configuration reload safe for commands that are already running.
 *
 * @author Zigono
 */
public final class BotRuntime implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(BotRuntime.class);

    /** Файл рядом с конфигурацией: в нём команда {@code /logs channel} хранит выбранный канал. */
    private static final String AUDIT_STATE_FILE = "logs-channel.yml";

    private final Path configFile;
    private final StaffService staff;
    private final AuditChannelState auditState;
    private final ExecutorService executor;
    private final ScheduledExecutorService maintenance;
    private final EmbedFactory embeds;
    private final ErrorTranslator errors;
    private final ConfirmationRegistry confirmations;
    private final PanelRegistry panels;
    private final HistoryRegistry histories;
    private final UserContextFactory users;
    private final DiscordAuditChannel auditChannel;
    private final ExecutionPipeline pipeline;
    private final AtomicBoolean closed = new AtomicBoolean();
    private final AtomicBoolean started = new AtomicBoolean();

    private volatile BotConfig config;
    private volatile Messages messages;
    private volatile PermissionFilter permissionFilter;
    private volatile ResponseRenderer renderer;
    private volatile SlashCommands.CommandNames commandNames;
    private volatile GatewayClient gateway;
    private volatile TargetsViewCache views;
    private volatile JDA jda;
    private volatile SecretRedactor redactor;
    private ConfigWatcher watcher;

    public BotRuntime(Path configFile) {
        this(configFile, null);
    }

    /**
     * @param configFile конфигурация бота
     * @param staff      реализация выдачи привилегий, которую передаёт плагин; {@code null} вне встроенного режима
     */
    public BotRuntime(Path configFile, StaffService staff) {
        this.staff = staff;
        this.configFile = configFile.toAbsolutePath();
        this.config = BotConfig.load(this.configFile);
        this.messages = Messages.load(config.language(), config.languageDirectory(),
                BotBootstrap.LANGUAGE_RESOURCE_DIRECTORY);
        this.permissionFilter = filter(config);
        this.renderer = new ResponseRenderer(config.responses(), this::messages);
        this.embeds = new EmbedFactory(this::messages, () -> config.embeds(),
                () -> config.ui().showDiagnostics());
        this.errors = new ErrorTranslator(this::messages);
        this.confirmations = new ConfirmationRegistry(config.confirmation().timeout(), config.confirmation().maxPending());
        this.panels = new PanelRegistry(config.ui().panelTimeout(), 500);
        this.histories = new HistoryRegistry(config.ui().panelTimeout(), 500);
        this.users = new UserContextFactory(() -> config);
        final BotConfig.AuditSettings audit = this.config.audit();
        this.auditState = AuditChannelState.load(this.config.baseDirectory().resolve(AUDIT_STATE_FILE),
                audit.enabled(), audit.channelId());
        this.auditChannel = new DiscordAuditChannel(() -> config, () -> jda, embeds, auditState);
        this.commandNames = SlashCommands.CommandNames.of(this.config.staff());
        this.redactor = SecretRedactor.of(config.secretValues());
        this.executor = Executors.newVirtualThreadPerTaskExecutor();
        this.maintenance = Executors.newSingleThreadScheduledExecutor(runnable -> {
            final Thread thread = new Thread(runnable, "dmc-bot-maintenance");
            thread.setDaemon(true);
            return thread;
        });
        this.pipeline = new ExecutionPipeline(this);
    }

    /** Starts the gateway connection, the Discord client and the configuration watcher. */
    public void start() {
        if (!started.compareAndSet(false, true)) {
            return;
        }
        LOGGER.info("{}", BotBuild.describe());
        LOGGER.info("Конфигурация: {} (ревизия {})", configFile, config.revision());
        startGateway();
        startDiscord();
        startWatcher();
        maintenance.scheduleWithFixedDelay(this::purgeInteractionState, 60L, 60L, TimeUnit.SECONDS);
    }

    private void startGateway() {
        final GatewayClient client = createGateway(config);
        this.gateway = client;
        this.views = new TargetsViewCache(client, config.control().requestTimeout(), config.ui().viewCacheTtl());
        client.start();
        if (client.awaitAuthentication()) {
            LOGGER.info("Шлюз {} принял управляющего клиента '{}'", client.gatewayId().orElse("неизвестно"),
                    config.control().clientId());
        } else {
            LOGGER.warn("Шлюз не принял управляющего клиента '{}' за {}; пока шлюз недоступен, команды будут сообщать о "
                    + "реальной ошибке соединения (последняя ошибка: {})",
                    config.control().clientId(), config.control().readyTimeout(),
                    client.lastError().orElse("нет"));
        }
    }

    private GatewayClient createGateway(BotConfig current) {
        final TransportSettings transport = current.transport();
        return new GatewayClient(transport, current.controlSecret(), current.control().requestTimeout(),
                current.control().handshakeTimeout(), current.control().readyTimeout());
    }

    private void startDiscord() {
        final JDABuilder builder = JDABuilder.createDefault(config.discord().token());
        builder.setStatus(OnlineStatus.valueOf(config.discord().status()));
        builder.setActivity(Activity.playing(config.discord().activity()));
        builder.enableIntents(GatewayIntent.GUILD_EXPRESSIONS);
        builder.addEventListeners(new BotListener(this));
        this.jda = builder.build();
        awaitDiscordReady();
        LOGGER.info("Discord-клиент готов: {}", jda.getSelfUser().getAsTag());
        registerCommands();
    }

    /**
     * Waits for the Discord client and fails fast when the login is rejected. Waiting without a deadline would
     * keep the process alive forever in front of a wrong token, which hides the real reason from the operator.
     */
    private void awaitDiscordReady() {
        final JDA api = jda;
        final Duration timeout = config.discord().readyTimeout();
        final long deadline = System.nanoTime() + timeout.toNanos();
        while (true) {
            final JDA.Status status = api.getStatus();
            if (status == JDA.Status.CONNECTED) {
                return;
            }
            if (status == JDA.Status.FAILED_TO_LOGIN || status == JDA.Status.SHUTTING_DOWN
                    || status == JDA.Status.SHUTDOWN) {
                throw new IllegalStateException("Discord-клиент не смог подключиться, статус " + status
                        + "; проверьте discord.token и настройки бота в Discord Developer Portal");
            }
            if (System.nanoTime() >= deadline) {
                throw new IllegalStateException("Discord-клиент не стал готов за " + timeout
                        + ", статус " + status);
            }
            try {
                Thread.sleep(50L);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Запуск Discord-клиента был прерван", e);
            }
        }
    }

    /** Registers the slash commands globally, or per configured guild when guild scoped registration is on. */
    public void registerCommands() {
        final JDA api = jda;
        if (api == null) {
            return;
        }
        final List<CommandData> commands = new ArrayList<>(SlashCommands.definitions(messages, config, commandNames));
        if (config.discord().guildScopedCommands()) {
            for (String guildId : config.discord().guildIds()) {
                final Guild guild = api.getGuildById(guildId);
                if (guild == null) {
                    LOGGER.warn("Настроенная гильдия {} недоступна боту, её команды не зарегистрированы",
                            guildId);
                    continue;
                }
                guild.updateCommands().addCommands(commands).queue(
                        updated -> LOGGER.info("Зарегистрировано команд гильдии: {} (гильдия {})", updated.size(), guildId),
                        error -> LOGGER.error("Не удалось зарегистрировать команды в гильдии {}: {}", guildId, error.getMessage()));
            }
            return;
        }
        api.updateCommands().addCommands(commands).queue(
                updated -> LOGGER.info("Зарегистрировано глобальных команд: {}", updated.size()),
                error -> LOGGER.error("Не удалось зарегистрировать глобальные команды: {}", error.getMessage()));
    }

    private void startWatcher() {
        final List<Path> files = new ArrayList<>();
        config.file().ifPresent(files::add);
        files.add(config.languageDirectory().resolve("ru.yml"));
        files.add(config.languageDirectory().resolve("en.yml"));
        final ConfigWatcher created = new ConfigWatcher(files, Duration.ofSeconds(2), this::onConfigurationChanged);
        created.start();
        this.watcher = created;
    }

    private void onConfigurationChanged(Path changed) {
        LOGGER.info("Обнаружено изменение конфигурации {}, перезагружаю конфигурацию бота", changed);
        try {
            reload();
        } catch (RuntimeException e) {
            LOGGER.error("Горячая перезагрузка не удалась, продолжает действовать прежняя конфигурация: {}", e.getMessage());
        }
    }

    /**
     * Reloads the configuration, the language files and the command definitions. Interaction state of commands
     * that are already running is preserved.
     */
    public synchronized void reload() {
        final BotConfig fresh = BotConfig.load(configFile);
        final Messages localized = Messages.load(fresh.language(), fresh.languageDirectory(),
                BotBootstrap.LANGUAGE_RESOURCE_DIRECTORY);
        this.config = fresh;
        this.messages = localized;
        this.permissionFilter = filter(fresh);
        this.renderer = new ResponseRenderer(fresh.responses(), this::messages);
        this.redactor = SecretRedactor.of(fresh.secretValues());
        this.commandNames = SlashCommands.CommandNames.of(fresh.staff());
        final GatewayClient current = gateway;
        if (current == null || !current.settings().equals(fresh.transport())) {
            LOGGER.info("Настройки транспорта изменились, переподключаю канал управления");
            if (current != null) {
                current.close();
            }
            final GatewayClient recreated = createGateway(fresh);
            this.gateway = recreated;
            this.views = new TargetsViewCache(recreated, fresh.control().requestTimeout(), fresh.ui().viewCacheTtl());
            recreated.start();
        }
        registerCommands();
    }

    private void purgeInteractionState() {
        try {
            final int expired = confirmations.purgeExpired() + panels.purgeExpired() + histories.purgeExpired();
            if (expired > 0) {
                LOGGER.debug("Удалено устаревших состояний взаимодействий: {}", expired);
            }
        } catch (RuntimeException e) {
            LOGGER.warn("Не удалось очистить состояния взаимодействий: {}", e.getMessage());
        }
    }

    private static PermissionFilter filter(BotConfig current) {
        return PermissionFilter.of(current.channels(), current.discord().guildIds(), false);
    }

    public BotConfig config() {
        return config;
    }

    public Messages messages() {
        return messages;
    }

    public PermissionFilter permissions() {
        return permissionFilter;
    }

    public ResponseRenderer renderer() {
        return renderer;
    }

    public EmbedFactory embeds() {
        return embeds;
    }

    public ErrorTranslator errors() {
        return errors;
    }

    public GatewayClient gateway() {
        return gateway;
    }

    public TargetsViewCache views() {
        return views;
    }

    public ConfirmationRegistry confirmations() {
        return confirmations;
    }

    public PanelRegistry panels() {
        return panels;
    }

    public HistoryRegistry histories() {
        return histories;
    }

    public UserContextFactory users() {
        return users;
    }

    public DiscordAuditChannel auditChannel() {
        return auditChannel;
    }

    /** @return реализация выдачи привилегий, {@code null} когда привилегии выдавать нечем */
    public StaffService staff() {
        return staff;
    }

    /** @return привилегии и иерархия выдачи из конфигурации бота */
    public StaffConfig staffConfig() {
        return config.staff();
    }

    /** @return имена слэш-команд персонала, приведённые к требованиям Discord */
    public SlashCommands.CommandNames commandNames() {
        return commandNames;
    }

    public ExecutionPipeline pipeline() {
        return pipeline;
    }

    public ExecutorService executor() {
        return executor;
    }

    public SecretRedactor redactor() {
        return redactor;
    }

    public java.util.Optional<JDA> jda() {
        return java.util.Optional.ofNullable(jda);
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        LOGGER.info("Останавливаю Discord-бота");
        final ConfigWatcher currentWatcher = watcher;
        if (currentWatcher != null) {
            currentWatcher.close();
        }
        maintenance.shutdownNow();
        final JDA api = jda;
        if (api != null) {
            api.shutdown();
        }
        final GatewayClient client = gateway;
        if (client != null) {
            client.close();
        }
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
        LOGGER.info("Discord-бот остановлен");
    }
}
