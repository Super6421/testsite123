package ru.zigono.dmc.bot.ui;

import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.dto.TargetSelection;

import java.time.Clock;
import java.time.Duration;
import java.util.Optional;

/**
 * State of the interactive console panel. The panel keeps the target the user selected so the command modal can
 * be opened and submitted without ever trusting the client for the target itself.
 *
 * @author Zigono
 */
public final class PanelRegistry {

    /** Selection stored for one panel. */
    public record Panel(String nonce, String userId, String guildId, String channelId, TargetSelection target,
                        String targetDescription, long createdAt, long expiresAt) {
    }

    private final ExpiringStore<Panel> store;

    public PanelRegistry(Duration ttl, int maxEntries) {
        this(ttl, maxEntries, Clock.systemUTC());
    }

    public PanelRegistry(Duration ttl, int maxEntries, Clock clock) {
        this.store = new ExpiringStore<>(clock, ttl, maxEntries, Panel::expiresAt);
    }

    public Panel register(String userId, String guildId, String channelId, TargetSelection target,
                          String targetDescription) {
        final String nonce = Ids.nonce(16);
        final long createdAt = store.now();
        final Panel panel = new Panel(nonce, userId, guildId, channelId, target, targetDescription, createdAt,
                store.expiresAt(createdAt));
        store.put(nonce, panel);
        return panel;
    }

    /**
     * @return the panel when it exists, has not expired and belongs to the invoking user
     */
    public Optional<Panel> find(String nonce, String userId) {
        return store.get(nonce).filter(panel -> panel.userId().equals(userId));
    }

    public Optional<Panel> peek(String nonce) {
        return store.peek(nonce);
    }

    public void remove(String nonce) {
        store.remove(nonce);
    }

    public int size() {
        return store.size();
    }

    public int purgeExpired() {
        return store.purgeExpired();
    }

    public void clear() {
        store.clear();
    }
}
