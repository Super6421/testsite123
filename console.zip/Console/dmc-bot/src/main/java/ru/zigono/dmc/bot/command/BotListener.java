package ru.zigono.dmc.bot.command;

import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.CommandAutoCompleteInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.GenericComponentInteractionCreateEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.BotRuntime;
import ru.zigono.dmc.bot.interaction.InteractionTarget;
import ru.zigono.dmc.bot.interaction.JdaInteractions;
import ru.zigono.dmc.bot.perm.PermissionFilter;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.bot.target.TargetOptions;
import ru.zigono.dmc.bot.ui.CustomId;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.List;
import java.util.Optional;

/**
 * Bridges the Discord events to the console flows. The listener itself contains no authorization logic: it builds
 * the identity, checks that the interaction comes from an allowed guild and channel, and hands the work to
 * {@link ConsoleFlow} and {@link ExecutionPipeline}, which ask the gateway for the authoritative answer.
 * <p>Every handler runs on a virtual thread, so a slow gateway never blocks the Discord event loop.</p>
 *
 * @author Zigono
 */
public final class BotListener extends ListenerAdapter {

    private static final Logger LOGGER = LoggerFactory.getLogger(BotListener.class);

    private final BotRuntime runtime;
    private final ConsoleFlow flow;
    /** Каналы, про отказ в которых уже написано в консоль: повторные попытки не засоряют лог. */
    private final java.util.Set<String> reportedDenials = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public BotListener(BotRuntime runtime) {
        this.runtime = runtime;
        this.flow = new ConsoleFlow(runtime);
    }

    @Override
    public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event) {
        final UserContext user = user(event);
        if (!allowed(event, user)) {
            return;
        }
        final InteractionTarget target = JdaInteractions.of(event, user, runtime.config().ui().ephemeral());
        final String name = event.getName();
        runtime.executor().execute(() -> {
            // Имена команд персонала задаются конфигурацией, поэтому сравниваются со значениями, а не в switch.
            final SlashCommands.CommandNames names = runtime.commandNames();
            if (name.equals(names.grant())) {
                staff(target, event, StaffService.Action.GRANT);
                return;
            }
            if (name.equals(names.remove())) {
                staff(target, event, StaffService.Action.REMOVE);
                return;
            }
            switch (name) {
                case SlashCommands.CONSOLE -> flow.console(target, targetOptions(event), option(event,
                        SlashCommands.OPTION_COMMAND), option(event, SlashCommands.OPTION_DRYRUN) != null
                        && Boolean.parseBoolean(option(event, SlashCommands.OPTION_DRYRUN)));
                case SlashCommands.HISTORY -> flow.history(target, option(event, SlashCommands.OPTION_SERVER),
                        option(event, SlashCommands.OPTION_USER), option(event, SlashCommands.OPTION_COMMAND),
                        option(event, SlashCommands.OPTION_STATUS), limit(event));
                case SlashCommands.SERVERS -> flow.servers(target);
                case SlashCommands.ADMIN -> admin(target, event);
                case SlashCommands.LOGS -> logs(target, event);
                default -> {
                    target.acknowledgeReply();
                    target.send(runtime.messages().format("command.unknown", name));
                }
            }
        });
    }

    @Override
    public void onCommandAutoCompleteInteraction(@NotNull CommandAutoCompleteInteractionEvent event) {
        final UserContext user = user(event);
        if (!allowed(event, user)) {
            event.replyChoices(List.of()).queue();
            return;
        }
        final String option = event.getFocusedOption().getName();
        final String typed = event.getFocusedOption().getValue();
        runtime.executor().execute(() -> event.replyChoices(flow.autocompleteChoices(user, option, typed))
                .queue(success -> { },
                        error -> LOGGER.debug("Не удалось ответить на автодополнение: {}", error.getMessage())));
    }

    @Override
    public void onGenericComponentInteractionCreate(@NotNull GenericComponentInteractionCreateEvent event) {
        final UserContext user = user(event);
        if (!allowed(event, user)) {
            return;
        }
        final Optional<CustomId.Parsed> parsed = CustomId.parse(event.getComponentId());
        if (parsed.isEmpty()) {
            return;
        }
        final InteractionTarget target = JdaInteractions.of(event, user, runtime.config().ui().ephemeral());
        final CustomId.Parsed id = parsed.get();
        runtime.executor().execute(() -> {
            switch (id.action()) {
                case CustomId.ACTION_CONFIRM -> flow.confirmation(target, id.nonce(), true);
                case CustomId.ACTION_CANCEL -> flow.confirmation(target, id.nonce(), false);
                case CustomId.ACTION_HISTORY -> flow.historyPage(target, id.nonce(), id.offset());
                case CustomId.ACTION_PANEL_TARGET -> flow.selectTarget(target, id.nonce(),
                        event instanceof net.dv8tion.jda.api.events.interaction.component.StringSelectInteractionEvent select
                                ? select.getValues() : List.of());
                case CustomId.ACTION_PANEL_EXECUTE -> flow.openCommandModal(target, id.nonce());
                case CustomId.ACTION_PANEL_MODAL -> target.acknowledgeReply();
                default -> LOGGER.debug("Пропускаю неизвестное действие компонента {}", id.action());
            }
        });
    }

    @Override
    public void onModalInteraction(@NotNull ModalInteractionEvent event) {
        final UserContext user = user(event);
        if (!allowed(event, user)) {
            return;
        }
        final Optional<CustomId.Parsed> parsed = CustomId.parse(event.getModalId());
        if (parsed.isEmpty() || !CustomId.ACTION_PANEL_MODAL.equals(parsed.get().action())) {
            return;
        }
        final String command = event.getValue("command") == null ? null : event.getValue("command").getAsString();
        final InteractionTarget target = JdaInteractions.of(event, user, runtime.config().ui().ephemeral());
        final String nonce = parsed.get().nonce();
        runtime.executor().execute(() -> flow.submitCommand(target, nonce, command));
    }

    /** {@code /logs channel}: выбранный канал становится каналом журнала, повторный вызов его выключает. */
    private void logs(InteractionTarget target, SlashCommandInteractionEvent event) {
        if (!SlashCommands.SUBCOMMAND_CHANNEL.equals(event.getSubcommandName())) {
            target.acknowledgeReply();
            target.send(runtime.messages().format("command.unknown", event.getName()));
            return;
        }
        final OptionMapping mapping = event.getOption(SlashCommands.OPTION_CHANNEL);
        final String channelId = mapping == null || mapping.getAsChannel() == null
                ? null : mapping.getAsChannel().getId();
        flow.logs(target, channelId);
    }

    /** {@code /персонал-выдать} и {@code /персонал-снять}: ник, привилегия и причина. */
    private void staff(InteractionTarget target, SlashCommandInteractionEvent event, StaffService.Action action) {
        flow.staff(target, action, option(event, SlashCommands.OPTION_NICK), option(event, SlashCommands.OPTION_RANK),
                option(event, SlashCommands.OPTION_REASON));
    }

    private void admin(InteractionTarget target, SlashCommandInteractionEvent event) {
        final String subcommand = event.getSubcommandName();
        if (SlashCommands.SUBCOMMAND_RELOAD.equals(subcommand)) {
            flow.reload(target);
            return;
        }
        if (SlashCommands.SUBCOMMAND_EMERGENCY.equals(subcommand)) {
            final String state = option(event, SlashCommands.OPTION_STATE);
            flow.emergency(target, SlashCommands.STATE_ON.equalsIgnoreCase(state));
            return;
        }
        target.acknowledgeReply();
        target.send(runtime.embeds().error(ru.zigono.dmc.common.errors.ErrorCode.INVALID_COMMAND.name(),
                "неизвестная подкоманда " + subcommand, null, runtime.config().ui().showRequestId()), List.of());
    }

    private TargetOptions targetOptions(SlashCommandInteractionEvent event) {
        final String server = option(event, SlashCommands.OPTION_SERVER);
        final String servers = option(event, SlashCommands.OPTION_SERVERS);
        final String group = option(event, SlashCommands.OPTION_GROUP);
        if (server != null && !server.isBlank()) {
            return TargetOptions.ofServer(server);
        }
        if (servers != null && !servers.isBlank()) {
            return TargetOptions.ofServers(servers);
        }
        if (group != null && !group.isBlank()) {
            return TargetOptions.ofGroup(group);
        }
        return TargetOptions.NONE;
    }

    private int limit(SlashCommandInteractionEvent event) {
        final OptionMapping mapping = event.getOption(SlashCommands.OPTION_LIMIT);
        return mapping == null ? runtime.config().ui().historyPageSize() : mapping.getAsInt();
    }

    private static String option(SlashCommandInteractionEvent event, String name) {
        final OptionMapping mapping = event.getOption(name);
        return mapping == null ? null : mapping.getAsString();
    }

    private UserContext user(net.dv8tion.jda.api.events.interaction.GenericInteractionCreateEvent event) {
        final String messageId = event instanceof GenericComponentInteractionCreateEvent component
                ? component.getMessageId() : null;
        return runtime.users().create(event, messageId);
    }

    /**
     * @return {@code true} when the interaction comes from an allowed guild and channel; otherwise the user is
     * told why and nothing else happens
     */
    private boolean allowed(net.dv8tion.jda.api.events.interaction.GenericInteractionCreateEvent event,
                            UserContext user) {
        final PermissionFilter.GuildCheck check = runtime.permissions().check(event.isFromGuild(), user.guildId(),
                user.channelId());
        if (!check.denied()) {
            return true;
        }
        reportDenial(user, check);
        // Автодополнение не может ответить сообщением: ему нужно отдать пустой список вариантов, иначе JDA
        // записывает непойманное исключение в консоль на каждое нажатие клавиши.
        if (event instanceof CommandAutoCompleteInteractionEvent autocomplete) {
            autocomplete.replyChoices(List.of()).queue(reply -> { },
                    error -> LOGGER.debug("Не удалось отклонить автодополнение: {}", error.getMessage()));
            return false;
        }
        final InteractionTarget target = JdaInteractions.of(event, user, true);
        target.acknowledgeReply();
        target.send(runtime.embeds().error(check.error().name(), runtime.messages().formatOrDefault(check.messageKey(),
                check.detail()), null, runtime.config().ui().showRequestId()), List.of());
        return false;
    }

    /**
     * Пишет в консоль одну строку на канал: пользователь, который по ошибке пишет команды не в тот канал,
     * не должен превращать журнал сервера в спам. Отказ всё равно виден в Discord.
     */
    private void reportDenial(UserContext user, PermissionFilter.GuildCheck check) {
        LOGGER.debug("Отклоняю взаимодействие от {} из канала {}: {}", user.userId(), user.channelId(),
                check.detail());
        if (reportedDenials.add(user.channelId() + "|" + check.error())) {
            LOGGER.info("Команды консоли отклонены: {}. Пользователь {} — дальнейшие попытки в этом канале "
                    + "будут только в debug-журнале.", check.detail(), user.userId());
        }
    }
}