package ru.zigono.dmc.bot.ui;

import ru.zigono.dmc.common.util.Ids;

import java.time.Clock;
import java.time.Duration;
import java.util.Optional;

/**
 * Query of a paginated history view. Pagination buttons only carry a nonce, so the filter itself can never be
 * tampered with by the client and the invoking user is always the only one able to browse the result.
 *
 * @author Zigono
 */
public final class HistoryRegistry {

    /** Stored history filter. */
    public record Query(String nonce, String userId, String guildId, String channelId, String serverId,
                        String username, String commandFragment, String status, int limit, long createdAt,
                        long expiresAt) {
    }

    private final ExpiringStore<Query> store;

    public HistoryRegistry(Duration ttl, int maxEntries) {
        this(ttl, maxEntries, Clock.systemUTC());
    }

    public HistoryRegistry(Duration ttl, int maxEntries, Clock clock) {
        this.store = new ExpiringStore<>(clock, ttl, maxEntries, Query::expiresAt);
    }

    public Query register(String userId, String guildId, String channelId, String serverId, String username,
                          String commandFragment, String status, int limit) {
        final String nonce = Ids.nonce(16);
        final long createdAt = store.now();
        final Query query = new Query(nonce, userId, guildId, channelId, serverId, username, commandFragment,
                status, limit, createdAt, store.expiresAt(createdAt));
        store.put(nonce, query);
        return query;
    }

    public Optional<Query> find(String nonce, String userId) {
        return store.get(nonce).filter(query -> query.userId().equals(userId));
    }

    public void remove(String nonce) {
        store.remove(nonce);
    }

    public int size() {
        return store.size();
    }

    public int purgeExpired() {
        return store.purgeExpired();
    }

    public void clear() {
        store.clear();
    }
}
