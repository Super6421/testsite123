package ru.zigono.dmc.bot.command;

import net.dv8tion.jda.api.interactions.commands.Command;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.BotRuntime;
import ru.zigono.dmc.bot.audit.AuditChannelState;
import ru.zigono.dmc.bot.audit.StaffAuditEntry;
import ru.zigono.dmc.bot.gateway.GatewayClient;
import ru.zigono.dmc.bot.interaction.InteractionTarget;
import ru.zigono.dmc.bot.perm.BotPermissions;
import ru.zigono.dmc.bot.perm.PermissionFilter;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.bot.target.TargetOptions;
import ru.zigono.dmc.bot.target.TargetSelectionParser;
import ru.zigono.dmc.bot.target.TargetValue;
import ru.zigono.dmc.bot.ui.DiscordComponents;
import ru.zigono.dmc.bot.ui.HistoryRegistry;
import ru.zigono.dmc.bot.ui.PanelRegistry;
import ru.zigono.dmc.common.command.CommandShortcuts;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.common.text.Text;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The user facing console flows behind the slash commands and the interactive panel. Nothing here decides what a
 * user may do: the flows ask the gateway for the permission aware view, send the request and show the answer. The
 * gateway validates permissions, policies, rate limits and the emergency switch again for every single command.
 *
 * @author Zigono
 */
public final class ConsoleFlow {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConsoleFlow.class);

    private final BotRuntime runtime;

    public ConsoleFlow(BotRuntime runtime) {
        this.runtime = runtime;
    }

    /** {@code /console}: with a command it executes it, without one it opens the interactive panel. */
    public void console(InteractionTarget target, TargetOptions options, String command, boolean dryRun) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final TargetsView view = runtime.views().get(user);
            if (command == null || command.isBlank()) {
                openPanel(target, view, options);
                return;
            }
            runtime.pipeline().run(target, ExecutionPipeline.Request.of(view, options, command, dryRun));
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** {@code /servers}: the status of every server the user may see. */
    public void servers(InteractionTarget target) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final TargetsView view = runtime.views().get(user);
            requireCapability(view.capabilities().status() || view.capabilities().read(), "console.status");
            final ControlMessages.StatusResponse response =
                    GatewayClient.join(runtime.gateway().status(user, List.of()), timeout());
            target.send(runtime.embeds().servers(response), List.of());
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** {@code /console-history}: the first page of the stored audit trail. */
    public void history(InteractionTarget target, String serverId, String username, String commandFragment,
                        String status, int limit) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final TargetsView view = runtime.views().get(user);
            requireCapability(view.capabilities().history(), "console.history");
            final HistoryRegistry.Query query = runtime.histories().register(user.userId(), user.guildId(),
                    user.channelId(), serverId, username, commandFragment, status,
                    limit <= 0 ? runtime.config().ui().historyPageSize() : limit);
            showHistory(target, user, query, 0);
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** {@code /dmc reload}: asks the gateway to reload its configuration. */
    public void reload(InteractionTarget target) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final TargetsView view = runtime.views().get(user);
            requireCapability(view.capabilities().reload(), "console.admin.reload");
            final ControlMessages.ReloadResponse response =
                    GatewayClient.join(runtime.gateway().reload(user), timeout());
            target.send(runtime.embeds().notice("embed.reload.title",
                    response.errorDetail == null || response.errorDetail.isBlank()
                            ? "embed.reload.done" : "embed.reload.failed",
                    runtime.config().embeds().palette().success()), List.of());
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** {@code /dmc emergency}: toggles the kill switch. */
    public void emergency(InteractionTarget target, boolean enabled) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final TargetsView view = runtime.views().get(user);
            requireCapability(view.capabilities().emergency(), "console.emergency.*");
            final ControlMessages.EmergencyResponse response =
                    GatewayClient.join(runtime.gateway().emergency(user, enabled), timeout());
            final boolean failed = response.errorDetail != null && !response.errorDetail.isBlank();
            target.send(runtime.embeds().notice("embed.emergency.title",
                            failed ? "embed.emergency.failed"
                                    : response.emergencyMode ? "embed.emergency.enabled" : "embed.emergency.disabled",
                            failed ? runtime.config().embeds().palette().error()
                                    : response.emergencyMode ? runtime.config().embeds().palette().warning()
                                    : runtime.config().embeds().palette().success()),
                    List.of());
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /**
     * A selection in the target menu of the panel. The value is re-validated against the permission aware view and
     * stored under a fresh nonce, so a forged component value can never address a forbidden server.
     */
    public void selectTarget(InteractionTarget target, String nonce, List<String> values) {
        target.acknowledgeEdit();
        final UserContext user = target.user();
        try {
            final PanelRegistry.Panel panel = runtime.panels().find(nonce, user.userId()).orElseThrow(
                    () -> new CommandException(ErrorCode.INVALID_TARGET, "панель устарела, выполните /console снова"));
            final TargetsView view = runtime.views().get(user);
            final String value = values == null || values.isEmpty() ? null : values.get(0);
            final TargetSelection selection = TargetValue.toSelection(view, value);
            runtime.panels().remove(panel.nonce());
            final PanelRegistry.Panel updated = runtime.panels().register(user.userId(), user.guildId(),
                    user.channelId(), selection, selection.describe());
            target.editMessage(runtime.embeds().panel(view, selection.describe(),
                            TargetSelectionParser.accessibleServers(view).size()),
                    panelRows(updated.nonce(), view));
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** The execute button of the panel: the command itself is asked for in a modal. */
    public void openCommandModal(InteractionTarget target, String nonce) {
        final UserContext user = target.user();
        final PanelRegistry.Panel panel = runtime.panels().find(nonce, user.userId()).orElse(null);
        if (panel == null) {
            target.acknowledgeReply();
            target.send(runtime.embeds().notice("embed.panel.title", "embed.panel.expired",
                    runtime.config().embeds().palette().warning()), List.of());
            return;
        }
        target.replyModal(DiscordComponents.commandModal(runtime::messages, panel.nonce(),
                runtime.config().normalizer().maxLength()));
    }

    /** The modal submission of the panel: the command runs against the target the panel holds. */
    public void submitCommand(InteractionTarget target, String nonce, String command) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final PanelRegistry.Panel panel = runtime.panels().find(nonce, user.userId()).orElseThrow(
                    () -> new CommandException(ErrorCode.INVALID_TARGET, "панель устарела, выполните /console снова"));
            final TargetsView view = runtime.views().get(user);
            runtime.pipeline().run(target, ExecutionPipeline.Request.of(view, optionsOf(panel.target()), command,
                    false));
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** A confirmation or cancellation button. Only the initiator may use it; the gateway checks the token again. */
    public void confirmation(InteractionTarget target, String nonce, boolean confirmed) {
        if (confirmed) {
            runtime.pipeline().confirm(target, nonce);
        } else {
            runtime.pipeline().cancel(target, nonce);
        }
    }

    /** A page button of the history view. */
    public void historyPage(InteractionTarget target, String nonce, int offset) {
        target.acknowledgeEdit();
        final UserContext user = target.user();
        try {
            final HistoryRegistry.Query query = runtime.histories().find(nonce, user.userId()).orElseThrow(
                    () -> new CommandException(ErrorCode.INVALID_COMMAND, "представление истории устарело, выполните /console-history снова"));
            showHistory(target, user, query, Math.max(0, offset));
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /**
     * {@code /персонал-выдать} и {@code /персонал-снять}: привилегия выдаётся или снимается в LuckPerms.
     * <p>Иерархию проверяют двое: этот метод — чтобы автор команды сразу получил понятный ответ, и плагин —
     * потому что LuckPerms и его конфигурация есть только у него, и его решение остаётся решающим.</p>
     * <p>Каждая попытка попадает в журнал: и удачная, и отклонённая ролью, и неудачная из-за LuckPerms.</p>
     */
    public void staff(InteractionTarget target, StaffService.Action action, String nickname, String rankKey,
                      String reason) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final StaffService service = runtime.staff();
            if (service == null || !service.available()) {
                staffProblem(target, service == null
                        ? runtime.messages().format("staff.unavailable.embedded")
                        : runtime.messages().format("staff.unavailable.reason", service.unavailableReason()));
                return;
            }
            final StaffConfig staff = runtime.staffConfig();
            final String nick = nickname == null ? "" : nickname.trim();
            if (!validNickname(nick)) {
                staffProblem(target, runtime.messages().format("staff.invalid_nick"));
                return;
            }
            final String explanation = reason == null ? "" : reason.trim();
            if (explanation.isEmpty()) {
                staffProblem(target, runtime.messages().format("staff.reason_required"));
                return;
            }
            final StaffConfig.Rank rank = staff.rank(rankKey).orElse(null);
            if (rank == null) {
                staffProblem(target, runtime.messages().format("staff.unknown_rank",
                        Text.sanitizeForDiscord(rankKey == null ? "" : rankKey), staff.rankKeys()));
                return;
            }
            final StaffService.Request request = new StaffService.Request(action, nick, rank.key(), explanation,
                    user.roleIds(), user.userId(), user.username(), user.guildId(), user.channelId());
            if (!staff.allows(user.roleIds(), rank.key())) {
                final List<String> allowed = staff.allowedRanks(user.roleIds()).stream()
                        .map(StaffConfig.Rank::display).toList();
                runtime.auditChannel().publishStaff(StaffAuditEntry.denied(target.interactionId(), request,
                        ErrorCode.PERMISSION_DENIED.name(), "роль автора команды не указана в staff.access"));
                staffProblem(target, runtime.messages().format("staff.not_allowed", rank.display(),
                        allowed.isEmpty() ? runtime.messages().raw("staff.not_allowed_none")
                                : String.join(", ", allowed)));
                return;
            }
            final StaffService.Result result = service.apply(request);
            runtime.auditChannel().publishStaff(StaffAuditEntry.of(target.interactionId(), request, result));
            target.send(runtime.embeds().staffResult(request, result, rank), List.of());
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /**
     * {@code /logs channel}: выбранный канал становится каналом журнала. Повторная команда с тем же каналом
     * выключает журнал, другой канал — переводит его туда. Состояние хранится в файле рядом с конфигурацией,
     * поэтому выбор переживает перезапуск сервера.
     */
    public void logs(InteractionTarget target, String channelId) {
        target.acknowledgeReply();
        final UserContext user = target.user();
        try {
            final PermissionSet permissions = PermissionSet.of(user.permissions(), user.deniedPermissions());
            if (!PermissionFilter.allows(permissions, BotPermissions.LOGS)) {
                throw new CommandException(ErrorCode.PERMISSION_DENIED, "нет права " + BotPermissions.LOGS);
            }
            final AuditChannelState state = runtime.auditChannel().state();
            final AuditChannelState.Outcome outcome = state.toggle(channelId);
            LOGGER.info("Канал журнала {}: {} ({}), изменение внёс {}", outcome, state.channelId(),
                    state.enabled() ? "включён" : "выключен", user.userId());
            target.send(runtime.embeds().logsToggle(outcome, state.channelId()), List.of());
        } catch (IllegalArgumentException e) {
            target.send(runtime.embeds().noticeText("embed.logs.title",
                            runtime.messages().format("embed.logs.missing_channel"),
                            runtime.config().embeds().palette().warning()),
                    List.of());
        } catch (CommandException e) {
            answer(target, e);
        } catch (RuntimeException e) {
            failed(target, user, e);
        }
    }

    /** Варианты автодополнения: привилегии показываются подписью, а в команду подставляется их ключ. */
    public List<Command.Choice> autocompleteChoices(UserContext user, String option, String typed) {
        if (SlashCommands.OPTION_RANK.equals(option)) {
            final String prefix = typed == null ? "" : typed.toLowerCase(Locale.ROOT);
            try {
                return runtime.staffConfig().allowedRanks(user.roleIds()).stream()
                        .filter(rank -> prefix.isEmpty()
                                || rank.key().toLowerCase(Locale.ROOT).startsWith(prefix)
                                || rank.name().toLowerCase(Locale.ROOT).startsWith(prefix))
                        .limit(runtime.config().ui().autocompleteLimit())
                        .map(rank -> new Command.Choice(Text.truncate(rank.display(), 100), rank.key()))
                        .toList();
            } catch (RuntimeException e) {
                LOGGER.debug("Автодополнение привилегий не удалось: {}", e.getMessage());
                return List.of();
            }
        }
        return autocomplete(user, option, typed).stream()
                .map(candidate -> new Command.Choice(candidate, candidate))
                .toList();
    }

    /** Autocomplete of the {@code server}, {@code group} and {@code command} options of the slash commands. */
    public List<String> autocomplete(UserContext user, String option, String typed) {
        final String prefix = typed == null ? "" : typed.toLowerCase(java.util.Locale.ROOT);
        try {
            final TargetsView view = runtime.views().get(user);
            final List<String> candidates = new ArrayList<>();
            switch (option) {
                case SlashCommands.OPTION_SERVER -> {
                    for (TargetsView.ServerOption server : TargetSelectionParser.accessibleServers(view)) {
                        candidates.add(server.id());
                    }
                }
                case SlashCommands.OPTION_GROUP -> {
                    for (TargetsView.GroupOption group : PermissionFilter.accessibleGroups(view)) {
                        candidates.add(group.name());
                    }
                }
                case SlashCommands.OPTION_COMMAND -> {
                    for (CommandShortcuts.Shortcut shortcut : runtime.config().shortcuts().all()) {
                        candidates.add(shortcut.name());
                    }
                }
                default -> {
                    return List.of();
                }
            }
            return candidates.stream()
                    .filter(candidate -> prefix.isEmpty()
                            || candidate.toLowerCase(java.util.Locale.ROOT).startsWith(prefix))
                    .distinct()
                    .limit(runtime.config().ui().autocompleteLimit())
                    .toList();
        } catch (RuntimeException e) {
            LOGGER.debug("Автодополнение для {} не удалось: {}", user == null ? "неизвестно" : user.userId(), e.getMessage());
            return List.of();
        }
    }

    private void openPanel(InteractionTarget target, TargetsView view, TargetOptions options) {
        final TargetSelection selection = TargetSelectionParser.parse(view, options == null ? TargetOptions.NONE : options);
        final PanelRegistry.Panel panel = runtime.panels().register(target.user().userId(), target.user().guildId(),
                target.user().channelId(), selection, selection.describe());
        target.send(runtime.embeds().panel(view, selection.describe(),
                TargetSelectionParser.accessibleServers(view).size()), panelRows(panel.nonce(), view));
    }

    private List<net.dv8tion.jda.api.interactions.components.LayoutComponent> panelRows(String nonce, TargetsView view) {
        return DiscordComponents.rows(
                DiscordComponents.row(DiscordComponents.targetMenu(runtime::messages, view, nonce)),
                DiscordComponents.row(DiscordComponents.executeButton(runtime::messages, nonce),
                        DiscordComponents.cancelButton(runtime::messages, nonce)));
    }

    private void showHistory(InteractionTarget target, UserContext user, HistoryRegistry.Query query, int offset) {
        final ControlMessages.HistoryResponse response = GatewayClient.join(
                runtime.gateway().history(user, query.serverId(), query.username(), query.commandFragment(),
                        query.status(), query.limit(), offset), timeout());
        target.editMessage(runtime.embeds().history(response, offset, query.limit(), query.commandFragment()),
                List.of(DiscordComponents.historyRow(runtime::messages, query.nonce(), offset, query.limit(),
                        response.total)));
    }

    private static TargetOptions optionsOf(TargetSelection selection) {
        if (selection.all()) {
            return TargetOptions.ofAll();
        }
        if (selection.group() != null && !selection.group().isBlank()) {
            return TargetOptions.ofGroup(selection.group());
        }
        if (selection.server() != null && !selection.server().isBlank()) {
            return TargetOptions.ofServer(selection.server());
        }
        if (!selection.servers().isEmpty()) {
            return TargetOptions.ofServers(String.join(",", selection.servers()));
        }
        return TargetOptions.NONE;
    }

    /** Понятный ответ на ошибку в самой команде: текст виден всегда, без режима диагностики. */
    private void staffProblem(InteractionTarget target, String message) {
        target.send(runtime.embeds().noticeText("embed.staff.failed_title", message,
                runtime.config().embeds().palette().error()), List.of());
    }

    /** Ник ограничен так же, как имена в Minecraft, но допускает префиксы Geyser и Floodgate. */
    private static boolean validNickname(String value) {
        if (value.length() < 2 || value.length() > 32) {
            return false;
        }
        for (int index = 0; index < value.length(); index++) {
            final char character = value.charAt(index);
            if (Character.isLetterOrDigit(character) || character == '_' || character == '.' || character == '-'
                    || character == '*') {
                continue;
            }
            return false;
        }
        return true;
    }

    private void requireCapability(boolean granted, String node) {
        if (!granted) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED, "missing " + node);
        }
    }

    private Duration timeout() {
        return runtime.config().control().requestTimeout();
    }

    private void answer(InteractionTarget target, CommandException error) {
        target.send(runtime.embeds().error(error.code().name(), error.getMessage(), target.interactionId(),
                showRequestId()), List.of());
    }

    private void failed(InteractionTarget target, UserContext user, RuntimeException error) {
        LOGGER.error("Запрос консоли от {} не удался", user.userId(), error);
        target.send(runtime.embeds().error(ErrorCode.INTERNAL_ERROR.name(), error.getMessage(), null,
                showRequestId()), List.of());
    }

    private boolean showRequestId() {
        return runtime.config().ui().showRequestId();
    }
}