package ru.zigono.dmc.bot.config;

import org.slf4j.Logger;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.EnvSubstitutor;
import ru.zigono.dmc.common.config.YamlConfig;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Objects;

/**
 * Files the bot owns on disk: {@code bot.yml} and the external language files next to it.
 * <p>The bundled defaults are the single source of truth: every file is written once and never overwritten
 * afterwards, so administrator edits survive an upgrade of the bot. A file that already exists is kept as it
 * is, which is why {@link #install()} is safe to call on every start.</p>
 *
 * @author Zigono
 */
public final class BotBootstrap {

    /** Name of the configuration file the bot installs and reads. */
    public static final String CONFIG_RESOURCE = "bot.yml";

    /** Resource directory of the message catalog bundled inside the bot jar. */
    public static final String LANGUAGE_RESOURCE_DIRECTORY = "bot-lang";
    private static final List<String> LANGUAGES = List.of("en.yml", "ru.yml");
    private static final String DEFAULT_LANGUAGE_DIRECTORY = "lang";

    private final Path configFile;
    private final Logger logger;
    private Path languageDirectory;

    public BotBootstrap(Path configFile, Logger logger) {
        this.configFile = Objects.requireNonNull(configFile, "configFile").toAbsolutePath();
        this.logger = Objects.requireNonNull(logger, "logger");
        this.languageDirectory = directory().resolve(DEFAULT_LANGUAGE_DIRECTORY);
    }

    /** @return the directory holding {@code bot.yml}, the language files and the bot data */
    public Path directory() {
        final Path parent = configFile.getParent();
        return parent == null ? Path.of(".").toAbsolutePath() : parent;
    }

    public Path configFile() {
        return configFile;
    }

    /**
     * @return the directory of the external language files, valid after {@link #install()}
     */
    public Path languageDirectory() {
        return languageDirectory;
    }

    /**
     * Writes the bundled defaults that are missing and resolves the language directory configured in
     * {@code bot.yml}.
     */
    public void install() {
        createDirectories(directory());
        if (!Files.isRegularFile(configFile)) {
            copyResource(CONFIG_RESOURCE, configFile);
        }
        this.languageDirectory = directory().resolve(configuredLanguageDirectory());
        installLanguageFiles();
        logger.debug("Файлы бота читаются из {}", directory());
    }

    /**
     * Writes the bundled language files next to the configuration.
     * <p>A configuration directory that cannot be written (a container may mount {@code config/} read only) is not
     * a reason to refuse to start: the language files bundled in the jar are used and the administrator gets a
     * warning instead of a failed start.</p>
     */
    private void installLanguageFiles() {
        try {
            Files.createDirectories(languageDirectory);
        } catch (IOException e) {
            logger.warn("Каталог языков {} недоступен для записи, используются языковые файлы из jar: {}", languageDirectory, e.getMessage());
            return;
        }
        for (String language : LANGUAGES) {
            copyOptionalResource(LANGUAGE_RESOURCE_DIRECTORY + "/" + language, languageDirectory.resolve(language));
        }
    }

    /**
     * Reads the language directory without resolving the secrets strictly: on a fresh installation the
     * environment variables of the secrets are not set yet and must not prevent the defaults from being written.
     */
    private String configuredLanguageDirectory() {
        final YamlConfig document = YamlConfig.load(configFile, false);
        final String configured = EnvSubstitutor
                .substitute(document.string("language_directory", DEFAULT_LANGUAGE_DIRECTORY),
                        System.getenv(), document.source(), false)
                .trim();
        return configured.isEmpty() ? DEFAULT_LANGUAGE_DIRECTORY : configured;
    }

    private static void createDirectories(Path path) {
        try {
            Files.createDirectories(path);
        } catch (IOException e) {
            throw new ConfigException("Не удалось создать " + path, e);
        }
    }

    private void copyResource(String resource, Path target) {
        copy(resource, target, false);
    }

    /** Copies a resource whose absence at the target location is not fatal, only a warning. */
    private void copyOptionalResource(String resource, Path target) {
        copy(resource, target, true);
    }

    private void copy(String resource, Path target, boolean lenient) {
        if (Files.isRegularFile(target)) {
            return;
        }
        try (InputStream stream = BotBootstrap.class.getClassLoader().getResourceAsStream(resource)) {
            if (stream == null) {
                throw new ConfigException("Ресурс " + resource + " отсутствует в jar бота");
            }
            Files.copy(stream, target, StandardCopyOption.REPLACE_EXISTING);
            logger.info("Установлен {}", target.toAbsolutePath());
        } catch (IOException e) {
            if (!lenient) {
                throw new ConfigException("Не удалось записать " + target, e);
            }
            logger.warn("Не удалось записать {}, используется копия из jar: {}",
                    target, e.getMessage());
        }
    }
}
