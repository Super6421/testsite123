package ru.zigono.dmc.bot.command;

import net.dv8tion.jda.api.entities.channel.ChannelType;
import net.dv8tion.jda.api.interactions.InteractionContextType;
import net.dv8tion.jda.api.interactions.commands.Command;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.interactions.commands.build.SlashCommandData;
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.common.text.Text;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Definition of the Discord slash commands. Names of commands and options are fixed (Discord requires stable
 * lower case identifiers), while every description comes from the language files.
 *
 * @author Zigono
 */
public final class SlashCommands {

    public static final String CONSOLE = "console";
    public static final String HISTORY = "console-history";
    public static final String SERVERS = "servers";
    public static final String ADMIN = "dmc";
    public static final String LOGS = "logs";

    public static final String OPTION_SERVER = "server";
    public static final String OPTION_SERVERS = "servers";
    public static final String OPTION_GROUP = "group";
    public static final String OPTION_COMMAND = "command";
    public static final String OPTION_DRYRUN = "dryrun";
    public static final String OPTION_USER = "user";
    public static final String OPTION_STATUS = "status";
    public static final String OPTION_LIMIT = "limit";
    public static final String OPTION_STATE = "state";
    public static final String OPTION_CHANNEL = "канал";
    public static final String OPTION_NICK = "ник";
    public static final String OPTION_RANK = "привилегия";
    public static final String OPTION_REASON = "причина";

    public static final String SUBCOMMAND_RELOAD = "reload";
    public static final String SUBCOMMAND_EMERGENCY = "emergency";
    public static final String SUBCOMMAND_CHANNEL = "channel";

    public static final String STATE_ON = "on";
    public static final String STATE_OFF = "off";

    private static final int MAX_DESCRIPTION = 100;

    /**
     * Discord принимает в именах команд только строчные буквы, цифры, дефис и подчёркивание. Кириллица —
     * это буквы, поэтому «персонал-выдать» допустимо; всё остальное заменяется безопасным именем, иначе бот
     * вообще не смог бы зарегистрировать команды.
     */
    private static final Pattern NAME = Pattern.compile("[-_\\p{L}\\p{N}]{1,32}");

    private static final Logger LOGGER = LoggerFactory.getLogger(SlashCommands.class);

    private SlashCommands() {
    }

    /** Итоговые имена команд персонала: уже приведённые к требованиям Discord. */
    public record CommandNames(String grant, String remove) {

        public static CommandNames of(StaffConfig staff) {
            return new CommandNames(sanitizeName(staff.grantCommand(), "staff-grant"),
                    sanitizeName(staff.removeCommand(), "staff-remove"));
        }
    }

    public static List<CommandData> definitions(Messages messages, BotConfig config, CommandNames names) {
        final List<CommandData> commands = new ArrayList<>(
                List.of(console(messages), history(messages, config), servers(messages), admin(messages),
                        logs(messages)));
        final StaffConfig staff = config.staff();
        if (staff.enabled() && !staff.isEmpty()) {
            commands.add(staffCommand(messages, names.grant(), "command.staff.grant.description"));
            commands.add(staffCommand(messages, names.remove(), "command.staff.remove.description"));
        }
        return List.copyOf(commands);
    }

    private static SlashCommandData staffCommand(Messages messages, String name, String descriptionKey) {
        return Commands.slash(name, description(messages, descriptionKey))
                .setContexts(InteractionContextType.GUILD)
                .addOptions(new OptionData(OptionType.STRING, OPTION_NICK,
                                description(messages, "command.staff.option.nick"))
                        .setRequired(true).setMaxLength(32))
                .addOptions(new OptionData(OptionType.STRING, OPTION_RANK,
                                description(messages, "command.staff.option.rank"))
                        .setRequired(true).setAutoComplete(true))
                .addOptions(new OptionData(OptionType.STRING, OPTION_REASON,
                                description(messages, "command.staff.option.reason"))
                        .setRequired(true).setMaxLength(200));
    }

    private static SlashCommandData logs(Messages messages) {
        final SubcommandData channel = new SubcommandData(SUBCOMMAND_CHANNEL,
                description(messages, "command.logs.channel.description"))
                .addOptions(new OptionData(OptionType.CHANNEL, OPTION_CHANNEL,
                                description(messages, "command.logs.channel.option"))
                        .setChannelTypes(ChannelType.TEXT, ChannelType.NEWS).setRequired(false));
        return Commands.slash(LOGS, description(messages, "command.logs.description"))
                .setContexts(InteractionContextType.GUILD)
                .addSubcommands(channel);
    }

    /** @return имя, допустимое для Discord, или {@code fallback}, если настроенное не подходит */
    public static String sanitizeName(String configured, String fallback) {
        final String candidate = configured == null ? "" : configured.trim().toLowerCase(Locale.ROOT);
        if (candidate.isEmpty()) {
            return fallback;
        }
        if (NAME.matcher(candidate).matches()) {
            return candidate;
        }
        LOGGER.warn("Имя слэш-команды '{}' недопустимо в Discord (нужны строчные буквы, цифры, дефис или "
                + "подчёркивание, не длиннее 32 символов), использую '{}'", configured, fallback);
        return fallback;
    }

    private static SlashCommandData console(Messages messages) {
        return Commands.slash(CONSOLE, description(messages, "command.console.description"))
                .setContexts(InteractionContextType.GUILD)
                .addOptions(new OptionData(OptionType.STRING, OPTION_SERVER,
                                description(messages, "command.console.option.server"))
                        .setRequired(false).setAutoComplete(true))
                .addOptions(new OptionData(OptionType.STRING, OPTION_SERVERS,
                                description(messages, "command.console.option.servers"))
                        .setRequired(false))
                .addOptions(new OptionData(OptionType.STRING, OPTION_GROUP,
                                description(messages, "command.console.option.group"))
                        .setRequired(false).setAutoComplete(true))
                .addOptions(new OptionData(OptionType.STRING, OPTION_COMMAND,
                                description(messages, "command.console.option.command"))
                        .setRequired(false).setAutoComplete(true))
                .addOptions(new OptionData(OptionType.BOOLEAN, OPTION_DRYRUN,
                                description(messages, "command.console.option.dryrun"))
                        .setRequired(false));
    }

    private static SlashCommandData history(Messages messages, BotConfig config) {
        final List<Command.Choice> statuses = new ArrayList<>();
        for (ExecutionStatus status : ExecutionStatus.values()) {
            if (statuses.size() >= 25) {
                break;
            }
            statuses.add(new Command.Choice(status.name(), status.name()));
        }
        statuses.add(new Command.Choice(ru.zigono.dmc.bot.audit.AuditEntry.STATUS_PARTIAL,
                ru.zigono.dmc.bot.audit.AuditEntry.STATUS_PARTIAL));
        return Commands.slash(HISTORY, description(messages, "command.history.description"))
                .setContexts(InteractionContextType.GUILD)
                .addOptions(new OptionData(OptionType.STRING, OPTION_SERVER,
                                description(messages, "command.history.option.server"))
                        .setRequired(false).setAutoComplete(true))
                .addOptions(new OptionData(OptionType.STRING, OPTION_USER,
                                description(messages, "command.history.option.user"))
                        .setRequired(false))
                .addOptions(new OptionData(OptionType.STRING, OPTION_COMMAND,
                                description(messages, "command.history.option.command"))
                        .setRequired(false))
                .addOptions(new OptionData(OptionType.STRING, OPTION_STATUS,
                                description(messages, "command.history.option.status"))
                        .setRequired(false).addChoices(statuses))
                .addOptions(new OptionData(OptionType.INTEGER, OPTION_LIMIT,
                                description(messages, "command.history.option.limit"))
                        .setRequired(false).setMinValue(1).setMaxValue(config.ui().historyMaxLimit()));
    }

    private static SlashCommandData servers(Messages messages) {
        return Commands.slash(SERVERS, description(messages, "command.servers.description"))
                .setContexts(InteractionContextType.GUILD);
    }

    private static SlashCommandData admin(Messages messages) {
        final SubcommandData reload = new SubcommandData(SUBCOMMAND_RELOAD,
                description(messages, "command.admin.reload.description"));
        final SubcommandData emergency = new SubcommandData(SUBCOMMAND_EMERGENCY,
                description(messages, "command.admin.emergency.description"))
                .addOptions(new OptionData(OptionType.STRING, OPTION_STATE,
                                description(messages, "command.admin.emergency.option.state"))
                        .setRequired(true)
                        .addChoices(new Command.Choice(STATE_ON, STATE_ON), new Command.Choice(STATE_OFF, STATE_OFF)));
        return Commands.slash(ADMIN, description(messages, "command.admin.description"))
                .setContexts(InteractionContextType.GUILD)
                .addSubcommands(reload, emergency);
    }

    private static String description(Messages messages, String key) {
        return Text.truncate(messages.formatOrDefault(key, key), MAX_DESCRIPTION)
                .toLowerCase(Locale.ROOT)
                .isBlank() ? key : Text.truncate(messages.formatOrDefault(key, key), MAX_DESCRIPTION);
    }

    public static boolean isOptionTrue(String value) {
        return STATE_ON.equalsIgnoreCase(value);
    }
}
