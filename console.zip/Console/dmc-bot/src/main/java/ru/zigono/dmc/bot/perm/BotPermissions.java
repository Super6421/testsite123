package ru.zigono.dmc.bot.perm;

/**
 * Permission nodes used by the bot user interface. The nodes the whole system shares live in
 * {@link ru.zigono.dmc.common.perm.Permission}; the nodes below are checked by the gateway as well, so they
 * are collected here to keep the two sides in sync.
 *
 * @author Zigono
 */
public final class BotPermissions {

    /** Everything the administration group of the bot requires. */
    public static final String ADMIN = "console.admin.*";

    /** Hot reload of the gateway configuration. */
    public static final String RELOAD = "console.admin.reload";

    /** Wildcard accepted by the gateway for the emergency kill switch. */
    public static final String EMERGENCY = "console.emergency.*";

    /** Explicit emergency toggling node. */
    public static final String EMERGENCY_TOGGLE = "console.emergency.toggle";

    /** Alternative emergency node accepted by the gateway. */
    public static final String EMERGENCY_ADMIN = "console.admin.emergency";

    /** Включение и выключение канала логов командой {@code /logs channel}. */
    public static final String LOGS = "console.logs";

    private BotPermissions() {
    }
}
