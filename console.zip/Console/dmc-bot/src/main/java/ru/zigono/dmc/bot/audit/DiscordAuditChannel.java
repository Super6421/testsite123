package ru.zigono.dmc.bot.audit;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.bot.ui.EmbedFactory;

import java.util.Objects;
import java.util.function.Supplier;

/**
 * Публикует журнал в канал Discord, чтобы операторы видели то же, что хранится в базе шлюза: кто, что, когда и
 * с каким результатом сделал.
 * <p>Канал и его включённость берутся из {@link AuditChannelState}: команда {@code /logs channel} включает,
 * выключает и переключает канал на лету, не требуя правки конфигурации и перезапуска.</p>
 *
 * @author Zigono
 */
public final class DiscordAuditChannel {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscordAuditChannel.class);

    private final Supplier<BotConfig> config;
    private final Supplier<JDA> jda;
    private final EmbedFactory embeds;
    private final AuditChannelState state;

    public DiscordAuditChannel(Supplier<BotConfig> config, Supplier<JDA> jda, EmbedFactory embeds,
                               AuditChannelState state) {
        this.config = Objects.requireNonNull(config, "config");
        this.jda = Objects.requireNonNull(jda, "jda");
        this.embeds = Objects.requireNonNull(embeds, "embeds");
        this.state = Objects.requireNonNull(state, "state");
    }

    /** @return текущее состояние канала логов: его меняет {@code /logs channel} */
    public AuditChannelState state() {
        return state;
    }

    /**
     * Публикует запись аудита выполненной команды. Ошибки только пишутся в журнал сервера: сломанный канал
     * логов не должен ломать выполнение команд.
     */
    public void publish(AuditEntry entry) {
        if (entry == null) {
            return;
        }
        final BotConfig.AuditSettings settings = config.get().audit();
        send(embeds.audit(entry, settings.includeRoles(), settings.includeOutput()), "записи аудита "
                + entry.requestId());
    }

    /** Публикует запись о выдаче или снятии привилегии: кто, кого, когда и по какой причине. */
    public void publishStaff(StaffAuditEntry entry) {
        if (entry == null) {
            return;
        }
        send(embeds.staffAudit(entry), "записи аудита персонала " + entry.requestId());
    }

    private void send(MessageEmbed embed, String what) {
        final String channelId = state.channelId();
        if (!state.enabled() || channelId == null) {
            LOGGER.debug("Пропускаю публикацию {}: канал логов выключен", what);
            return;
        }
        final JDA api = jda.get();
        if (api == null) {
            LOGGER.debug("Пропускаю публикацию {}: Discord ещё не подключён", what);
            return;
        }
        final MessageChannel channel = resolve(api, channelId);
        if (channel == null) {
            LOGGER.warn("Канал логов {} недоступен боту, включите логи заново командой /logs channel в нужном канале",
                    channelId);
            return;
        }
        channel.sendMessageEmbeds(embed).queue(
                message -> LOGGER.debug("{} опубликована в канале {}", what, channel.getId()),
                error -> LOGGER.warn("Не удалось опубликовать {}: {}", what, error.getMessage()));
    }

    private MessageChannel resolve(JDA api, String channelId) {
        for (String guildId : config.get().discord().guildIds()) {
            final Guild guild = api.getGuildById(guildId);
            if (guild == null) {
                continue;
            }
            final MessageChannel channel = guild.getTextChannelById(channelId);
            if (channel != null) {
                return channel;
            }
        }
        try {
            return api.getChannelById(MessageChannel.class, channelId);
        } catch (RuntimeException e) {
            LOGGER.debug("Не удалось определить канал логов {} напрямую: {}", channelId, e.getMessage());
            return null;
        }
    }
}