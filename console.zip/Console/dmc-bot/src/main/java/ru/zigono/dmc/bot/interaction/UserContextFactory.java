package ru.zigono.dmc.bot.interaction;

import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.GenericInteractionCreateEvent;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Builds the identity that travels with every gateway request: Discord ids, roles and the effective ACL of the
 * member, resolved from the bot configuration. The gateway merges this with its own ACL and stays authoritative.
 *
 * @author Zigono
 */
public final class UserContextFactory {

    private final Supplier<BotConfig> config;

    public UserContextFactory(Supplier<BotConfig> config) {
        this.config = Objects.requireNonNull(config, "config");
    }

    public UserContext create(GenericInteractionCreateEvent event, String messageId) {
        final User user = event.getUser();
        final Guild guild = event.getGuild();
        final Member member = event.getMember();
        final String userId = user.getId();
        final String username = member != null && member.getEffectiveName() != null && !member.getEffectiveName().isBlank()
                ? member.getEffectiveName()
                : user.getName();
        final String guildId = guild == null ? null : guild.getId();
        final List<String> roleIds = new ArrayList<>();
        if (member != null) {
            for (Role role : member.getRoles()) {
                roleIds.add(role.getId());
            }
        }
        final PermissionSet permissions = config.get().permissions().resolve(guildId, roleIds, userId);
        return new UserContext(userId, username, guildId, event.getChannelId(), messageId, event.getId(),
                List.copyOf(roleIds),
                permissions.allow().stream().sorted().toList(),
                permissions.deny().stream().sorted().toList());
    }
}
