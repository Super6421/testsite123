package ru.zigono.dmc.bot.ui;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.MessageEmbed;
import ru.zigono.dmc.bot.audit.AuditChannelState;
import ru.zigono.dmc.bot.audit.AuditEntry;
import ru.zigono.dmc.bot.audit.StaffAuditEntry;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.bot.render.ErrorTranslator;
import ru.zigono.dmc.bot.render.RenderedResponse;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.common.text.Text;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.HistoryEntry;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Builds every embed of the bot from the language files and the configured colours. No title, description, field
 * name, footer or colour is hardcoded here, so the whole user interface can be re-localized and re-themed without
 * touching the code.
 *
 * @author Zigono
 */
public final class EmbedFactory {

    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ROOT);
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
    private static final int MAX_FIELDS = MessageEmbed.MAX_FIELD_AMOUNT;
    private static final int MAX_DESCRIPTION = MessageEmbed.DESCRIPTION_MAX_LENGTH;

    private final Supplier<Messages> messages;
    private final Supplier<BotConfig.EmbedSettings> settings;
    private final Supplier<Boolean> diagnostics;

    public EmbedFactory(Supplier<Messages> messages, Supplier<BotConfig.EmbedSettings> settings) {
        this(messages, settings, () -> Boolean.FALSE);
    }

    public EmbedFactory(Supplier<Messages> messages, Supplier<BotConfig.EmbedSettings> settings,
                        Supplier<Boolean> diagnostics) {
        this.messages = Objects.requireNonNull(messages, "messages");
        this.settings = Objects.requireNonNull(settings, "settings");
        this.diagnostics = Objects.requireNonNull(diagnostics, "diagnostics");
    }

    public Messages messages() {
        return messages.get();
    }

    /** The interactive console panel. */
    public MessageEmbed panel(TargetsView view, String targetDescription, int availableTargets) {
        final EmbedBuilder embed = builder(palette().info())
                .setTitle(text("embed.panel.title"))
                .setDescription(text("embed.panel.description"));
        embed.addField(fieldName("embed.field.target"), fieldValue(targetDescription == null
                ? text("embed.value.target_unset")
                : targetDescription), true);
        embed.addField(fieldName("embed.field.targets"), fieldValue(Integer.toString(availableTargets)), true);
        if (diagnostics()) {
            embed.addField(fieldName("embed.field.mode"), fieldValue(text(view != null && view.singleServerMode()
                    ? "embed.value.mode.single"
                    : "embed.value.mode.multi")), true);
            embed.addField(fieldName("embed.field.revision"),
                    fieldValue(shortRevision(view == null ? null : view.configRevision())), true);
        }
        return embed.build();
    }

    /** The result of a regular or broadcast execution. */
    public MessageEmbed result(ResultView view, boolean showRequestId) {
        final int color = view.dryRun() ? palette().warning() : statusColor(view.status());
        final EmbedBuilder embed = builder(color).setTitle(statusTitle(view.status()));
        applyOutput(embed, view.output());
        embed.addField(fieldName("embed.field.target"), fieldValue(view.target()), true);
        embed.addField(fieldName("embed.field.command"), fieldValue(code(view.command())), true);
        if (view.dryRun()) {
            embed.addField(fieldName("embed.field.mode"), fieldValue(text("embed.value.dry_run")), true);
        }
        if (view.outcomes().size() > 1) {
            embed.addField(fieldName("embed.field.servers"), fieldValue(serverSummary(view.outcomes())), false);
        }
        if (diagnostics()) {
            embed.addField(fieldName("embed.field.duration"), fieldValue(messages().format("embed.value.duration",
                    view.durationMillis())), true);
        }
        if (showRequestId) {
            embed.addField(fieldName("embed.field.request_id"), fieldValue(code(view.requestId())), true);
        }
        return embed.build();
    }

    /** The detailed report of a dry run. */
    public MessageEmbed dryRun(ResultView view, boolean showRequestId) {
        final EmbedBuilder embed = builder(palette().warning())
                .setTitle(text("embed.dryrun.title"))
                .setDescription(text("embed.dryrun.description"));
        embed.addField(fieldName("embed.field.target"), fieldValue(view.target()), true);
        embed.addField(fieldName("embed.field.command"), fieldValue(code(view.command())), false);
        if (view.dryRunSummary() != null && !view.dryRunSummary().isBlank()) {
            embed.addField(fieldName("embed.field.summary"), fieldValue(view.dryRunSummary()), false);
        }
        final StringBuilder checks = new StringBuilder();
        for (String check : view.dryRunChecks()) {
            if (!checks.isEmpty()) {
                checks.append('\n');
            }
            checks.append(messages().format("embed.dryrun.check", check));
        }
        if (!checks.isEmpty() && diagnostics()) {
            embed.addField(fieldName("embed.field.checks"), fieldValue(checks.toString()), false);
        }
        if (view.outcomes().size() > 1) {
            embed.addField(fieldName("embed.field.servers"), fieldValue(serverSummary(view.outcomes())), false);
        }
        if (showRequestId) {
            embed.addField(fieldName("embed.field.request_id"), fieldValue(code(view.requestId())), true);
        }
        return embed.build();
    }

    /** A failed request, rendered from its standardized error code. */
    public MessageEmbed error(String codeName, String detail, String requestId, boolean showRequestId) {
        final ErrorTranslator translator = new ErrorTranslator(messages);
        final ru.zigono.dmc.common.errors.ErrorCode code = ErrorTranslator.codeOf(codeName);
        final EmbedBuilder embed = builder(palette().error())
                .setTitle(text("embed.error.title"))
                .setDescription(text("embed.error.description"));
        embed.addField(fieldName("embed.field.reason"), fieldValue(translator.describe(codeName)), false);
        if (code != null) {
            final String hint = translator.hint(code);
            if (!hint.isBlank()) {
                embed.addField(fieldName("embed.field.hint"), fieldValue(hint), false);
            }
        }
        if (detail != null && !detail.isBlank() && diagnostics()) {
            embed.addField(fieldName("embed.field.details"), fieldValue(code(detail)), false);
        }
        if (showRequestId) {
            embed.addField(fieldName("embed.field.request_id"), fieldValue(code(requestId)), true);
        }
        return embed.build();
    }

    /** The confirmation prompt of a dangerous command. */
    public MessageEmbed confirmation(ConfirmationRegistry.Pending pending) {
        final EmbedBuilder embed = builder(palette().warning())
                .setTitle(text("embed.confirm.title"))
                .setDescription(text("embed.confirm.description"));
        embed.addField(fieldName("embed.field.target"), fieldValue(pending.targetDescription()), true);
        embed.addField(fieldName("embed.field.user"), fieldValue(pending.username()), true);
        embed.addField(fieldName("embed.field.command"), fieldValue(code(pending.command())), false);
        embed.addField(fieldName("embed.field.expires"), fieldValue("<t:" + (pending.expiresAt() / 1000L) + ":R>"), true);
        return embed.build();
    }

    /** A short notice, for example that a confirmation expired. */
    public MessageEmbed notice(String titleKey, String descriptionKey) {
        return notice(titleKey, descriptionKey, palette().neutral());
    }

    public MessageEmbed notice(String titleKey, String descriptionKey, int color) {
        return builder(color)
                .setTitle(text(titleKey))
                .setDescription(text(descriptionKey))
                .build();
    }

    /** Уведомление с готовым текстом описания: когда текст собирается вызывающим кодом с подстановками. */
    public MessageEmbed noticeText(String titleKey, String description, int color) {
        return builder(color)
                .setTitle(text(titleKey))
                .setDescription(Text.truncate(description == null ? "" : description, MAX_DESCRIPTION))
                .build();
    }

    /** The status of the servers the user may see. */
    public MessageEmbed servers(ControlMessages.StatusResponse response) {
        final List<ControlMessages.ServerStatusEntry> entries = response == null ? List.of() : response.servers;
        final EmbedBuilder embed = builder(palette().info())
                .setTitle(text("embed.servers.title"))
                .setDescription(messages().format("embed.servers.description", entries.size()));
        if (entries.isEmpty()) {
            embed.addField(fieldName("embed.field.servers"), fieldValue(text("embed.servers.none")), false);
        }
        for (ControlMessages.ServerStatusEntry entry : entries.subList(0, Math.min(MAX_FIELDS - 3, entries.size()))) {
            embed.addField(fieldName(icon(entry.status()) + " " + entry.name()), fieldValue(serverDetails(entry)), false);
        }
        if (response != null && diagnostics()) {
            embed.addField(fieldName("embed.field.gateway"), fieldValue(code(response.gatewayId)), true);
            embed.addField(fieldName("embed.field.revision"), fieldValue(shortRevision(response.configRevision)), true);
            embed.addField(fieldName("embed.field.uptime"), fieldValue(messages().format("embed.value.uptime",
                    response.uptimeSeconds)), true);
        }
        return embed.build();
    }

    /** One page of the command history. */
    public MessageEmbed history(ControlMessages.HistoryResponse response, int offset, int pageSize, String filter) {
        final List<HistoryEntry> entries = response == null ? List.of() : response.entries;
        final long total = response == null ? 0L : response.total;
        final int page = pageSize <= 0 ? 1 : (offset / pageSize) + 1;
        final int pages = pageSize <= 0 ? 1 : Math.max(1, (int) Math.ceil(total / (double) pageSize));
        final EmbedBuilder embed = builder(palette().info())
                .setTitle(text("embed.history.title"))
                .setDescription(messages().format("embed.history.description", page, pages, total,
                        filter == null || filter.isBlank() ? text("embed.history.no_filter") : filter));
        if (entries.isEmpty()) {
            embed.addField(fieldName("embed.field.entries"), fieldValue(text("embed.history.empty")), false);
        }
        for (HistoryEntry entry : entries.subList(0, Math.min(MAX_FIELDS - 1, entries.size()))) {
            embed.addField(fieldName(icon(entry.status()) + " " + safe(entry.username()) + " · " + safe(entry.serverId())),
                    fieldValue(messages().format("embed.history.entry",
                            TIME.format(Instant.ofEpochMilli(entry.createdAt()).atZone(ZoneId.systemDefault())),
                            code(entry.command()), statusLabel(entry.status()))),
                    false);
        }
        return embed.build();
    }

    /** The audit record published in the audit channel. */
    public MessageEmbed audit(AuditEntry entry, boolean includeRoles, boolean includeOutput) {
        final EmbedBuilder embed = builder("SUCCESS".equals(entry.status()) ? palette().audit() : palette().error())
                .setTitle(icon(entry.status()) + " " + text("embed.audit.title"))
                .setTimestamp(Instant.ofEpochMilli(entry.timestamp()));
        embed.addField(fieldName("embed.field.user"), fieldValue(safe(entry.username()) + " (" + code(entry.userId()) + ")"), true);
        embed.addField(fieldName("embed.field.target"), fieldValue(entry.target()), true);
        embed.addField(fieldName("embed.field.status"), fieldValue(statusLabel(entry.status())), true);
        embed.addField(fieldName("embed.field.command"), fieldValue(code(entry.command())), false);
        embed.addField(fieldName("embed.field.duration"), fieldValue(messages().format("embed.value.duration",
                entry.durationMillis())), true);
        embed.addField(fieldName("embed.field.request_id"), fieldValue(code(entry.requestId())), true);
        embed.addField(fieldName("embed.field.channel"), fieldValue(code(entry.channelId())), true);
        if (!entry.outcomes().isEmpty()) {
            embed.addField(fieldName("embed.field.servers"), fieldValue(serverSummary(entry.outcomes())), false);
        }
        if (entry.errorCode() != null && !entry.errorCode().isBlank()) {
            final ErrorTranslator translator = new ErrorTranslator(messages);
            final String detail = entry.errorDetail() == null || entry.errorDetail().isBlank()
                    ? ""
                    : "\n" + code(entry.errorDetail());
            embed.addField(fieldName("embed.field.error"),
                    fieldValue(translator.describe(entry.errorCode()) + detail), false);
        }
        if (includeOutput && !entry.response().isBlank()) {
            embed.addField(fieldName("embed.field.output"),
                    fieldValue(Text.truncate(entry.response(), MessageEmbed.VALUE_MAX_LENGTH)), false);
        }
        if (includeRoles && !entry.roleIds().isEmpty()) {
            embed.addField(fieldName("embed.field.roles"), fieldValue(code(String.join(", ", entry.roleIds()))), false);
        }
        return embed.build();
    }

    /**
     * Ответ автору команды {@code /персонал-выдать} и {@code /персонал-снять}. Технические подробности
     * (группа LuckPerms, основная группа) показываются только в режиме диагностики.
     */
    public MessageEmbed staffResult(StaffService.Request request, StaffService.Result result,
                                    StaffConfig.Rank rank) {
        final boolean grant = request.action() == StaffService.Action.GRANT;
        final String rankName = result.rankName() != null ? result.rankName()
                : rank != null ? rank.name() : request.rankKey();
        final int color;
        final String titleKey;
        final String description;
        if (!result.success()) {
            color = palette().error();
            titleKey = "embed.staff.failed_title";
            final String detail = result.errorDetail() == null || result.errorDetail().isBlank()
                    ? new ErrorTranslator(messages).describe(String.valueOf(result.error()))
                    : result.errorDetail();
            description = messages().format("embed.staff.failed_description", plain(detail));
        } else if (!result.changed()) {
            color = palette().warning();
            titleKey = grant ? "embed.staff.granted_title" : "embed.staff.removed_title";
            description = text("embed.staff.unchanged_description");
        } else {
            color = palette().success();
            titleKey = grant ? "embed.staff.granted_title" : "embed.staff.removed_title";
            description = messages().format(grant ? "embed.staff.granted_description"
                    : "embed.staff.removed_description", plain(result.target()), plain(rankName));
        }
        final EmbedBuilder embed = builder(color)
                .setTitle((result.success() ? icon("SUCCESS") : icon("FAILED")) + " " + text(titleKey))
                .setDescription(description);
        embed.addField(fieldName("embed.field.staff_target"), fieldValue(plain(result.target())), true);
        embed.addField(fieldName("embed.field.staff_rank"), fieldValue(plain(rankName)), true);
        embed.addField(fieldName("embed.field.staff_reason"), fieldValue(plain(request.reason())), true);
        if (diagnostics() && result.group() != null && !result.group().isBlank()) {
            embed.addField(fieldName("embed.field.staff_group"), fieldValue(code(result.group())), true);
        }
        return embed.build();
    }

    /** Запись журнала о выдаче или снятии привилегии: кто, кого, когда и по какой причине. */
    public MessageEmbed staffAudit(StaffAuditEntry entry) {
        final boolean grant = entry.action() == StaffService.Action.GRANT;
        final String titleKey = !entry.success() ? "embed.audit.staff_failed"
                : grant ? "embed.audit.staff_granted" : "embed.audit.staff_removed";
        final EmbedBuilder embed = builder(entry.success() ? palette().audit() : palette().error())
                .setTitle(icon(entry.success() ? "SUCCESS" : "FAILED") + " " + text(titleKey))
                .setTimestamp(Instant.ofEpochMilli(entry.timestamp()));
        embed.addField(fieldName("embed.field.staff_actor"), fieldValue(actor(entry)), true);
        embed.addField(fieldName("embed.field.staff_target"), fieldValue(plain(entry.target())), true);
        embed.addField(fieldName("embed.field.staff_rank"),
                fieldValue(plain(entry.rankName() != null ? entry.rankName() : entry.group())), true);
        embed.addField(fieldName("embed.field.staff_reason"), fieldValue(plain(entry.reason())), true);
        if (!entry.success()) {
            final String detail = entry.errorDetail().isBlank()
                    ? new ErrorTranslator(messages).describe(entry.errorCode())
                    : entry.errorDetail();
            embed.addField(fieldName("embed.field.error"),
                    fieldValue(plain(detail) + (entry.errorCode().isBlank() ? "" : "\n" + code(entry.errorCode()))),
                    false);
        }
        if (diagnostics() && entry.group() != null && !entry.group().isBlank()) {
            embed.addField(fieldName("embed.field.staff_group"), fieldValue(code(entry.group())), true);
        }
        return embed.build();
    }

    /** Ответ на команду {@code /logs channel}: логи включены, выключены или уведены в другой канал. */
    public MessageEmbed logsToggle(AuditChannelState.Outcome outcome, String channelId) {
        final String descriptionKey = switch (outcome) {
            case ENABLED -> "embed.logs.enabled";
            case DISABLED -> "embed.logs.disabled";
            case SWITCHED -> "embed.logs.switched";
        };
        final int color = outcome == AuditChannelState.Outcome.DISABLED ? palette().warning() : palette().success();
        return builder(color)
                .setTitle((outcome == AuditChannelState.Outcome.DISABLED ? "🔕" : "🔔") + " " + text("embed.logs.title"))
                .setDescription(messages().format(descriptionKey, channelId == null ? "" : "<#" + channelId + ">"))
                .build();
    }

    /** @return подпись автора записи журнала в виде «Имя (id)» */
    private static String actor(StaffAuditEntry entry) {
        final String name = entry.actorName() == null || entry.actorName().isBlank() ? "-" : entry.actorName();
        return entry.actorId() == null || entry.actorId().isBlank() ? name : name + " (" + entry.actorId() + ")";
    }

    /**
     * Пользовательский текст в эмбеде: управляющие символы убираются, а собака получает невидимый разделитель,
     * чтобы причина или ник не могли никого упомянуть.
     */
    private static String plain(String value) {
        if (value == null || value.isBlank()) {
            return "-";
        }
        return Text.sanitizeForDiscord(value).replace("@", "@\u200B");
    }

    private void applyOutput(EmbedBuilder embed, RenderedResponse output) {
        if (output == null) {
            embed.setDescription(text("response.empty"));
            return;
        }
        if (output.hasAttachment()) {
            embed.setDescription(output.chunks().isEmpty() ? text("response.empty") : output.chunks().get(0));
            return;
        }
        if (output.embeddable()) {
            embed.setDescription(Text.truncate(output.text(), MAX_DESCRIPTION));
            return;
        }
        embed.setDescription(text("embed.result.output_follows"));
    }

    private String serverDetails(ControlMessages.ServerStatusEntry entry) {
        final StringBuilder value = new StringBuilder();
        value.append(messages().formatOrDefault("status.label." + entry.status(), safe(entry.status())));
        final ServerMetrics metrics = entry.metrics();
        if (metrics != null && entry.status() != null
                && (entry.status().equals("ONLINE") || entry.status().equals("DEGRADED"))) {
            value.append('\n').append(messages().format("embed.servers.metrics", metrics.onlinePlayers(),
                    metrics.maxPlayers(), String.format(Locale.ROOT, "%.1f", metrics.tps()),
                    String.format(Locale.ROOT, "%.1f", metrics.mspt())));
            if (metrics.minecraftVersion() != null) {
                value.append('\n').append(messages().format("embed.servers.version", metrics.minecraftVersion(),
                        safe(metrics.serverSoftware())));
            }
        }
        if (entry.errorDetail() != null && !entry.errorDetail().isBlank()) {
            value.append('\n').append(code(entry.errorDetail()));
        }
        if (entry.lastSeenMillis() > 0) {
            value.append('\n').append(messages().format("embed.servers.last_seen",
                    TIMESTAMP.format(Instant.ofEpochMilli(entry.lastSeenMillis()).atZone(ZoneId.systemDefault()))));
        }
        return value.toString();
    }

    private String serverSummary(List<ServerOutcome> outcomes) {
        final StringBuilder summary = new StringBuilder();
        for (ServerOutcome outcome : outcomes) {
            if (!summary.isEmpty()) {
                summary.append('\n');
            }
            summary.append(messages().format("embed.result.server_line",
                    icon(outcome.status().name()) + " " + outcome.serverId(), statusLabel(outcome.status().name())));
        }
        return summary.toString();
    }

    public int statusColor(String status) {
        if (status == null) {
            return palette().neutral();
        }
        return switch (status.toUpperCase(Locale.ROOT)) {
            case "SUCCESS", "DRY_RUN" -> palette().success();
            case "PARTIAL", "DEGRADED", "CONNECTING" -> palette().warning();
            default -> palette().error();
        };
    }

    public String statusLabel(String status) {
        if (status == null || status.isBlank()) {
            return ExecutionStatus.UNKNOWN.name();
        }
        return messages().formatOrDefault("status.label." + status.toUpperCase(Locale.ROOT), status);
    }

    /** The human readable heading of a status, for example {@code ✅ Команда выполнена}. */
    public String statusTitle(String status) {
        final String key = status == null || status.isBlank() ? ExecutionStatus.UNKNOWN.name()
                : status.toUpperCase(Locale.ROOT);
        return icon(key) + " " + messages().formatOrDefault("status.title." + key, statusLabel(key));
    }

    /** @return {@code true} when the operator asked for the technical fields of the embeds */
    public boolean diagnostics() {
        return Boolean.TRUE.equals(diagnostics.get());
    }

    public String icon(String status) {
        if (status == null) {
            return messages().formatOrDefault("status.icon.UNKNOWN", "");
        }
        return messages().formatOrDefault("status.icon." + status.toUpperCase(Locale.ROOT), "");
    }

    private EmbedBuilder builder(int color) {
        final BotConfig.EmbedSettings current = settings.get();
        final EmbedBuilder embed = new EmbedBuilder().setColor(color);
        if (current.timestamp()) {
            embed.setTimestamp(Instant.now());
        }
        if (current.footer() != null && !current.footer().isBlank()) {
            embed.setFooter(Text.truncate(current.footer(), 2048));
        }
        return embed;
    }

    private BotConfig.EmbedSettings.Palette palette() {
        return settings.get().palette();
    }

    private String text(String key) {
        return messages().format(key);
    }

    /**
     * Имя поля эмбеда. Значение либо ключ языка ({@code embed.field.*}) — тогда берётся перевод, либо уже
     * готовый текст (например {@code "🟢 Мой сервер"}), который остаётся как есть.
     * <p>Раньше ключ подставлялся в эмбед дословно, из-за чего в Discord были видны строки вида
     * {@code embed.field.user}.</p>
     */
    private String fieldName(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        final String resolved = messages().has(value) ? messages().format(value) : value;
        return Text.truncate(resolved, MessageEmbed.TITLE_MAX_LENGTH);
    }

    private static String fieldValue(String value) {
        final String safe = value == null || value.isBlank() ? "-" : value;
        return Text.truncate(safe, MessageEmbed.VALUE_MAX_LENGTH);
    }

    private static String code(String value) {
        if (value == null || value.isBlank()) {
            return "-";
        }
        return "\u0060" + value + "\u0060";
    }

    private static String safe(String value) {
        return value == null || value.isBlank() ? "-" : value;
    }

    private static String shortRevision(String revision) {
        if (revision == null || revision.isBlank()) {
            return "-";
        }
        return revision.length() <= 12 ? revision : revision.substring(0, 12);
    }
}
