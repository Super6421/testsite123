package ru.zigono.dmc.bot.gateway;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.BotBuild;
import ru.zigono.dmc.bot.render.ErrorTranslator;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.MessageTypes;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.dto.PolicySnapshot;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.TransportClient;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Control plane client of the Discord bot.
 * <p>The bot never executes anything itself: it authenticates against the gateway with its own identity and then
 * exchanges {@link ControlMessages} request/response pairs. Every failure is reported as a real failure, so a
 * user never receives a fabricated success when the gateway is unreachable.</p>
 *
 * @author Zigono
 */
public final class GatewayClient implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(GatewayClient.class);
    private static final int DEFAULT_HEARTBEAT_SECONDS = 30;

    private final TransportSettings settings;
    private final byte[] secret;
    private final Duration requestTimeout;
    private final Duration handshakeTimeout;
    private final Duration readyTimeout;
    private final TransportClient transport;
    private final ScheduledExecutorService scheduler;
    private final AtomicReference<GatewayState> state = new AtomicReference<>(GatewayState.STOPPED);
    private final AtomicReference<String> lastError = new AtomicReference<>();
    private final AtomicReference<String> gatewayId = new AtomicReference<>();
    private final AtomicReference<String> configRevision = new AtomicReference<>();
    private volatile CompletableFuture<Void> authentication = new CompletableFuture<>();
    private volatile int heartbeatIntervalSeconds = DEFAULT_HEARTBEAT_SECONDS;
    private volatile long latencyMillis = -1L;

    public GatewayClient(TransportSettings settings, byte[] secret, Duration requestTimeout, Duration handshakeTimeout,
                         Duration readyTimeout) {
        this.settings = Objects.requireNonNull(settings, "settings");
        this.secret = Objects.requireNonNull(secret, "secret");
        this.requestTimeout = Objects.requireNonNull(requestTimeout, "requestTimeout");
        this.handshakeTimeout = Objects.requireNonNull(handshakeTimeout, "handshakeTimeout");
        this.readyTimeout = Objects.requireNonNull(readyTimeout, "readyTimeout");
        this.scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            final Thread thread = new Thread(runnable, "dmc-bot-gateway-keepalive");
            thread.setDaemon(true);
            return thread;
        });
        this.transport = new TransportClient(settings, KeyResolver.single(settings.localClientId(), secret),
                new Listener());
    }

    public void start() {
        if (!state.compareAndSet(GatewayState.STOPPED, GatewayState.CONNECTING)) {
            return;
        }
        LOGGER.info("Подключаюсь к шлюзу {}:{} как управляющий клиент '{}'", settings.host(), settings.port(),
                settings.localClientId());
        transport.start();
        scheduler.scheduleWithFixedDelay(this::keepAlive, heartbeatIntervalSeconds, heartbeatIntervalSeconds,
                TimeUnit.SECONDS);
    }

    /** Blocks until the handshake completed. */
    public boolean awaitAuthentication() {
        try {
            authentication.get(readyTimeout.toMillis(), TimeUnit.MILLISECONDS);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (java.util.concurrent.TimeoutException e) {
            return false;
        } catch (java.util.concurrent.ExecutionException e) {
            return false;
        }
    }

    public GatewayState state() {
        return state.get();
    }

    public boolean authenticated() {
        return state.get().ready() && transport.connected();
    }

    public Optional<String> lastError() {
        return Optional.ofNullable(lastError.get());
    }

    public Optional<String> gatewayId() {
        return Optional.ofNullable(gatewayId.get());
    }

    public Optional<String> configRevision() {
        return Optional.ofNullable(configRevision.get());
    }

    public long latencyMillis() {
        return latencyMillis;
    }

    public int heartbeatIntervalSeconds() {
        return heartbeatIntervalSeconds;
    }

    public TransportSettings settings() {
        return settings;
    }

    public CompletableFuture<TargetsView> targets(UserContext user) {
        final ControlMessages.TargetsRequest request = new ControlMessages.TargetsRequest();
        request.user = user;
        return exchange(request, ControlMessages.TargetsResponse.class).thenApply(response -> response.view);
    }

    public CompletableFuture<ControlMessages.ExecuteResponse> execute(ControlMessages.ExecuteRequest request) {
        return exchange(request, ControlMessages.ExecuteResponse.class);
    }

    public CompletableFuture<ControlMessages.StatusResponse> status(UserContext user, List<String> serverIds) {
        final ControlMessages.StatusRequest request = new ControlMessages.StatusRequest();
        request.user = user;
        request.serverIds = serverIds == null ? List.of() : List.copyOf(serverIds);
        return exchange(request, ControlMessages.StatusResponse.class);
    }

    public CompletableFuture<ControlMessages.HistoryResponse> history(UserContext user, String serverId,
                                                                      String username, String commandFragment,
                                                                      String status, int limit, int offset) {
        final ControlMessages.HistoryRequest request = new ControlMessages.HistoryRequest();
        request.user = user;
        request.serverId = blankToNull(serverId);
        request.username = blankToNull(username);
        request.commandFragment = blankToNull(commandFragment);
        request.status = blankToNull(status);
        request.limit = limit;
        request.offset = offset;
        return exchange(request, ControlMessages.HistoryResponse.class);
    }

    public CompletableFuture<ControlMessages.ReloadResponse> reload(UserContext user) {
        final ControlMessages.ReloadRequest request = new ControlMessages.ReloadRequest();
        request.user = user;
        return exchange(request, ControlMessages.ReloadResponse.class);
    }

    public CompletableFuture<ControlMessages.EmergencyResponse> emergency(UserContext user, boolean enabled) {
        final ControlMessages.EmergencyRequest request = new ControlMessages.EmergencyRequest();
        request.user = user;
        request.enabled = enabled;
        return exchange(request, ControlMessages.EmergencyResponse.class);
    }

    public CompletableFuture<PolicySnapshot> policySnapshot(UserContext user) {
        final ControlMessages.ConfigSnapshotRequest request = new ControlMessages.ConfigSnapshotRequest();
        request.user = user;
        return exchange(request, ControlMessages.ConfigSnapshotResponse.class).thenApply(response -> response.policy);
    }

    public CompletableFuture<Long> ping() {
        return transport.ping().whenComplete((latency, error) -> {
            if (error == null && latency != null) {
                latencyMillis = latency;
            }
        });
    }

    /**
     * Blocks on a gateway response, unwrapping the transport exceptions so callers can render a real status.
     */
    public static <T> T join(CompletableFuture<T> future, Duration timeout) {
        try {
            return future.orTimeout(timeout.toMillis(), TimeUnit.MILLISECONDS).join();
        } catch (CompletionException e) {
            final Throwable cause = e.getCause() == null ? e : e.getCause();
            if (cause instanceof CommandException commandException) {
                throw commandException;
            }
            if (cause instanceof RuntimeException runtimeException) {
                throw runtimeException;
            }
            throw new CommandException(ErrorCode.INTERNAL_ERROR, String.valueOf(cause.getMessage()), cause);
        }
    }

    private <T extends Message> CompletableFuture<T> exchange(Message request, Class<T> type) {
        if (!authenticated()) {
            final String detail = lastError.get() == null
                    ? "соединение со шлюзом не аутентифицировано"
                    : "соединение со шлюзом не аутентифицировано: " + lastError.get();
            return CompletableFuture.failedFuture(new CommandException(ErrorCode.CONNECTION_LOST, detail));
        }
        request.setClientId(settings.localClientId());
        final CompletableFuture<Message> future;
        try {
            future = transport.request(request, requestTimeout);
        } catch (RuntimeException e) {
            return CompletableFuture.failedFuture(e);
        }
        return future.thenApply(message -> convert(message, type));
    }

    private <T extends Message> T convert(Message message, Class<T> type) {
        if (message instanceof HandshakeMessages.ErrorMessage error) {
            final ErrorCode code = ErrorTranslator.codeOf(error.code);
            throw new CommandException(code == null ? ErrorCode.PROTOCOL_ERROR : code,
                    error.detail == null ? "шлюз отклонил запрос" : error.detail);
        }
        if (!type.isInstance(message)) {
            throw new CommandException(ErrorCode.PROTOCOL_ERROR, "unexpected response "
                    + MessageTypes.nameOf(message.getClass()) + ", expected " + MessageTypes.nameOf(type));
        }
        return type.cast(message);
    }

    private void keepAlive() {
        if (!authenticated()) {
            return;
        }
        try {
            ping().whenComplete((latency, error) -> {
                if (error != null) {
                    LOGGER.debug("Не удалось отправить keep-alive шлюзу: {}", error.getMessage());
                }
            });
        } catch (RuntimeException e) {
            LOGGER.debug("Keep-alive шлюза пропущен: {}", e.getMessage());
        }
    }

    private void handshake(Connection connection) {
        state.set(GatewayState.HANDSHAKING);
        try {
            final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
            hello.role = "control";
            hello.agentName = BotBuild.AGENT_NAME;
            hello.agentVersion = BotBuild.VERSION;
            hello.platform = platform();
            hello.capabilities = List.of("targets", "execute", "status", "history", "reload", "emergency");
            final HandshakeMessages.HelloAck ack = request(hello, HandshakeMessages.HelloAck.class);
            gatewayId.set(ack.gatewayId);
            configRevision.set(ack.configRevision);
            if (ack.heartbeatIntervalSeconds > 0) {
                heartbeatIntervalSeconds = ack.heartbeatIntervalSeconds;
            }

            final HandshakeMessages.AuthRequest auth = new HandshakeMessages.AuthRequest();
            auth.role = "control";
            auth.challenge = ack.challenge;
            auth.agentVersion = BotBuild.VERSION;
            final HandshakeMessages.AuthResult result = request(auth, HandshakeMessages.AuthResult.class);
            if (!result.authenticated) {
                final String detail = result.errorCode + ": " + result.errorDetail;
                lastError.set(detail);
                state.set(GatewayState.REJECTED);
                LOGGER.error("Шлюз отказал управляющему клиенту '{}': {}", settings.localClientId(), detail);
                connection.close();
                return;
            }
            if (result.gatewayId != null) {
                gatewayId.set(result.gatewayId);
            }
            if (result.configRevision != null) {
                configRevision.set(result.configRevision);
            }
            if (result.heartbeatIntervalSeconds > 0) {
                heartbeatIntervalSeconds = result.heartbeatIntervalSeconds;
            }
            lastError.set(null);
            state.set(GatewayState.AUTHENTICATED);
            authentication.complete(null);
            LOGGER.info("Аутентификация как управляющий клиент '{}' на шлюзе {} (сессия {})", settings.localClientId(),
                    result.gatewayId, result.sessionId);
        } catch (RuntimeException e) {
            lastError.set(e.getMessage());
            state.set(GatewayState.CONNECTING);
            LOGGER.warn("Рукопожатие со шлюзом не удалось: {}", e.getMessage());
            connection.close();
        }
    }

    private <T extends Message> T request(Message message, Class<T> type) {
        try {
            final Message response = transport.request(message, handshakeTimeout)
                    .get(handshakeTimeout.toMillis(), TimeUnit.MILLISECONDS);
            return convert(response, type);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new CommandException(ErrorCode.CONNECTION_LOST, "рукопожатие было прервано");
        } catch (java.util.concurrent.TimeoutException e) {
            throw new CommandException(ErrorCode.TIMEOUT, "шлюз не ответил на рукопожатие вовремя");
        } catch (java.util.concurrent.ExecutionException e) {
            final Throwable cause = e.getCause() == null ? e : e.getCause();
            if (cause instanceof CommandException commandException) {
                throw commandException;
            }
            throw new CommandException(ErrorCode.CONNECTION_LOST,
                    cause.getMessage() == null ? "рукопожатие не удалось" : cause.getMessage());
        }
    }

    private static String platform() {
        return System.getProperty("os.name", "unknown") + " " + System.getProperty("java.version", "unknown");
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    @Override
    public void close() {
        state.set(GatewayState.STOPPED);
        scheduler.shutdownNow();
        transport.close();
        authentication.completeExceptionally(new CommandException(ErrorCode.CONNECTION_LOST, "бот завершает работу"));
    }

    /** Transport callbacks: handshake on connect, health bookkeeping on disconnect. */
    private final class Listener implements TransportClient.Listener {

        @Override
        public void onConnected(Connection connection) {
            LOGGER.debug("Транспорт до шлюза поднят (соединение {})", connection.id());
            Thread.ofVirtual().name("dmc-bot-handshake").start(() -> handshake(connection));
        }

        @Override
        public void onMessage(Connection connection, Message message) {
            if (message instanceof HandshakeMessages.ShutdownNotice shutdown) {
                LOGGER.warn("Шлюз объявил об остановке через {} с: {}", shutdown.graceSeconds, shutdown.reason);
                return;
            }
            if (message instanceof HandshakeMessages.ErrorMessage error) {
                LOGGER.error("Шлюз сообщил об ошибке {}: {}", error.code, error.detail);
            }
        }

        @Override
        public void onDisconnected(Throwable cause) {
            if (state.getAndSet(state.get() == GatewayState.REJECTED ? GatewayState.REJECTED : GatewayState.CONNECTING)
                    != GatewayState.STOPPED) {
                LOGGER.warn("Потеряно соединение со шлюзом{}", cause == null ? "" : ": " + cause.getMessage());
            }
            if (!authentication.isDone()) {
                authentication = new CompletableFuture<>();
            }
        }

        @Override
        public void onViolation(ProtocolException violation) {
            lastError.set(violation.getMessage());
            LOGGER.error("Нарушение протокола шлюза: {}", violation.getMessage());
        }
    }

    static String describeState(GatewayState value) {
        return value.name().toLowerCase(Locale.ROOT);
    }
}
