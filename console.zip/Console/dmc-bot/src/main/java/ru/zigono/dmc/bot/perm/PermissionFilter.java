package ru.zigono.dmc.bot.perm;

import ru.zigono.dmc.bot.config.ChannelPolicy;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.PermissionConfig;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.protocol.dto.TargetsView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * Guild isolation, channel restrictions and ACL resolution of the bot.
 * <p>The gateway authorizes every request again; this filter exists so a user only ever sees targets and
 * controls they may actually use, and so a misuse of the console outside of the configured place is rejected
 * before it leaves Discord.</p>
 *
 * @author Zigono
 */
public final class PermissionFilter {

    /** Outcome of a guild and channel validation. */
    public record GuildCheck(boolean allowed, ErrorCode error, String messageKey, String detail) {

        public static GuildCheck allow() {
            return new GuildCheck(true, null, null, null);
        }

        public static GuildCheck deny(ErrorCode error, String messageKey, String detail) {
            return new GuildCheck(false, Objects.requireNonNull(error, "error"),
                    Objects.requireNonNull(messageKey, "messageKey"), detail);
        }

        public boolean denied() {
            return !allowed;
        }
    }

    private final ChannelPolicy channels;
    private final Set<String> allowedGuilds;
    private final boolean allowDirectMessages;

    /**
     * @param channels            channel restrictions
     * @param allowedGuilds       guilds the bot serves, an empty set means every guild
     * @param allowDirectMessages whether the console may be used in direct messages
     */
    public PermissionFilter(ChannelPolicy channels, Set<String> allowedGuilds, boolean allowDirectMessages) {
        this.channels = Objects.requireNonNull(channels, "channels");
        this.allowedGuilds = Set.copyOf(allowedGuilds == null ? Set.of() : allowedGuilds);
        this.allowDirectMessages = allowDirectMessages;
    }

    public static PermissionFilter of(ChannelPolicy channels, Collection<String> allowedGuilds,
                                      boolean allowDirectMessages) {
        return new PermissionFilter(channels, allowedGuilds == null ? Set.of() : Set.copyOf(allowedGuilds),
                allowDirectMessages);
    }

    /**
     * Validates where an interaction came from.
     *
     * @param fromGuild {@code false} for direct messages
     */
    public GuildCheck check(boolean fromGuild, String guildId, String channelId) {
        if (!fromGuild && !allowDirectMessages) {
            return GuildCheck.deny(ErrorCode.AUTHENTICATION_FAILED, "error.direct_message",
                    "консоль недоступна в личных сообщениях");
        }
        if (guildId != null && !allowsGuild(guildId)) {
            return GuildCheck.deny(ErrorCode.PERMISSION_DENIED, "error.guild_not_allowed",
                    "guild " + guildId + " не обслуживается этим ботом");
        }
        if (!channels.allows(guildId, channelId)) {
            return GuildCheck.deny(ErrorCode.PERMISSION_DENIED, "error.channel_not_allowed",
                    "channel " + channelId + " не разрешён для команд консоли");
        }
        return GuildCheck.allow();
    }

    public boolean allowsGuild(String guildId) {
        return allowedGuilds.isEmpty() || (guildId != null && allowedGuilds.contains(guildId));
    }

    public Set<String> allowedGuilds() {
        return allowedGuilds;
    }

    public ChannelPolicy channels() {
        return channels;
    }

    /**
     * Resolves the effective ACL of a Discord member. Deny always wins, and the guild scoped assignments are
     * additive to the global ones.
     */
    public PermissionSet resolve(PermissionConfig permissions, String guildId, Collection<String> roleIds,
                                 String userId) {
        return permissions.resolve(guildId, roleIds == null ? List.of() : roleIds, userId);
    }

    /** @return only the servers the gateway marked as accessible for this user */
    public static List<TargetsView.ServerOption> accessibleServers(TargetsView view) {
        final List<TargetsView.ServerOption> result = new ArrayList<>();
        for (TargetsView.ServerOption option : view.servers()) {
            if (option.enabled()) {
                result.add(option);
            }
        }
        return List.copyOf(result);
    }

    /** @return only the groups that still contain an accessible server */
    public static List<TargetsView.GroupOption> accessibleGroups(TargetsView view) {
        final Set<String> servers = new LinkedHashSet<>();
        for (TargetsView.ServerOption option : accessibleServers(view)) {
            servers.add(option.id());
        }
        final List<TargetsView.GroupOption> result = new ArrayList<>();
        for (TargetsView.GroupOption group : view.groups()) {
            if (group.servers().stream().anyMatch(servers::contains)) {
                result.add(group);
            }
        }
        return List.copyOf(result);
    }

    public static boolean allows(PermissionSet permissions, String node) {
        return permissions != null && node != null && permissions.allows(node);
    }

    public static boolean allowsAny(PermissionSet permissions, Collection<String> nodes) {
        if (permissions == null || nodes == null) {
            return false;
        }
        for (String node : nodes) {
            if (permissions.allows(node)) {
                return true;
            }
        }
        return false;
    }
}
