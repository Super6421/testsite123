package ru.zigono.dmc.bot;

import ru.zigono.dmc.protocol.ProtocolVersion;

/**
 * Static build information of the Discord bot.
 *
 * @author Zigono
 */
public final class BotBuild {

    /** Human readable name of the component. */
    public static final String NAME = "Discord Minecraft Console Bot";

    /** Version of this build. */
    public static final String VERSION = "1.0.0";

    /** Original author of the project. */
    public static final String AUTHOR = "Zigono";

    /** Agent name advertised during the gateway handshake. */
    public static final String AGENT_NAME = "dmc-bot";

    private BotBuild() {
    }

    public static String describe() {
        return NAME + " " + VERSION + " (protocol " + ProtocolVersion.describe() + ") by " + AUTHOR;
    }
}
