package ru.zigono.dmc.bot.gateway;

/**
 * Lifecycle of the control connection between the bot and the gateway.
 *
 * @author Zigono
 */
public enum GatewayState {

    /** The client has not been started yet or has been closed. */
    STOPPED,
    /** A TCP/TLS connection is being established or is waiting to be established. */
    CONNECTING,
    /** The transport is up and the handshake is in progress. */
    HANDSHAKING,
    /** Hello, challenge and authentication succeeded: requests may be sent. */
    AUTHENTICATED,
    /** The gateway refused the credentials; the transport will retry once the operator fixes the secret. */
    REJECTED;

    public boolean ready() {
        return this == AUTHENTICATED;
    }
}
