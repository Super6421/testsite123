package ru.zigono.dmc.bot.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.config.YamlConfig;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Состояние канала логов: включён он или выключен и куда публиковать записи.
 * <p>Команда {@code /logs channel} меняет его на лету, а маленький файл рядом с конфигурацией бота
 * ({@code logs-channel.yml}) сохраняет выбор между перезапусками сервера. Значение из файла важнее того, что
 * записано в {@code logging.discord.channel_id}: администратор один раз включает логи командой в Discord и
 * больше не правит конфигурацию.</p>
 *
 * @author Zigono
 */
public final class AuditChannelState {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditChannelState.class);

    /** Кавычка выносится в константу: в Java-строке записать её напрямую вместе с текстом нельзя. */
    private static final char QUOTE = 34;

    /** Что произошло после вызова {@code /logs channel}. */
    public enum Outcome {
        ENABLED,
        DISABLED,
        SWITCHED
    }

    private final Path file;
    private volatile boolean enabled;
    private volatile String channelId;

    private AuditChannelState(Path file, boolean enabled, String channelId) {
        this.file = file;
        this.enabled = enabled;
        this.channelId = channelId;
    }

    /**
     * Читает состояние из файла, а когда файла ещё нет — берёт настройку из конфигурации бота.
     *
     * @param file     файл состояния, {@code null} — хранить только в памяти
     * @param fallback канал и признак включённости из конфигурации
     */
    public static AuditChannelState load(Path file, boolean fallbackEnabled, String fallbackChannelId) {
        final String configured = fallbackChannelId == null || fallbackChannelId.isBlank() ? null : fallbackChannelId;
        if (file == null || !Files.isRegularFile(file)) {
            return new AuditChannelState(file, fallbackEnabled && configured != null, configured);
        }
        try {
            final YamlConfig state = YamlConfig.loadOptional(file, false);
            final String stored = state.string("logging.discord.channel_id", "").trim();
            final String channel = stored.isEmpty() ? configured : stored;
            final boolean enabled = state.bool("logging.discord.enabled", fallbackEnabled) && channel != null;
            LOGGER.debug("Канал логов из {}: {} ({})", file.getFileName(), channel, enabled ? "включён" : "выключен");
            return new AuditChannelState(file, enabled, channel);
        } catch (RuntimeException e) {
            LOGGER.warn("Не удалось прочитать {} ({}), беру канал логов из конфигурации", file, e.getMessage());
            return new AuditChannelState(file, fallbackEnabled && configured != null, configured);
        }
    }

    public boolean enabled() {
        return enabled && channelId != null;
    }

    public String channelId() {
        return channelId;
    }

    /**
     * Повторная команда с тем же каналом выключает логи, другой канал — переключает их. Пока логи выключены,
     * вызов с каналом включает их на нём.
     *
     * @param requested канал из команды; {@code null} или пусто — «тот же канал, что и сейчас»
     */
    public synchronized Outcome toggle(String requested) {
        final String wanted = requested == null || requested.isBlank() ? channelId : requested.trim();
        if (wanted == null) {
            throw new IllegalArgumentException("канал логов не указан и ещё ни разу не выбирался");
        }
        final Outcome outcome;
        if (enabled() && wanted.equals(channelId)) {
            enabled = false;
            outcome = Outcome.DISABLED;
        } else if (wanted.equals(channelId)) {
            enabled = true;
            outcome = Outcome.ENABLED;
        } else {
            final boolean wasEnabled = enabled();
            channelId = wanted;
            enabled = true;
            outcome = wasEnabled ? Outcome.SWITCHED : Outcome.ENABLED;
        }
        persist();
        return outcome;
    }

    private void persist() {
        if (file == null) {
            return;
        }
        final String text = "# Канал логов Discord Minecraft Console — автор: Zigono." + System.lineSeparator()
                + "# Файл создан командой /logs channel: правьте канал командой в Discord, а не вручную."
                + System.lineSeparator()
                + "logging:" + System.lineSeparator()
                + "  discord:" + System.lineSeparator()
                + "    enabled: " + enabled + System.lineSeparator()
                + "    channel_id: " + QUOTE + (channelId == null ? "" : channelId) + QUOTE
                + System.lineSeparator();
        try {
            final Path absolute = file.toAbsolutePath().normalize();
            final Path parent = absolute.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(absolute, text, StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException e) {
            LOGGER.warn("Не удалось сохранить канал логов в {}: {}", file, e.getMessage());
        }
    }

    @Override
    public String toString() {
        return "AuditChannelState[enabled=" + enabled() + ", channel=" + channelId + "]";
    }

    /** @return файл состояния, {@code null} когда состояние живёт только в памяти */
    public Path file() {
        return file;
    }
}