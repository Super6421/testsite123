package ru.zigono.dmc.bot.interaction;

import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.components.LayoutComponent;
import net.dv8tion.jda.api.interactions.modals.Modal;
import net.dv8tion.jda.api.utils.FileUpload;
import net.dv8tion.jda.api.utils.messages.MessageEditData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.List;
import java.util.Objects;

/**
 * Shared implementation of {@link InteractionTarget}: every answer goes through the interaction hook, which keeps
 * the flow identical for slash commands, buttons, select menus and modals.
 *
 * @author Zigono
 */
abstract class AbstractInteractionTarget implements InteractionTarget {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractInteractionTarget.class);

    private final UserContext user;
    private final boolean ephemeral;
    private final String interactionId;
    private volatile InteractionHook hook;

    AbstractInteractionTarget(UserContext user, boolean ephemeral, String interactionId) {
        this.user = Objects.requireNonNull(user, "user");
        this.ephemeral = ephemeral;
        this.interactionId = interactionId;
    }

    @Override
    public UserContext user() {
        return user;
    }

    @Override
    public boolean ephemeral() {
        return ephemeral;
    }

    @Override
    public String interactionId() {
        return interactionId;
    }

    protected void hook(InteractionHook value) {
        this.hook = value;
    }

    protected InteractionHook hook() {
        final InteractionHook current = hook;
        if (current == null) {
            throw new IllegalStateException("взаимодействие " + interactionId + " ещё не подтверждено");
        }
        return current;
    }

    @Override
    public void send(MessageEmbed embed, List<LayoutComponent> components) {
        hook().sendMessageEmbeds(embed).addComponents(components).setEphemeral(ephemeral)
                .queue(message -> { }, error -> logFailure("отправить сообщение", error));
    }

    @Override
    public void send(String content) {
        hook().sendMessage(content).setEphemeral(ephemeral)
                .queue(message -> { }, error -> logFailure("отправить сообщение", error));
    }

    @Override
    public void sendAttachment(byte[] content, String fileName, MessageEmbed embed) {
        hook().sendFiles(FileUpload.fromData(content, fileName)).addEmbeds(embed).setEphemeral(ephemeral)
                .queue(message -> { }, error -> logFailure("отправить вложение", error));
    }

    @Override
    public void editMessage(MessageEmbed embed, List<LayoutComponent> components) {
        final String messageId = messageId();
        if (messageId == null) {
            send(embed, components);
            return;
        }
        hook().editMessageById(messageId, MessageEditData.fromEmbeds(embed)).setComponents(components)
                .queue(message -> { }, error -> logFailure("изменить сообщение", error));
    }

    @Override
    public void replyModal(Modal modal) {
        throw new UnsupportedOperationException("взаимодействие " + interactionId + " не может ответить модальным окном");
    }

    /** @return the identifier of the message carrying the component, or {@code null} */
    protected String messageId() {
        return null;
    }

    @Override
    public void logFailure(String what, Throwable error) {
        LOGGER.warn("Не удалось выполнить действие «{}» для взаимодействия {}: {}", what, interactionId,
                error == null ? "неизвестно" : error.getMessage());
    }
}
