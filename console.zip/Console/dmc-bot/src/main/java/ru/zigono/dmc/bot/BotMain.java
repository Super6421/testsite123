package ru.zigono.dmc.bot;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.OutputStreamAppender;
import ch.qos.logback.core.encoder.Encoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.config.BotBootstrap;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.logging.JsonLogEncoder;
import ru.zigono.dmc.protocol.ProtocolVersion;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Command line entry point of the Discord bot.
 * <pre>
 * java -jar dmc-bot.jar run [--config config/bot.yml]
 * java -jar dmc-bot.jar version
 * java -jar dmc-bot.jar help
 * </pre>
 * <p>The bot is a normal long running process: it installs its default files on the first start, connects to the
 * gateway and to Discord, registers the slash commands and then stays in the foreground until it is stopped.</p>
 *
 * @author Zigono
 */
public final class BotMain {

    private static final String DEFAULT_CONFIG = "config/bot.yml";

    private BotMain() {
    }

    public static void main(String[] args) throws Exception {
        final String command = args.length == 0 || args[0].startsWith("-") ? "run" : args[0];
        switch (command) {
            case "run" -> run(args);
            case "version" -> System.out.println(BotBuild.describe());
            case "help", "--help", "-h" -> usage();
            default -> {
                usage();
                System.exit(2);
            }
        }
    }

    private static void run(String[] args) throws Exception {
        final BotBootstrap bootstrap = new BotBootstrap(Path.of(option(args, "--config", DEFAULT_CONFIG)),
                LoggerFactory.getLogger(BotBootstrap.class));
        bootstrap.install();
        final BotConfig probe = BotConfig.load(bootstrap.configFile());
        configureLogRedaction(probe.secretValues());
        final Logger logger = LoggerFactory.getLogger(BotMain.class);
        logger.info("{}", BotBuild.describe());
        logger.info("Загружена конфигурация {} (ревизия {})", bootstrap.configFile(), probe.revision());
        final BotRuntime runtime = new BotRuntime(bootstrap.configFile());
        Runtime.getRuntime().addShutdownHook(new Thread(runtime::close, "dmc-bot-shutdown"));
        try {
            runtime.start();
        } catch (RuntimeException e) {
            logger.error("Бот не запустился: {}", e.getMessage());
            logger.debug("Сбой при запуске", e);
            runtime.close();
            System.exit(1);
        }
        Thread.currentThread().join();
    }

    /**
     * Installs the configured secrets in the log encoder so they are redacted even when they leak into an
     * exception message or a stack trace.
     */
    private static void configureLogRedaction(List<String> secrets) {
        if (!(LoggerFactory.getILoggerFactory() instanceof LoggerContext context)) {
            return;
        }
        final List<String> all = new ArrayList<>(secrets);
        final Iterator<Appender<ILoggingEvent>> appenders = context.getLogger("ROOT").iteratorForAppenders();
        while (appenders.hasNext()) {
            final Appender<ILoggingEvent> appender = appenders.next();
            if (appender instanceof OutputStreamAppender<ILoggingEvent> streamAppender) {
                final Encoder<ILoggingEvent> encoder = streamAppender.getEncoder();
                if (encoder instanceof JsonLogEncoder jsonEncoder) {
                    jsonEncoder.setSecrets(all);
                }
            }
        }
    }

    private static String option(String[] args, String name, String fallback) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(name)) {
                return args[i + 1];
            }
        }
        return fallback;
    }

    private static void usage() {
        System.out.println(BotBuild.describe());
        System.out.println("Protocol version " + ProtocolVersion.describe());
        System.out.println();
        System.out.println("Usage:");
        System.out.println("  run    [--config " + DEFAULT_CONFIG + "]");
        System.out.println("  version");
    }
}
