package ru.zigono.dmc.bot.render;

import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.i18n.Messages;

import java.util.Locale;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Turns error codes into safe, localized descriptions. Internal details are never rendered from here; they are
 * only attached as a separate field, so a stack trace can never reach Discord.
 *
 * @author Zigono
 */
public final class ErrorTranslator {

    private final Supplier<Messages> messages;

    public ErrorTranslator(Supplier<Messages> messages) {
        this.messages = Objects.requireNonNull(messages, "messages");
    }

    public String describe(String codeName) {
        return describe(codeOf(codeName));
    }

    public String describe(ErrorCode code) {
        final ErrorCode effective = code == null ? ErrorCode.INTERNAL_ERROR : code;
        return messages.get().formatOrDefault(effective.messageKey(), effective.name());
    }

    /**
     * @return the localized description of a failure, preferring the specific message key carried by the
     * exception over the generic error code
     */
    public String describe(Throwable throwable) {
        if (throwable instanceof CommandException commandException) {
            final String key = commandException.arguments().getOrDefault("key", commandException.code().messageKey());
            return messages.get().formatOrDefault(key, describe(commandException.code()));
        }
        return describe(ErrorCode.INTERNAL_ERROR);
    }

    /**
     * @return a retry hint for the error, or an empty string when retrying is pointless
     */
    public String hint(ErrorCode code) {
        final ErrorCode effective = code == null ? ErrorCode.INTERNAL_ERROR : code;
        if (!effective.retryable()) {
            return "";
        }
        return messages.get().formatOrDefault("error.retry_hint." + effective.name(), "");
    }

    public static ErrorCode codeOf(String name) {
        if (name == null || name.isBlank()) {
            return null;
        }
        try {
            return ErrorCode.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return ErrorCode.INTERNAL_ERROR;
        }
    }
}
