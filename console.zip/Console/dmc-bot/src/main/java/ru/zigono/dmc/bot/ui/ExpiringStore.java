package ru.zigono.dmc.bot.ui;

import java.time.Clock;
import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.ToLongFunction;

/**
 * Small bounded store of short lived interaction state. Every entry carries the epoch millisecond at which it
 * expires; expired entries are dropped lazily, when the capacity is reached and by the periodic purge.
 *
 * @author Zigono
 */
final class ExpiringStore<T> {

    private final ConcurrentMap<String, T> entries = new ConcurrentHashMap<>();
    private final Clock clock;
    private final Duration ttl;
    private final int maxEntries;
    private final ToLongFunction<T> expiry;

    ExpiringStore(Clock clock, Duration ttl, int maxEntries, ToLongFunction<T> expiry) {
        this.clock = Objects.requireNonNull(clock, "clock");
        this.ttl = Objects.requireNonNull(ttl, "ttl");
        this.maxEntries = Math.max(1, maxEntries);
        this.expiry = Objects.requireNonNull(expiry, "expiry");
    }

    long now() {
        return clock.millis();
    }

    long expiresAt(long createdAt) {
        return createdAt + ttl.toMillis();
    }

    Duration ttl() {
        return ttl;
    }

    void put(String key, T value) {
        purgeExpired();
        if (entries.size() >= maxEntries) {
            evictOldest();
        }
        entries.put(key, value);
    }

    /** @return the entry when it exists and has not expired; expired entries are removed */
    Optional<T> get(String key) {
        if (key == null) {
            return Optional.empty();
        }
        final T value = entries.get(key);
        if (value == null) {
            return Optional.empty();
        }
        if (expired(value)) {
            entries.remove(key, value);
            return Optional.empty();
        }
        return Optional.of(value);
    }

    /** @return the entry even when it has expired, used to distinguish "unknown" from "expired" */
    Optional<T> peek(String key) {
        return key == null ? Optional.empty() : Optional.ofNullable(entries.get(key));
    }

    void remove(String key) {
        if (key != null) {
            entries.remove(key);
        }
    }

    boolean expired(T value) {
        return now() >= expiry.applyAsLong(value);
    }

    int purgeExpired() {
        int removed = 0;
        for (Map.Entry<String, T> entry : entries.entrySet()) {
            if (expired(entry.getValue()) && entries.remove(entry.getKey(), entry.getValue())) {
                removed++;
            }
        }
        return removed;
    }

    int size() {
        return entries.size();
    }

    void clear() {
        entries.clear();
    }

    private void evictOldest() {
        String oldestKey = null;
        long oldestExpiry = Long.MAX_VALUE;
        for (Map.Entry<String, T> entry : entries.entrySet()) {
            final long candidate = expiry.applyAsLong(entry.getValue());
            if (candidate < oldestExpiry) {
                oldestExpiry = candidate;
                oldestKey = entry.getKey();
            }
        }
        if (oldestKey != null) {
            entries.remove(oldestKey);
        }
    }
}
