package ru.zigono.dmc.bot.ui;

import net.dv8tion.jda.api.interactions.components.ActionRow;
import net.dv8tion.jda.api.interactions.components.ItemComponent;
import net.dv8tion.jda.api.interactions.components.LayoutComponent;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.interactions.components.selections.SelectOption;
import net.dv8tion.jda.api.interactions.components.selections.StringSelectMenu;
import net.dv8tion.jda.api.interactions.components.text.TextInput;
import net.dv8tion.jda.api.interactions.components.text.TextInputStyle;
import net.dv8tion.jda.api.interactions.modals.Modal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.target.TargetSelectionParser;
import ru.zigono.dmc.bot.target.TargetValue;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.common.text.Text;
import ru.zigono.dmc.protocol.dto.TargetsView;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Interactive components of the bot: select menus, buttons and modals. Every component carries a nonce and never
 * user input, so a component can only ever refer to state the bot itself stored.
 *
 * @author Zigono
 */
public final class DiscordComponents {

    private static final Logger LOGGER = LoggerFactory.getLogger(DiscordComponents.class);

    /** Discord allows at most 25 options in a select menu. */
    public static final int MAX_SELECT_OPTIONS = 25;
    private static final int MAX_LABEL = 100;
    private static final int MAX_VALUE = 100;

    private DiscordComponents() {
    }

    /**
     * Target selector of the console panel: every accessible server, every accessible group and, when the user
     * owns the capability, the broadcast to every server.
     */
    public static StringSelectMenu targetMenu(Supplier<Messages> messages, TargetsView view, String nonce) {
        final Messages current = messages.get();
        final StringSelectMenu.Builder builder = StringSelectMenu.create(CustomId.panelTarget(nonce))
                .setPlaceholder(Text.truncate(current.format("ui.select.target_placeholder"), MAX_LABEL))
                .setMinValues(1)
                .setMaxValues(1);
        final List<SelectOption> options = new ArrayList<>();
        for (TargetsView.ServerOption server : TargetSelectionParser.accessibleServers(view)) {
            options.add(SelectOption.of(Text.truncate(server.name(), MAX_LABEL),
                            Text.truncate(TargetValue.server(server.id()), MAX_VALUE))
                    .withDescription(Text.truncate(current.formatOrDefault("status.label." + server.status(),
                            String.valueOf(server.status())), MAX_LABEL)));
        }
        for (TargetsView.GroupOption group : view.groups()) {
            if (group.servers().isEmpty()) {
                continue;
            }
            options.add(SelectOption.of(Text.truncate(current.format("ui.select.group_option", group.name()), MAX_LABEL),
                            Text.truncate(TargetValue.group(group.name()), MAX_VALUE))
                    .withDescription(Text.truncate(current.format("ui.select.group_description",
                            group.servers().size()), MAX_LABEL)));
        }
        if (view.capabilities().broadcastAll()) {
            options.add(SelectOption.of(Text.truncate(current.format("ui.select.all_servers"), MAX_LABEL),
                            TargetValue.all())
                    .withDescription(Text.truncate(current.format("ui.select.all_servers_description"), MAX_LABEL)));
        }
        if (options.size() > MAX_SELECT_OPTIONS) {
            LOGGER.warn("Пользователь может указать {} целей, в селекторе показаны только первые {}",
                    options.size(), MAX_SELECT_OPTIONS);
        }
        builder.addOptions(options.subList(0, Math.min(MAX_SELECT_OPTIONS, options.size())));
        return builder.build();
    }

    public static Button executeButton(Supplier<Messages> messages, String nonce) {
        return Button.primary(CustomId.panelExecute(nonce), Text.truncate(messages.get().format("ui.button.execute"), 80));
    }

    public static Button confirmButton(Supplier<Messages> messages, String nonce) {
        return Button.success(CustomId.confirm(nonce), Text.truncate(messages.get().format("ui.button.confirm"), 80));
    }

    public static Button cancelButton(Supplier<Messages> messages, String nonce) {
        return Button.danger(CustomId.cancel(nonce), Text.truncate(messages.get().format("ui.button.cancel"), 80));
    }

    public static LayoutComponent confirmationRow(Supplier<Messages> messages, String nonce) {
        return row(confirmButton(messages, nonce), cancelButton(messages, nonce));
    }

    public static Modal commandModal(Supplier<Messages> messages, String nonce, int maxLength) {
        final Messages current = messages.get();
        final TextInput input = TextInput.create("command", Text.truncate(current.format("ui.modal.command_label"), 45),
                        TextInputStyle.SHORT)
                .setRequired(true)
                .setMinLength(1)
                .setMaxLength(Math.max(1, Math.min(maxLength, TextInput.MAX_VALUE_LENGTH)))
                .setPlaceholder(Text.truncate(current.format("ui.modal.command_placeholder"), 100))
                .build();
        return Modal.create(CustomId.panelModal(nonce), Text.truncate(current.format("ui.modal.command_title"), 45))
                .addComponents(ActionRow.of(input))
                .build();
    }

    /**
     * Pagination row of the history view: the buttons are disabled at the edges and only rendered when a second
     * page exists.
     */
    public static LayoutComponent historyRow(Supplier<Messages> messages, String nonce, int offset, int pageSize,
                                             long total) {
        final Messages current = messages.get();
        final int previous = Math.max(0, offset - pageSize);
        final int next = offset + pageSize;
        final boolean hasPrevious = offset > 0;
        final boolean hasNext = next < total;
        final Button previousButton = Button.secondary(CustomId.historyPage(nonce, previous),
                        Text.truncate(current.format("ui.button.previous"), 80))
                .withDisabled(!hasPrevious);
        final Button nextButton = Button.secondary(CustomId.historyPage(nonce, next),
                        Text.truncate(current.format("ui.button.next"), 80))
                .withDisabled(!hasNext);
        return row(previousButton, nextButton);
    }

    public static LayoutComponent row(ItemComponent... items) {
        return ActionRow.of(items);
    }

    public static List<LayoutComponent> rows(LayoutComponent... rows) {
        return List.of(rows);
    }
}
