package ru.zigono.dmc.bot.render;

import java.util.List;
import java.util.Objects;

/**
 * Minecraft output prepared for Discord: the sanitized text, the chunks it has to be split into and, when the
 * output is too large, the file that carries it.
 * <p>An empty chunk list means the text fits into a single embed description. The attachment array is compared
 * by identity, which is intentional: instances are never used as map keys.</p>
 *
 * @author Zigono
 */
public record RenderedResponse(String text, List<String> chunks, byte[] attachment, String attachmentName,
                               boolean empty) {

    public RenderedResponse {
        text = text == null ? "" : text;
        chunks = chunks == null ? List.of() : List.copyOf(chunks);
        Objects.requireNonNull(attachmentName == null ? "" : attachmentName, "attachmentName");
    }

    public static RenderedResponse empty(String text) {
        return new RenderedResponse(text, List.of(), null, "", true);
    }

    public boolean hasAttachment() {
        return attachment != null && attachment.length > 0;
    }

    /** @return {@code true} when the whole output fits into the embed description */
    public boolean embeddable() {
        return !hasAttachment() && chunks.isEmpty();
    }

    public boolean singleMessage() {
        return !hasAttachment() && chunks.size() <= 1;
    }

    public int length() {
        return text.length();
    }

    public int lineCount() {
        if (text.isEmpty()) {
            return 0;
        }
        int lines = 1;
        for (int index = 0; index < text.length(); index++) {
            if (text.charAt(index) == '\n') {
                lines++;
            }
        }
        return lines;
    }
}
