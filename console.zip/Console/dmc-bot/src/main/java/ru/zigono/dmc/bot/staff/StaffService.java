package ru.zigono.dmc.bot.staff;

import ru.zigono.dmc.common.errors.ErrorCode;

import java.util.List;

/**
 * Применение привилегии на стороне сервера Minecraft.
 * <p>Привилегия живёт в LuckPerms, а LuckPerms есть только у плагина, поэтому реализацию этого интерфейса
 * даёт плагин: в одиночном («embedded») режиме он передаёт её боту при запуске. Если реализации нет, команды
 * {@code /персонал-выдать} и {@code /персонал-снять} честно сообщают, что выдача привилегий недоступна,
 * вместо того чтобы делать вид, что команда выполнена.</p>
 *
 * @author Zigono
 */
public interface StaffService {

    /** Что именно делает команда. */
    enum Action {
        GRANT,
        REMOVE
    }

    /**
     * Запрос на изменение привилегии.
     *
     * @param actorRoleIds роли Discord того, кто выдаёт: иерархия описана ролями, а не правами консоли
     */
    record Request(Action action, String target, String rankKey, String reason, List<String> actorRoleIds,
                   String actorId, String actorName, String guildId, String channelId) {

        public Request {
            actorRoleIds = actorRoleIds == null ? List.of() : List.copyOf(actorRoleIds);
        }
    }

    /**
     * Результат изменения привилегии.
     *
     * @param changed {@code false}, когда у игрока уже было (или уже не было) это значение: ошибки нет, но и
     *                менять было нечего
     */
    record Result(boolean success, boolean changed, ErrorCode error, String errorDetail, String target,
                  String rankKey, String rankName, String group, String primaryBefore, String primaryAfter) {

        public static Result success(Request request, String rankName, String group, boolean changed,
                                     String primaryBefore, String primaryAfter) {
            return new Result(true, changed, null, null, request.target(), request.rankKey(), rankName, group,
                    primaryBefore, primaryAfter);
        }

        public static Result failure(Request request, ErrorCode error, String detail) {
            return new Result(false, false, error, detail, request.target(), request.rankKey(), null, null, null, null);
        }

        public static Result failure(Request request, ErrorCode error, String detail, String rankName, String group) {
            return new Result(false, false, error, detail, request.target(), request.rankKey(), rankName, group,
                    null, null);
        }
    }

    /** @return {@code true}, когда выдача привилегий доступна в этом режиме работы */
    boolean available();

    /** @return причина недоступности: готовая фраза для пользователя */
    String unavailableReason();

    /** Применяет привилегию. Метод блокирующий: он вызывается на виртуальном потоке бота. */
    Result apply(Request request);
}