package ru.zigono.dmc.bot.config;

import ru.zigono.dmc.common.config.YamlConfig;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Channel restrictions of the console: which channels may be used, globally and per guild.
 * <p>Deny always wins. A non empty per guild allow list replaces the global allow list, so one guild can
 * narrow or extend the global policy without touching the other guilds.</p>
 *
 * @author Zigono
 */
public final class ChannelPolicy {

    private final Set<String> globalAllowed;
    private final Set<String> globalDenied;
    private final Map<String, Set<String>> guildAllowed;
    private final Map<String, Set<String>> guildDenied;

    private ChannelPolicy(Set<String> globalAllowed, Set<String> globalDenied,
                          Map<String, Set<String>> guildAllowed, Map<String, Set<String>> guildDenied) {
        this.globalAllowed = globalAllowed;
        this.globalDenied = globalDenied;
        this.guildAllowed = guildAllowed;
        this.guildDenied = guildDenied;
    }

    /**
     * @param root     the full configuration document
     * @param guildIds guilds the bot is configured for
     */
    public static ChannelPolicy from(YamlConfig root, Set<String> guildIds) {
        final YamlConfig global = root.section("channels");
        final Set<String> allowed = new LinkedHashSet<>(global.stringList("allowed", List.of()));
        final Set<String> denied = new LinkedHashSet<>(global.stringList("denied", List.of()));
        final Map<String, Set<String>> perGuildAllowed = new LinkedHashMap<>();
        final Map<String, Set<String>> perGuildDenied = new LinkedHashMap<>();
        for (String guildId : guildIds) {
            perGuildAllowed.put(guildId, Set.copyOf(
                    root.stringList("guilds." + guildId + ".channels.allowed", List.of())));
            perGuildDenied.put(guildId, Set.copyOf(
                    root.stringList("guilds." + guildId + ".channels.denied", List.of())));
        }
        return new ChannelPolicy(Set.copyOf(allowed), Set.copyOf(denied),
                Map.copyOf(perGuildAllowed), Map.copyOf(perGuildDenied));
    }

    public static ChannelPolicy unrestricted() {
        return new ChannelPolicy(Set.of(), Set.of(), Map.of(), Map.of());
    }

    /**
     * @return {@code true} when the channel may be used for console commands
     */
    public boolean allows(String guildId, String channelId) {
        if (channelId == null || channelId.isBlank()) {
            return !restricted() && globalDenied.isEmpty();
        }
        if (globalDenied.contains(channelId)) {
            return false;
        }
        if (guildId != null && guildDenied.getOrDefault(guildId, Set.of()).contains(channelId)) {
            return false;
        }
        final Set<String> allowed = guildId == null ? Set.of() : guildAllowed.getOrDefault(guildId, Set.of());
        final Set<String> effective = allowed.isEmpty() ? globalAllowed : allowed;
        return effective.isEmpty() || effective.contains(channelId);
    }

    public Set<String> allowedChannels(String guildId) {
        final Set<String> allowed = guildId == null ? Set.of() : guildAllowed.getOrDefault(guildId, Set.of());
        return allowed.isEmpty() ? globalAllowed : allowed;
    }

    public Set<String> deniedChannels(String guildId) {
        final Set<String> denied = new LinkedHashSet<>(globalDenied);
        if (guildId != null) {
            denied.addAll(guildDenied.getOrDefault(guildId, Set.of()));
        }
        return Set.copyOf(denied);
    }

    /**
     * @return {@code true} when at least one channel allow list is configured
     */
    public boolean restricted() {
        return !globalAllowed.isEmpty() || !guildAllowed.values().stream().allMatch(Set::isEmpty);
    }
}
