package ru.zigono.dmc.bot.gateway;

import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Short lived cache of the permission aware target view. Autocomplete and the interactive panel ask for the view
 * very often, and the answer only changes when the configuration or the ACL changes, so it is cached per identity
 * for a few seconds instead of being requested for every keystroke.
 *
 * @author Zigono
 */
public final class TargetsViewCache {

    private record Entry(TargetsView view, long expiresAt) {
    }

    private final GatewayClient gateway;
    private final Duration timeout;
    private final Duration ttl;
    private final Map<String, Entry> entries = new ConcurrentHashMap<>();

    public TargetsViewCache(GatewayClient gateway, Duration timeout, Duration ttl) {
        this.gateway = Objects.requireNonNull(gateway, "gateway");
        this.timeout = Objects.requireNonNull(timeout, "timeout");
        this.ttl = Objects.requireNonNull(ttl, "ttl");
    }

    /** @return the view of the user, from the cache when it is still fresh */
    public TargetsView get(UserContext user) {
        final String key = key(user);
        final Entry cached = entries.get(key);
        final long now = System.currentTimeMillis();
        if (cached != null && cached.expiresAt() > now) {
            return cached.view();
        }
        final TargetsView view = GatewayClient.join(gateway.targets(user), timeout);
        entries.put(key, new Entry(view, now + ttl.toMillis()));
        return view;
    }

    /** Drops every cached view, for example after a configuration reload. */
    public void invalidate() {
        entries.clear();
    }

    public int size() {
        return entries.size();
    }

    private static String key(UserContext user) {
        return user.userId() + "|" + user.guildId() + "|" + String.join(",", user.roleIds()) + "|"
                + String.join(",", user.permissions()) + "|" + String.join(",", user.deniedPermissions());
    }
}
