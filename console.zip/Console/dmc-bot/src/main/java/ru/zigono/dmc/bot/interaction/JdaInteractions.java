package ru.zigono.dmc.bot.interaction;

import net.dv8tion.jda.api.events.interaction.GenericInteractionCreateEvent;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.GenericComponentInteractionCreateEvent;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.modals.Modal;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.Objects;

/**
 * Adapts the JDA interaction types to {@link InteractionTarget}.
 *
 * @author Zigono
 */
public final class JdaInteractions {

    private JdaInteractions() {
    }

    public static InteractionTarget of(SlashCommandInteractionEvent event, UserContext user, boolean ephemeral) {
        return new SlashTarget(event, user, ephemeral);
    }

    public static InteractionTarget of(GenericComponentInteractionCreateEvent event, UserContext user,
                                       boolean ephemeral) {
        return new ComponentTarget(event, user, ephemeral);
    }

    public static InteractionTarget of(ModalInteractionEvent event, UserContext user, boolean ephemeral) {
        return new ModalTarget(event, user, ephemeral);
    }

    public static InteractionTarget of(GenericInteractionCreateEvent event, UserContext user, boolean ephemeral) {
        if (event instanceof SlashCommandInteractionEvent slash) {
            return of(slash, user, ephemeral);
        }
        if (event instanceof GenericComponentInteractionCreateEvent component) {
            return of(component, user, ephemeral);
        }
        if (event instanceof ModalInteractionEvent modal) {
            return of(modal, user, ephemeral);
        }
        throw new IllegalArgumentException("неподдерживаемый тип взаимодействия " + event.getClass().getSimpleName());
    }

    /** Slash commands always answer with a new message. */
    private static final class SlashTarget extends AbstractInteractionTarget {

        private final SlashCommandInteractionEvent event;

        private SlashTarget(SlashCommandInteractionEvent event, UserContext user, boolean ephemeral) {
            super(user, ephemeral, event.getId());
            this.event = Objects.requireNonNull(event, "event");
        }

        @Override
        public void acknowledgeReply() {
            hook(event.deferReply(ephemeral()).complete());
        }

        @Override
        public void acknowledgeEdit() {
            acknowledgeReply();
        }
    }

    /** Buttons and select menus may either answer with a new message or update their own message. */
    private static final class ComponentTarget extends AbstractInteractionTarget {

        private final GenericComponentInteractionCreateEvent event;

        private ComponentTarget(GenericComponentInteractionCreateEvent event, UserContext user, boolean ephemeral) {
            super(user, ephemeral, event.getId());
            this.event = Objects.requireNonNull(event, "event");
        }

        @Override
        public void acknowledgeReply() {
            hook(event.deferReply(ephemeral()).complete());
        }

        @Override
        public void acknowledgeEdit() {
            hook(event.deferEdit().complete());
        }

        @Override
        protected String messageId() {
            return event.getMessageId();
        }

        @Override
        public void replyModal(Modal modal) {
            event.replyModal(modal).queue(message -> { }, error -> logFailure("открыть модальное окно", error));
        }
    }

    /** Modal submissions answer with a new message. */
    private static final class ModalTarget extends AbstractInteractionTarget {

        private final ModalInteractionEvent event;

        private ModalTarget(ModalInteractionEvent event, UserContext user, boolean ephemeral) {
            super(user, ephemeral, event.getId());
            this.event = Objects.requireNonNull(event, "event");
        }

        @Override
        public void acknowledgeReply() {
            hook(event.deferReply(ephemeral()).complete());
        }

        @Override
        public void acknowledgeEdit() {
            acknowledgeReply();
        }
    }
}
