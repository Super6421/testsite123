const fs = require("fs");
for (const p of ["dmc-common/src/test/java/ru/zigono/dmc/common/perm/PermissionConfigSyntaxTest.java","dmc-plugin/src/test/java/ru/zigono/dmc/plugin/config/ExampleConfigTest.java"]) {
  console.log("========== " + p);
  console.log(fs.readFileSync(p,"utf8"));
}