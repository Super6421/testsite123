const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/java/ru/zigono/dmc/plugin/embedded/EmbeddedConfigWriter.java","utf8");
console.log("lines=" + t.split("\n").length);
console.log(t);