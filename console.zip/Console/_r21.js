const fs = require("fs");
const c = fs.readFileSync("docs/CONFIGURATION.md","utf8").split("\n");
console.log("=== CONFIGURATION 88-104 ===");
console.log(c.slice(87,104).map((l,i)=>(88+i)+": "+l).join("\n"));
console.log("=== CONFIGURATION 377-450 ===");
console.log(c.slice(376,450).map((l,i)=>(377+i)+": "+l).join("\n"));