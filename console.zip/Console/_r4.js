const fs = require("fs");
for (const p of ["dmc-common/src/main/java/ru/zigono/dmc/common/perm/PermissionConfig.java"]) {
  const t = fs.readFileSync(p,"utf8");
  console.log("===== " + p + " (" + t.split("\n").length + " lines)");
  console.log(t);
}