const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/command/CommandPolicyEngine.java","utf8").split("\n");
console.log(t.slice(118, 152).map((l,i)=>(119+i)+": "+l).join("\n"));