const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/staff/StaffConfig.java","utf8").split("\n");
const i = t.findIndex(l => /private static List<Rank> parseRanks/.test(l));
console.log(t.slice(i, i+40).map((l,k)=>(i+1+k)+": "+l).join("\n"));