const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/staff/StaffConfig.java","utf8").split("\n");
const i = t.findIndex(l => l.includes("parseRanks"));
console.log(t.slice(i-2, i+45).map((l,k)=>(i-1+k)+": "+l).join("\n"));