const fs = require("fs");
const p = fs.readFileSync("docs/PERMISSIONS.md","utf8").split("\n");
console.log("=== PERMISSIONS 146-192 ===");
console.log(p.slice(145,192).map((l,i)=>(146+i)+": "+l).join("\n"));
const i = fs.readFileSync("docs/INSTALLATION.md","utf8").split("\n");
console.log("=== INSTALLATION 42-136 ===");
console.log(i.slice(41,136).map((l,k)=>(42+k)+": "+l).join("\n"));