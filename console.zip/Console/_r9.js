const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/java/ru/zigono/dmc/plugin/execution/PluginPolicy.java","utf8");
console.log(t);