package ru.zigono.dmc.protocol;

import ru.zigono.dmc.common.errors.ErrorCode;

/**
 * Protocol level failure: invalid signature, replayed request, unsupported version, malformed frame.
 * Every instance carries the error code reported to the caller and a detail string used for internal logs only.
 *
 * @author Zigono
 */
public class ProtocolException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Why the message was refused. Callers use it to attribute the rejection to the right metric and audit
     * event without parsing the detail string.
     */
    public enum Reason {
        PROTOCOL,
        AUTHENTICATION,
        REPLAY,
        TIMESTAMP
    }

    private final ErrorCode code;
    private final Reason reason;

    public ProtocolException(ErrorCode code, String detail) {
        this(code, defaultReason(code), detail, null);
    }

    public ProtocolException(ErrorCode code, String detail, Throwable cause) {
        this(code, defaultReason(code), detail, cause);
    }

    public ProtocolException(ErrorCode code, Reason reason, String detail) {
        this(code, reason, detail, null);
    }

    public ProtocolException(ErrorCode code, Reason reason, String detail, Throwable cause) {
        super(detail, cause);
        this.code = code;
        this.reason = reason;
    }

    private static Reason defaultReason(ErrorCode code) {
        return code == ErrorCode.AUTHENTICATION_FAILED ? Reason.AUTHENTICATION : Reason.PROTOCOL;
    }

    public ErrorCode code() {
        return code;
    }

    public Reason reason() {
        return reason;
    }

    public static ProtocolException authentication(String detail) {
        return new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, Reason.AUTHENTICATION, detail);
    }

    public static ProtocolException identity(String detail) {
        return new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, Reason.AUTHENTICATION, detail);
    }

    public static ProtocolException signature(String detail) {
        return new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, Reason.AUTHENTICATION, detail);
    }

    public static ProtocolException replay(String detail) {
        return new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, Reason.REPLAY, detail);
    }

    public static ProtocolException timestamp(String detail) {
        return new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, Reason.TIMESTAMP, detail);
    }

    public static ProtocolException malformed(String detail) {
        return new ProtocolException(ErrorCode.PROTOCOL_ERROR, Reason.PROTOCOL, detail);
    }
}