package ru.zigono.dmc.protocol.transport;

import ru.zigono.dmc.protocol.Message;

import java.util.Map;

/**
 * One established transport connection, either from a Minecraft plugin or from the Discord bot.
 *
 * @author Zigono
 */
public interface Connection {

    /** Stable identifier of the connection, used in logs and security audit records. */
    String id();

    /** Remote address of the peer. */
    String remoteAddress();

    /** @return {@code true} while the underlying channel is active */
    boolean open();

    /** Queues a message for delivery. */
    void send(Message message);

    /** Closes the connection without waiting for pending writes. */
    void close();

    /** Identity claimed and authenticated on this connection, {@code null} before authentication. */
    String clientId();

    /** Binds the connection to an authenticated identity, so no other identity can be used on it. */
    void bind(String clientId);

    /** Role of the peer: {@code plugin} or {@code control}. */
    String role();

    void setRole(String role);

    /** Epoch millis when the connection was opened. */
    long connectedAt();

    /** Mutable per connection attributes, for example the current session id or latency. */
    Map<String, Object> attributes();

    /** @return round trip latency in milliseconds, or {@code -1} when unknown */
    long latencyMillis();

    void setLatencyMillis(long latency);
}