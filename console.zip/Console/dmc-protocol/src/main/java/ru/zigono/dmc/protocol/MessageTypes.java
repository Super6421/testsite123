package ru.zigono.dmc.protocol;

import com.fasterxml.jackson.annotation.JsonSubTypes;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Maps message classes to their wire names, derived from {@link JsonSubTypes} so the two can never drift apart.
 *
 * @author Zigono
 */
public final class MessageTypes {

    private static final Map<Class<?>, String> NAMES = new LinkedHashMap<>();

    static {
        final JsonSubTypes subtypes = Message.class.getAnnotation(JsonSubTypes.class);
        if (subtypes != null) {
            for (JsonSubTypes.Type type : subtypes.value()) {
                NAMES.put(type.value(), type.name());
            }
        }
    }

    private MessageTypes() {
    }

    public static String nameOf(Class<?> type) {
        return NAMES.getOrDefault(type, type.getSimpleName().toUpperCase(java.util.Locale.ROOT));
    }

    public static Map<Class<?>, String> all() {
        return Map.copyOf(NAMES);
    }
}