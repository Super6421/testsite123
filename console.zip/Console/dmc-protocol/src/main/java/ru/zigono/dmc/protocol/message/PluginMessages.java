package ru.zigono.dmc.protocol.message;

import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;

/**
 * Messages exchanged between the gateway and a Minecraft plugin.
 *
 * @author Zigono
 */
public final class PluginMessages {

    private PluginMessages() {
    }

    /** Periodic status report of a Minecraft server. */
    public static final class Heartbeat extends Message {
        public ServerMetrics metrics;
        public int queuedCommands;
        public long lastCommandAt;
        public String status;
        public long sequence;
    }

    /** Acknowledges a heartbeat and can adjust the interval. */
    public static final class HeartbeatAck extends Message {
        public int heartbeatIntervalSeconds;
        public long serverTime;
        public long sequence;
    }

    /** Command to execute on the Minecraft server. */
    public static final class CommandDispatch extends Message {
        public String serverId;
        public String command;
        public String targetDescription;
        public UserContext issuer;
        public CommandVisibility visibility;
        public long issuedAt;
        public long timeoutMillis;
        public boolean dryRun;
        public int attempt;
    }

    /**
     * Sent by the plugin the moment it takes a command from the connection, before it reaches the Minecraft
     * main thread. The gateway uses it to decide whether a retry is safe: a command that was never accepted
     * can be retried, a command that was accepted never is.
     */
    public static final class CommandAccepted extends Message {
        public String serverId;
        public boolean accepted;
        public String reason;
        public long acceptedAt;
        public long queuedMillis;
    }

    /** Real result of an execution, produced by the Minecraft server console. */
    public static final class CommandOutcomeMessage extends Message {
        public String serverId;
        public String command;
        public ServerOutcome outcome;
    }
}