package ru.zigono.dmc.protocol;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import ru.zigono.dmc.common.util.Hashing;
import ru.zigono.dmc.common.util.Json;

import java.nio.charset.StandardCharsets;

/**
 * HMAC-SHA256 request signing. The signature covers the message envelope and payload: the canonical form is the
 * compact JSON representation of the message without the {@code signature} field, so any modification of the
 * type, identity, request id, timestamp, nonce or payload invalidates it.
 *
 * @author Zigono
 */
public final class MessageSigner {

    public static final String SIGNATURE_FIELD = "signature";

    private MessageSigner() {
    }

    public static String canonical(Message message) {
        final JsonNode node = Json.mapper().valueToTree(message);
        if (node instanceof ObjectNode object) {
            object.remove(SIGNATURE_FIELD);
        }
        return node.toString();
    }

    public static void sign(Message message, byte[] key) {
        final String canonical = canonical(message);
        message.setSignature(Hashing.hex(Hashing.hmacSha256(key, canonical.getBytes(StandardCharsets.UTF_8))));
    }

    public static boolean verify(Message message, byte[] key) {
        final String signature = message.getSignature();
        if (signature == null || signature.isBlank()) {
            return false;
        }
        final String canonical = canonical(message);
        final byte[] expected = Hashing.hmacSha256(key, canonical.getBytes(StandardCharsets.UTF_8));
        final byte[] provided;
        try {
            provided = Hashing.fromHex(signature);
        } catch (IllegalArgumentException e) {
            return false;
        }
        return Hashing.constantTimeEquals(expected, provided);
    }
}