package ru.zigono.dmc.protocol.dto;

import ru.zigono.dmc.common.target.TargetSpec;

import java.util.List;

/**
 * Wire representation of a target selector sent by the bot.
 *
 * @author Zigono
 */
public record TargetSelection(String server, List<String> servers, String group, boolean all) {

    public TargetSelection {
        servers = servers == null ? List.of() : List.copyOf(servers);
    }

    public static TargetSelection from(TargetSpec spec) {
        return new TargetSelection(spec.server(), spec.servers(), spec.group(), spec.broadcastAll());
    }

    public TargetSpec toSpec() {
        return new TargetSpec(server, servers, group, all);
    }

    public String describe() {
        return toSpec().describe();
    }
}