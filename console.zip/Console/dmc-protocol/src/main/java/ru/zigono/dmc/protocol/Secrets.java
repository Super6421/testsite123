package ru.zigono.dmc.protocol;

import ru.zigono.dmc.common.util.Hashing;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Decodes shared secrets. Plain values are used as UTF-8 bytes, {@code hex:...} and {@code base64:...} prefixes
 * allow binary secrets. Secrets shorter than the configured minimum are rejected at startup.
 *
 * @author Zigono
 */
public final class Secrets {

    public static final int MIN_LENGTH = 16;

    private Secrets() {
    }

    public static byte[] decode(String value, String owner) {
        if (value == null || value.isBlank()) {
            throw new ProtocolException(ru.zigono.dmc.common.errors.ErrorCode.CONFIGURATION_ERROR,
                    "не задан секрет для " + owner);
        }
        final String trimmed = value.trim();
        final byte[] result;
        if (trimmed.startsWith("hex:")) {
            result = Hashing.fromHex(trimmed.substring(4).trim());
        } else if (trimmed.startsWith("base64:")) {
            result = Base64.getDecoder().decode(trimmed.substring(7).trim());
        } else {
            result = trimmed.getBytes(StandardCharsets.UTF_8);
        }
        if (result.length < MIN_LENGTH) {
            throw new ProtocolException(ru.zigono.dmc.common.errors.ErrorCode.CONFIGURATION_ERROR,
                    "секрет для " + owner + " должен быть не короче " + MIN_LENGTH + " bytes long");
        }
        return result;
    }

    public static String describe(String value) {
        return value == null ? "absent" : "present(" + value.length() + " chars)";
    }
}