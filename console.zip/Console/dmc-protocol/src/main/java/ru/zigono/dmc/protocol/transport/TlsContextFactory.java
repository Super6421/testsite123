package ru.zigono.dmc.protocol.transport;

import io.netty.handler.ssl.ClientAuth;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.SslProvider;
import ru.zigono.dmc.common.config.ConfigException;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;

/**
 * Builds Netty {@link SslContext} instances from PKCS12/JKS keystores or from PEM files.
 * TLS is mandatory unless unencrypted transport was explicitly enabled in the configuration.
 *
 * @author Zigono
 */
public final class TlsContextFactory {

    private TlsContextFactory() {
    }

    public static SslContext serverContext(TransportSettings settings) {
        if (!settings.tlsEnabled()) {
            return null;
        }
        final SslContextBuilder builder;
        if (settings.keyStore() != null) {
            builder = SslContextBuilder.forServer(keyManagerFactory(settings.keyStore(),
                    settings.keyStorePassword(), settings.keyPassword()));
        } else if (settings.certificateChain() != null && settings.privateKey() != null) {
            builder = SslContextBuilder.forServer(settings.certificateChain().toFile(),
                    settings.privateKey().toFile(), settings.keyPassword());
        } else {
            throw new ConfigException("TLS включён, но не задан ни tls.keystore, ни пара tls.certificate/tls.private_key");
        }
        final TrustManagerFactory trustManager = trustManagerFactory(settings.trustStore(), settings.trustStorePassword());
        if (trustManager != null) {
            builder.trustManager(trustManager);
        } else if (settings.caCertificate() != null) {
            builder.trustManager(settings.caCertificate().toFile());
        } else if (settings.requireClientCertificate()) {
            throw new ConfigException("tls.require_client_certificate включён, но не задан truststore или CA-сертификат");
        }
        if (settings.requireClientCertificate()) {
            builder.clientAuth(ClientAuth.REQUIRE);
        } else {
            builder.clientAuth(ClientAuth.OPTIONAL);
        }
        return build(apply(builder, settings));
    }

    public static SslContext clientContext(TransportSettings settings) {
        if (!settings.tlsEnabled()) {
            return null;
        }
        final SslContextBuilder builder = SslContextBuilder.forClient()
                .endpointIdentificationAlgorithm("HTTPS");
        final TrustManagerFactory trustManager = trustManagerFactory(settings.trustStore(), settings.trustStorePassword());
        if (trustManager != null) {
            builder.trustManager(trustManager);
        } else if (settings.caCertificate() != null) {
            builder.trustManager(settings.caCertificate().toFile());
        }
        if (settings.keyStore() != null) {
            builder.keyManager(keyManagerFactory(settings.keyStore(), settings.keyStorePassword(), settings.keyPassword()));
        } else if (settings.certificateChain() != null && settings.privateKey() != null) {
            builder.keyManager(settings.certificateChain().toFile(), settings.privateKey().toFile(), settings.keyPassword());
        }
        return build(apply(builder, settings));
    }

    private static SslContext build(SslContextBuilder builder) {
        try {
            return builder.build();
        } catch (javax.net.ssl.SSLException e) {
            throw new ConfigException("Не удалось инициализировать TLS-контекст: " + e.getMessage(), e);
        }
    }

    private static SslContextBuilder apply(SslContextBuilder builder, TransportSettings settings) {
        builder.sslProvider(SslProvider.JDK);
        if (settings.protocols() != null && !settings.protocols().isEmpty()) {
            builder.protocols(settings.protocols().toArray(String[]::new));
        }
        return builder;
    }

    private static KeyManagerFactory keyManagerFactory(Path keyStore, String storePassword, String keyPassword) {
        if (!Files.isRegularFile(keyStore)) {
            throw new ConfigException("Хранилище ключей не найдено: " + keyStore.toAbsolutePath());
        }
        final char[] store = storePassword == null ? new char[0] : storePassword.toCharArray();
        final char[] key = keyPassword == null || keyPassword.isEmpty() ? store : keyPassword.toCharArray();
        try (InputStream stream = Files.newInputStream(keyStore)) {
            final KeyStore loaded = load(keyStore, store);
            loaded.load(stream, store);
            final KeyManagerFactory factory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            factory.init(loaded, key);
            return factory;
        } catch (Exception e) {
            throw new ConfigException("Не удалось загрузить хранилище ключей " + keyStore.toAbsolutePath() + ": " + e.getMessage(), e);
        }
    }

    private static TrustManagerFactory trustManagerFactory(Path trustStore, String password) {
        if (trustStore == null) {
            return null;
        }
        if (!Files.isRegularFile(trustStore)) {
            throw new ConfigException("Хранилище доверенных сертификатов не найдено: " + trustStore.toAbsolutePath());
        }
        final char[] store = password == null ? new char[0] : password.toCharArray();
        try (InputStream stream = Files.newInputStream(trustStore)) {
            final KeyStore loaded = load(trustStore, store);
            loaded.load(stream, store);
            final TrustManagerFactory factory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            factory.init(loaded);
            return factory;
        } catch (Exception e) {
            throw new ConfigException("Не удалось загрузить хранилище доверенных сертификатов " + trustStore.toAbsolutePath() + ": " + e.getMessage(), e);
        }
    }

    private static KeyStore load(Path path, char[] password) throws Exception {
        final String name = path.getFileName().toString().toLowerCase(java.util.Locale.ROOT);
        final String type = name.endsWith(".jks") ? "JKS"
                : name.endsWith(".p12") || name.endsWith(".pfx") ? "PKCS12" : KeyStore.getDefaultType();
        final KeyStore keyStore = KeyStore.getInstance(type);
        keyStore.load(null, password);
        return keyStore;
    }
}