package ru.zigono.dmc.protocol.dto;

import java.util.List;

/**
 * Real result of an execution on one Minecraft server.
 *
 * @author Zigono
 */
public record ServerOutcome(
        String serverId,
        ExecutionStatus status,
        List<String> output,
        long durationMillis,
        String errorCode,
        String errorDetail,
        String requestId,
        long completedAt) {

    public ServerOutcome {
        output = output == null ? List.of() : List.copyOf(output);
    }

    public static ServerOutcome success(String serverId, List<String> output, long durationMillis, String requestId) {
        return new ServerOutcome(serverId, ExecutionStatus.SUCCESS, output, durationMillis, null, null, requestId,
                System.currentTimeMillis());
    }

    public static ServerOutcome failure(String serverId, ExecutionStatus status, String errorCode, String detail) {
        return new ServerOutcome(serverId, status, List.of(), 0L, errorCode, detail, null, System.currentTimeMillis());
    }

    public String outputAsText() {
        return String.join("\n", output);
    }
}