package ru.zigono.dmc.protocol.transport;

import ru.zigono.dmc.protocol.Message;

/**
 * Callbacks invoked by the transport server for every connection lifecycle event.
 *
 * @author Zigono
 */
public interface ConnectionHandler {

    void onOpen(Connection connection);

    void onMessage(Connection connection, Message message);

    void onClose(Connection connection);

    void onFailure(Connection connection, Throwable cause);
}