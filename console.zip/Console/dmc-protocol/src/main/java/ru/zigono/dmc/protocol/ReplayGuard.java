package ru.zigono.dmc.protocol;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Replay protection. Every message carries a unique request id, a nonce and a timestamp; the guard rejects
 * repeated identifiers, nonces it has already seen inside the validity window and timestamps outside it.
 *
 * @author Zigono
 */
public final class ReplayGuard {

    private final long windowMillis;
    private final int maxEntries;
    private final Map<String, Long> seen = new ConcurrentHashMap<>();

    public ReplayGuard(long windowMillis, int maxEntries) {
        if (windowMillis <= 0) {
            throw new IllegalArgumentException("windowMillis должен быть положительным");
        }
        this.windowMillis = windowMillis;
        this.maxEntries = Math.max(1024, maxEntries);
    }

    /**
     * Validates a message envelope that starts a new exchange and remembers it.
     *
     * @throws ProtocolException when the message is a replay or carries an expired timestamp
     */
    public void check(String clientId, String requestId, String nonce, long timestamp) {
        check(clientId, requestId, nonce, timestamp, false);
    }

    /**
     * Validates a message envelope and remembers it.
     * <p>A correlated reply deliberately reuses the request id of the message it answers, so only its nonce is
     * required to be fresh. Every other message must carry a request id nobody has used inside the window.</p>
     *
     * @param reply whether the message answers an earlier request
     * @throws ProtocolException when the message is a replay or carries an expired timestamp
     */
    public void check(String clientId, String requestId, String nonce, long timestamp, boolean reply) {
        final long now = System.currentTimeMillis();
        if (timestamp <= 0) {
            throw ProtocolException.timestamp("сообщение без отметки времени");
        }
        if (Math.abs(now - timestamp) > windowMillis) {
            throw ProtocolException.timestamp("отметка времени сообщения вне допустимого окна");
        }
        if (requestId == null || requestId.isBlank()) {
            throw ProtocolException.authentication(
                    reply ? "reply without request id" : "message without request id");
        }
        if (nonce == null || nonce.isBlank()) {
            throw ProtocolException.authentication("сообщение без nonce");
        }
        final long expiresAt = now + windowMillis;
        if (!reply) {
            remember(identity(clientId, "r", requestId), expiresAt, "replayed request id");
        }
        remember(identity(clientId, "n", nonce), expiresAt, "replayed nonce");
    }

    private void remember(String key, long expiresAt, String reason) {
        prune(expiresAt);
        final Long previous = seen.putIfAbsent(key, expiresAt);
        if (previous != null) {
            throw ProtocolException.replay(reason);
        }
    }

    private String identity(String clientId, String kind, String value) {
        return (clientId == null ? "unknown" : clientId) + "|" + kind + "|" + value;
    }

    private void prune(long now) {
        if (seen.size() < maxEntries) {
            return;
        }
        seen.entrySet().removeIf(entry -> entry.getValue() < now);
    }

    public int size() {
        return seen.size();
    }

    public long windowMillis() {
        return windowMillis;
    }

    public void clear() {
        seen.clear();
    }
}