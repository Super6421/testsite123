package ru.zigono.dmc.protocol.transport;

import io.netty.channel.Channel;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.net.SecureMessageCodec;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Netty backed {@link Connection} implementation.
 *
 * @author Zigono
 */
public final class NettyConnection implements Connection {

    private static final AtomicLong SEQUENCE = new AtomicLong();

    private final Channel channel;
    private final SecureMessageCodec codec;
    private final String id;
    private final long connectedAt = System.currentTimeMillis();
    private final AtomicReference<String> role = new AtomicReference<>("unknown");
    private final Map<String, Object> attributes = new ConcurrentHashMap<>();
    private final AtomicLong latencyMillis = new AtomicLong(-1L);

    public NettyConnection(Channel channel, SecureMessageCodec codec) {
        this.channel = channel;
        this.codec = codec;
        this.id = "c-" + SEQUENCE.incrementAndGet() + "-" + Integer.toHexString(System.identityHashCode(channel));
    }

    public Channel channel() {
        return channel;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String remoteAddress() {
        return String.valueOf(channel.remoteAddress());
    }

    @Override
    public boolean open() {
        return channel.isActive();
    }

    @Override
    public void send(Message message) {
        if (!channel.isActive()) {
            throw new ru.zigono.dmc.protocol.ProtocolException(
                    ru.zigono.dmc.common.errors.ErrorCode.CONNECTION_LOST, "соединение закрыто");
        }
        channel.writeAndFlush(message);
    }

    @Override
    public void close() {
        channel.close();
    }

    @Override
    public String clientId() {
        return codec.boundClientId();
    }

    @Override
    public void bind(String clientId) {
        codec.bindClientId(clientId);
    }

    @Override
    public String role() {
        return role.get();
    }

    @Override
    public void setRole(String role) {
        if (role != null) {
            this.role.set(role);
        }
    }

    @Override
    public long connectedAt() {
        return connectedAt;
    }

    @Override
    public Map<String, Object> attributes() {
        return attributes;
    }

    @Override
    public long latencyMillis() {
        return latencyMillis.get();
    }

    @Override
    public void setLatencyMillis(long latency) {
        latencyMillis.set(latency);
    }

    @Override
    public String toString() {
        return "Connection[" + id + ", " + remoteAddress() + ", client=" + clientId() + ", role=" + role() + "]";
    }
}