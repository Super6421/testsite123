package ru.zigono.dmc.protocol;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import ru.zigono.dmc.protocol.message.ControlMessages;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;

/**
 * Base class of every message exchanged over the secure channel.
 * <p>The envelope carries the identity, a monotonically unique request id, a timestamp and a nonce; the
 * signature covers all of them plus the payload. See {@code PROTOCOL.md}.</p>
 *
 * @author Zigono
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = HandshakeMessages.Hello.class, name = "HELLO"),
        @JsonSubTypes.Type(value = HandshakeMessages.HelloAck.class, name = "HELLO_ACK"),
        @JsonSubTypes.Type(value = HandshakeMessages.AuthRequest.class, name = "AUTH"),
        @JsonSubTypes.Type(value = HandshakeMessages.AuthResult.class, name = "AUTH_RESULT"),
        @JsonSubTypes.Type(value = HandshakeMessages.Ping.class, name = "PING"),
        @JsonSubTypes.Type(value = HandshakeMessages.Pong.class, name = "PONG"),
        @JsonSubTypes.Type(value = HandshakeMessages.ShutdownNotice.class, name = "SHUTDOWN"),
        @JsonSubTypes.Type(value = HandshakeMessages.ErrorMessage.class, name = "ERROR"),
        @JsonSubTypes.Type(value = PluginMessages.Heartbeat.class, name = "HEARTBEAT"),
        @JsonSubTypes.Type(value = PluginMessages.HeartbeatAck.class, name = "HEARTBEAT_ACK"),
        @JsonSubTypes.Type(value = PluginMessages.CommandDispatch.class, name = "COMMAND"),
        @JsonSubTypes.Type(value = PluginMessages.CommandAccepted.class, name = "COMMAND_ACCEPTED"),
        @JsonSubTypes.Type(value = PluginMessages.CommandOutcomeMessage.class, name = "COMMAND_RESULT"),
        @JsonSubTypes.Type(value = ControlMessages.TargetsRequest.class, name = "TARGETS_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.TargetsResponse.class, name = "TARGETS_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.ExecuteRequest.class, name = "EXECUTE_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.ExecuteResponse.class, name = "EXECUTE_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.StatusRequest.class, name = "STATUS_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.StatusResponse.class, name = "STATUS_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.HistoryRequest.class, name = "HISTORY_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.HistoryResponse.class, name = "HISTORY_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.ReloadRequest.class, name = "RELOAD_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.ReloadResponse.class, name = "RELOAD_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.EmergencyRequest.class, name = "EMERGENCY_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.EmergencyResponse.class, name = "EMERGENCY_RESPONSE"),
        @JsonSubTypes.Type(value = ControlMessages.ConfigSnapshotRequest.class, name = "CONFIG_SNAPSHOT_REQUEST"),
        @JsonSubTypes.Type(value = ControlMessages.ConfigSnapshotResponse.class, name = "CONFIG_SNAPSHOT_RESPONSE")
})
public abstract class Message {

    private int protocolVersion = ProtocolVersion.CURRENT;
    private String requestId;
    private String clientId;
    private long timestamp;
    private String nonce;
    private String signature;
    private boolean reply;

    protected Message() {
    }

    /**
     * @return the wire name of this message, derived from the class name unless overridden
     */
    @JsonIgnore
    public String type() {
        return MessageTypes.nameOf(getClass());
    }

    public int getProtocolVersion() {
        return protocolVersion;
    }

    public void setProtocolVersion(int protocolVersion) {
        this.protocolVersion = protocolVersion;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getNonce() {
        return nonce;
    }

    public void setNonce(String nonce) {
        this.nonce = nonce;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    /**
     * @return {@code true} when this message answers another one instead of starting a new exchange
     */
    public boolean isReply() {
        return reply;
    }

    public void setReply(boolean reply) {
        this.reply = reply;
    }

    /**
     * Copies the correlation envelope of another message so a response can be matched to its request.
     * <p>The reply flag travels inside the signed envelope, which is what lets replay protection tell a genuine
     * answer to an earlier request apart from a replayed request id.</p>
     */
    public <T extends Message> T correlate(T response) {
        response.setRequestId(requestId);
        response.setProtocolVersion(protocolVersion);
        response.setReply(true);
        return response;
    }
}