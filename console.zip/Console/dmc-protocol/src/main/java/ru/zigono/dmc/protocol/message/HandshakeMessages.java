package ru.zigono.dmc.protocol.message;

import ru.zigono.dmc.protocol.Message;

/**
 * Handshake, authentication, keep alive and lifecycle messages.
 *
 * @author Zigono
 */
public final class HandshakeMessages {

    private HandshakeMessages() {
    }

    /** First message of a client: identity and protocol capabilities. */
    public static final class Hello extends Message {
        public String role;
        public String agentName;
        public String agentVersion;
        public String platform;
        public String serverId;
        public java.util.List<String> capabilities = java.util.List.of();
    }

    /** Answer of the gateway, carrying the authentication challenge. */
    public static final class HelloAck extends Message {
        public String gatewayId;
        public String gatewayVersion;
        public int minSupportedProtocolVersion;
        public int maxSupportedProtocolVersion;
        public int heartbeatIntervalSeconds;
        public String challenge;
        public String configRevision;
        public boolean emergencyMode;
        public long serverTime;
    }

    /** Authentication proof: the signature covers the challenge and the shared secret. */
    public static final class AuthRequest extends Message {
        public String role;
        public String serverId;
        public String challenge;
        public String agentVersion;
    }

    /** Authentication result. */
    public static final class AuthResult extends Message {
        public boolean authenticated;
        public String errorCode;
        public String errorDetail;
        public String sessionId;
        public String serverId;
        public String gatewayId;
        public String configRevision;
        public int heartbeatIntervalSeconds;
        public String message;
        public long serverTime;
    }

    /** Round trip time probe. */
    public static final class Ping extends Message {
        public long sentAt;
        public long sequence;
    }

    /** Answer to {@link Ping}. */
    public static final class Pong extends Message {
        public long sentAt;
        public long sequence;
        public long serverTime;
    }

    /** Graceful shutdown announcement. */
    public static final class ShutdownNotice extends Message {
        public String reason;
        public int graceSeconds;
        public boolean restarting;
    }

    /** Standardized error reply. */
    public static final class ErrorMessage extends Message {
        public String code;
        public String detail;
        public java.util.Map<String, String> arguments = java.util.Map.of();
        public boolean fatal;
    }
}