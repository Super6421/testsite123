package ru.zigono.dmc.protocol.net;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToMessageCodec;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.common.util.Json;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.MessageSigner;
import ru.zigono.dmc.protocol.MessageTypes;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.ProtocolVersion;
import ru.zigono.dmc.protocol.ReplayGuard;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/**
 * Turns {@link Message} objects into framed, signed JSON payloads and back.
 * <p>Outbound: assigns request id, timestamp and nonce, signs the envelope with the shared secret of the
 * connection and serializes it. Inbound: parses, checks the protocol version, verifies the signature, applies
 * replay protection and enforces that a connection only ever speaks for one identity.</p>
 *
 * @author Zigono
 */
public final class SecureMessageCodec extends MessageToMessageCodec<ByteBuf, Message> {

    private final KeyResolver keys;
    private final ReplayGuard replayGuard;
    private final Consumer<ProtocolException> violationHandler;
    private final boolean verifyInbound;
    private final boolean enforceBoundIdentity;
    private final AtomicReference<String> localClientId = new AtomicReference<>();
    private final AtomicReference<String> boundClientId = new AtomicReference<>();

    public SecureMessageCodec(KeyResolver keys, ReplayGuard replayGuard, boolean verifyInbound,
                              boolean enforceBoundIdentity, String localClientId,
                              Consumer<ProtocolException> violationHandler) {
        this.keys = keys;
        this.replayGuard = replayGuard;
        this.verifyInbound = verifyInbound;
        this.enforceBoundIdentity = enforceBoundIdentity;
        this.localClientId.set(localClientId);
        this.violationHandler = violationHandler == null ? ignored -> { } : violationHandler;
    }

    public void bindClientId(String clientId) {
        this.boundClientId.set(clientId);
    }

    public String boundClientId() {
        return boundClientId.get();
    }

    @Override
    protected void encode(ChannelHandlerContext context, Message message, List<Object> out) {
        final String clientId = resolveOutboundClientId(message);
        message.setClientId(clientId);
        if (message.getRequestId() == null || message.getRequestId().isBlank()) {
            message.setRequestId(Ids.ulid());
        }
        message.setTimestamp(System.currentTimeMillis());
        if (message.getNonce() == null || message.getNonce().isBlank()) {
            message.setNonce(Ids.nonce(16));
        }
        if (message.getProtocolVersion() <= 0) {
            message.setProtocolVersion(ProtocolVersion.CURRENT);
        }
        final Optional<byte[]> key = keys.keyFor(clientId);
        if (key.isPresent()) {
            MessageSigner.sign(message, key.get());
        } else {
            throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED,
                    "для id клиента не настроен секрет '" + clientId + "'");
        }
        final byte[] payload = Json.writeBytes(message);
        final ByteBuf buffer = context.alloc().buffer(payload.length);
        buffer.writeBytes(payload);
        out.add(buffer);
    }

    private String resolveOutboundClientId(Message message) {
        final String bound = boundClientId.get();
        if (bound != null) {
            return bound;
        }
        if (message.getClientId() != null && !message.getClientId().isBlank()) {
            return message.getClientId();
        }
        final String local = localClientId.get();
        if (local == null) {
            throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "не удалось определить отправителя");
        }
        return local;
    }

    @Override
    protected void decode(ChannelHandlerContext context, ByteBuf buffer, List<Object> out) {
        final byte[] payload = new byte[buffer.readableBytes()];
        buffer.readBytes(payload);
        final Message message;
        try {
            message = Json.mapper().readValue(payload, Message.class);
        } catch (IOException | RuntimeException e) {
            fail(context, ProtocolException.malformed("повреждённое сообщение: " + e.getClass().getSimpleName()));
            return;
        }
        if (!ProtocolVersion.isCompatible(message.getProtocolVersion())) {
            fail(context, ProtocolException.malformed("неподдерживаемая версия протокола " + message.getProtocolVersion()
                    + ", эта сборка поддерживает " + ProtocolVersion.describe()));
            return;
        }
        final String clientId = message.getClientId();
        if (clientId == null || clientId.isBlank()) {
            fail(context, ProtocolException.identity("сообщение без отправителя"));
            return;
        }
        if (enforceBoundIdentity) {
            final String bound = boundClientId.get();
            if (bound != null && !bound.equals(clientId)) {
                fail(context, ProtocolException.identity("несовпадение отправителя в " + MessageTypes.nameOf(message.getClass())
                        + ": соединение привязано к '" + bound + "', а сообщение заявляет '" + clientId + "'"));
                return;
            }
        }
        final Optional<byte[]> key = keys.keyFor(clientId);
        if (key.isEmpty()) {
            fail(context, ProtocolException.identity("неизвестный id клиента '" + clientId + "'"));
            return;
        }
        if (verifyInbound && !MessageSigner.verify(message, key.get())) {
            fail(context, ProtocolException.signature("неверная подпись в " + MessageTypes.nameOf(message.getClass())));
            return;
        }
        if (enforceBoundIdentity && boundClientId.get() == null) {
            // the signature proved the identity, so the connection is now pinned to it
            boundClientId.set(clientId);
        }
        try {
            replayGuard.check(clientId, message.getRequestId(), message.getNonce(), message.getTimestamp(),
                    message.isReply());
        } catch (ProtocolException e) {
            fail(context, e);
            return;
        }
        out.add(message);
    }

    private void fail(ChannelHandlerContext context, ProtocolException exception) {
        violationHandler.accept(exception);
        context.close();
    }
}