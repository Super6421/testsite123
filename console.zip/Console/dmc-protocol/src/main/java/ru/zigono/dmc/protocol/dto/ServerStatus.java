package ru.zigono.dmc.protocol.dto;

/**
 * Lifecycle state of a Minecraft server connection as seen by the gateway.
 *
 * @author Zigono
 */
public enum ServerStatus {
    CONNECTING,
    ONLINE,
    DEGRADED,
    OFFLINE,
    AUTH_FAILED;

    public boolean available() {
        return this == ONLINE || this == DEGRADED;
    }
}