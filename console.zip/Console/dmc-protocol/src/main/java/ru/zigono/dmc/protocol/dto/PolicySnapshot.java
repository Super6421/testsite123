package ru.zigono.dmc.protocol.dto;

import java.util.List;
import java.util.Map;

/**
 * Authoritative policy view handed to the bot so it can render the same decisions the gateway enforces:
 * which commands are dangerous, which are blocked and what the confirmation rules are.
 *
 * @author Zigono
 */
public record PolicySnapshot(
        String revision,
        int maxCommandLength,
        List<String> blockedSequences,
        List<String> dangerousPatterns,
        List<String> blockedPatterns,
        List<String> allowedPatterns,
        List<RuleSnapshot> rules,
        boolean confirmationEnabled,
        int confirmationTimeoutSeconds,
        int queueMaxSize,
        boolean emergencyMode,
        String responseMode,
        int maxMessageLength,
        int attachmentThreshold,
        List<ShortcutSnapshot> aliases,
        List<ShortcutSnapshot> templates) {

    public PolicySnapshot {
        blockedSequences = blockedSequences == null ? List.of() : List.copyOf(blockedSequences);
        dangerousPatterns = dangerousPatterns == null ? List.of() : List.copyOf(dangerousPatterns);
        blockedPatterns = blockedPatterns == null ? List.of() : List.copyOf(blockedPatterns);
        allowedPatterns = allowedPatterns == null ? List.of() : List.copyOf(allowedPatterns);
        rules = rules == null ? List.of() : List.copyOf(rules);
        aliases = aliases == null ? List.of() : List.copyOf(aliases);
        templates = templates == null ? List.of() : List.copyOf(templates);
    }

    public record RuleSnapshot(String pattern, boolean deny, String permission, boolean requireConfirmation) {
    }

    /** One configured Discord alias or template. */
    public record ShortcutSnapshot(String name, String command, String permission, Map<String, String> rules) {

        public ShortcutSnapshot {
            rules = rules == null ? Map.of() : Map.copyOf(rules);
        }
    }
}