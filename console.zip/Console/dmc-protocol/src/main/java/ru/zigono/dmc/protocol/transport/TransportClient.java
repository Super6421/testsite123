package ru.zigono.dmc.protocol.transport;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.ReplayGuard;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.net.SecureMessageCodec;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;


/**
 * Netty client used by the Discord bot and by the Minecraft plugin. Reconnects with exponential backoff,
 * correlates requests and responses by request id and keeps the connection healthy with idle timeouts.
 *
 * @author Zigono
 */
public final class TransportClient implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransportClient.class);

    /** Listener notified about connection lifecycle and unsolicited messages. */
    public interface Listener {

        void onConnected(Connection connection);

        void onMessage(Connection connection, Message message);

        void onDisconnected(Throwable cause);

        default void onViolation(ProtocolException violation) {
        }
    }

    private final TransportSettings settings;
    private final KeyResolver keys;
    private final Listener listener;
    private final EventLoopGroup group;
    private final ScheduledExecutorService scheduler;
    private final Map<String, PendingRequest> pending = new ConcurrentHashMap<>();
    private final AtomicBoolean running = new AtomicBoolean();
    private final AtomicBoolean connecting = new AtomicBoolean();
    private volatile Channel channel;
    private volatile NettyConnection connection;
    private volatile long reconnectDelayMillis;

    private record PendingRequest(CompletableFuture<Message> future, ScheduledFuture<?> timeout) {
    }

    public TransportClient(TransportSettings settings, KeyResolver keys, Listener listener) {
        this.settings = settings;
        this.keys = keys;
        this.listener = listener;
        this.group = new NioEventLoopGroup(settings.workerThreads());
        this.scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            final Thread thread = new Thread(runnable, "dmc-transport-client-" + settings.localClientId());
            thread.setDaemon(true);
            return thread;
        });
        this.reconnectDelayMillis = settings.reconnectInitialDelay().toMillis();
    }

    public void start() {
        if (running.compareAndSet(false, true)) {
            connect();
        }
    }

    public boolean connected() {
        final Channel current = channel;
        return current != null && current.isActive();
    }

    public Optional<Connection> connection() {
        return Optional.ofNullable((Connection) connection).filter(Connection::open);
    }

    private void connect() {
        if (!running.get() || !connecting.compareAndSet(false, true)) {
            return;
        }
        final SslContext sslContext = settings.tlsEnabled() ? TlsContextFactory.clientContext(settings) : null;
        final Bootstrap bootstrap = new Bootstrap()
                .group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY, true)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, (int) settings.connectTimeout().toMillis())
                .handler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel socketChannel) {
                        final SecureMessageCodec codec = new SecureMessageCodec(keys,
                                new ReplayGuard(120_000L, 200_000), true, false, settings.localClientId(),
                                violation -> {
                                    listener.onViolation(violation);
                                    socketChannel.close();
                                });
                        final NettyConnection nettyConnection = new NettyConnection(socketChannel, codec);
                        nettyConnection.bind(settings.localClientId());
                        nettyConnection.setRole(settings.localRole());
                        if (sslContext != null) {
                            socketChannel.pipeline().addLast("tls",
                                    sslContext.newHandler(socketChannel.alloc(), settings.host(), settings.port()));
                        }
                        socketChannel.pipeline()
                                .addLast("idle", new IdleStateHandler(0, 0, (int) settings.idleTimeout().toSeconds()))
                                .addLast("frameDecoder", new LengthFieldFrame(settings.maxFrameBytes()))
                                .addLast("frameEncoder", new LengthFieldPrepender(4))
                                .addLast("codec", codec)
                                .addLast("handler", new ClientHandler(nettyConnection));
                    }
                });
        final ChannelFuture future = bootstrap.connect(settings.host(), settings.port());
        future.addListener(result -> {
            connecting.set(false);
            if (!result.isSuccess()) {
                LOGGER.warn("Не удалось подключиться к шлюзу {}:{}: {}", settings.host(), settings.port(),
                        result.cause() == null ? "неизвестно" : result.cause().getMessage());
                scheduleReconnect();
            }
        });
    }

    private void scheduleReconnect() {
        if (!running.get()) {
            return;
        }
        final long delay = reconnectDelayMillis;
        reconnectDelayMillis = Math.min((long) (delay * settings.reconnectMultiplier()),
                settings.reconnectMaxDelay().toMillis());
        LOGGER.debug("Переподключение к шлюзу через {} мс", delay);
        try {
            scheduler.schedule(this::connect, delay, TimeUnit.MILLISECONDS);
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            LOGGER.debug("Переподключение пропущено: клиент завершает работу");
        }
    }

    /**
     * Sends a message and waits for the reply that carries the same request id.
     *
     * @throws CommandException when the client is not connected
     */
    public CompletableFuture<Message> request(Message message, Duration timeout) {
        if (!connected()) {
            throw new CommandException(ErrorCode.CONNECTION_LOST, "соединение со шлюзом не установлено");
        }
        final String requestId = message.getRequestId() == null ? Ids.ulid() : message.getRequestId();
        message.setRequestId(requestId);
        final CompletableFuture<Message> future = new CompletableFuture<>();
        final ScheduledFuture<?> timeoutTask = scheduler.schedule(() -> {
            final PendingRequest removed = pending.remove(requestId);
            if (removed != null) {
                removed.future().completeExceptionally(new CommandException(ErrorCode.TIMEOUT,
                        "нет ответа от шлюза в течение " + timeout.toMillis() + " ms"));
            }
        }, timeout.toMillis(), TimeUnit.MILLISECONDS);
        pending.put(requestId, new PendingRequest(future, timeoutTask));
        try {
            send(message);
        } catch (RuntimeException e) {
            failPending(requestId, e);
        }
        return future;
    }

    public boolean send(Message message) {
        final Channel current = channel;
        if (current == null || !current.isActive()) {
            throw new CommandException(ErrorCode.CONNECTION_LOST, "соединение со шлюзом не установлено");
        }
        current.writeAndFlush(message);
        return true;
    }

    /** Measures the round trip time to the gateway; used for the latency metric. */
    public CompletableFuture<Long> ping() {
        final HandshakeMessages.Ping ping = new HandshakeMessages.Ping();
        ping.setClientId(settings.localClientId());
        ping.sentAt = System.currentTimeMillis();
        ping.sequence = System.nanoTime();
        return request(ping, settings.connectTimeout()).thenApply(response -> System.currentTimeMillis() - ping.sentAt);
    }

    private void failPending(String requestId, Throwable cause) {
        final PendingRequest removed = pending.remove(requestId);
        if (removed != null) {
            removed.timeout().cancel(false);
            removed.future().completeExceptionally(cause);
        }
    }

    private void failAllPending(Throwable cause) {
        for (Map.Entry<String, PendingRequest> entry : pending.entrySet()) {
            final PendingRequest request = pending.remove(entry.getKey());
            if (request != null) {
                request.timeout().cancel(false);
                request.future().completeExceptionally(cause);
            }
        }
    }

    @Override
    public void close() {
        running.set(false);
        final Channel current = channel;
        if (current != null) {
            current.close().awaitUninterruptibly(settings.shutdownGrace().toMillis());
        }
        failAllPending(new CommandException(ErrorCode.CONNECTION_LOST, "клиент завершает работу"));
        scheduler.shutdownNow();
        group.shutdownGracefully(0, settings.shutdownGrace().toMillis(), TimeUnit.MILLISECONDS);
    }

    /**
     * Frame decoder with the configured maximum payload size.
     */
    private static final class LengthFieldFrame extends LengthFieldBasedFrameDecoder {
        private LengthFieldFrame(int maxFrameBytes) {
            super(maxFrameBytes, 0, 4, 0, 4);
        }
    }

    /**
     * Netty handler of the client pipeline.
     */
    private final class ClientHandler extends SimpleChannelInboundHandler<Message> {

        private final NettyConnection nettyConnection;

        private ClientHandler(NettyConnection nettyConnection) {
            this.nettyConnection = nettyConnection;
        }

        @Override
        public void channelActive(ChannelHandlerContext context) {
            channel = context.channel();
            connection = nettyConnection;
            nettyConnection.bind(settings.localClientId());
            reconnectDelayMillis = settings.reconnectInitialDelay().toMillis();
            LOGGER.info("Подключено к шлюзу {}:{}", settings.host(), settings.port());
            listener.onConnected(nettyConnection);
        }

        @Override
        protected void channelRead0(ChannelHandlerContext context, Message message) {
            final PendingRequest request = message.getRequestId() == null ? null : pending.remove(message.getRequestId());
            if (request != null) {
                request.timeout().cancel(false);
                request.future().complete(message);
            }
            listener.onMessage(nettyConnection, message);
        }

        @Override
        public void channelInactive(ChannelHandlerContext context) {
            connection = null;
            channel = null;
            LOGGER.info("Соединение со шлюзом разорвано");
            failAllPending(new CommandException(ErrorCode.CONNECTION_LOST, "соединение со шлюзом было закрыто"));
            listener.onDisconnected(null);
            scheduleReconnect();
        }

        @Override
        public void userEventTriggered(ChannelHandlerContext context, Object event) {
            if (event instanceof IdleStateEvent) {
                LOGGER.debug("Закрываю неактивное соединение со шлюзом");
                context.close();
            }
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext context, Throwable cause) {
            LOGGER.warn("Ошибка соединения со шлюзом: {}", cause.getMessage());
            listener.onDisconnected(cause);
            context.close();
        }
    }

    public List<Connection> connections() {
        final Connection current = connection;
        return current == null ? List.of() : List.of(current);
    }
}