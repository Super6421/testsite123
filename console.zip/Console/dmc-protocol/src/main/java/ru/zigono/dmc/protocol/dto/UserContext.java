package ru.zigono.dmc.protocol.dto;

import java.util.List;

/**
 * Identity of the Discord user that initiated a command. It travels with every request so the gateway and the
 * audit trail can attribute the action; the gateway never trusts it blindly because the request is signed by
 * the bot and the bot is the only party allowed to send it.
 *
 * @author Zigono
 */
public record UserContext(
        String userId,
        String username,
        String guildId,
        String channelId,
        String messageId,
        String interactionId,
        List<String> roleIds,
        List<String> permissions,
        List<String> deniedPermissions) {

    public UserContext {
        roleIds = roleIds == null ? List.of() : List.copyOf(roleIds);
        permissions = permissions == null ? List.of() : List.copyOf(permissions);
        deniedPermissions = deniedPermissions == null ? List.of() : List.copyOf(deniedPermissions);
    }

    public static UserContext of(String userId, String username, String guildId, String channelId) {
        return new UserContext(userId, username, guildId, channelId, null, null, List.of(), List.of(), List.of());
    }

    public String describe() {
        return username == null || username.isBlank() ? userId : username;
    }
}