package ru.zigono.dmc.protocol.message;

import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.dto.HistoryEntry;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.List;

/**
 * Messages exchanged between the Discord bot (control plane client) and the gateway.
 *
 * @author Zigono
 */
public final class ControlMessages {

    private ControlMessages() {
    }

    /** Asks which targets and capabilities the user has. */
    public static final class TargetsRequest extends Message {
        public UserContext user;
    }

    /** Answer to {@link TargetsRequest}. */
    public static final class TargetsResponse extends Message {
        public TargetsView view;
    }

    /** A command execution request, possibly a broadcast or a dry run. */
    public static final class ExecuteRequest extends Message {
        public UserContext user;
        public TargetSelection target;
        public String command;
        public String normalizedCommand;
        public String requiredPermission;
        public boolean dryRun;
        public boolean confirmed;
        public String confirmationId;
        public long issuedAt;
        public long timeoutMillis;
    }

    /** Result of an execution request, one outcome per server. */
    public static final class ExecuteResponse extends Message {
        public String targetDescription;
        public String command;
        public boolean dryRun;
        public List<ServerOutcome> outcomes = List.of();
        public long durationMillis;
        public String errorCode;
        public String errorDetail;
        public String confirmationId;
        public long confirmationExpiresAt;
        public String responseMode;
        public String dryRunSummary;
        public List<String> dryRunChecks = List.of();
    }

    /** Requests the authoritative policy snapshot used by the bot UI. */
    public static final class ConfigSnapshotRequest extends Message {
        public UserContext user;
    }

    /** Answer to {@link ConfigSnapshotRequest}. */
    public static final class ConfigSnapshotResponse extends Message {
        public ru.zigono.dmc.protocol.dto.PolicySnapshot policy;
    }

    /** Requests the status of the servers the user may see. */
    public static final class StatusRequest extends Message {
        public UserContext user;
        public List<String> serverIds = List.of();
    }

    /** One server status entry. */
    public record ServerStatusEntry(String id, String name, String status, ServerMetrics metrics, String errorDetail,
                                    long lastSeenMillis) {
    }

    /** Answer to {@link StatusRequest}. */
    public static final class StatusResponse extends Message {
        public List<ServerStatusEntry> servers = List.of();
        public String gatewayId;
        public String configRevision;
        public long uptimeSeconds;
    }

    /** Command history query. */
    public static final class HistoryRequest extends Message {
        public UserContext user;
        public String serverId;
        public String username;
        public String commandFragment;
        public String status;
        public Long fromMillis;
        public Long toMillis;
        public int limit = 25;
        public int offset = 0;
    }

    /** Answer to {@link HistoryRequest}. */
    public static final class HistoryResponse extends Message {
        public List<HistoryEntry> entries = List.of();
        public long total;
        public int limit;
        public int offset;
    }

    /** Hot reload request. */
    public static final class ReloadRequest extends Message {
        public UserContext user;
    }

    /** Hot reload result. */
    public static final class ReloadResponse extends Message {
        public boolean reloaded;
        public String configRevision;
        public List<String> reloadedSections = List.of();
        public String errorDetail;
    }

    /** Emergency kill switch request. */
    public static final class EmergencyRequest extends Message {
        public UserContext user;
        public boolean enabled;
    }

    /** Emergency kill switch result. */
    public static final class EmergencyResponse extends Message {
        public boolean emergencyMode;
        public String errorDetail;
    }
}
