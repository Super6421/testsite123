package ru.zigono.dmc.protocol;

/**
 * Version of the wire protocol. The gateway and the plugin exchange their versions during the handshake so
 * both sides can be upgraded independently within the supported range.
 *
 * @author Zigono
 */
public final class ProtocolVersion {

    /** Version implemented by this build. */
    public static final int CURRENT = 1;

    /** Oldest version this build still speaks. */
    public static final int MIN_SUPPORTED = 1;

    private ProtocolVersion() {
    }

    public static boolean isCompatible(int version) {
        return version >= MIN_SUPPORTED && version <= CURRENT;
    }

    public static String describe() {
        return CURRENT + " (supported " + MIN_SUPPORTED + ".." + CURRENT + ")";
    }
}