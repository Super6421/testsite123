package ru.zigono.dmc.protocol.dto;

/**
 * Result of a single server execution.
 *
 * @author Zigono
 */
public enum ExecutionStatus {
    SUCCESS,
    FAILED,
    TIMEOUT,
    OFFLINE,
    DENIED,
    QUEUE_FULL,
    CANCELLED,
    UNKNOWN,
    DRY_RUN;

    public boolean successful() {
        return this == SUCCESS || this == DRY_RUN;
    }
}