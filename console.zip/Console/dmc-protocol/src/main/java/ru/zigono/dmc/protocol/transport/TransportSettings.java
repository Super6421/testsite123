package ru.zigono.dmc.protocol.transport;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.nio.file.Path;
import java.time.Duration;
import java.util.List;

/**
 * Network settings shared by the gateway server, the bot and the plugin client.
 * <pre>
 * network:
 *   host: "0.0.0.0"
 *   port: 8443
 *   # 0 asks the operating system for a free port; the embedded mode binds its loopback
 *   # listener that way and reads the port back from the listener.
 *   max_frame_bytes: 1048576
 *   idle_timeout: 120s
 *   connect_timeout: 10s
 *   handshake_timeout: 15s
 *   shutdown_grace: 10s
 *   reconnect:
 *     initial_delay: 1s
 *     max_delay: 60s
 *     multiplier: 2.0
 * tls:
 *   enabled: true
 *   allow_insecure_transport: false
 *   keystore: "tls/server.p12"
 *   keystore_password: "${TLS_KEYSTORE_PASSWORD}"
 *   key_password: "${TLS_KEY_PASSWORD:}"
 *   truststore: "tls/truststore.p12"
 *   truststore_password: "${TLS_TRUSTSTORE_PASSWORD}"
 *   require_client_certificate: true
 *   protocols: [ "TLSv1.3", "TLSv1.2" ]
 * </pre>
 *
 * @author Zigono
 */
public record TransportSettings(
        boolean tlsEnabled,
        boolean allowInsecureTransport,
        String host,
        int port,
        Path keyStore,
        String keyStorePassword,
        String keyPassword,
        Path trustStore,
        String trustStorePassword,
        Path certificateChain,
        Path privateKey,
        Path caCertificate,
        boolean requireClientCertificate,
        List<String> protocols,
        int maxFrameBytes,
        Duration connectTimeout,
        Duration handshakeTimeout,
        Duration idleTimeout,
        Duration shutdownGrace,
        Duration reconnectInitialDelay,
        Duration reconnectMaxDelay,
        double reconnectMultiplier,
        int workerThreads,
        String localClientId,
        String localRole) {

    public static final int DEFAULT_MAX_FRAME_BYTES = 1_048_576;

    public TransportSettings {
        protocols = protocols == null || protocols.isEmpty() ? List.of("TLSv1.3", "TLSv1.2") : List.copyOf(protocols);
        if (maxFrameBytes <= 0) {
            maxFrameBytes = DEFAULT_MAX_FRAME_BYTES;
        }
        if (workerThreads <= 0) {
            workerThreads = Math.max(2, Runtime.getRuntime().availableProcessors());
        }
    }

    /**
     * Builds settings from the {@code network} and {@code tls} sections.
     *
     * @param networkSection the {@code network} section of the component configuration
     * @param tlsSection     the {@code tls} section of the component configuration
     * @param baseDirectory  directory used to resolve relative paths
     * @param localClientId  identity used for outbound messages, {@code null} for a server
     * @param localRole      role advertised in the handshake
     */
    public static TransportSettings from(YamlConfig networkSection, YamlConfig tlsSection, Path baseDirectory,
                                         String localClientId, String localRole) {
        final boolean tlsEnabled = tlsSection.bool("enabled", true);
        final boolean allowInsecure = tlsSection.bool("allow_insecure_transport", false);
        if (!tlsEnabled && !allowInsecure) {
            throw new ConfigException("tls.enabled выключен, но tls.allow_insecure_transport не задан: "
                    + "незашифрованный транспорт команд требует явного согласия");
        }
        final String host = networkSection.string("host", "127.0.0.1");
        final int port = networkSection.integer("port", 8443);
        if (port < 0 || port > 65535) {
            throw new ConfigException("network.port должен быть корректным TCP-портом, либо 0, чтобы операционная система "
                    + "выбрала свободный порт (именно так встроенный режим поднимает свой loopback-слушатель)");
        }
        final Path keyStore = resolve(baseDirectory, tlsSection.string("keystore", null));
        final Path trustStore = resolve(baseDirectory, tlsSection.string("truststore", null));
        return new TransportSettings(
                tlsEnabled,
                allowInsecure,
                host,
                port,
                keyStore,
                tlsSection.string("keystore_password", null),
                tlsSection.string("key_password", null),
                trustStore,
                tlsSection.string("truststore_password", null),
                resolve(baseDirectory, tlsSection.string("certificate", null)),
                resolve(baseDirectory, tlsSection.string("private_key", null)),
                resolve(baseDirectory, tlsSection.string("ca_certificate", null)),
                tlsSection.bool("require_client_certificate", false),
                tlsSection.stringList("protocols", List.of("TLSv1.3", "TLSv1.2")),
                networkSection.integer("max_frame_bytes", DEFAULT_MAX_FRAME_BYTES),
                networkSection.duration("connect_timeout", Duration.ofSeconds(10)),
                networkSection.duration("handshake_timeout", Duration.ofSeconds(15)),
                networkSection.duration("idle_timeout", Duration.ofSeconds(120)),
                networkSection.duration("shutdown_grace", Duration.ofSeconds(10)),
                networkSection.duration("reconnect.initial_delay", Duration.ofSeconds(1)),
                networkSection.duration("reconnect.max_delay", Duration.ofSeconds(60)),
                networkSection.doubleValue("reconnect.multiplier", 2.0d),
                networkSection.integer("worker_threads", 0),
                localClientId,
                localRole);
    }

    private static Path resolve(Path baseDirectory, String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        final Path path = Path.of(value.trim());
        return path.isAbsolute() || baseDirectory == null ? path : baseDirectory.resolve(path);
    }

    public boolean tlsConfigured() {
        return tlsEnabled;
    }
}