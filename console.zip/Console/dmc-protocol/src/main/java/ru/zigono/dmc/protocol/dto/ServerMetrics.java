package ru.zigono.dmc.protocol.dto;

/**
 * Metrics reported by a Minecraft server through the heartbeat.
 *
 * @author Zigono
 */
public record ServerMetrics(
        String serverId,
        String minecraftVersion,
        String serverSoftware,
        String pluginVersion,
        int onlinePlayers,
        int maxPlayers,
        double tps,
        double mspt,
        long uptimeSeconds,
        long usedMemoryBytes,
        long maxMemoryBytes,
        double cpuLoad,
        String worldName,
        int loadedChunks,
        long collectedAt) {

    public static ServerMetrics empty(String serverId) {
        return new ServerMetrics(serverId, null, null, null, 0, 0, 0, 0, 0, 0, 0, 0, null, 0, 0L);
    }
}