package ru.zigono.dmc.protocol.transport;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.concurrent.GlobalEventExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.ReplayGuard;
import ru.zigono.dmc.protocol.net.SecureMessageCodec;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * TLS protected Netty server that accepts Minecraft plugin and Discord bot connections.
 *
 * @author Zigono
 */
public final class TransportServer implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransportServer.class);

    private final TransportSettings settings;
    private final KeyResolver keys;
    private final ConnectionHandler handler;
    private final Consumer<ProtocolException> violations;
    private final ReplayGuard replayGuard;
    private final ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    private EventLoopGroup bossGroup;
    private EventLoopGroup workerGroup;
    private Channel serverChannel;
    private SslContext sslContext;

    public TransportServer(TransportSettings settings, KeyResolver keys, ConnectionHandler handler,
                           Consumer<ProtocolException> violationHandler) {
        this.settings = settings;
        this.keys = keys;
        this.handler = handler;
        this.violations = violationHandler == null ? ignored -> { } : violationHandler;
        this.replayGuard = new ReplayGuard(TimeUnit.SECONDS.toMillis(120), 200_000);
    }

    public void start() throws InterruptedException {
        if (settings.tlsEnabled()) {
            sslContext = TlsContextFactory.serverContext(settings);
        } else {
            LOGGER.warn("TLS отключён для слушателя шлюза ({}:{}); это недопустимо в рабочей среде",
                    settings.host(), settings.port());
        }
        bossGroup = new NioEventLoopGroup(1);
        workerGroup = new NioEventLoopGroup(settings.workerThreads());
        final SslContext tlsContext = sslContext;
        final ServerBootstrap bootstrap = new ServerBootstrap()
                .group(bossGroup, workerGroup)
                .channel(NioServerSocketChannel.class)
                .option(ChannelOption.SO_BACKLOG, 256)
                .childOption(ChannelOption.TCP_NODELAY, true)
                .childOption(ChannelOption.SO_KEEPALIVE, true)
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    @Override
                    protected void initChannel(SocketChannel channel) {
                        channels.add(channel);
                        final SecureMessageCodec codec = new SecureMessageCodec(keys, replayGuard, true, true, null,
                                violation -> violations.accept(violation));
                        if (tlsContext != null) {
                            channel.pipeline().addLast("tls", tlsContext.newHandler(channel.alloc()));
                        }
                        channel.pipeline()
                                .addLast("idle", new IdleStateHandler(0, 0, (int) settings.idleTimeout().toSeconds()))
                                .addLast("frameDecoder", new LengthFieldBasedFrameDecoder(settings.maxFrameBytes(), 0, 4, 0, 4))
                                .addLast("frameEncoder", new LengthFieldPrepender(4))
                                .addLast("codec", codec)
                                .addLast("handler", new ServerHandler(new NettyConnection(channel, codec)));
                    }
                });
        final ChannelFuture future = bootstrap.bind(new InetSocketAddress(settings.host(), settings.port())).sync();
        serverChannel = future.channel();
        LOGGER.info("Слушатель шлюза привязан к {}:{}{}", settings.host(), settings.port(),
                settings.tlsEnabled() ? " с TLS" : " без TLS");
    }

    public int port() {
        return serverChannel == null ? -1 : ((InetSocketAddress) serverChannel.localAddress()).getPort();
    }

    public List<Connection> connections() {
        final List<Connection> result = new ArrayList<>();
        channels.forEach(channel -> {
            final ServerHandler serverHandler = channel.pipeline().get(ServerHandler.class);
            if (serverHandler != null) {
                result.add(serverHandler.connection());
            }
        });
        return result;
    }

    @Override
    public void close() {
        if (serverChannel != null) {
            serverChannel.close().awaitUninterruptibly(settings.shutdownGrace().toMillis());
        }
        channels.close().awaitUninterruptibly(settings.shutdownGrace().toMillis());
        if (bossGroup != null) {
            bossGroup.shutdownGracefully(0, settings.shutdownGrace().toMillis(), TimeUnit.MILLISECONDS);
        }
        if (workerGroup != null) {
            workerGroup.shutdownGracefully(0, settings.shutdownGrace().toMillis(), TimeUnit.MILLISECONDS);
        }
        LOGGER.info("Слушатель шлюза остановлен");
    }

    /**
     * Per connection Netty handler forwarding events to the {@link ConnectionHandler}.
     */
    private final class ServerHandler extends SimpleChannelInboundHandler<Message> {

        private final Connection connection;

        private ServerHandler(Connection connection) {
            this.connection = connection;
        }

        private Connection connection() {
            return connection;
        }

        @Override
        public void channelActive(ChannelHandlerContext context) {
            LOGGER.debug("Соединение открыто из {}", connection.remoteAddress());
            handler.onOpen(connection);
        }

        @Override
        protected void channelRead0(ChannelHandlerContext context, Message message) {
            handler.onMessage(connection, message);
        }

        @Override
        public void channelInactive(ChannelHandlerContext context) {
            LOGGER.debug("Соединение {} закрыто", connection.id());
            handler.onClose(connection);
        }

        @Override
        public void userEventTriggered(ChannelHandlerContext context, Object event) {
            if (event instanceof IdleStateEvent) {
                LOGGER.debug("Закрываю неактивное соединение {}", connection.id());
                context.close();
            }
        }

        @Override
        public void exceptionCaught(ChannelHandlerContext context, Throwable cause) {
            handler.onFailure(connection, cause);
            context.close();
        }
    }
}
