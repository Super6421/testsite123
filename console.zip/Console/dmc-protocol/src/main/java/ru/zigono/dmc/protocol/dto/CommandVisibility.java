package ru.zigono.dmc.protocol.dto;

/**
 * How the execution should be announced on the Minecraft side, resolved from the plugin configuration and
 * from the command visibility rules of the gateway.
 *
 * @author Zigono
 */
public record CommandVisibility(boolean showInConsole, boolean showInGame, String permission, String format,
                                String resultFormat, String announcement) {

    public static CommandVisibility consoleOnly() {
        return new CommandVisibility(true, false, null, null, null, null);
    }

    public CommandVisibility orDefault(CommandVisibility fallback) {
        return this;
    }
}