package ru.zigono.dmc.protocol.dto;

import java.util.List;

/**
 * Everything the bot needs to render a permission aware UI: the servers and groups the user may address plus
 * the effective capabilities. The gateway is the single source of truth for the ACL.
 *
 * @author Zigono
 */
public record TargetsView(
        boolean singleServerMode,
        String defaultServer,
        List<ServerOption> servers,
        List<GroupOption> groups,
        Capabilities capabilities,
        String configRevision,
        long generatedAt) {

    public TargetsView {
        servers = servers == null ? List.of() : List.copyOf(servers);
        groups = groups == null ? List.of() : List.copyOf(groups);
    }

    public record ServerOption(String id, String name, ServerStatus status, boolean enabled) {
    }

    public record GroupOption(String name, List<String> servers) {
        public GroupOption {
            servers = servers == null ? List.of() : List.copyOf(servers);
        }
    }

    public record Capabilities(boolean read, boolean execute, boolean dryRun, boolean broadcast, boolean broadcastAll,
                               boolean status, boolean history, boolean reload, boolean emergency) {

        public static Capabilities none() {
            return new Capabilities(false, false, false, false, false, false, false, false, false);
        }
    }
}