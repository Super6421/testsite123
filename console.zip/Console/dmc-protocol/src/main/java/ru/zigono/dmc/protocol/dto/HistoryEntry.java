package ru.zigono.dmc.protocol.dto;

/**
 * One record of the command history.
 *
 * @author Zigono
 */
public record HistoryEntry(
        String requestId,
        String userId,
        String username,
        String guildId,
        String channelId,
        String target,
        String serverId,
        String command,
        String status,
        long durationMillis,
        String response,
        String errorCode,
        boolean dryRun,
        long createdAt) {
}