package ru.zigono.dmc.protocol;

import java.util.Map;
import java.util.Optional;

/**
 * Resolves the shared secret of a client. The gateway looks it up in the configuration; standalone clients
 * return their own single credential.
 *
 * @author Zigono
 */
@FunctionalInterface
public interface KeyResolver {

    Optional<byte[]> keyFor(String clientId);

    static KeyResolver single(String clientId, byte[] key) {
        return requested -> clientId != null && clientId.equals(requested) ? Optional.of(key) : Optional.empty();
    }

    static KeyResolver of(Map<String, byte[]> keys) {
        final Map<String, byte[]> copy = Map.copyOf(keys);
        return clientId -> Optional.ofNullable(copy.get(clientId));
    }

    static KeyResolver empty() {
        return clientId -> Optional.empty();
    }
}