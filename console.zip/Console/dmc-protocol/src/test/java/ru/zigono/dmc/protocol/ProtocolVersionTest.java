package ru.zigono.dmc.protocol;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Compatibility rules of the protocol version.
 *
 * @author Zigono
 */
class ProtocolVersionTest {

    @Test
    @DisplayName("only supported protocol versions are accepted")
    void compatibility() {
        assertTrue(ProtocolVersion.isCompatible(ProtocolVersion.CURRENT));
        assertTrue(ProtocolVersion.isCompatible(ProtocolVersion.MIN_SUPPORTED));
        assertFalse(ProtocolVersion.isCompatible(0));
        assertFalse(ProtocolVersion.isCompatible(ProtocolVersion.CURRENT + 1));
        assertFalse(ProtocolVersion.isCompatible(99));
    }

    @Test
    @DisplayName("secrets must be long enough and support hex encoding")
    void secretDecoding() {
        assertTrue(Secrets.decode("0123456789abcdef", "test").length == 16);
        assertTrue(Secrets.decode("hex:00112233445566778899aabbccddeeff", "test").length == 16);
        assertTrue(Secrets.decode("base64:MDEyMzQ1Njc4OWFiY2RlZg==", "test").length == 16);
        org.junit.jupiter.api.Assertions.assertThrows(ProtocolException.class, () -> Secrets.decode("short", "test"));
        org.junit.jupiter.api.Assertions.assertThrows(ProtocolException.class, () -> Secrets.decode(null, "test"));
    }
}