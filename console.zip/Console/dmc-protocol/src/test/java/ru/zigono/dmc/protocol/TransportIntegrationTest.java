package ru.zigono.dmc.protocol;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.support.TestCertificates;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.ConnectionHandler;
import ru.zigono.dmc.protocol.transport.TransportClient;
import ru.zigono.dmc.protocol.transport.TransportServer;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * End to end transport test over real TLS sockets.
 *
 * @author Zigono
 */
class TransportIntegrationTest {

    private static final byte[] PLUGIN_KEY = "survival-secret-0000000000000000".getBytes(StandardCharsets.UTF_8);

    /**
     * @param keyStore   keystore of this side, {@code null} when the side has no client certificate
     * @param trustStore artifacts whose certificate is trusted by this side, {@code null} for the trust all default
     */
    private static TransportSettings settings(TestCertificates.Artifacts keyStore, TestCertificates.Artifacts trustStore,
                                              int port, String clientId, String role) {
        return new TransportSettings(true, false, "127.0.0.1", port,
                keyStore == null ? null : keyStore.keyStore(),
                keyStore == null ? null : TestCertificates.PASSWORD,
                keyStore == null ? null : TestCertificates.PASSWORD,
                trustStore == null ? null : trustStore.trustStore(),
                trustStore == null ? null : TestCertificates.PASSWORD,
                null, null, null, false,
                List.of("TLSv1.3", "TLSv1.2"), 262_144,
                Duration.ofSeconds(5), Duration.ofSeconds(10), Duration.ofMinutes(1), Duration.ofSeconds(2),
                Duration.ofMillis(100), Duration.ofSeconds(2), 2.0d, 2, clientId, role);
    }

    @Test
    @DisplayName("plugin and gateway exchange signed messages over TLS")
    void exchangesSignedMessages(@TempDir Path directory) throws Exception {
        final TestCertificates.Artifacts gatewayCerts = TestCertificates.generate(directory.resolve("gateway"));

        final CompletableFuture<HandshakeMessages.Pong> pong = new CompletableFuture<>();
        final CountDownLatch connected = new CountDownLatch(1);
        final CopyOnWriteArrayList<String> received = new CopyOnWriteArrayList<>();
        final TransportServer server = new TransportServer(
                settings(gatewayCerts, null, 0, null, "gateway"),
                KeyResolver.of(Map.of("survival", PLUGIN_KEY)),
                new ConnectionHandler() {
                    @Override
                    public void onOpen(Connection connection) {
                    }

                    @Override
                    public void onMessage(Connection connection, Message message) {
                        received.add(MessageTypes.nameOf(message.getClass()));
                        if (message instanceof HandshakeMessages.Ping ping) {
                            final HandshakeMessages.Pong reply = ping.correlate(new HandshakeMessages.Pong());
                            reply.sentAt = ping.sentAt;
                            reply.sequence = ping.sequence;
                            reply.serverTime = System.currentTimeMillis();
                            connection.send(reply);
                        }
                    }

                    @Override
                    public void onClose(Connection connection) {
                    }

                    @Override
                    public void onFailure(Connection connection, Throwable cause) {
                    }
                },
                violation -> { });
        server.start();

        final CopyOnWriteArrayList<ProtocolException> violations = new CopyOnWriteArrayList<>();
        final TransportClient client = new TransportClient(
                settings(null, gatewayCerts, server.port(), "survival", "plugin"),
                KeyResolver.single("survival", PLUGIN_KEY),
                new TransportClient.Listener() {
                    @Override
                    public void onConnected(Connection connection) {
                        connected.countDown();
                    }

                    @Override
                    public void onMessage(Connection connection, Message message) {
                        if (message instanceof HandshakeMessages.Pong pongMessage) {
                            pong.complete(pongMessage);
                        }
                    }

                    @Override
                    public void onDisconnected(Throwable cause) {
                    }

                    @Override
                    public void onViolation(ProtocolException violation) {
                        violations.add(violation);
                    }
                });
        try {
            client.start();
            assertTrue(connected.await(10, TimeUnit.SECONDS), "the client must connect to the gateway");

            final PluginMessages.Heartbeat heartbeat = new PluginMessages.Heartbeat();
            heartbeat.metrics = ru.zigono.dmc.protocol.dto.ServerMetrics.empty("survival");
            heartbeat.status = "ONLINE";
            client.send(heartbeat);

            final long sentAt = System.currentTimeMillis();
            final HandshakeMessages.Pong reply = client.request(newPing(), Duration.ofSeconds(10))
                    .thenApply(message -> (HandshakeMessages.Pong) message)
                    .get(10, TimeUnit.SECONDS);
            assertNotNull(reply);
            assertTrue(reply.serverTime >= sentAt);
            assertTrue(received.contains("HEARTBEAT"), () -> "gateway received: " + received);
            assertTrue(received.contains("PING"), () -> "gateway received: " + received);
            assertTrue(violations.isEmpty(), () -> "unexpected violations: " + violations);
        } finally {
            client.close();
            server.close();
        }
    }

    private static HandshakeMessages.Ping newPing() {
        final HandshakeMessages.Ping ping = new HandshakeMessages.Ping();
        ping.sentAt = System.currentTimeMillis();
        ping.sequence = System.nanoTime();
        return ping;
    }

    @Test
    @DisplayName("a client with the wrong secret is rejected and disconnected")
    void wrongSecretRejected(@TempDir Path directory) throws Exception {
        final TestCertificates.Artifacts gatewayCerts = TestCertificates.generate(directory.resolve("gateway"));
        final CopyOnWriteArrayList<ProtocolException> violations = new CopyOnWriteArrayList<>();
        final CountDownLatch closed = new CountDownLatch(1);
        final TransportServer server = new TransportServer(
                settings(gatewayCerts, null, 0, null, "gateway"),
                KeyResolver.of(Map.of("survival", PLUGIN_KEY)),
                new ConnectionHandler() {
                    @Override
                    public void onOpen(Connection connection) {
                    }

                    @Override
                    public void onMessage(Connection connection, Message message) {
                    }

                    @Override
                    public void onClose(Connection connection) {
                        closed.countDown();
                    }

                    @Override
                    public void onFailure(Connection connection, Throwable cause) {
                    }
                },
                violations::add);
        server.start();
        final CountDownLatch connected = new CountDownLatch(1);
        final TransportClient client = new TransportClient(
                settings(null, gatewayCerts, server.port(), "survival", "plugin"),
                KeyResolver.single("survival", "totally-wrong-secret-00000000".getBytes(StandardCharsets.UTF_8)),
                new TransportClient.Listener() {
                    @Override
                    public void onConnected(Connection connection) {
                        connected.countDown();
                    }

                    @Override
                    public void onMessage(Connection connection, Message message) {
                    }

                    @Override
                    public void onDisconnected(Throwable cause) {
                    }
                });
        try {
            client.start();
            assertTrue(connected.await(10, TimeUnit.SECONDS), "the TLS handshake must succeed before authentication");
            final PluginMessages.Heartbeat heartbeat = new PluginMessages.Heartbeat();
            heartbeat.metrics = ru.zigono.dmc.protocol.dto.ServerMetrics.empty("survival");
            client.send(heartbeat);

            final long deadline = System.currentTimeMillis() + 10_000L;
            while (violations.isEmpty() && System.currentTimeMillis() < deadline) {
                Thread.sleep(25L);
            }
            assertTrue(!violations.isEmpty(), "the gateway must report an authentication violation");
            assertEquals(ErrorCode.AUTHENTICATION_FAILED, violations.get(0).code());
            assertTrue(closed.await(10, TimeUnit.SECONDS), "the gateway must close the offending connection");
        } finally {
            client.close();
            server.close();
        }
    }

    @Test
    @DisplayName("requests without a connection fail fast")
    void requestWithoutConnection() {
        final TransportClient client = new TransportClient(
                settings(null, null, 65001, "survival", "plugin"),
                KeyResolver.single("survival", PLUGIN_KEY),
                new TransportClient.Listener() {
                    @Override
                    public void onConnected(Connection connection) {
                    }

                    @Override
                    public void onMessage(Connection connection, Message message) {
                    }

                    @Override
                    public void onDisconnected(Throwable cause) {
                    }
                });
        try {
            final AtomicReference<RuntimeException> failure = new AtomicReference<>();
            try {
                client.request(newPing(), Duration.ofSeconds(1));
            } catch (RuntimeException e) {
                failure.set(e);
            }
            assertNotNull(failure.get());
            assertEquals("ru.zigono.dmc.common.errors.CommandException", failure.get().getClass().getName());
        } finally {
            client.close();
        }
    }
}