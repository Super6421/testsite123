package ru.zigono.dmc.protocol;

import io.netty.buffer.ByteBuf;
import io.netty.channel.embedded.EmbeddedChannel;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.net.SecureMessageCodec;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Framing, signing and verification of protocol messages.
 *
 * @author Zigono
 */
class MessageCodecTest {

    private static final byte[] SURVIVAL_KEY = "survival-secret-0000000000000000".getBytes(StandardCharsets.UTF_8);
    private static final byte[] LOBBY_KEY = "lobby-secret-0000000000000000000".getBytes(StandardCharsets.UTF_8);

    private static SecureMessageCodec codec(String localClientId, boolean enforceBoundIdentity, List<ProtocolException> violations) {
        return new SecureMessageCodec(KeyResolver.of(java.util.Map.of("survival", SURVIVAL_KEY, "lobby", LOBBY_KEY,
                "bot", LOBBY_KEY)), new ReplayGuard(120_000, 4096), true, enforceBoundIdentity, localClientId,
                violations::add);
    }

    private static PluginMessages.CommandDispatch dispatch(String clientId) {
        final PluginMessages.CommandDispatch message = new PluginMessages.CommandDispatch();
        message.setClientId(clientId);
        message.serverId = "survival";
        message.command = "cmi heal Zigono";
        message.issuer = ru.zigono.dmc.protocol.dto.UserContext.of("1", "Zigono", "10", "20");
        return message;
    }

    @Test
    @DisplayName("a signed message survives the round trip")
    void roundTrip() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("bot", false, violations));
        assertTrue(sender.writeOutbound(dispatch("bot")));
        final ByteBuf frame = sender.readOutbound();
        assertNotNull(frame);

        final EmbeddedChannel receiver = new EmbeddedChannel(codec(null, true, violations));
        assertTrue(receiver.writeInbound(frame));
        final PluginMessages.CommandDispatch received = assertInstanceOf(PluginMessages.CommandDispatch.class,
                receiver.readInbound());
        assertEquals("survival", received.serverId);
        assertEquals("cmi heal Zigono", received.command);
        assertNotNull(received.getSignature());
        assertTrue(violations.isEmpty());
    }

    @Test
    @DisplayName("a tampered payload is rejected and the connection is closed")
    void tamperedPayloadRejected() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("bot", false, violations));
        sender.writeOutbound(dispatch("bot"));
        final ByteBuf frame = sender.readOutbound();
        final int index = frame.readerIndex();
        frame.setByte(index + 40, frame.getByte(index + 40) ^ 0x01);

        final EmbeddedChannel receiver = new EmbeddedChannel(codec(null, true, violations));
        receiver.writeInbound(frame);
        assertNull(receiver.readInbound());
        assertEquals(1, violations.size());
        assertEquals(ru.zigono.dmc.common.errors.ErrorCode.AUTHENTICATION_FAILED, violations.get(0).code());
    }

    @Test
    @DisplayName("an identity mismatch on a bound connection is rejected")
    void identityMismatchRejected() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("lobby", false, violations));
        sender.writeOutbound(dispatch("lobby"));
        final ByteBuf frame = sender.readOutbound();

        final SecureMessageCodec boundCodec = codec(null, true, violations);
        boundCodec.bindClientId("survival");
        final EmbeddedChannel receiver = new EmbeddedChannel(boundCodec);
        receiver.writeInbound(frame);
        assertNull(receiver.readInbound());
        assertEquals(1, violations.size());
        assertTrue(violations.get(0).getMessage().contains("несовпадение отправителя"));
    }

    @Test
    @DisplayName("unknown clients and unsupported protocol versions are rejected")
    void rejectsUnknownClientAndVersion() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("bot", false, violations));
        final PluginMessages.CommandDispatch message = dispatch("bot");
        message.setProtocolVersion(99);
        sender.writeOutbound(message);
        final ByteBuf frame = sender.readOutbound();

        final EmbeddedChannel receiver = new EmbeddedChannel(codec(null, true, violations));
        receiver.writeInbound(frame);
        assertNull(receiver.readInbound());
        assertTrue(violations.get(0).getMessage().contains("неподдерживаемая версия протокола"));

        final List<ProtocolException> second = new ArrayList<>();
        final EmbeddedChannel stranger = new EmbeddedChannel(codec("intruder", false, second));
        assertThrows(io.netty.handler.codec.EncoderException.class,
                () -> stranger.writeOutbound(dispatch("intruder")), "signing with an unknown identity must fail");
    }

    @Test
    @DisplayName("replayed messages are rejected by the receiver")
    void replayedMessageRejected() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("bot", false, violations));
        sender.writeOutbound(dispatch("bot"));
        final ByteBuf frame = sender.readOutbound();
        final ByteBuf copy = frame.copy();

        final EmbeddedChannel receiver = new EmbeddedChannel(codec(null, true, violations));
        receiver.writeInbound(frame);
        assertInstanceOf(PluginMessages.CommandDispatch.class, receiver.readInbound());
        receiver.writeInbound(copy);
        assertNull(receiver.readInbound());
        assertEquals(1, violations.size());
        assertEquals(ru.zigono.dmc.common.errors.ErrorCode.AUTHENTICATION_FAILED, violations.get(0).code());
    }

    @Test
    @DisplayName("handshake messages round trip as well")
    void handshakeRoundTrip() {
        final List<ProtocolException> violations = new ArrayList<>();
        final EmbeddedChannel sender = new EmbeddedChannel(codec("bot", false, violations));
        final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
        hello.setClientId("bot");
        hello.role = "control";
        hello.agentName = "dmc-bot";
        hello.agentVersion = "1.0.0";
        sender.writeOutbound(hello);
        final ByteBuf frame = sender.readOutbound();

        final EmbeddedChannel receiver = new EmbeddedChannel(codec(null, true, violations));
        receiver.writeInbound(frame);
        final HandshakeMessages.Hello received = assertInstanceOf(HandshakeMessages.Hello.class, receiver.readInbound());
        assertEquals("control", received.role);
        assertEquals("dmc-bot", received.agentName);
    }
}