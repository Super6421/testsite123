package ru.zigono.dmc.protocol.support;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 * Generates short lived self signed certificates for transport tests.
 *
 * @author Zigono
 */
public final class TestCertificates {

    public static final String PASSWORD = "test-password";

    private TestCertificates() {
    }

    /**
     * @param directory directory receiving {@code server.p12} and {@code truststore.p12}
     */
    public static Artifacts generate(Path directory) {
        try {
            Files.createDirectories(directory);
            final KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048);
            final KeyPair keyPair = generator.generateKeyPair();
            final X500Name subject = new X500Name("CN=localhost, O=Zigono, OU=DMC tests");
            final Instant now = Instant.now();
            final JcaX509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(subject,
                    BigInteger.valueOf(now.toEpochMilli()),
                    Date.from(now.minus(1, ChronoUnit.HOURS)),
                    Date.from(now.plus(1, ChronoUnit.DAYS)),
                    subject,
                    keyPair.getPublic());
            builder.addExtension(Extension.basicConstraints, true, new BasicConstraints(true));
            builder.addExtension(Extension.subjectAlternativeName, false, new GeneralNames(new GeneralName[]{
                    new GeneralName(GeneralName.dNSName, "localhost"),
                    new GeneralName(GeneralName.dNSName, "gateway"),
                    new GeneralName(GeneralName.iPAddress, "127.0.0.1")
            }));
            final ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(keyPair.getPrivate());
            final X509Certificate certificate = new JcaX509CertificateConverter()
                    .getCertificate(builder.build(signer));

            final Path keyStorePath = directory.resolve("server.p12");
            final KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(null, PASSWORD.toCharArray());
            keyStore.setKeyEntry("gateway", keyPair.getPrivate(), PASSWORD.toCharArray(),
                    new Certificate[]{certificate});
            try (OutputStream out = Files.newOutputStream(keyStorePath)) {
                keyStore.store(out, PASSWORD.toCharArray());
            }

            final Path trustStorePath = directory.resolve("truststore.p12");
            final KeyStore trustStore = KeyStore.getInstance("PKCS12");
            trustStore.load(null, PASSWORD.toCharArray());
            trustStore.setCertificateEntry("gateway", certificate);
            try (OutputStream out = Files.newOutputStream(trustStorePath)) {
                trustStore.store(out, PASSWORD.toCharArray());
            }

            return new Artifacts(keyStorePath, trustStorePath, certificate);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to generate test certificates", e);
        }
    }

    public record Artifacts(Path keyStore, Path trustStore, X509Certificate certificate) {
        public String password() {
            return PASSWORD;
        }
    }
}