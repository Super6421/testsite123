package ru.zigono.dmc.protocol;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.protocol.message.PluginMessages;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * HMAC signature of the canonical message envelope.
 *
 * @author Zigono
 */
class MessageSignatureTest {

    private static final byte[] KEY = "0123456789abcdef0123456789abcdef".getBytes(StandardCharsets.UTF_8);
    private static final byte[] OTHER_KEY = "ffffffffffffffffffffffffffffffff".getBytes(StandardCharsets.UTF_8);

    private static PluginMessages.CommandDispatch dispatch() {
        final PluginMessages.CommandDispatch message = new PluginMessages.CommandDispatch();
        message.setClientId("gateway");
        message.setRequestId("01JTESTREQUEST000000000000");
        message.setNonce("aabbccddeeff00112233445566778899");
        message.setTimestamp(System.currentTimeMillis());
        message.serverId = "survival";
        message.command = "cmi heal Zigono";
        message.attempt = 1;
        return message;
    }

    @Test
    @DisplayName("a signed message verifies with the same key only")
    void signAndVerify() {
        final PluginMessages.CommandDispatch message = dispatch();
        MessageSigner.sign(message, KEY);
        assertTrue(MessageSigner.verify(message, KEY));
        assertFalse(MessageSigner.verify(message, OTHER_KEY));
    }

    @Test
    @DisplayName("any modification of the payload invalidates the signature")
    void tamperedPayloadRejected() {
        final PluginMessages.CommandDispatch message = dispatch();
        MessageSigner.sign(message, KEY);
        message.command = "cmi heal Attacker";
        assertFalse(MessageSigner.verify(message, KEY));
    }

    @Test
    @DisplayName("changing the envelope invalidates the signature")
    void tamperedEnvelopeRejected() {
        final PluginMessages.CommandDispatch message = dispatch();
        MessageSigner.sign(message, KEY);
        message.setClientId("somebody-else");
        assertFalse(MessageSigner.verify(message, KEY));
    }

    @Test
    @DisplayName("the reply flag is part of the signed envelope")
    void tamperedReplyFlagRejected() {
        final PluginMessages.CommandDispatch message = dispatch();
        final PluginMessages.CommandOutcomeMessage outcome = message.correlate(new PluginMessages.CommandOutcomeMessage());
        MessageSigner.sign(outcome, KEY);
        assertTrue(MessageSigner.verify(outcome, KEY));
        outcome.setReply(false);
        assertFalse(MessageSigner.verify(outcome, KEY));
    }

    @Test
    @DisplayName("messages without a signature are rejected")
    void missingSignature() {
        assertFalse(MessageSigner.verify(dispatch(), KEY));
        final PluginMessages.CommandDispatch message = dispatch();
        message.setSignature("not-hex");
        assertFalse(MessageSigner.verify(message, KEY));
    }
}