package ru.zigono.dmc.protocol;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.errors.ErrorCode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Replay protection for timestamps, request ids, nonces and correlated replies.
 *
 * @author Zigono
 */
class ReplayGuardTest {

    @Test
    @DisplayName("the same request id cannot be used twice")
    void rejectsReplayedRequestId() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        guard.check("survival", "01J1", "nonce-1", now);
        final ProtocolException exception = assertThrows(ProtocolException.class,
                () -> guard.check("survival", "01J1", "nonce-2", now));
        assertEquals(ErrorCode.AUTHENTICATION_FAILED, exception.code());
    }

    @Test
    @DisplayName("the same nonce cannot be used twice")
    void rejectsReplayedNonce() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        guard.check("survival", "01J1", "nonce-1", now);
        assertThrows(ProtocolException.class, () -> guard.check("survival", "01J2", "nonce-1", now));
    }

    @Test
    @DisplayName("nonces are scoped per identity")
    void scopedPerIdentity() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        guard.check("survival", "01J1", "nonce-1", now);
        guard.check("lobby", "01J1", "nonce-1", now);
        assertTrue(guard.size() >= 4);
    }

    @Test
    @DisplayName("stale and future timestamps are rejected")
    void rejectsTimestampOutsideWindow() {
        final ReplayGuard guard = new ReplayGuard(5_000, 1024);
        final long now = System.currentTimeMillis();
        assertEquals(ErrorCode.AUTHENTICATION_FAILED,
                assertThrows(ProtocolException.class, () -> guard.check("survival", "01J1", "n1", now - 60_000)).code());
        assertEquals(ErrorCode.AUTHENTICATION_FAILED,
                assertThrows(ProtocolException.class, () -> guard.check("survival", "01J2", "n2", now + 60_000)).code());
        guard.check("survival", "01J3", "n3", now);
    }

    @Test
    @DisplayName("a correlated reply may reuse the request id of the message it answers")
    void acceptsRepliesThatReuseTheRequestId() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        guard.check("survival", "01J1", "nonce-1", now);
        guard.check("survival", "01J1", "nonce-2", now, true);
        guard.check("survival", "01J1", "nonce-3", now, true);
        assertThrows(ProtocolException.class, () -> guard.check("survival", "01J1", "nonce-4", now));
    }

    @Test
    @DisplayName("a replayed reply is still rejected, because every message needs a fresh nonce")
    void rejectsReplayedReplyNonce() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        guard.check("survival", "01J1", "nonce-1", now, true);
        assertThrows(ProtocolException.class, () -> guard.check("survival", "01J1", "nonce-1", now, true));
    }

    @Test
    @DisplayName("a reply without a request id cannot be correlated and is rejected")
    void rejectsReplyWithoutRequestId() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        assertThrows(ProtocolException.class, () -> guard.check("survival", null, "nonce-1", now, true));
        assertThrows(ProtocolException.class, () -> guard.check("survival", " ", "nonce-2", now, true));
    }

    @Test
    @DisplayName("messages without a request id or nonce are rejected")
    void requiresEnvelopeFields() {
        final ReplayGuard guard = new ReplayGuard(60_000, 1024);
        final long now = System.currentTimeMillis();
        assertThrows(ProtocolException.class, () -> guard.check("survival", null, "n1", now));
        assertThrows(ProtocolException.class, () -> guard.check("survival", "01J1", null, now));
        assertThrows(ProtocolException.class, () -> guard.check("survival", "01J1", "n1", 0));
    }
}