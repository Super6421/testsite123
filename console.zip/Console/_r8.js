const fs = require("fs");
const t = fs.readFileSync("dmc-gateway/src/main/java/ru/zigono/dmc/gateway/auth/AuthorizationService.java","utf8");
console.log(t);