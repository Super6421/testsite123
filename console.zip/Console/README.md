# Discord Minecraft Console Gateway

**Управление Minecraft-серверами из Discord: настоящие команды, настоящий ответ сервера, защищённый control-plane.**

> **Автор: Zigono** · Лицензия MIT · Версия 1.0.0 · Протокол 1

Система позволяет авторизованным пользователям Discord выполнять команды на Minecraft-серверах
(одном, нескольких, группе или на всех сразу), получать **реальный вывод серверной консоли**,
видеть состояние серверов и историю действий — под полноценным ACL, command policy engine,
rate limiting, очередями, аудитом и защищённым протоколом.

MVP, mock-ответов, заглушек и незаконченных подсистем в проекте нет: каждая команда доходит до
Bukkit/Paper консоли и возвращается обратно.

---

## Архитектура

Один и тот же код собирается в **два развёртывания**, между которыми можно переключаться одной настройкой:

| Режим | Что запускается | Когда использовать |
|---|---|---|
| **Embedded** («всё внутри плагина») | Discord-бот и шлюз работают **внутри процесса Paper-плагина**; наружу открыт только порт Minecraft | Панельный хостинг (Pterodactyl и подобные), один игровой сервер |
| **Три компонента** | Отдельные процессы `dmc-gateway` и `dmc-bot`, плагины подключаются к шлюзу по сети через TLS + HMAC | Свой VPS, несколько Minecraft-серверов, общий аудит и метрики, Redis |

Оба режима используют один протокол, одну модель прав, один command policy engine и один аудит — меняется только то, где физически работает control-plane.

### Режим embedded — один jar внутри плагина

```text
                        ┌──────────────────────────────────────────┐
                        │                Discord                   │
                        │  /console  /console-history  /servers    │
                        └───────────────────┬──────────────────────┘
                                            │  Discord interactions
                                            ▼
   ┌────────────────────────────────────────────────────────────────────┐
   │ Paper server — один процесс, один jar                              │
   │                                                                    │
   │   Discord Bot (JDA)   ──►  Embedded Gateway  ──►  DMC plugin       │
   │   slash-команды            ACL · command policy   консоль + LP     │
   │   UI · аудит-канал         rate limit · очередь   захват вывода    │
   │   подтверждения            аудит в SQLite         LuckPerms        │
   │                                                                    │
   │   Связь: loopback 127.0.0.1, свободный порт, TLS выключен          │
   └────────────────────────────────────────────────────────────────────┘
```

Плагин поднимает шлюз на loopback (`127.0.0.1`, свободный порт выбирает система) и подключается к нему как обычный клиент, а Discord-бот стартует в том же процессе. TLS не требуется: трафик не покидает машину. Конфигурация шлюза и бота (`embedded/gateway.yml`, `embedded/bot.yml`) вместе с секретами связи (`server.secret`, `control.secret`) генерируется автоматически из `config.yml`, а база аудита ведётся в SQLite (`embedded/data/gateway.db`).

### Режим трёх компонентов

```text
                        ┌──────────────────────────────────────────┐
                        │                Discord                   │
                        │  /console  /console-history  /servers    │
                        └───────────────────┬──────────────────────┘
                                            │  Discord interactions
                                            ▼
                        ┌──────────────────────────────────────────┐
                        │              Discord Bot (JDA)           │
                        │  slash commands · permission-aware UI    │
                        │  confirmations · embeds · audit channel  │
                        └───────────────────┬──────────────────────┘
                                            │  TLS + HMAC-SHA256 (role control)
                                            ▼
                        ┌──────────────────────────────────────────┐
                        │            Secure Gateway                │
                        │  ACL · policy · rate limit · queues      │
                        │  retry · audit (PostgreSQL/SQLite)       │
                        │  metrics · health · Redis (optional)     │
                        └───┬───────────────┬───────────────┬──────┘
                            │               │               │
              TLS+HMAC      │               │               │   TLS+HMAC
              role plugin   │               │               │   role plugin
                            ▼               ▼               ▼
                 ┌───────────────┐ ┌───────────────┐ ┌───────────────┐
                 │ Paper plugin  │ │ Paper plugin  │ │ Paper plugin  │
                 │    Lobby      │ │   Survival    │ │   SkyBlock    │
                 │ консоль+LP    │ │ консоль+LP    │ │ консоль+LP    │
                 └───────────────┘ └───────────────┘ └───────────────┘
```

Роли компонентов:

- **Discord** — интерфейс управления.
- **Discord Bot** — Discord-взаимодействия, UI, подтверждения, отображение результата.
- **Secure Gateway** — защищённый control-plane, единственный источник правды по правам и политикам.
- **Minecraft Plugin** — доверенный исполнитель: выполняет команду в главном потоке сервера и
  возвращает реальный вывод консоли.
- **LuckPerms** — Minecraft-side слой контроля видимости активности Discord Console в игре.
- **Embedded-режим** — те же роли, но шлюз и бот живут внутри процесса плагина: наружу не публикуется ни порт, ни сертификат, ни отдельный процесс.

---

## Главный принцип: pipeline команды

Ни один этап нельзя обойти — pipeline выполняется и ботом (для UI), и заново шлюзом (для
принудительного исполнения), поэтому подделанный клиент не может пропустить проверку.

```text
Discord User
      │
      ▼
Discord Authentication
      │
      ▼
Guild / Channel Validation
      │
      ▼
Discord Role Permissions
      │
      ▼
Target Permission
      │
      ▼
Command Normalization
      │
      ▼
Command Policy Engine
      │
      ▼
Rate Limit
      │
      ▼
Dangerous Command Check
      │
      ▼
Confirmation
      │
      ▼
Secure Gateway Protocol
      │
      ▼
Minecraft Plugin Authentication
      │
      ▼
Minecraft Command Execution
      │
      ▼
Real Minecraft Response
      │
      ▼
Gateway
      │
      ├── Audit Log
      ├── Security Log
      └── Metrics
      │
      ▼
Discord Response
```

---

## Возможности

**Управление**

- `/console` — выполнение команды на выбранном сервере, нескольких серверах, группе или на всех.
- `/console dryrun` — проверка прав, цели, policy, лимитов и требования подтверждения без выполнения.
- `/console-history` — история с фильтрами по пользователю, серверу, команде, статусу и датам.
- `/servers` — состояние серверов, доступных пользователю: игроки, TPS, MSPT, аптайм, память, версии.
- Server groups, aliases и безопасные templates с валидацией параметров.
- `/персонал-выдать` и `/персонал-снять` — выдача и снятие привилегий LuckPerms прямо из Discord: ник, привилегия, причина. Доступные привилегии задаются ролям Discord в `staff.access`.
- `/logs channel` — включить, выключить или перенести журнал выдачи прав в выбранный канал.

**Безопасность**

- Discord ACL: wildcard-права, deny > allow, изоляция по гильдиям, ограничения каналов.
- Command Policy Engine: blocked / allowed (whitelist) / dangerous команды, привязка прав к паттернам.
- Нормализация команды **до** проверки прав: защита от injection, chaining и обхода ACL через аргументы.
- Подтверждение опасных команд инициатором с TTL.
- TLS, HMAC-SHA256 подпись каждого сообщения, nonce, timestamp, replay protection, pinning идентичности.
- IP/CIDR allowlist, лимиты на соединения, секреты только из окружения, редакция секретов в логах.
- Immutable security audit: критические события не удаляются обычной очисткой истории.
- Emergency kill switch (`console.emergency.*`), состояние переживает перезапуск.

**Надёжность**

- Очередь на каждый сервер (FIFO внутри, параллельно между серверами), `on_disconnect: cancel|hold|retry`.
- Retry только для заведомо не принятых команд — повтор опасной команды с неизвестным состоянием запрещён.
- Heartbeat и статусы `ONLINE / OFFLINE / CONNECTING / DEGRADED / AUTH_FAILED`.
- Graceful shutdown, hot reload конфигурации без ломания активных команд.
- Rate limiting per user / role / server / command / group / global с переопределениями.

**Эксплуатация**

- PostgreSQL (production) и SQLite (простой старт), автоматические миграции, retention-политика.
- Prometheus `/metrics`, health `/health`, `/health/live`, `/health/ready`.
- Структурные JSON-логи с correlation id (`request_id`) во всех компонентах.
- Горизонтальное масштабирование нескольких экземпляров шлюза через Redis (опционально).
- Docker и docker compose, systemd-юниты, локализация `ru` / `en`.
- Сообщения, логи и тексты Discord — на русском (`language: ru`); `language: en` переключает на английские.
- Повреждённый `config.yml` не останавливает плагин: прежний файл сохраняется как `config.yml.broken-<дата>`, на его место пишется стандартный, сервер продолжает работать.
- Несколько серверов настраиваются в одном `config.yml` плагина: разделы `servers`, `groups` и `mode` — отдельные файлы для сети не нужны.
- Оформление ответов рассчитано на игроков: эмодзи-статусы и короткая карточка результата без технических полей (возвращаются `ui.show_diagnostics: true`); в футере — подпись автора, Zigono.
- Подписи полей в карточках берутся из локализации: в Discord видно «Пользователь», «Цель», «Статус», а не служебные ключи вида `embed.field.*`.
- Журнал сервера остаётся чистым: отказ по каналу пишется один раз на канал, метрики плагина — на уровне DEBUG.
- Панельный хостинг: embedded-режим без второго процесса, портов и TLS.

---

## Быстрый старт

### Pterodactyl / панельный хостинг — один jar (embedded)

На панельном хостинге нет ни второго процесса, ни второго порта, поэтому шлюз и Discord-бот работают внутри плагина — в том же процессе, что и Minecraft.

1. Загрузите `dist/DiscordMinecraftConsole-1.0.0.jar` в каталог `plugins/` сервера — файловым менеджером панели или по SFTP. Файл весит ≈ 22 МБ: внутри уже есть шлюз, бот и все нужные библиотеки (Netty, JDA, драйвер SQLite) — больше ставить нечего.
2. Перезапустите сервер. Плагин создаст `plugins/DiscordMinecraftConsole/config.yml`, сгенерирует `embedded/gateway.yml`, `embedded/bot.yml` и секреты связи, и поднимет локальный шлюз на `127.0.0.1` (свободный порт выбирает система). В консоли появится `Встроенный режим включён: шлюз ... работает внутри этого сервера на 127.0.0.1:<порт>`.
3. Откройте `plugins/DiscordMinecraftConsole/config.yml`. Поставляемый файл уже заполнен рабочими значениями — токен бота, гильдия, роль с полным доступом и канал консоли; замените их на свои, если ставите бота в другую гильдию или на другой канал:

```yaml
embedded:
  enabled: true
  discord:
    token: "ТОКЕН_БОТА"        # либо переменная окружения DISCORD_TOKEN
    guilds: "ID_ГИЛЬДИИ"       # необязательно: ограничить бота одной гильдией
    audit_channel_id: "ID_КАНАЛА_ЛОГОВ"   # кто какую команду выполнил
  permissions:
    roles:
      ID_РОЛИ_АДМИНИСТРАТОРА: console.*   # права — строкой, без скобок
```

   Токен берётся в Discord Developer Portal → ваше приложение → **Bot** → **Reset Token**. Права выдаются ролям и пользователям по их id — см. `docs/PERMISSIONS.md`.
4. Пригласите бота в гильдию со scopes `bot` + `applications.commands` (**OAuth2 → URL Generator**), иначе slash-команды не появятся.
5. Перезапустите сервер: в консоли появится `Discord-бот запущен и работает как <бот>`, а в Discord — команды `/console`, `/console-history`, `/servers`.
6. Проверка: `/console list` возвращает реальный вывод консоли сервера, а `/discordconsole status` в консоли сервера (или в игре с правом `discordconsole.admin`) показывает loopback-порт и состояние бота.

Дополнительных портов, TLS-сертификатов, PostgreSQL, Redis и второго процесса в этом режиме не нужно. Полная инструкция — `docs/INSTALLATION.md` §2, все ключи — `docs/CONFIGURATION.md` §4.1.

### Три компонента: Docker

```bash
cp .env.example .env          # заполните DISCORD_TOKEN, секреты, POSTGRES_PASSWORD
mkdir -p config tls
cp config/gateway.example.yml config/gateway.yml
cp config/bot.example.yml     config/bot.yml
cp config/plugin.example.yml  config/plugin.yml

# 1. Сборка образа (собирает все три артефакта)
docker build -t zigono/dmc-gateway:1.0.0 .

# 2. TLS-материал: CA, сертификат шлюза и по сертификату на каждый сервер
docker run --rm -v "$PWD/tls:/opt/dmc/tls" zigono/dmc-gateway:1.0.0 \
  certs --out /opt/dmc/tls --hosts gateway.example.com,127.0.0.1 \
        --clients discord-bot,lobby,survival,skyblock \
        --password "$TLS_KEYSTORE_PASSWORD"

# 3. Запуск шлюза + PostgreSQL (+ Redis и бот по профилям)
docker compose up -d gateway
docker compose --profile redis --profile bot up -d
```

### Три компонента: без Docker

```bash
# Требуется JDK 21 и Maven 3.9+
mvn -B clean package            # артефакты появятся в dist/

java -jar dist/dmc-gateway-1.0.0.jar certs --out tls \
     --hosts localhost,10.0.0.5 --clients discord-bot,lobby,survival --password changeit

java -jar dist/dmc-gateway-1.0.0.jar run --config config/gateway.yml    # шлюз
java -jar dist/dmc-bot-1.0.0.jar  --config config/bot.yml               # бот
```

Плагин `dist/DiscordMinecraftConsole-1.0.0.jar` устанавливается в `plugins/` каждого Paper-сервера
(Paper 1.21.1), после чего сервер перезапускается и получает свой `config.yml`.

Подробности: `docs/INSTALLATION.md`.

---

## Модули

| Модуль | Назначение | Ключевые пакеты |
|---|---|---|
| `dmc-common` | ACL, wildcard-права, policy engine, нормализация и валидация команд, rate limit, каталог серверов, i18n, конфиг | `perm`, `command`, `rate`, `target`, `config`, `i18n`, `text`, `security` |
| `dmc-protocol` | Wire protocol: envelope, HMAC-подпись, replay guard, типы сообщений, Netty-транспорт с TLS | `message`, `dto`, `net`, `transport` |
| `dmc-gateway` | Runtime шлюза: слушатель, ACL, очереди, retry, аудит, БД, метрики, Redis, CLI (`run`/`certs`/`version`) | `api`, `auth`, `queue`, `db`, `metrics`, `net`, `redis`, `config` |
| `dmc-bot` | Discord-бот: slash-команды, UI, подтверждения, аудит-канал | `bot` |
| `dmc-plugin` | Paper-плагин: исполнение команд, захват вывода, heartbeat, LuckPerms, видимость в игре, а также embedded-режим (шлюз и бот внутри плагина) | plugin packages, `config` (EmbeddedSettings), `embedded` |

## Артефакты сборки

| Артефакт | Что это | Куда ставить |
|---|---|---|
| `dist/dmc-gateway-1.0.0.jar` | Шлюз (fat jar, main class `ru.zigono.dmc.gateway.GatewayMain`) | Хост/контейнер шлюза |
| `dist/dmc-bot-1.0.0.jar` | Discord-бот (fat jar, main class `ru.zigono.dmc.bot.BotMain`) | Хост/контейнер бота |
| `dist/DiscordMinecraftConsole-1.0.0.jar` | Плагин Paper, ≈ 22 МБ. Для embedded-режима достаточно только этого файла: шлюз и Discord-бот уже внутри (Netty, Jackson и SnakeYAML релоцированы в `ru.zigono.dmc.libs.*`, а SLF4J и бэкенд логирования берутся у сервера — чтобы не спорить с его логгером). Из jar исключены неиспользуемые в этом режиме зависимости: PostgreSQL, Redis (Lettuce/Reactor), BouncyCastle, protobuf и voice-библиотеки JDA; нативный драйвер SQLite оставлен под x86_64/aarch64 Linux, Linux-Musl и Windows | `plugins/` каждого Minecraft-сервера |

---

## Документация

| Документ | Содержание |
|---|---|
| `docs/INSTALLATION.md` | Требования, сборка, установка плагина, генерация TLS, первый запуск |
| `docs/CONFIGURATION.md` | Все параметры шлюза, бота и плагина + полные примеры |
| `docs/PERMISSIONS.md` | Модель прав Discord и LuckPerms, wildcard, deny-приоритет, изоляция гильдий |
| `docs/SECURITY.md` | Threat model, TLS, подписи, управление и ротация секретов, аудит |
| `docs/PROTOCOL.md` | Формат кадров, envelope, правила подписи, handshake, все типы сообщений, статусы |
| `docs/DEPLOYMENT.md` | systemd, сеть и firewall, PostgreSQL/Redis, масштабирование, мониторинг, бэкапы |
| `docs/UPGRADE.md` | Версионирование, совместимость протокола, пошаговое обновление, откат |
| `docs/TROUBLESHOOTING.md` | Матрица симптом → причина → решение с конкретными командами |

Примеры конфигурации: `config/gateway.example.yml`, `config/bot.example.yml`,
`config/plugin.example.yml` (внешний шлюз), `config/plugin-embedded.example.yml` (всё внутри
плагина), переменные окружения — `.env.example`.

Режим embedded пошагово: `docs/INSTALLATION.md` §2; все ключи — `docs/CONFIGURATION.md` §4.1;
диагностика — `docs/TROUBLESHOOTING.md` §14; особенности панельного хостинга —
`docs/DEPLOYMENT.md` §1.3.

---

## Тестирование

```bash
mvn -B -ntp clean verify        # сборка + все тесты всех модулей
mvn -B -ntp -pl dmc-common test # только ACL/policy/normalization/rate limit
mvn -B -ntp -pl dmc-protocol test
```

Покрытые области: permissions и wildcard, deny-приоритет, command policies, нормализация и
валидация, rate limit, очереди и retry, целостность подписи и replay protection, реальный TLS
транспорт (самоподписанные сертификаты генерируются тестовой утилитой).

Embedded-режим покрыт отдельно: генерируемые `gateway.yml` и `bot.yml`
загружаются реальными конфиг-парсерами, а тест runtime поднимает шлюз в процессе и подключает
к нему двух протокольных пиров по loopback.

CI: `.github/workflows/ci.yml` (JDK 21, Maven cache, `mvn -B -ntp clean verify`, выгрузка
`dist/*.jar`, проверка YAML и `docker compose config`).

---

## Лицензия

MIT — см. `LICENSE`.

```text
Copyright (c) 2026 Zigono
```

**Автор проекта: Zigono.**