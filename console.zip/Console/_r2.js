const fs = require("fs");
const p = "dmc-plugin/src/main/java/ru/zigono/dmc/plugin/config/PluginConfig.java";
const t = fs.readFileSync(p,"utf8").split("\n");
console.log("lines="+t.length);
t.forEach((l,i)=>{ if (/^\s*(public|private|static|final|record|class|this\.)/.test(l) && !/^\s*\/\//.test(l)) console.log((i+1)+": "+l.replace(/\s+$/,"")); });