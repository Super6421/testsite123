const fs = require("fs");
const file = "config/plugin-embedded.example.yml";
const t = fs.readFileSync(file, "utf8");
const oldBlock = `  # ACL: роли и пользователи Discord по id. deny всегда важнее allow.
  # Права пишутся строкой без скобок, несколько прав — через запятую.
  # Маски: console.*, console.server.<id>.*, console.command.<команда>.*
  permissions:
    roles:
      222222222222222222: console.*
      333333333333333333:
        allow: "console.read, console.status, console.execute, console.history"
        deny: "console.admin.*, console.command.stop"
    users:
      456789012345678901: console.read, console.status`;
const newBlock = `  # ACL: роли и пользователи Discord по id. deny всегда важнее allow.
  # Список пишется строкой через запятую, без скобок. Что можно писать:
  #   console.*                — всё (console.read — панель, console.execute — выполнение)
  #   server:survival          — доступ к серверу (server:* — ко всем серверам)
  #   group:all                — доступ к группе серверов
  #   kick                     — команда Minecraft с любыми аргументами
  #   cmd:ban %player% 7d      — то же самое, если хочется записать целиком
  #   essentials.heal          — право в стиле LuckPerms: разрешает команду heal
  #   console.command.kick.*   — полная форма записи команды
  permissions:
    roles:
      222222222222222222: console.*
      333333333333333333:
        allow: "console.read, console.status, console.execute, console.history, kick, mute"
        deny: "console.admin.*, stop, restart"
    users:
      456789012345678901: "console.read, console.status"`;
if (!t.includes(oldBlock)) throw new Error("блок permissions не найден");
fs.writeFileSync(file, t.replace(oldBlock, newBlock), "utf8");
console.log("пример обновлён");