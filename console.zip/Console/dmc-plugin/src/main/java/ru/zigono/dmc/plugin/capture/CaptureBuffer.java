package ru.zigono.dmc.plugin.capture;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Bounded line buffer of one capture session. It stops accepting lines as soon as the configured limit on the
 * number of lines or characters is reached and reports how many lines were dropped, so the result is always
 * honest about being truncated.
 *
 * @author Zigono
 */
public final class CaptureBuffer {

    private final int maxLines;
    private final int maxChars;
    private final List<String> lines = new ArrayList<>();
    private int characters;
    private boolean saturated;
    private boolean truncated;
    private int droppedLines;

    public CaptureBuffer(int maxLines, int maxChars) {
        this.maxLines = Math.max(1, maxLines);
        this.maxChars = Math.max(1, maxChars);
    }

    /**
     * Appends one line.
     *
     * @return {@code false} when the buffer is full and the line was dropped
     */
    public synchronized boolean append(String line) {
        if (line == null) {
            return false;
        }
        if (saturated || lines.size() >= maxLines) {
            saturated = true;
            truncated = true;
            droppedLines++;
            return false;
        }
        final int cost = line.length() + 1;
        if (characters + cost > maxChars) {
            final int room = maxChars - characters - 1;
            if (room > 0) {
                lines.add(line.substring(0, Math.min(room, line.length())));
            }
            saturated = true;
            truncated = true;
            droppedLines++;
            return false;
        }
        lines.add(line);
        characters += cost;
        return true;
    }

    public synchronized List<String> lines() {
        return List.copyOf(lines);
    }

    public synchronized String text() {
        return String.join("\n", Collections.unmodifiableList(lines));
    }

    public synchronized int size() {
        return lines.size();
    }

    public synchronized boolean empty() {
        return lines.isEmpty();
    }

    public synchronized boolean truncated() {
        return truncated;
    }

    public synchronized int droppedLines() {
        return droppedLines;
    }

    public synchronized boolean saturated() {
        return saturated;
    }
}