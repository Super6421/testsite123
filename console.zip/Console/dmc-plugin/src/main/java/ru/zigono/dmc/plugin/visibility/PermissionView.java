package ru.zigono.dmc.plugin.visibility;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Permission lookup of one viewer. Kept as a plain data source, so the visibility rules can be unit tested
 * without a running server.
 *
 * @author Zigono
 */
@FunctionalInterface
public interface PermissionView {

    boolean has(String node);

    /** @return a view backed by an explicit set of granted nodes */
    static PermissionView of(Collection<String> granted) {
        final Set<String> nodes = new LinkedHashSet<>();
        if (granted != null) {
            granted.forEach(node -> nodes.add(node.toLowerCase(Locale.ROOT)));
        }
        return nodes::contains;
    }

    /** @return a view that grants nothing */
    static PermissionView none() {
        return node -> false;
    }

    /** @return a view that grants everything */
    static PermissionView all() {
        return node -> true;
    }
}