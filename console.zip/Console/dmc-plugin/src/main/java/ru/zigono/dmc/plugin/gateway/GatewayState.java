package ru.zigono.dmc.plugin.gateway;

/**
 * Connection state of the plugin towards the gateway. The names match {@code ServerStatus} of the protocol, so
 * the heartbeat can report them directly.
 *
 * @author Zigono
 */
public enum GatewayState {
    CONNECTING,
    ONLINE,
    DEGRADED,
    OFFLINE,
    AUTH_FAILED;

    /** @return the language key of the localized description of this state */
    public String messageKey() {
        return "common.status." + name();
    }
}