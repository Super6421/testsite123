package ru.zigono.dmc.plugin.capture;

import java.util.List;

/**
 * Result of one capture session, as returned by the console.
 *
 * @author Zigono
 */
public record CaptureOutcome(String requestId, String command, List<String> lines, boolean truncated, int droppedLines,
                             long durationMillis, CaptureSession.ReleaseReason reason) {

    public CaptureOutcome {
        lines = lines == null ? List.of() : List.copyOf(lines);
    }

    public String text() {
        return String.join("\n", lines);
    }

    public boolean empty() {
        return lines.isEmpty();
    }

    public int lineCount() {
        return lines.size();
    }
}