package ru.zigono.dmc.plugin.staff;

import org.slf4j.Logger;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.luckperms.LuckPermsIntegration;

import java.util.function.Supplier;

/**
 * Выдача и снятие привилегий в LuckPerms по команде из Discord.
 * <p>Плагин — последняя инстанция: он ещё раз проверяет иерархию из {@code staff.access}, потому что именно
 * здесь исполняется изменение, и потому что LuckPerms есть только у него. Проверка в Discord нужна для
 * понятного ответа, а не для безопасности.</p>
 *
 * @author Zigono
 */
public final class LuckPermsStaffService implements StaffService {

    private final Logger logger;
    private final Supplier<PluginConfig> config;
    private final Supplier<LuckPermsIntegration> luckPerms;

    public LuckPermsStaffService(Logger logger, Supplier<PluginConfig> config,
                                 Supplier<LuckPermsIntegration> luckPerms) {
        this.logger = logger;
        this.config = config;
        this.luckPerms = luckPerms;
    }

    @Override
    public boolean available() {
        final PluginConfig current = config.get();
        final LuckPermsIntegration integration = luckPerms.get();
        return current != null && current.staff().enabled() && integration != null && integration.canManage();
    }

    @Override
    public String unavailableReason() {
        final PluginConfig current = config.get();
        if (current == null) {
            return "конфигурация плагина ещё не загружена";
        }
        if (!current.staff().enabled()) {
            return "раздел staff выключен в config.yml (staff.enabled: false)";
        }
        final LuckPermsIntegration integration = luckPerms.get();
        return integration == null ? "интеграция с LuckPerms ещё не готова" : integration.unavailableReason();
    }

    @Override
    public Result apply(Request request) {
        final PluginConfig current = config.get();
        final StaffConfig staff = current == null ? StaffConfig.disabled() : current.staff();
        if (!staff.enabled()) {
            return Result.failure(request, ErrorCode.CONFIGURATION_ERROR,
                    "выдача привилегий выключена: staff.enabled: false в config.yml");
        }
        final StaffConfig.Rank rank = staff.rank(request.rankKey()).orElse(null);
        if (rank == null) {
            return Result.failure(request, ErrorCode.INVALID_COMMAND,
                    "привилегия '" + request.rankKey() + "' не настроена. Доступные: " + staff.rankKeys());
        }
        if (!staff.allows(request.actorRoleIds(), rank.key())) {
            return Result.failure(request, ErrorCode.PERMISSION_DENIED,
                    "роль автора команды не указана в staff.access для привилегии '" + rank.key() + "'",
                    rank.name(), rank.group());
        }
        final LuckPermsIntegration integration = luckPerms.get();
        if (integration == null || !integration.canManage()) {
            return Result.failure(request, ErrorCode.CONFIGURATION_ERROR,
                    integration == null ? "интеграция с LuckPerms ещё не готова" : integration.unavailableReason(),
                    rank.name(), rank.group());
        }
        final boolean grant = request.action() == Action.GRANT;
        final LuckPermsIntegration.Change change = grant
                ? integration.grant(request.target(), rank.group(), staff.mode(), staff.defaultGroup())
                : integration.revoke(request.target(), rank.group(), staff.mode(), staff.defaultGroup());
        if (!change.success()) {
            return Result.failure(request, ErrorCode.INVALID_COMMAND, change.detail(), rank.name(), rank.group());
        }
        if (change.changed()) {
            logger.info("Привилегия '{}' ({}) {} игроку {} по запросу {} ({}): причина — {}", rank.name(), rank.group(),
                    grant ? "выдана" : "снята", request.target(), request.actorName(), request.actorId(),
                    request.reason());
        } else {
            logger.debug("Привилегия '{}' игрока {} уже была в нужном состоянии", rank.name(), request.target());
        }
        return Result.success(request, rank.name(), rank.group(), change.changed(), null, null);
    }
}