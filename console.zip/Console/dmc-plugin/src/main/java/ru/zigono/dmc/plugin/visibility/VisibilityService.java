package ru.zigono.dmc.plugin.visibility;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.slf4j.Logger;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.luckperms.LuckPermsIntegration;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Announces Discord Console activity on the Minecraft server: a line in the server console and, depending on the
 * configured visibility mode and on LuckPerms, a line for the players. Commands listed in
 * {@code minecraft.visibility.hidden_commands} are never announced anywhere, which is what stops credentials
 * typed into Discord from leaking into the game.
 * <p>All methods must be called from the main server thread.</p>
 *
 * @author Zigono
 */
public final class VisibilityService {

    private static final String DEFAULT_COMMAND_FORMAT = "&7[&9Discord&7] &f{user} &7executed: &f{command}";
    private static final String DEFAULT_RESULT_FORMAT = "&7[&9Discord&7] &7result: &f{result}";
    private static final int MAX_SUMMARY_LENGTH = 240;

    private final Logger logger;
    private final LuckPermsIntegration luckPerms;
    private final Supplier<Messages> messages;
    private final Supplier<VisibilityPolicy> policy;
    private boolean adventureAvailable = true;

    public VisibilityService(Logger logger, LuckPermsIntegration luckPerms, Supplier<Messages> messages,
                             Supplier<VisibilityPolicy> policy) {
        this.logger = logger;
        this.luckPerms = luckPerms;
        this.messages = messages;
        this.policy = policy;
    }

    /** Announces that a command was executed through Discord Console. */
    public void echoCommand(ExecutionEcho echo, PluginConfig config) {
        final VisibilityPolicy visibility = policy.get();
        if (echo.command() == null || visibility.hidden(echo.command())) {
            return;
        }
        final String format = commandFormat(config);
        final Map<String, String> visible = placeholders(echo, config, config.server().name());
        if (config.logging().commandEcho()) {
            send(Bukkit.getConsoleSender(), CommandEcho.format(format, visible));
        }
        if (!config.visibility().enabled()) {
            return;
        }
        final Map<String, String> masked = placeholders(echo, config, config.visibility().hiddenServerLabel());
        for (Player player : Bukkit.getOnlinePlayers()) {
            final Viewer viewer = viewer(player);
            if (!visibility.maySeeCommands(viewer)) {
                continue;
            }
            final boolean serverVisible = visibility.maySeeServer(viewer);
            send(player, CommandEcho.format(format, serverVisible ? visible : masked));
        }
        final String serverLine = config.visibility().serverFormat();
        if (serverLine != null && !serverLine.isBlank() && !formatContainsServer(format)) {
            announceServerLine(serverLine, visible, masked, visibility);
        }
    }

    /** Announces the real result of a command. */
    public void echoResult(ExecutionEcho echo, PluginConfig config) {
        final VisibilityPolicy visibility = policy.get();
        if (echo.command() == null || visibility.hidden(echo.command())) {
            return;
        }
        if (!config.visibility().showResults()) {
            return;
        }
        final String summary = echo.output().isEmpty()
                ? messages.get().raw("plugin.visibility.result_unknown")
                : CommandEcho.summarize(echo.output(), MAX_SUMMARY_LENGTH);
        final ExecutionEcho withResult = new ExecutionEcho(echo.user(), echo.command(), echo.server(), echo.target(),
                echo.output(), echo.status(), echo.durationMillis(), echo.requestId());
        final String format = resultFormat(config);
        final Map<String, String> visible = placeholders(withResult, config, config.server().name());
        visible.put("result", summary);
        if (config.logging().commandEcho()) {
            send(Bukkit.getConsoleSender(), CommandEcho.format(format, visible));
        }
        if (!config.visibility().enabled()) {
            return;
        }
        final Map<String, String> masked = placeholders(withResult, config, config.visibility().hiddenServerLabel());
        masked.put("result", summary);
        for (Player player : Bukkit.getOnlinePlayers()) {
            final Viewer viewer = viewer(player);
            if (!visibility.maySeeResults(viewer)) {
                continue;
            }
            final boolean serverVisible = visibility.maySeeServer(viewer);
            send(player, CommandEcho.format(format, serverVisible ? visible : masked));
        }
    }

    private void announceServerLine(String pattern, Map<String, String> visible, Map<String, String> masked,
                                    VisibilityPolicy visibility) {
        send(Bukkit.getConsoleSender(), CommandEcho.format(pattern, visible));
        if (!visibility.settings().enabled()) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            final Viewer viewer = viewer(player);
            if (!visibility.maySeeCommands(viewer)) {
                continue;
            }
            send(player, CommandEcho.format(pattern, visibility.maySeeServer(viewer) ? visible : masked));
        }
    }

    private Map<String, String> placeholders(ExecutionEcho echo, PluginConfig config, String server) {
        final Map<String, String> values = new LinkedHashMap<>();
        values.put("user", echo.user() == null || echo.user().isBlank() ? "неизвестно" : echo.user());
        values.put("command", echo.command() == null ? "" : echo.command().normalized());
        values.put("target", echo.target() == null ? "" : echo.target());
        values.put("server", server == null ? config.server().name() : server);
        values.put("status", echo.status() == null ? "" : echo.status());
        values.put("duration", Long.toString(echo.durationMillis()));
        values.put("request_id", echo.requestId() == null ? "" : echo.requestId());
        values.put("result", "");
        return values;
    }

    private Viewer viewer(Player player) {
        return Viewer.of(player.getName(), luckPerms.bypasses(player), node -> luckPerms.has(player, node));
    }

    private String commandFormat(PluginConfig config) {
        final String configured = config.visibility().format();
        if (configured != null && !configured.isBlank()) {
            return configured;
        }
        return messages.get().formatOrDefault("plugin.visibility.format", DEFAULT_COMMAND_FORMAT);
    }

    private String resultFormat(PluginConfig config) {
        final String configured = config.visibility().resultFormat();
        if (configured != null && !configured.isBlank()) {
            return configured;
        }
        return messages.get().formatOrDefault("plugin.visibility.result", DEFAULT_RESULT_FORMAT);
    }

    private static boolean formatContainsServer(String format) {
        return format.contains("{server}");
    }

    /** Sends a formatted line, using Adventure when it is available and legacy colour codes otherwise. */
    public void send(CommandSender target, String text) {
        if (target == null || text == null || text.isBlank()) {
            return;
        }
        if (adventureAvailable) {
            try {
                target.sendMessage(component(text));
                return;
            } catch (Throwable unavailable) {
                adventureAvailable = false;
                logger.warn("Adventure недоступен ({}), перехожу на устаревшие цветовые коды",
                        unavailable.toString());
            }
        }
        target.sendMessage(CommandEcho.legacyToSection(text));
    }

    /** Renders a configured format into a component: MiniMessage when it uses tags, legacy codes otherwise. */
    public Component component(String text) {
        if (CommandEcho.looksLikeMiniMessage(text)) {
            return MiniMessage.miniMessage().deserialize(text);
        }
        return LegacyComponentSerializer.legacySection().deserialize(CommandEcho.legacyToSection(text));
    }
}