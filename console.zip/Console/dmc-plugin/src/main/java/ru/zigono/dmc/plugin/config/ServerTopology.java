package ru.zigono.dmc.plugin.config;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.target.ServerCatalog;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Каталог серверов Minecraft, объявленный целиком в одном {@code config.yml} плагина.
 * <p>Раздел {@code servers} описывает все серверы сети, раздел {@code groups} — именованные наборы серверов,
 * а {@code mode} задаёт режим работы шлюза. Сервер, на котором запущен плагин, всегда присутствует в каталоге:
 * его id, имя и описание берутся из раздела {@code server}, а записи в {@code servers} только дополняют их
 * (псевдонимы, отключение, собственный секрет).</p>
 * <p>Каталог проверяется теми же правилами, что применяет шлюз ({@link ServerCatalog}), поэтому ошибка в
 * псевдонимах или в ссылке на неизвестный сервер видна сразу при запуске, а не в Discord.</p>
 *
 * @author Zigono
 */
public final class ServerTopology {

    /** Один сервер каталога. {@code local} помечает сервер, внутри которого работает этот плагин. */
    public record Server(String id, String name, String description, boolean enabled, List<String> aliases,
                         String secret, boolean local) {

        public Server {
            aliases = List.copyOf(aliases);
        }

        public boolean hasSecret() {
            return secret != null && !secret.isBlank();
        }
    }

    private final List<Server> servers;
    private final Map<String, List<String>> groups;
    private final boolean multi;

    private ServerTopology(List<Server> servers, Map<String, List<String>> groups, boolean multi) {
        this.servers = List.copyOf(servers);
        this.groups = Map.copyOf(groups);
        this.multi = multi;
    }

    /**
     * @param root полный документ {@code config.yml}
     */
    public static ServerTopology of(YamlConfig root) {
        final String localId = text(root.string("server.id", "main"), "main").toLowerCase(Locale.ROOT);
        final Server local = new Server(localId,
                text(root.string("server.name", localId), localId),
                text(root.string("server.description", ""), ""),
                true, List.of(), "", true);
        final Map<String, Server> byId = new LinkedHashMap<>();
        byId.put(localId, local);

        final YamlConfig declared = root.sectionOrEmpty("servers");
        for (String rawId : declared.keys("")) {
            final String id = rawId.trim().toLowerCase(Locale.ROOT);
            if (id.isEmpty()) {
                continue;
            }
            final YamlConfig entry = declared.sectionOrEmpty(rawId);
            final List<String> aliases = values(entry, "aliases");
            final boolean enabled = entry.bool("enabled", true);
            final String secret = text(entry.string("secret", ""), "");
            final Server known = byId.get(id);
            byId.put(id, new Server(id,
                    text(entry.string("name", ""), known == null ? id : known.name()),
                    text(entry.string("description", ""), known == null ? "" : known.description()),
                    enabled, aliases, secret, known != null));
        }

        final Map<String, List<String>> groups = new LinkedHashMap<>();
        final YamlConfig declaredGroups = root.sectionOrEmpty("groups");
        for (String rawName : declaredGroups.keys("")) {
            final String name = rawName.trim().toLowerCase(Locale.ROOT);
            if (name.isEmpty()) {
                continue;
            }
            // Группа пишется или строкой ("main, lobby"), или разделом с ключом servers.
            final List<String> members = declaredGroups.raw(rawName) instanceof Map<?, ?>
                    ? values(declaredGroups.sectionOrEmpty(rawName), "servers")
                    : split(declaredGroups.stringList(rawName, List.of()));
            if (!members.isEmpty()) {
                groups.put(name, members);
            }
        }

        final String explicitMode = root.string("mode", "").trim().toLowerCase(Locale.ROOT);
        if (!explicitMode.isEmpty() && !explicitMode.equals("single") && !explicitMode.equals("multi")) {
            throw new ConfigException("Параметр mode должен быть 'single' или 'multi', а указано '"
                    + explicitMode + "'");
        }
        final long enabledServers = byId.values().stream().filter(Server::enabled).count();
        final boolean multi = explicitMode.isEmpty() ? enabledServers > 1 : explicitMode.equals("multi");
        final ServerTopology topology = new ServerTopology(new ArrayList<>(byId.values()), groups, multi);
        topology.validate();
        return topology;
    }

    /**
     * @return секция {@code servers} для шлюза: те же поля плюс секрет каждого сервера
     */
    public Map<String, Object> gatewayServers(Map<String, String> secrets) {
        final Map<String, Object> result = new LinkedHashMap<>();
        for (Server server : servers) {
            final Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("name", server.name());
            entry.put("description", server.description());
            entry.put("enabled", server.enabled());
            if (!server.aliases().isEmpty()) {
                entry.put("aliases", new ArrayList<>(server.aliases()));
            }
            final String secret = secrets.get(server.id());
            if (secret == null || secret.isBlank()) {
                throw new ConfigException("Для сервера '" + server.id()
                        + " нет секрета: он создаётся автоматически в каталоге embedded");
            }
            entry.put("secret", secret);
            result.put(server.id(), entry);
        }
        return result;
    }

    /** @return секция {@code groups} для шлюза */
    public Map<String, Object> gatewayGroups() {
        final Map<String, Object> result = new LinkedHashMap<>();
        groups.forEach((name, members) -> result.put(name, map("servers", new ArrayList<>(members))));
        return result;
    }

    public List<Server> servers() {
        return servers;
    }

    public List<Server> extraServers() {
        return servers.stream().filter(server -> !server.local()).toList();
    }

    public Map<String, List<String>> groups() {
        return groups;
    }

    /** @return {@code single} или {@code multi} — то, что попадает в конфигурацию шлюза */
    public String mode() {
        return multi ? "multi" : "single";
    }

    public boolean multi() {
        return multi;
    }

    /**
     * Повторяет каталог в виде документа и отдаёт его {@link ServerCatalog}, чтобы псевдонимы и ссылки групп
     * проверялись ровно тем же кодом, который потом читает сгенерированную конфигурацию шлюза.
     */
    private void validate() {
        final Map<String, Object> document = new LinkedHashMap<>();
        document.put("mode", mode());
        document.put("servers", gatewayServers(fakeSecrets()));
        document.put("groups", gatewayGroups());
        ServerCatalog.from(YamlConfig.of(document, "config.yml#servers"));
    }

    private Map<String, String> fakeSecrets() {
        final Map<String, String> result = new LinkedHashMap<>();
        for (Server server : servers) {
            result.put(server.id(), "0000000000000000000000000000000000000000000000000000000000000000");
        }
        return result;
    }

    private static List<String> values(YamlConfig section, String key) {
        return split(section.stringList(key, List.of()));
    }

    /**
     * Разворачивает список значений: список можно писать как перечисление через запятую, точку с запятой,
     * вертикальную черту или пробел.
     */
    private static List<String> split(List<String> raw) {
        final Set<String> result = new LinkedHashSet<>();
        for (String value : raw) {
            for (String part : value.split("[,;|\\s]+")) {
                final String trimmed = part.trim();
                if (!trimmed.isEmpty()) {
                    result.add(trimmed);
                }
            }
        }
        return List.copyOf(result);
    }

    private static String text(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    private static Map<String, Object> map(Object... keyValues) {
        final Map<String, Object> result = new LinkedHashMap<>();
        for (int index = 0; index < keyValues.length; index += 2) {
            result.put(String.valueOf(keyValues[index]), keyValues[index + 1]);
        }
        return result;
    }
}
