package ru.zigono.dmc.plugin.command;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.DmcPlugin;
import ru.zigono.dmc.plugin.capture.ConsoleCapture;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.embedded.EmbeddedRuntime;
import ru.zigono.dmc.plugin.gateway.GatewayStatus;
import ru.zigono.dmc.plugin.metrics.PluginMetrics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * {@code /discordconsole status|reload} with tab completion. The command is the operator entry point: it shows
 * the live connection state and applies a hot reload of the configuration without restarting the server.
 *
 * @author Zigono
 */
public final class DiscordConsoleCommand implements CommandExecutor, TabCompleter {

    /** Permission required to use this command. */
    public static final String ADMIN_PERMISSION = "discordconsole.admin";

    private static final List<String> SUBCOMMANDS = List.of("status", "reload");

    private final DmcPlugin plugin;

    public DiscordConsoleCommand(DmcPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label,
                             @NotNull String[] args) {
        final Messages messages = plugin.messages();
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            plugin.visibility().send(sender, messages.raw("plugin.admin.no_permission"));
            return true;
        }
        if (args.length == 0) {
            plugin.visibility().send(sender, messages.raw("plugin.admin.usage"));
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "status" -> printStatus(sender, messages);
            case "reload" -> reload(sender, messages);
            default -> plugin.visibility().send(sender,
                    messages.format("plugin.admin.unknown", args[0]));
        }
        return true;
    }

    private void printStatus(CommandSender sender, Messages messages) {
        final PluginConfig config = plugin.config();
        final GatewayStatus status = plugin.gateway().status();
        final PluginMetrics metrics = plugin.metrics();
        final ConsoleCapture capture = plugin.capture();
        final String never = messages.raw("plugin.status.never");
        final String ack = status.lastHeartbeatAckAt() <= 0L ? never
                : Math.max(0L, (System.currentTimeMillis() - status.lastHeartbeatAckAt()) / 1000L) + "s";
        final String latency = status.latencyMillis() < 0L ? never : status.latencyMillis() + "ms";
        final String gatewayLabel = status.gatewayId() == null ? never : status.gatewayId();
        final List<String> lines = new ArrayList<>();
        lines.add(messages.raw("plugin.status.header"));
        lines.add(messages.format("plugin.status.connection",
                messages.formatOrDefault(status.state().messageKey(), status.state().name())));
        lines.add(messages.format("plugin.status.server", config.server().name(), config.server().id()));
        lines.add(messages.format("plugin.status.gateway", status.host(), status.port(), gatewayLabel));
        final EmbeddedRuntime embedded = plugin.embedded();
        if (embedded != null) {
            final EmbeddedRuntime.EmbeddedStatus embeddedStatus = embedded.status();
            final String botState = messages.formatOrDefault("plugin.status.embedded_"
                            + embeddedStatus.botState().name().toLowerCase(Locale.ROOT),
                    embeddedStatus.botState().name().toLowerCase(Locale.ROOT));
            final String botLabel = embeddedStatus.discordUser() == null
                    ? botState : botState + " " + embeddedStatus.discordUser();
            lines.add(messages.format("plugin.status.embedded", embeddedStatus.port(), botLabel));
            if (embeddedStatus.lastError() != null) {
                lines.add(messages.format("plugin.status.embedded_error", embeddedStatus.lastError()));
            }
        }
        lines.add(messages.format("plugin.status.heartbeat", status.heartbeatIntervalSeconds(), ack));
        lines.add(messages.format("plugin.status.latency", latency));
        lines.add(messages.format("plugin.status.queue", plugin.executions().runningCount(),
                plugin.executions().queueDepth()));
        lines.add(messages.format("plugin.status.counters", metrics.commands(), metrics.succeeded(),
                metrics.failed(), metrics.denied()));
        lines.add(messages.format("plugin.status.capture", capture == null ? "none" : capture.backend(),
                config.capture().quietPeriodMs(), config.capture().maxWaitMs(), config.capture().maxLines()));
        lines.add(messages.format("plugin.status.visibility", plugin.visibilityPolicy().mode().name()
                        .toLowerCase(Locale.ROOT), config.visibility().defaultVisible(),
                plugin.visibilityPolicy().hiddenPatterns()));
        lines.add(messages.format("plugin.status.luckperms", plugin.luckPerms().description()));
        lines.add(messages.format("plugin.status.config", shortRevision(config.revision()), config.language()));
        if (plugin.gateway().lastError() != null) {
            lines.add(messages.format("plugin.status.error", plugin.gateway().lastError()));
        }
        for (String line : lines) {
            plugin.visibility().send(sender, line);
        }
    }

    private void reload(CommandSender sender, Messages messages) {
        try {
            final String revision = plugin.reloadConfiguration();
            plugin.visibility().send(sender, plugin.messages().format("reload.success",
                    shortRevision(revision)));
        } catch (ConfigException failure) {
            plugin.visibility().send(sender, plugin.messages().format("reload.failed", failure.getMessage()));
        } catch (RuntimeException failure) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Горячая перезагрузка не удалась", failure);
            plugin.visibility().send(sender, plugin.messages().format("reload.failed",
                    failure.getClass().getSimpleName()));
        }
    }

    private static String shortRevision(String revision) {
        if (revision == null) {
            return "неизвестно";
        }
        return revision.length() <= 12 ? revision : revision.substring(0, 12);
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias,
                                      @NotNull String[] args) {
        if (!sender.hasPermission(ADMIN_PERMISSION) || args.length != 1) {
            return List.of();
        }
        final String prefix = args[0].toLowerCase(Locale.ROOT);
        final List<String> result = new ArrayList<>();
        for (String subcommand : SUBCOMMANDS) {
            if (subcommand.startsWith(prefix)) {
                result.add(subcommand);
            }
        }
        return result;
    }
}