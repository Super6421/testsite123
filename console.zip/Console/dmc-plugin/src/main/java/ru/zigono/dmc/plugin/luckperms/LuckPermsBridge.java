package ru.zigono.dmc.plugin.luckperms;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Thin wrapper around the LuckPerms API. This class is only loaded when LuckPerms is actually enabled, so a
 * server without LuckPerms never resolves a single LuckPerms class.
 *
 * @author Zigono
 */
final class LuckPermsBridge {

    /** Сколько ждать LuckPerms: он может сходить за игроком в свою базу. */
    private static final long LOOKUP_TIMEOUT_SECONDS = 10L;

    private final LuckPerms luckPerms;

    LuckPermsBridge() {
        this.luckPerms = LuckPermsProvider.get();
    }

    boolean has(Player player, String node) {
        final User user = user(player);
        if (user == null) {
            return player.hasPermission(node);
        }
        return user.getCachedData().getPermissionData().checkPermission(node).asBoolean();
    }

    String primaryGroup(Player player) {
        final User user = user(player);
        return user == null ? null : user.getPrimaryGroup();
    }

    String serverName() {
        return luckPerms.getServerName();
    }

    /** @return {@code true}, когда такая группа есть в LuckPerms: выдать неизвестную группу нельзя */
    boolean groupExists(String group) {
        return group != null && !group.isBlank() && luckPerms.getGroupManager().getGroup(group.trim()) != null;
    }

    /**
     * @return уникальный идентификатор игрока по нику, {@code null} когда LuckPerms такого игрока не знает
     */
    UUID lookupUniqueId(String username) {
        return await(luckPerms.getUserManager().lookupUniqueId(username), "поиск игрока " + username);
    }

    /**
     * Изменяет группы игрока.
     *
     * @param grant        {@code true} — выдать привилегию, {@code false} — снять
     * @param replace      {@code true} — у игрока остаётся ровно эта привилегия (режим {@code set})
     * @param defaultGroup группа, в которую возвращается игрок, когда основную группу снимают
     * @return {@code true}, когда LuckPerms действительно что-то изменил
     */
    boolean modifyGroup(UUID uniqueId, String group, boolean grant, boolean replace, String defaultGroup) {
        final AtomicBoolean changed = new AtomicBoolean();
        final CompletableFuture<Void> future = luckPerms.getUserManager().modifyUser(uniqueId, user -> {
            final InheritanceNode node = InheritanceNode.builder(group).build();
            if (grant) {
                if (replace) {
                    user.data().clear(LuckPermsBridge::isInheritance);
                    user.setPrimaryGroup(group);
                    changed.set(true);
                    return;
                }
                changed.set(user.data().add(node).wasSuccessful());
                return;
            }
            final boolean removed = user.data().remove(node).wasSuccessful();
            if (replace && group.equalsIgnoreCase(user.getPrimaryGroup())) {
                user.data().clear(LuckPermsBridge::isInheritance);
                user.setPrimaryGroup(defaultGroup);
                changed.set(true);
                return;
            }
            changed.set(removed);
        });
        await(future, "изменение групп игрока");
        return changed.get();
    }

    private static boolean isInheritance(Node node) {
        return node instanceof InheritanceNode;
    }

    private User user(Player player) {
        final UUID uniqueId = player.getUniqueId();
        return luckPerms.getUserManager().getUser(uniqueId);
    }

    /** Ждёт ответ LuckPerms и переводит его ошибки в понятные сообщения. */
    private static <T> T await(CompletableFuture<T> future, String what) {
        try {
            return future.get(LOOKUP_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LuckPerms: " + what + " прерван", interrupted);
        } catch (ExecutionException failure) {
            throw new IllegalStateException("LuckPerms: " + what + " не удался (" + failure.getCause() + ")",
                    failure);
        } catch (TimeoutException timeout) {
            throw new IllegalStateException("LuckPerms не ответил за " + LOOKUP_TIMEOUT_SECONDS + " с: " + what);
        }
    }
}