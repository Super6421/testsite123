package ru.zigono.dmc.plugin;

/**
 * Static build metadata of the Minecraft plugin. The version is taken from {@code plugin.yml} at runtime so it
 * can never drift away from the Maven build.
 *
 * @author Zigono
 */
public final class PluginBuild {

    /** Plugin name, identical to {@code name} in {@code plugin.yml}. */
    public static final String NAME = "DiscordMinecraftConsole";

    /** Author of the project. */
    public static final String AUTHOR = "Zigono";

    /** Project website. */
    public static final String WEBSITE = "https://github.com/zigono/discord-minecraft-console";

    /** Role advertised to the gateway during the handshake. */
    public static final String ROLE = "plugin";

    private PluginBuild() {
    }
}