package ru.zigono.dmc.plugin.gateway;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.PluginBuild;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.execution.CommandExecutionService;
import ru.zigono.dmc.plugin.execution.MessageSink;
import ru.zigono.dmc.plugin.metrics.PluginMetrics;
import ru.zigono.dmc.plugin.version.VersionAdapter;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.MessageTypes;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.ProtocolVersion;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.TransportClient;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Owns the connection to the gateway: handshake, authentication, heartbeat and command routing.
 * <p>The endpoint is normally the {@code network}/{@code tls} section of the configuration. In the embedded mode
 * the {@link #GatewayConnection(JavaPlugin, Supplier, Supplier, VersionAdapter, PluginMetrics, Function) transport
 * resolver} points it at the control plane that runs inside this very process.</p>
 * Reconnection with exponential backoff is provided by {@link TransportClient}; after too many authentication
 * failures the plugin stops reconnecting instead of flooding the gateway, and waits for a configuration reload.
 *
 * @author Zigono
 */
public final class GatewayConnection implements TransportClient.Listener, MessageSink, AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(GatewayConnection.class);
    private static final int MAX_AUTHENTICATION_FAILURES = 5;

    private final JavaPlugin plugin;
    private final Supplier<PluginConfig> config;
    private final Supplier<Messages> messages;
    private final VersionAdapter adapter;
    private final PluginMetrics metrics;
    private final Function<PluginConfig, TransportSettings> transportResolver;
    private final AtomicLong heartbeatSequence = new AtomicLong();
    private final AtomicLong heartbeatsSent = new AtomicLong();
    private final AtomicLong violations = new AtomicLong();
    private final AtomicLong authenticationFailures = new AtomicLong();

    private volatile TransportClient client;
    private volatile CommandExecutionService executions;
    private volatile Consumer<PluginMessages.CommandDispatch> dispatchHandler;
    private volatile GatewayState state = GatewayState.OFFLINE;
    private volatile String gatewayId;
    private volatile String gatewayVersion;
    private volatile String sessionId;
    private volatile String configRevision;
    private volatile String lastError;
    private volatile int heartbeatIntervalSeconds = 10;
    private volatile boolean emergencyMode;
    private volatile long connectedAt;
    private volatile long lastHeartbeatAckAt;
    private volatile long lastHeartbeatSentAt;
    private volatile long lastLatencyMillis = -1L;
    private volatile BukkitTask heartbeatTask;

    public GatewayConnection(JavaPlugin plugin, Supplier<PluginConfig> config, Supplier<Messages> messages,
                             VersionAdapter adapter, PluginMetrics metrics) {
        this(plugin, config, messages, adapter, metrics, PluginConfig::transport);
    }

    /**
     * @param transportResolver decides which endpoint the connection is opened against, used by the embedded mode
     *                          to talk to the control plane of this process instead of a remote gateway
     */
    public GatewayConnection(JavaPlugin plugin, Supplier<PluginConfig> config, Supplier<Messages> messages,
                             VersionAdapter adapter, PluginMetrics metrics,
                             Function<PluginConfig, TransportSettings> transportResolver) {
        this.plugin = plugin;
        this.config = config;
        this.messages = messages;
        this.adapter = adapter;
        this.metrics = metrics;
        this.transportResolver = transportResolver;
    }

    public void attach(CommandExecutionService executions, Consumer<PluginMessages.CommandDispatch> dispatchHandler) {
        this.executions = executions;
        this.dispatchHandler = dispatchHandler;
    }

    /** Builds the transport from the current configuration and starts connecting. */
    public void start() {
        final PluginConfig current = config.get();
        if (current.secret() == null || current.secret().length == 0) {
            LOGGER.error("Секрет сервера отсутствует, плагин не подключится к шлюзу");
            state(GatewayState.AUTH_FAILED, "missing server secret");
            return;
        }
        final TransportSettings settings = transport(current);
        heartbeatIntervalSeconds = (int) Math.max(1L, current.heartbeat().interval().toSeconds());
        final TransportClient transport = new TransportClient(settings,
                KeyResolver.single(current.server().id(), current.secret()), this);
        this.client = transport;
        state(GatewayState.CONNECTING, null);
        transport.start();
        LOGGER.info("Подключаюсь к шлюзу {}:{} как '{}' (TLS {})", settings.host(), settings.port(),
                current.server().id(), settings.tlsEnabled() ? "включён" : "выключен");
    }

    /** Stops the current transport and starts a new one, used when connection settings changed. */
    public void restart() {
        closeTransport();
        start();
    }

    /**
     * Applies a hot reloaded configuration. The transport is restarted only when the connection settings or the
     * secret changed, so a running connection is never dropped for nothing.
     */
    public void reload(PluginConfig previous, PluginConfig current) {
        heartbeatIntervalSeconds = (int) Math.max(1L, current.heartbeat().interval().toSeconds());
        final boolean transportChanged = previous == null
                || !transport(previous).equals(transport(current))
                || !java.util.Arrays.equals(previous.secret(), current.secret());
        if (transportChanged) {
            LOGGER.info("Настройки соединения изменились, переподключаюсь к шлюзу");
            restart();
        }
    }

    @Override
    public void onConnected(Connection connection) {
        state(GatewayState.CONNECTING, null);
        final PluginConfig current = config.get();
        final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
        hello.role = PluginBuild.ROLE;
        hello.agentName = PluginBuild.NAME;
        hello.agentVersion = plugin.getDescription().getVersion();
        hello.platform = adapter.describe();
        hello.serverId = current.server().id();
        hello.capabilities = List.of("commands", "console-capture", "heartbeat", "metrics", "dry-run", "visibility",
                "luckperms", "protocol-" + ProtocolVersion.CURRENT);
        try {
            connection.send(hello);
        } catch (RuntimeException failure) {
            LOGGER.warn("Не удалось отправить рукопожатие шлюзу: {}", failure.getMessage());
        }
    }

    @Override
    public void onMessage(Connection connection, Message message) {
        if (message instanceof HandshakeMessages.HelloAck ack) {
            handleHelloAck(connection, ack);
            return;
        }
        if (message instanceof HandshakeMessages.AuthResult result) {
            handleAuthResult(connection, result);
            return;
        }
        if (message instanceof PluginMessages.HeartbeatAck ack) {
            lastHeartbeatAckAt = System.currentTimeMillis();
            lastLatencyMillis = lastHeartbeatSentAt <= 0L ? -1L : Math.max(0L, lastHeartbeatAckAt - lastHeartbeatSentAt);
            if (ack.serverTime > 0L && Math.abs(ack.serverTime - lastHeartbeatAckAt) > 60_000L) {
                LOGGER.debug("Часы шлюза отличаются от часов этого сервера на {} мс", ack.serverTime - lastHeartbeatAckAt);
            }
            return;
        }
        if (message instanceof PluginMessages.CommandDispatch dispatch) {
            final Consumer<PluginMessages.CommandDispatch> handler = dispatchHandler;
            if (handler == null) {
                LOGGER.warn("Получена команда до завершения запуска плагина, игнорирую её");
                return;
            }
            handler.accept(dispatch);
            return;
        }
        if (message instanceof HandshakeMessages.Ping ping) {
            replyToPing(connection, ping);
            return;
        }
        if (message instanceof HandshakeMessages.ShutdownNotice notice) {
            LOGGER.info("Шлюз попросил этот сервер остановиться через {} с: {}", notice.graceSeconds,
                    notice.reason);
            state(GatewayState.OFFLINE, notice.reason);
            return;
        }
        if (message instanceof HandshakeMessages.ErrorMessage error) {
            lastError = error.code + ": " + error.detail;
            LOGGER.warn("Шлюз сообщил об ошибке {}: {}{}", error.code, error.detail, error.fatal ? " (критично)" : "");
            return;
        }
        LOGGER.debug("Игнорирую неожиданное сообщение {}", MessageTypes.nameOf(message.getClass()));
    }

    private void handleHelloAck(Connection connection, HandshakeMessages.HelloAck ack) {
        gatewayId = ack.gatewayId;
        gatewayVersion = ack.gatewayVersion;
        configRevision = ack.configRevision;
        emergencyMode = ack.emergencyMode;
        if (ack.heartbeatIntervalSeconds > 0) {
            heartbeatIntervalSeconds = ack.heartbeatIntervalSeconds;
        }
        if (ack.minSupportedProtocolVersion > ProtocolVersion.CURRENT
                || ack.maxSupportedProtocolVersion < ProtocolVersion.MIN_SUPPORTED) {
            lastError = "gateway speaks protocol " + ack.minSupportedProtocolVersion + ".."
                    + ack.maxSupportedProtocolVersion + ", этот плагин поддерживает " + ProtocolVersion.describe();
            LOGGER.error("Несовпадение протокола: {}", lastError);
            state(GatewayState.AUTH_FAILED, lastError);
            connection.close();
            return;
        }
        LOGGER.info("Шлюз '{}' ответил на рукопожатие (версия {}, протокол {})", ack.gatewayId,
                ack.gatewayVersion, ack.maxSupportedProtocolVersion);
        final HandshakeMessages.AuthRequest auth = ack.correlate(new HandshakeMessages.AuthRequest());
        auth.role = PluginBuild.ROLE;
        auth.serverId = config.get().server().id();
        auth.challenge = ack.challenge;
        auth.agentVersion = plugin.getDescription().getVersion();
        try {
            connection.send(auth);
        } catch (RuntimeException failure) {
            LOGGER.warn("Не удалось отправить запрос аутентификации: {}", failure.getMessage());
        }
    }

    private void handleAuthResult(Connection connection, HandshakeMessages.AuthResult result) {
        if (result.authenticated) {
            sessionId = result.sessionId;
            configRevision = result.configRevision;
            if (result.gatewayId != null) {
                gatewayId = result.gatewayId;
            }
            if (result.heartbeatIntervalSeconds > 0) {
                heartbeatIntervalSeconds = result.heartbeatIntervalSeconds;
            }
            connectedAt = System.currentTimeMillis();
            lastHeartbeatAckAt = connectedAt;
            lastError = null;
            authenticationFailures.set(0L);
            state(GatewayState.ONLINE, null);
            LOGGER.info("Аутентификация на шлюзе '{}' выполнена, сессия {}", gatewayId, sessionId);
            startHeartbeat();
            return;
        }
        final String detail = result.errorDetail == null ? result.errorCode : result.errorDetail;
        lastError = detail;
        state(GatewayState.AUTH_FAILED, detail);
        stopHeartbeat();
        final long failures = authenticationFailures.incrementAndGet();
        LOGGER.error("Аутентификация на шлюзе не удалась ({}): {}", result.errorCode, detail);
        if (failures >= MAX_AUTHENTICATION_FAILURES) {
            LOGGER.error("Аутентификация не удалась {} раз подряд, прекращаю попытки переподключения. Исправьте "
                    + "security.server_secret и выполните /discordconsole reload.", failures);
            closeTransport();
        }
    }

    private void replyToPing(Connection connection, HandshakeMessages.Ping ping) {
        final HandshakeMessages.Pong pong = ping.correlate(new HandshakeMessages.Pong());
        pong.sentAt = ping.sentAt;
        pong.sequence = ping.sequence;
        pong.serverTime = System.currentTimeMillis();
        try {
            connection.send(pong);
        } catch (RuntimeException failure) {
            LOGGER.debug("Не удалось ответить на ping: {}", failure.getMessage());
        }
    }

    @Override
    public void onDisconnected(Throwable cause) {
        stopHeartbeat();
        final GatewayState previous = state;
        state(GatewayState.OFFLINE, cause == null ? null : cause.getMessage());
        if (previous != GatewayState.OFFLINE) {
            LOGGER.warn("Соединение со шлюзом разорвано, переподключаюсь с задержкой");
        }
    }

    @Override
    public void onViolation(ProtocolException violation) {
        violations.incrementAndGet();
        lastError = violation.getMessage();
        LOGGER.warn("Нарушение протокола на соединении со шлюзом: {}", violation.getMessage());
    }

    /** Starts or restarts the heartbeat task with the current interval. */
    public synchronized void startHeartbeat() {
        stopHeartbeat();
        final long intervalTicks = Math.max(20L, heartbeatIntervalSeconds * 20L);
        heartbeatTask = Bukkit.getScheduler().runTaskTimer(plugin, this::sendHeartbeat, intervalTicks, intervalTicks);
    }

    private synchronized void stopHeartbeat() {
        final BukkitTask task = heartbeatTask;
        heartbeatTask = null;
        if (task != null) {
            try {
                task.cancel();
            } catch (IllegalStateException alreadyCancelled) {
                LOGGER.debug("Задача heartbeat уже была отменена");
            }
        }
    }

    /** Sends one heartbeat with the real metrics of this server. Runs on the main thread. */
    void sendHeartbeat() {
        final TransportClient transport = client;
        if (transport == null || !transport.connected()) {
            return;
        }
        final PluginConfig current = config.get();
        final PluginMessages.Heartbeat heartbeat = new PluginMessages.Heartbeat();
        heartbeat.metrics = collectMetrics(current);
        heartbeat.queuedCommands = queuedCommands();
        heartbeat.lastCommandAt = lastCommandAt;
        heartbeat.status = effectiveState(transport).name();
        heartbeat.sequence = heartbeatSequence.incrementAndGet();
        lastHeartbeatSentAt = System.currentTimeMillis();
        try {
            transport.send(heartbeat);
            heartbeatsSent.incrementAndGet();
            metrics.heartbeatSent();
        } catch (RuntimeException failure) {
            LOGGER.debug("Не удалось отправить heartbeat: {}", failure.getMessage());
        }
    }

    private volatile long lastCommandAt;

    /** Records the moment the last command was accepted, used by the heartbeat. */
    public void markCommandReceived() {
        lastCommandAt = System.currentTimeMillis();
    }

    private int queuedCommands() {
        final CommandExecutionService service = executions;
        return service == null ? 0 : service.queueDepth() + service.runningCount();
    }

    private GatewayState effectiveState(TransportClient transport) {
        final GatewayState current = state;
        if (current == GatewayState.AUTH_FAILED) {
            return current;
        }
        if (!transport.connected()) {
            return GatewayState.CONNECTING;
        }
        final long degradedThreshold = config.get().heartbeat().degradedLatencyMs() <= 0.0d ? Long.MAX_VALUE
                : (long) config.get().heartbeat().degradedLatencyMs();
        if (lastLatencyMillis > degradedThreshold) {
            return GatewayState.DEGRADED;
        }
        return current == GatewayState.CONNECTING ? GatewayState.ONLINE : current;
    }

    /** Collects the live metrics of this server. Must run on the main thread. */
    public ServerMetrics collectMetrics(PluginConfig current) {
        final List<World> worlds = Bukkit.getWorlds();
        final String worldName = worlds.isEmpty() ? null : worlds.get(0).getName();
        final int chunks = adapter.loadedChunks();
        final Runtime runtime = Runtime.getRuntime();
        final long used = runtime.totalMemory() - runtime.freeMemory();
        return new ServerMetrics(current.server().id(), adapter.minecraftVersion(), adapter.serverSoftware(),
                plugin.getDescription().getVersion(), Bukkit.getOnlinePlayers().size(), Bukkit.getMaxPlayers(),
                adapter.tps(), adapter.mspt(), ManagementFactory.getRuntimeMXBean().getUptime() / 1000L, used,
                runtime.maxMemory(), cpuLoad(), worldName, chunks, System.currentTimeMillis());
    }

    private double cpuLoad() {
        try {
            final java.lang.management.OperatingSystemMXBean bean = ManagementFactory.getOperatingSystemMXBean();
            if (bean instanceof com.sun.management.OperatingSystemMXBean extended) {
                final double load = extended.getProcessCpuLoad();
                return load < 0.0d ? 0.0d : Math.round(load * 10_000.0d) / 100.0d;
            }
        } catch (Throwable unsupported) {
            LOGGER.debug("Загрузка CPU недоступна на этой платформе: {}", unsupported.toString());
        }
        return 0.0d;
    }

    @Override
    public boolean send(Message message) {
        final TransportClient transport = client;
        if (transport == null) {
            return false;
        }
        try {
            return transport.send(message);
        } catch (RuntimeException failure) {
            LOGGER.debug("Не удалось отправить {} шлюзу: {}", MessageTypes.nameOf(message.getClass()),
                    failure.getMessage());
            return false;
        }
    }

    public boolean connected() {
        final TransportClient transport = client;
        return transport != null && transport.connected();
    }

    public GatewayState state() {
        return state;
    }

    public boolean emergencyMode() {
        return emergencyMode;
    }

    public long latencyMillis() {
        return lastLatencyMillis;
    }

    public String gatewayId() {
        return gatewayId;
    }

    public String lastError() {
        return lastError;
    }

    /** @return the immutable snapshot rendered by the status command */
    public GatewayStatus status() {
        final PluginConfig current = config.get();
        final TransportSettings settings = transport(current);
        return new GatewayStatus(effectiveStateOrOffline(), current.server().id(), settings.host(),
                settings.port(), settings.tlsEnabled(), gatewayId, gatewayVersion, sessionId,
                configRevision, heartbeatIntervalSeconds, connectedAt, lastHeartbeatAckAt, lastLatencyMillis,
                heartbeatsSent.get(), violations.get(), authenticationFailures.get(), lastError);
    }

    /** @return the endpoint of this connection, resolved from the current configuration */
    private TransportSettings transport(PluginConfig current) {
        return transportResolver.apply(current);
    }

    private GatewayState effectiveStateOrOffline() {
        final TransportClient transport = client;
        return transport == null ? GatewayState.OFFLINE : effectiveState(transport);
    }

    private void state(GatewayState updated, String error) {
        this.state = updated;
        if (error != null) {
            this.lastError = error;
        }
    }

    private void closeTransport() {
        stopHeartbeat();
        final TransportClient transport = client;
        client = null;
        if (transport != null) {
            try {
                transport.close();
            } catch (RuntimeException failure) {
                LOGGER.debug("Не удалось корректно закрыть транспорт: {}", failure.getMessage());
            }
        }
        state(GatewayState.OFFLINE, null);
    }

    @Override
    public void close() {
        closeTransport();
    }
}