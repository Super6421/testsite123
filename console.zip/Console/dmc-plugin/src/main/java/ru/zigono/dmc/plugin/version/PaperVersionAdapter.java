package ru.zigono.dmc.plugin.version;

import org.bukkit.Bukkit;
import org.bukkit.World;

/**
 * Adapter for Paper 1.21 and newer. Uses the tick reporting and the cached world counters of the Paper API
 * instead of iterating the worlds.
 *
 * @author Zigono
 */
public final class PaperVersionAdapter implements VersionAdapter {

    private static final int MINIMUM_MINOR_VERSION = 21;

    @Override
    public String id() {
        return "paper-1.21";
    }

    @Override
    public String describe() {
        return "Paper/Spigot 1.21+ (tick API, cached world counters)";
    }

    @Override
    public double tps() {
        final double[] tps = Bukkit.getTPS();
        if (tps.length == 0) {
            return -1.0d;
        }
        return Math.round(tps[0] * 100.0d) / 100.0d;
    }

    @Override
    public double mspt() {
        final double value = Bukkit.getAverageTickTime();
        return value <= 0.0d ? -1.0d : Math.round(value * 100.0d) / 100.0d;
    }

    @Override
    public int worldCount() {
        return Bukkit.getWorlds().size();
    }

    @Override
    public int loadedChunks() {
        int chunks = 0;
        for (World world : Bukkit.getWorlds()) {
            chunks += world.getChunkCount();
        }
        return chunks;
    }

    @Override
    public String minecraftVersion() {
        return Bukkit.getMinecraftVersion();
    }

    @Override
    public String serverSoftware() {
        return Bukkit.getName() + " " + Bukkit.getVersion();
    }

    /** @return {@code true} when the version string describes a server this adapter can drive */
    public static boolean supports(int major, int minor) {
        return major > 1 || (major == 1 && minor >= MINIMUM_MINOR_VERSION);
    }
}