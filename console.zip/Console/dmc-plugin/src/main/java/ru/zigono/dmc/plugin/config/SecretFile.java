package ru.zigono.dmc.plugin.config;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.util.Hashing;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.PosixFilePermission;
import java.security.SecureRandom;
import java.util.EnumSet;
import java.util.Set;

/**
 * Shared secret kept in a file next to the configuration.
 * <p>The embedded mode does not need an administrator to invent a secret for the traffic that never leaves the
 * machine, so the plugin generates one on the first start and reuses it afterwards. The file is written with
 * owner only permissions where the filesystem supports them.</p>
 *
 * @author Zigono
 */
public final class SecretFile {

    /** Number of random bytes behind a generated secret. */
    public static final int SECRET_BYTES = 32;

    /** Prefix understood by {@link ru.zigono.dmc.protocol.Secrets}: the value in the file is hex encoded. */
    private static final String HEX_PREFIX = "hex:";

    private SecretFile() {
    }

    /**
     * Reads the secret from the given file, generating a new one when the file does not exist yet.
     *
     * @param file location of the secret, its parent directory is created when missing
     * @return the secret in the {@code hex:...} form used by the configuration files
     */
    public static String readOrCreate(Path file) {
        final Path absolute = file.toAbsolutePath().normalize();
        if (Files.isRegularFile(absolute)) {
            return read(absolute);
        }
        final String generated = generate();
        write(absolute, generated);
        return generated;
    }

    /**
     * @return the configuration form of an already decoded secret, so the gateway and the plugin always compare
     *         the same bytes whatever form the administrator wrote them in
     */
    public static String encode(byte[] secret) {
        return HEX_PREFIX + Hashing.hex(secret);
    }

    /** @return the secret stored in the file, without touching the filesystem */
    public static String read(Path file) {
        final Path absolute = file.toAbsolutePath().normalize();
        final String value;
        try {
            value = Files.readString(absolute, StandardCharsets.UTF_8).trim();
        } catch (IOException e) {
            throw new ConfigException("Не удалось прочитать файл секрета " + absolute, e);
        }
        if (value.isEmpty()) {
            throw new ConfigException("Файл секрета " + absolute + " пуст: удалите его, и новый секрет сгенерируется автоматически");
        }
        return value;
    }

    /** Writes the secret, creating the parent directory when needed. */
    public static void write(Path file, String secret) {
        final Path absolute = file.toAbsolutePath().normalize();
        try {
            final Path parent = absolute.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(absolute, secret + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new ConfigException("Не удалось записать файл секрета " + absolute, e);
        }
        restrict(absolute);
    }

    private static String generate() {
        final byte[] bytes = new byte[SECRET_BYTES];
        new SecureRandom().nextBytes(bytes);
        return HEX_PREFIX + Hashing.hex(bytes);
    }

    /**
     * Removes the group and other bits. A filesystem without POSIX permissions (Windows) or a read only
     * attribute does not stop the plugin: the file already lives inside the server directory.
     */
    private static void restrict(Path file) {
        final Set<PosixFilePermission> ownerOnly = EnumSet.of(PosixFilePermission.OWNER_READ,
                PosixFilePermission.OWNER_WRITE);
        try {
            Files.setPosixFilePermissions(file, ownerOnly);
        } catch (UnsupportedOperationException | IOException unsupported) {
            // Not a POSIX filesystem: nothing to do.
        }
    }
}
