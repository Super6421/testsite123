package ru.zigono.dmc.plugin.visibility;

/**
 * Optional refinement nodes. A {@code null} node disables the refinement, so the base permission is enough.
 *
 * @author Zigono
 */
public record VisibilityNodes(String commands, String results, String servers) {

    public static VisibilityNodes none() {
        return new VisibilityNodes(null, null, null);
    }
}