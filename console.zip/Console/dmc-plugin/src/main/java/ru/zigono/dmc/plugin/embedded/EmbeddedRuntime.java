package ru.zigono.dmc.plugin.embedded;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.bot.BotRuntime;
import ru.zigono.dmc.bot.staff.StaffService;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.gateway.Gateway;
import ru.zigono.dmc.plugin.PluginBuild;
import ru.zigono.dmc.plugin.config.EmbeddedSettings;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.config.SecretFile;
import ru.zigono.dmc.plugin.config.ServerTopology;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The whole control plane of the system, running inside the Minecraft server process.
 * <p>An administrator who cannot install a second process and cannot open a second port - a Minecraft server on
 * a game panel, for example - gets exactly the same behaviour as the split deployment: this class starts the
 * gateway, generates the configuration of the gateway and of the Discord bot from the plugin configuration, gives
 * the plugin a loopback connection to that gateway and finally starts the Discord bot in the same JVM. Nothing
 * but the plugin is installed, nothing but the Minecraft port is reachable from outside.</p>
 * <p>The loopback listener is the only place where the transport runs without TLS. It never leaves the machine,
 * which is why the generated configuration opts in explicitly with {@code allow_insecure_transport: true}.</p>
 *
 * @author Zigono
 */
public final class EmbeddedRuntime implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedRuntime.class);

    /** Lifecycle of the Discord bot that runs inside the plugin. */
    public enum BotState {
        /** The administrator did not configure a Discord token yet. */
        DISABLED,
        /** The gateway is up, the Discord client is still starting. */
        STARTING,
        /** The bot is online and the control plane accepted it. */
        ONLINE,
        /** The bot could not start, {@link EmbeddedStatus#lastError()} says why. */
        FAILED
    }

    /** Immutable snapshot rendered by {@code /discordconsole status}. */
    public record EmbeddedStatus(boolean running, int port, BotState botState, String discordUser, String lastError) {
    }

    private final EmbeddedSettings settings;
    /** Выдача привилегий живёт в плагине (там LuckPerms), поэтому бот получает её готовой. */
    private final java.util.function.Supplier<StaffService> staff;
    private final AtomicBoolean closed = new AtomicBoolean();
    private final AtomicBoolean botStarted = new AtomicBoolean();

    private volatile Gateway gateway;
    private volatile BotRuntime bot;
    private volatile TransportSettings transport;
    private volatile int port = -1;
    private volatile BotState botState = BotState.DISABLED;
    private volatile String discordUser;
    private volatile String lastError;

    public EmbeddedRuntime(EmbeddedSettings settings) {
        this(settings, () -> null);
    }

    /**
     * @param settings настройки встроенного режима
     * @param staff    выдача привилегий, которую плагин передаёт запускаемому боту; значение берётся в момент
     *                 запуска бота, потому что интеграция с LuckPerms создаётся позже встроенного шлюза
     */
    public EmbeddedRuntime(EmbeddedSettings settings, java.util.function.Supplier<StaffService> staff) {
        this.settings = settings;
        this.staff = staff == null ? () -> null : staff;
    }

    /**
     * Generates the configuration of the control plane, starts it and connects it to the server. Must run before
     * the plugin opens its own connection, because the port the listener bound becomes part of that connection.
     *
     * @param config the current plugin configuration
     */
    public void start(PluginConfig config) {
        if (!settings.enabled()) {
            return;
        }
        final Path directory = settings.directory().toAbsolutePath().normalize();
        try {
            Files.createDirectories(directory);
        } catch (java.io.IOException e) {
            throw new ConfigException("Не удалось создать служебный каталог " + directory, e);
        }
        final Map<String, String> serverSecrets = serverSecrets(config);
        final String controlSecret = SecretFile.readOrCreate(settings.controlSecretFile());
        EmbeddedConfigWriter.writeGateway(settings.gatewayConfigFile(), config, serverSecrets, controlSecret);
        warnAboutRemoteServers(config);
        final Gateway created = new Gateway(settings.gatewayConfigFile());
        try {
            created.start();
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new ConfigException("Запуск встроенного шлюза был прерван", interrupted);
        } catch (RuntimeException failure) {
            created.close();
            throw new ConfigException("Не удалось запустить встроенный шлюз: " + failure.getMessage(), failure);
        }
        final int bound = created.transportServer().port();
        if (bound <= 0) {
            created.close();
            throw new ConfigException("Встроенный шлюз не занял loopback-порт");
        }
        this.gateway = created;
        this.port = bound;
        this.transport = loopback(config.transport(), bound, clientHost(config.embedded().bindHost()));
        if (settings.botConfigured()) {
            EmbeddedConfigWriter.writeBot(settings.botConfigFile(), config, controlSecret, bound);
        }
        LOGGER.info("Встроенный режим включён: шлюз {} работает внутри этого сервера на {}:{} "
                + "(служебные файлы — {})", PluginBuild.NAME, EmbeddedConfigWriter.LOOPBACK_HOST, bound, directory);
    }

    /**
     * @return the settings the plugin connects with: the gateway of this process, reached over the loopback
     *         interface without TLS, whatever the {@code network} and {@code tls} sections of the configuration say
     */
    public TransportSettings transportSettings(PluginConfig current) {
        final TransportSettings bound = transport;
        return bound == null ? current.transport() : bound;
    }

    /** Starts the Discord bot in a background thread: the Minecraft main thread must never wait for Discord. */
    public void startBot() {
        if (!settings.enabled() || !botStarted.compareAndSet(false, true)) {
            return;
        }
        if (!settings.botConfigured()) {
            botState = BotState.DISABLED;
            LOGGER.warn("Discord-бот не запущен: впишите токен в embedded.discord.token файла "
                    + "plugins/DiscordMinecraftConsole/config.yml (или задайте переменную окружения "
                    + "DISCORD_TOKEN) — иначе команды из Discord не дойдут до сервера. "
                    + "Сам Minecraft при этом работает как обычно.");
            return;
        }
        botState = BotState.STARTING;
        Thread.ofVirtual().name("dmc-embedded-bot").start(this::runBot);
    }

    private void runBot() {
        final BotRuntime created = new BotRuntime(settings.botConfigFile(), staff.get());
        this.bot = created;
        try {
            created.start();
        } catch (RuntimeException failure) {
            botState = BotState.FAILED;
            lastError = failure.getMessage();
            LOGGER.error("Discord-бот не запустился: {}", failure.getMessage());
            LOGGER.debug("Подробности ошибки запуска Discord-бота", failure);
            created.close();
            return;
        }
        if (closed.get()) {
            created.close();
            return;
        }
        discordUser = created.jda().map(api -> api.getSelfUser().getAsTag()).orElse(null);
        botState = BotState.ONLINE;
        lastError = null;
        LOGGER.info("Discord-бот запущен и работает как {}", discordUser);
    }

    /** Regenerates the configuration of the control plane and of the bot after a hot reload of the plugin. */
    public void reload(PluginConfig config) {
        if (!settings.enabled() || gateway == null) {
            return;
        }
        final Map<String, String> serverSecrets = serverSecrets(config);
        final String controlSecret = SecretFile.read(settings.controlSecretFile());
        final EmbeddedSettings current = config.embedded();
        if (!current.enabled()) {
            LOGGER.warn("embedded.enabled нельзя выключить на работающем сервере: перезапустите сервер, "
                    + "чтобы выйти из встроенного режима");
            return;
        }
        EmbeddedConfigWriter.writeGateway(current.gatewayConfigFile(), config, serverSecrets, controlSecret);
        if (current.botConfigured()) {
            EmbeddedConfigWriter.writeBot(current.botConfigFile(), config, controlSecret, port);
            startBot();
        }
        LOGGER.info("Служебная конфигурация шлюза и бота пересобрана из config.yml. Изменённый секрет "
                + "сервера вступит в силу только после перезапуска: уже запущенный шлюз использует те ключи, "
                + "с которыми стартовал.");
    }

    /** @return the snapshot rendered by {@code /discordconsole status} */
    public EmbeddedStatus status() {
        return new EmbeddedStatus(settings.enabled() && gateway != null, port, botState, discordUser, lastError);
    }

    public int port() {
        return port;
    }

    /** @return {@code true} while the control plane of this process is up */
    public boolean running() {
        return !closed.get() && gateway != null;
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        final BotRuntime currentBot = bot;
        if (currentBot != null) {
            LOGGER.info("Останавливаю Discord-бота");
            try {
                currentBot.close();
            } catch (RuntimeException failure) {
                LOGGER.warn("Discord-бот завершился с ошибкой: {}", failure.getMessage());
            }
        }
        final Gateway currentGateway = gateway;
        if (currentGateway != null) {
            currentGateway.close();
        }
    }

    /**
     * @return секрет каждого сервера каталога: сервер этого процесса использует секрет плагина, остальные
     *         получают собственный секрет, который создаётся в каталоге {@code embedded}
     */
    private Map<String, String> serverSecrets(PluginConfig config) {
        final Map<String, String> secrets = new LinkedHashMap<>();
        for (ServerTopology.Server server : config.embedded().topology().servers()) {
            if (server.local()) {
                secrets.put(server.id(), SecretFile.encode(config.secret()));
            } else if (server.hasSecret()) {
                secrets.put(server.id(), server.secret());
            } else {
                secrets.put(server.id(), SecretFile.readOrCreate(config.embedded().serverSecretFile(server.id())));
            }
        }
        return secrets;
    }

    /**
     * Серверы, объявленные в {@code config.yml} дополнительно, подключаются к этому шлюзу по сети: пока он
     * слушает только loopback-адрес и случайный порт, они не смогут этого сделать, поэтому администратор
     * получает предупреждение и подсказку.
     */
    private void warnAboutRemoteServers(PluginConfig config) {
        final ServerTopology topology = config.embedded().topology();
        if (topology.extraServers().isEmpty()) {
            return;
        }
        final EmbeddedSettings current = config.embedded();
        if (EmbeddedSettings.DEFAULT_BIND_HOST.equals(current.bindHost())
                && current.bindPort() == EmbeddedSettings.DEFAULT_BIND_PORT) {
            LOGGER.warn("В config.yml объявлены другие серверы ({}), но embedded.network оставлен по умолчанию: "
                            + "шлюз слушает только 127.0.0.1 на случайном порту, поэтому эти серверы не смогут "
                            + "подключиться. Укажите доступные им адрес и порт, например host: 0.0.0.0 и port: 8443.",
                    String.join(", ", topology.extraServers().stream().map(ServerTopology.Server::id).toList()));
            return;
        }
        LOGGER.info("Шлюз принимает другие серверы на {}:{}. Секреты лежат в {} (файлы server-<id>.secret): "
                        + "их значения укажите в security.server_secret конфигурации каждого сервера.",
                current.bindHost(), current.bindPort(), current.directory().toAbsolutePath());
    }

    /**
     * @return адрес, по которому этот процесс подключается к собственному шлюзу: если шлюз слушает только
     *         loopback или все интерфейсы, достаточно 127.0.0.1, иначе используется указанный адрес
     */
    private static String clientHost(String bindHost) {
        if (bindHost == null || bindHost.isBlank() || bindHost.equals("0.0.0.0") || bindHost.equals("::")
                || bindHost.equals("localhost") || EmbeddedSettings.DEFAULT_BIND_HOST.equals(bindHost)) {
            return EmbeddedConfigWriter.LOOPBACK_HOST;
        }
        return bindHost;
    }

    /**
     * @return the same transport settings with the loopback endpoint of this process and without TLS material:
     *         nothing of the {@code network} and {@code tls} sections is used, they describe an external gateway
     */
    private static TransportSettings loopback(TransportSettings base, int port, String host) {
        return new TransportSettings(false, true, host, port,
                null, null, null, null, null, null, null, null, false, base.protocols(), base.maxFrameBytes(),
                base.connectTimeout(), base.handshakeTimeout(), base.idleTimeout(), base.shutdownGrace(),
                base.reconnectInitialDelay(), base.reconnectMaxDelay(), base.reconnectMultiplier(),
                base.workerThreads(), base.localClientId(), base.localRole());
    }
}
