package ru.zigono.dmc.plugin.metrics;

import ru.zigono.dmc.protocol.dto.ExecutionStatus;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Counters of the plugin. They are reported in {@code /discordconsole status} and in the periodic metrics line,
 * which is what the gateway scrapes together with the heartbeat.
 *
 * @author Zigono
 */
public final class PluginMetrics {

    private final AtomicLong commands = new AtomicLong();
    private final AtomicLong succeeded = new AtomicLong();
    private final AtomicLong failed = new AtomicLong();
    private final AtomicLong denied = new AtomicLong();
    private final AtomicLong queueFull = new AtomicLong();
    private final AtomicLong refused = new AtomicLong();
    private final AtomicLong timedOut = new AtomicLong();
    private final AtomicLong outputLines = new AtomicLong();
    private final AtomicLong totalDurationMillis = new AtomicLong();
    private final AtomicLong heartbeats = new AtomicLong();
    private final AtomicLong captureFailures = new AtomicLong();

    public void commandReceived() {
        commands.incrementAndGet();
    }

    public void recordOutcome(ExecutionStatus status, int lines, long durationMillis) {
        outputLines.addAndGet(lines);
        totalDurationMillis.addAndGet(Math.max(0L, durationMillis));
        if (status == ExecutionStatus.SUCCESS || status == ExecutionStatus.DRY_RUN) {
            succeeded.incrementAndGet();
        } else if (status == ExecutionStatus.DENIED) {
            denied.incrementAndGet();
        } else if (status == ExecutionStatus.QUEUE_FULL) {
            queueFull.incrementAndGet();
        } else if (status == ExecutionStatus.TIMEOUT) {
            timedOut.incrementAndGet();
            failed.incrementAndGet();
        } else {
            failed.incrementAndGet();
        }
    }

    public void commandRefused() {
        refused.incrementAndGet();
    }

    public void heartbeatSent() {
        heartbeats.incrementAndGet();
    }

    public void captureFailure() {
        captureFailures.incrementAndGet();
    }

    public long commands() {
        return commands.get();
    }

    public long succeeded() {
        return succeeded.get();
    }

    public long failed() {
        return failed.get();
    }

    public long denied() {
        return denied.get();
    }

    public long queueFull() {
        return queueFull.get();
    }

    public long refused() {
        return refused.get();
    }

    public long timedOut() {
        return timedOut.get();
    }

    public long outputLines() {
        return outputLines.get();
    }

    public long heartbeats() {
        return heartbeats.get();
    }

    public long captureFailures() {
        return captureFailures.get();
    }

    /** @return the average execution duration in milliseconds, or {@code 0} when nothing ran yet */
    public long averageDurationMillis() {
        final long count = succeeded.get() + failed.get() + denied.get();
        return count == 0L ? 0L : totalDurationMillis.get() / count;
    }
}