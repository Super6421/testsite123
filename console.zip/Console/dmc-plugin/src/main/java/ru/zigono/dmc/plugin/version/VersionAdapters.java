package ru.zigono.dmc.plugin.version;

import org.bukkit.Bukkit;

/**
 * Selects the version adapter from the Bukkit version string and from the presence of the Paper API.
 *
 * @author Zigono
 */
public final class VersionAdapters {

    /** Class that only exists in Paper builds and therefore marks a Paper server. */
    private static final String PAPER_MARKER = "io.papermc.paper.plugin.configuration.PluginMeta";

    private VersionAdapters() {
    }

    /** Selects the adapter for the running server. */
    public static VersionAdapter select() {
        return select(Bukkit.getBukkitVersion());
    }

    /**
     * Selects the adapter for a Bukkit version string such as {@code 1.21.1-R0.1-SNAPSHOT}.
     *
     * @param bukkitVersion version reported by {@link Bukkit#getBukkitVersion()}
     */
    public static VersionAdapter select(String bukkitVersion) {
        final int[] version = parse(bukkitVersion);
        if (version != null && paperPresent() && PaperVersionAdapter.supports(version[0], version[1])) {
            return new PaperVersionAdapter();
        }
        return new LegacyVersionAdapter();
    }

    /** @return {@code true} when the Paper API is present on the classpath */
    public static boolean paperPresent() {
        try {
            Class.forName(PAPER_MARKER, false, VersionAdapters.class.getClassLoader());
            return true;
        } catch (Throwable missing) {
            return false;
        }
    }

    /**
     * @return {@code {major, minor}} parsed from a Bukkit version string, or {@code null} when it cannot be parsed
     */
    static int[] parse(String bukkitVersion) {
        if (bukkitVersion == null || bukkitVersion.isBlank()) {
            return null;
        }
        int index = 0;
        final StringBuilder digits = new StringBuilder();
        while (index < bukkitVersion.length()) {
            final char character = bukkitVersion.charAt(index);
            if (Character.isDigit(character) || (character == '.' && digits.length() > 0 && digits.indexOf(".") < 0)) {
                digits.append(character);
                index++;
            } else {
                break;
            }
        }
        if (digits.length() == 0) {
            return null;
        }
        final String[] parts = digits.toString().split("\\.");
        try {
            final int major = Integer.parseInt(parts[0]);
            final int minor = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            return new int[]{major, minor};
        } catch (NumberFormatException e) {
            return null;
        }
    }
}