package ru.zigono.dmc.plugin.config;

import org.bukkit.plugin.java.JavaPlugin;
import org.slf4j.Logger;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.PluginBuild;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Copies the bundled default files into the plugin data directory and loads the configuration from there.
 * <p>The shipped {@code config.yml} and the language files are the single source of truth: they are written
 * once and never overwritten afterwards, so administrator edits survive plugin upgrades.</p>
 *
 * @author Zigono
 */
public final class ConfigBootstrap {

    private static final String CONFIG_RESOURCE = "config.yml";
    /** Resource directory of the message catalog bundled inside the plugin jar. */
    public static final String LANG_RESOURCE_DIRECTORY = "plugin-lang";
    private static final List<String> LANGUAGES = List.of("en.yml", "ru.yml");

    private final JavaPlugin plugin;
    private final Logger logger;

    public ConfigBootstrap(JavaPlugin plugin, Logger logger) {
        this.plugin = plugin;
        this.logger = logger;
    }

    public Path dataDirectory() {
        return plugin.getDataFolder().toPath();
    }

    public Path configFile() {
        return dataDirectory().resolve(CONFIG_RESOURCE);
    }

    public Path languageDirectory() {
        return dataDirectory().resolve("lang");
    }

    /** Writes {@code config.yml} and the language files when they are missing. */
    public void installDefaults() {
        if (!plugin.getDataFolder().isDirectory() && !plugin.getDataFolder().mkdirs()) {
            throw new ConfigException("Не удалось создать каталог плагина " + plugin.getDataFolder());
        }
        if (!Files.isRegularFile(configFile())) {
            plugin.saveResource(CONFIG_RESOURCE, false);
        }
        try {
            Files.createDirectories(languageDirectory());
        } catch (IOException e) {
            throw new ConfigException("Не удалось создать каталог " + languageDirectory(), e);
        }
        for (String language : LANGUAGES) {
            copyResource(LANG_RESOURCE_DIRECTORY + "/" + language, languageDirectory().resolve(language));
        }
    }

    private void copyResource(String resource, Path target) {
        if (Files.isRegularFile(target)) {
            return;
        }
        try (InputStream stream = plugin.getResource(resource)) {
            if (stream == null) {
                throw new ConfigException("Ресурс " + resource + " отсутствует в jar-файле плагина");
            }
            Files.copy(stream, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new ConfigException("Не удалось записать " + target, e);
        }
    }

    /**
     * Loads the configuration file, applying environment variable substitution.
     * <p>A hand-edited YAML file that no longer parses must not leave the server without the console: the broken
     * file is kept next to the original and the shipped default takes its place, so no value is lost and the
     * server keeps working while the administrator copies the values back.</p>
     */
    public PluginConfig load() {
        final Path file = configFile();
        if (!Files.isRegularFile(file)) {
            throw new ConfigException("Файл конфигурации " + file + " не найден");
        }
        Path usable = repairMalformed(file);
        try {
            return PluginConfig.load(usable, dataDirectory());
        } catch (ConfigException invalid) {
            logger.error("{}", invalid.getMessage());
            usable = restoreDefault(usable);
            return PluginConfig.load(usable, dataDirectory());
        }
    }

    /**
     * Checks the YAML syntax of the file and, when it is broken, replaces it with the shipped default.
     *
     * @return the file the configuration is read from
     */
    private Path repairMalformed(Path file) {
        try {
            YamlConfig.parse(Files.readString(file, StandardCharsets.UTF_8), file.toAbsolutePath().toString(), false);
            return file;
        } catch (ConfigException malformed) {
            logger.error("{}", malformed.getMessage());
        } catch (IOException unreadable) {
            throw new ConfigException("Не удалось прочитать файл конфигурации " + file, unreadable);
        }
        return restoreDefault(file);
    }

    /** Moves the file aside and writes the bundled default in its place, so a broken configuration is never fatal. */
    private Path restoreDefault(Path file) {
        try (InputStream bundled = plugin.getResource(CONFIG_RESOURCE)) {
            if (bundled == null) {
                throw new ConfigException("Ресурс " + CONFIG_RESOURCE + " отсутствует в jar-файле плагина: "
                        + "восстановить конфигурацию автоматически нельзя. Исправьте " + file
                        + " вручную и перезапустите сервер.");
            }
            return recoverMalformed(file, bundled.readAllBytes(), logger);
        } catch (IOException e) {
            throw new ConfigException("Не удалось прочитать встроенный " + CONFIG_RESOURCE
                    + " для восстановления конфигурации", e);
        }
    }

    /**
     * Moves {@code file} aside as {@code <имя>.broken-<дата-время>} and writes {@code bundledDefault} in its place.
     * Kept package private so the recovery can be exercised without a running server.
     *
     * @return the file the configuration is read from afterwards
     */
    static Path recoverMalformed(Path file, byte[] bundledDefault, Logger logger) {
        final String stamp = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").format(LocalDateTime.now());
        final Path backup = file.resolveSibling(file.getFileName() + ".broken-" + stamp);
        try {
            Files.move(file, backup, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new ConfigException("Файл конфигурации " + file + " повреждён, и сохранить его как "
                    + backup + " не удалось. Исправьте YAML вручную и перезапустите сервер.", e);
        }
        try {
            Files.write(file, bundledDefault);
        } catch (IOException e) {
            throw new ConfigException("Файл конфигурации " + file + " заменён, но записать стандартный "
                    + CONFIG_RESOURCE + " не удалось: " + e.getMessage(), e);
        }
        logger.warn("Файл конфигурации не является корректным (ошибка выше: там указаны строка и столбец). "
                + "Файл заменён на стандартный, прежнее содержимое сохранено как {}. "
                + "Перенесите оттуда свои значения в {} и перезапустите сервер: сейчас действуют значения по умолчанию.",
                backup.getFileName(), file.getFileName());
        return file;
    }

    /** Loads the localized messages of the configured language, with the data directory as override. */
    public Messages messages(PluginConfig config) {
        final Messages messages = Messages.load(config.language(), languageDirectory(), LANG_RESOURCE_DIRECTORY);
        logger.debug("Загружено сообщений: {} (язык '{}')", messages.entries().size(), config.language());
        return messages;
    }

    public String describe() {
        return PluginBuild.NAME + " " + plugin.getDescription().getVersion();
    }
}
