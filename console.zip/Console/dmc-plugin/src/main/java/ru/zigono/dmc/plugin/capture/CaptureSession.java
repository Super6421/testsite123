package ru.zigono.dmc.plugin.capture;

import ru.zigono.dmc.plugin.text.OutputSanitizer;

import java.util.function.LongSupplier;

/**
 * One active capture of the server console output. The session is created on the main thread right before a
 * command is dispatched and is released when the console stayed quiet for the configured period, when the hard
 * stop is reached or when the output limit is hit.
 *
 * @author Zigono
 */
public final class CaptureSession {

    /** Why a capture session was closed. */
    public enum ReleaseReason {
        QUIET,
        MAX_WAIT,
        SATURATED,
        DISABLED,
        CANCELLED
    }

    private final String requestId;
    private final String command;
    private final CaptureSettings settings;
    private final LongSupplier clock;
    private final CaptureBuffer buffer;
    private final long startedAt;
    private volatile long lastActivityAt;
    private volatile boolean active = true;
    private volatile long releasedAt;
    private volatile ReleaseReason releaseReason;
    private volatile CaptureOutcome outcome;

    public CaptureSession(String requestId, String command, CaptureSettings settings, LongSupplier clock) {
        this.requestId = requestId;
        this.command = command;
        this.settings = settings;
        this.clock = clock;
        this.startedAt = clock.getAsLong();
        this.lastActivityAt = this.startedAt;
        this.buffer = new CaptureBuffer(settings.maxLines(), settings.maxChars());
        if (!settings.enabled()) {
            release(ReleaseReason.DISABLED);
        }
    }

    public String requestId() {
        return requestId;
    }

    public String command() {
        return command;
    }

    public CaptureSettings settings() {
        return settings;
    }

    public long startedAt() {
        return startedAt;
    }

    public long lastActivityAt() {
        return lastActivityAt;
    }

    public boolean active() {
        return active;
    }

    public CaptureBuffer buffer() {
        return buffer;
    }

    public int lineCount() {
        return buffer.size();
    }

    /**
     * Feeds one console line into this session.
     *
     * @return {@code true} when the line was captured
     */
    public boolean accept(String loggerName, String level, String rawLine) {
        if (!active) {
            return false;
        }
        final String sanitized = OutputSanitizer.sanitize(rawLine);
        if (sanitized.isBlank()) {
            return false;
        }
        lastActivityAt = clock.getAsLong();
        final String line = OutputSanitizer.truncate(sanitized, settings.maxLineLength());
        if (!buffer.append(line)) {
            release(ReleaseReason.SATURATED);
            return false;
        }
        return true;
    }

    /** @return milliseconds since the last console line of this session */
    public long idleMillis(long now) {
        return Math.max(0L, now - lastActivityAt);
    }

    /** @return milliseconds since the command was dispatched */
    public long elapsedMillis(long now) {
        return Math.max(0L, now - startedAt);
    }

    /** @return {@code true} when the hard stop was reached */
    public boolean hardStopReached(long now) {
        return elapsedMillis(now) >= settings.maxWaitMs();
    }

    /** @return {@code true} when the capture may be closed */
    public boolean shouldFinish(long now) {
        if (!active) {
            return true;
        }
        if (buffer.saturated()) {
            return true;
        }
        if (hardStopReached(now)) {
            return true;
        }
        // The quiet period starts with the first captured line: a command whose output is produced a few ticks
        // after dispatch must never be reported as "no output". Without any output the hard stop ends the wait.
        return settings.quietPeriodMs() > 0 && buffer.size() > 0 && idleMillis(now) >= settings.quietPeriodMs();
    }

    /** Releases the session and returns its immutable outcome. */
    public CaptureOutcome release(ReleaseReason reason) {
        synchronized (this) {
            if (!active && outcome != null) {
                return outcome;
            }
            active = false;
            releasedAt = clock.getAsLong();
            releaseReason = reason;
            outcome = new CaptureOutcome(requestId, command, buffer.lines(),
                    buffer.truncated() || reason == ReleaseReason.SATURATED,
                    buffer.droppedLines(),
                    Math.max(0L, releasedAt - startedAt),
                    reason);
            return outcome;
        }
    }

    /** Releases the session because the execution was cancelled or the plugin is shutting down. */
    public CaptureOutcome cancel() {
        return active ? release(ReleaseReason.CANCELLED) : outcome;
    }

    public long releasedAt() {
        return releasedAt;
    }

    public ReleaseReason releaseReason() {
        return releaseReason;
    }

    /** @return the outcome, or {@code null} while the session is still running */
    public CaptureOutcome outcome() {
        return outcome;
    }
}