package ru.zigono.dmc.plugin.execution;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.capture.CaptureOutcome;
import ru.zigono.dmc.plugin.capture.CaptureSession;
import ru.zigono.dmc.plugin.capture.CaptureSettings;
import ru.zigono.dmc.plugin.capture.CaptureSink;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.metrics.PluginMetrics;
import ru.zigono.dmc.plugin.visibility.ExecutionEcho;
import ru.zigono.dmc.plugin.visibility.VisibilityService;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.PluginMessages;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Heart of the plugin: takes a command from the connection, answers immediately whether it was accepted, executes
 * it on the server main thread, captures the real console output and reports the real result.
 * <p>The {@code accepted} flag is sent before the command reaches the main thread, which is what makes the retry
 * logic of the gateway safe: a command that was never accepted may be retried, a command that was accepted never
 * is, because it may already have changed the world.</p>
 *
 * @author Zigono
 */
public final class CommandExecutionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CommandExecutionService.class);
    private static final long MINIMUM_TIMEOUT_MILLIS = 1_000L;
    private static final long TIMEOUT_MARGIN_MILLIS = 250L;

    private final JavaPlugin plugin;
    private final Supplier<PluginConfig> config;
    private final Supplier<Messages> messages;
    private final Supplier<PluginPolicy> policy;
    private final VisibilityService visibility;
    private final MessageSink gateway;
    private final CaptureSink sink;
    private final PluginMetrics metrics;
    private final ExecutionQueue<PendingExecution> queue;
    private volatile boolean shuttingDown;

    public CommandExecutionService(JavaPlugin plugin, Supplier<PluginConfig> config, Supplier<Messages> messages,
                                   Supplier<PluginPolicy> policy, VisibilityService visibility, MessageSink gateway,
                                   CaptureSink sink, PluginMetrics metrics) {
        this.plugin = plugin;
        this.config = config;
        this.messages = messages;
        this.policy = policy;
        this.visibility = visibility;
        this.gateway = gateway;
        this.sink = sink;
        this.metrics = metrics;
        final PluginConfig initial = config.get();
        this.queue = new ExecutionQueue<>(initial.execution().maxConcurrent(), initial.execution().queueSize());
    }

    /** Applies hot reloaded limits. Commands that already wait keep their place in the queue. */
    public void reconfigure(PluginConfig current) {
        queue.reconfigure(current.execution().maxConcurrent(), current.execution().queueSize());
    }

    public boolean shuttingDown() {
        return shuttingDown;
    }

    public int queueDepth() {
        return queue.depth();
    }

    public int runningCount() {
        return queue.runningCount();
    }

    /** Handles one command dispatch. Called from the transport thread, never from the main thread. */
    public void onDispatch(PluginMessages.CommandDispatch dispatch) {
        final PluginConfig current = config.get();
        final Messages lang = messages.get();
        final String serverId = current.server().id();
        if (shuttingDown) {
            refuse(dispatch, serverId, lang.format("plugin.command.rejected_shutting_down"));
            return;
        }
        final PluginPolicy activePolicy = policy.get();
        final NormalizedCommand command;
        try {
            command = activePolicy.normalize(dispatch.command);
        } catch (CommandException invalid) {
            refuse(dispatch, serverId, lang.format("plugin.command.rejected_invalid", invalid.getMessage()));
            return;
        }
        final PluginPolicy.Verdict verdict = activePolicy.check(command);
        if (verdict.denied()) {
            metrics.commandReceived();
            metrics.recordOutcome(ExecutionStatus.DENIED, 0, 0L);
            LOGGER.info("Команда отклонена '{}': {}", command.normalized(), verdict.reason());
            accept(dispatch, serverId, true, null);
            sendOutcome(dispatch, OutcomeBuilder.outcome(serverId, dispatch.getRequestId(), ExecutionStatus.DENIED,
                    List.of(), 0L, ErrorCode.POLICY_DENIED.name(), verdict.reason()));
            return;
        }
        if (dispatch.dryRun) {
            metrics.commandReceived();
            metrics.recordOutcome(ExecutionStatus.DRY_RUN, 0, 0L);
            accept(dispatch, serverId, true, null);
            sendOutcome(dispatch, OutcomeBuilder.outcome(serverId, dispatch.getRequestId(), ExecutionStatus.DRY_RUN,
                    List.of(), 0L, ErrorCode.DRY_RUN.name(), lang.format("plugin.command.dryrun", command.normalized())));
            return;
        }
        final PendingExecution pending = new PendingExecution(dispatch, command, System.currentTimeMillis());
        final ExecutionQueue.SubmitResult submitted = queue.submit(pending);
        if (submitted != ExecutionQueue.SubmitResult.ACCEPTED) {
            metrics.commandRefused();
            final String reason = submitted == ExecutionQueue.SubmitResult.QUEUE_FULL
                    ? lang.format("plugin.command.rejected_queue_full", queue.depth())
                    : lang.format("plugin.command.rejected_shutting_down");
            LOGGER.warn("Команда отклонена '{}': {}", command.normalized(), reason);
            refuse(dispatch, serverId, reason);
            return;
        }
        metrics.commandReceived();
        accept(dispatch, serverId, true, null);
        drain();
    }

    /** Stops accepting commands, cancels everything that waits and reports it honestly. */
    public void shutdown() {
        shuttingDown = true;
        final List<PendingExecution> waiting = new ArrayList<>(queue.drainWaiting());
        final List<PendingExecution> active = new ArrayList<>(queue.running());
        queue.shutdown();
        for (PendingExecution pending : waiting) {
            queue.complete(pending);
            cancelExecution(pending, config.get());
        }
        for (PendingExecution pending : active) {
            cancelExecution(pending, config.get());
        }
    }

    private void cancelExecution(PendingExecution pending, PluginConfig current) {
        if (!pending.beginFinishing()) {
            return;
        }
        cancelTask(pending);
        final CaptureSession session = pending.session();
        if (session != null) {
            sink.unregister(session);
            session.cancel();
        }
        queue.complete(pending);
        sendOutcome(pending.dispatch(), OutcomeBuilder.outcome(current.server().id(), pending.requestId(),
                ExecutionStatus.CANCELLED, List.of(), 0L, ErrorCode.CONNECTION_LOST.name(),
                messages.get().format("plugin.command.rejected_shutting_down")));
    }

    private void drain() {
        if (shuttingDown) {
            return;
        }
        PendingExecution pending;
        while (!shuttingDown && (pending = queue.next()) != null) {
            start(pending);
        }
    }

    private void start(PendingExecution pending) {
        try {
            Bukkit.getScheduler().runTask(plugin, () -> executeOnMainThread(pending));
        } catch (RuntimeException failure) {
            queue.complete(pending);
            finishImmediately(pending, "не удалось запланировать команду в главном потоке: " + failure.getMessage());
        }
    }

    private void executeOnMainThread(PendingExecution pending) {
        final PluginConfig current = config.get();
        if (shuttingDown) {
            finishImmediately(pending, messages.get().format("plugin.command.rejected_shutting_down"));
            return;
        }
        final long timeout = Math.max(MINIMUM_TIMEOUT_MILLIS, pending.dispatch().timeoutMillis);
        final long budget = Math.min(current.capture().maxWaitMs(), Math.max(250L, timeout - TIMEOUT_MARGIN_MILLIS));
        pending.markStarted(System.currentTimeMillis(), System.currentTimeMillis() + budget);
        try {
            visibility.echoCommand(ExecutionEcho.command(describeIssuer(pending.dispatch().issuer), pending.command(),
                    current.server().name(), pending.dispatch().targetDescription, pending.requestId()), current);
        } catch (RuntimeException announcementFailure) {
            LOGGER.debug("Не удалось объявить команду на этом сервере", announcementFailure);
        }
        final CaptureSettings captureSettings = current.capture();
        final CaptureSession session = new CaptureSession(pending.requestId(), pending.command().normalized(),
                captureSettings, System::currentTimeMillis);
        pending.session(session);
        sink.register(session);
        final long started = System.nanoTime();
        boolean executed = false;
        String failure = null;
        try {
            executed = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), pending.command().normalized());
        } catch (Throwable thrown) {
            failure = thrown.getMessage() == null ? thrown.getClass().getSimpleName() : thrown.getMessage();
        }
        pending.markDispatch(executed, failure, Math.max(0L, (System.nanoTime() - started) / 1_000_000L));
        if (current.logging().debug()) {
            LOGGER.info("Выполнено '{}' в главном потоке, консоль приняла={}, заняло {} мс",
                    pending.command().normalized(), executed, pending.dispatchDurationMillis());
        }
        scheduleCompletion(pending, current);
    }

    private void scheduleCompletion(PendingExecution pending, PluginConfig current) {
        final int period = Math.max(1, current.execution().pollIntervalTicks());
        final BukkitTask task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            final CaptureSession session = pending.session();
            if (session == null) {
                return;
            }
            final long now = System.currentTimeMillis();
            if (!session.shouldFinish(now) && now < pending.hardStopAt()) {
                return;
            }
            complete(pending, current);
        }, period, period);
        pending.pollTask(task);
    }

    private void complete(PendingExecution pending, PluginConfig current) {
        if (!pending.beginFinishing()) {
            return;
        }
        cancelTask(pending);
        final CaptureSession session = pending.session();
        final long now = System.currentTimeMillis();
        final CaptureSession.ReleaseReason reason;
        if (session == null) {
            reason = CaptureSession.ReleaseReason.CANCELLED;
        } else if (session.buffer().saturated()) {
            reason = CaptureSession.ReleaseReason.SATURATED;
        } else if (now >= pending.hardStopAt()) {
            reason = CaptureSession.ReleaseReason.MAX_WAIT;
        } else {
            reason = CaptureSession.ReleaseReason.QUIET;
        }
        final CaptureOutcome capture;
        if (session == null) {
            capture = null;
        } else {
            sink.unregister(session);
            capture = session.release(reason);
        }
        final Messages lang = messages.get();
        final List<String> raw = capture == null ? List.of() : capture.lines();
        final OutcomeBuilder.Trimmed trimmed = OutcomeBuilder.trim(raw, new OutcomeBuilder.Limits(
                current.capture().maxLines(), current.capture().maxChars(), current.capture().maxLineLength()));
        final List<String> output = new ArrayList<>(trimmed.lines());
        if (trimmed.droppedLines() > 0) {
            output.add(lang.format("plugin.command.output_truncated", trimmed.droppedLines()));
        }
        final ExecutionStatus status = statusOf(pending, capture, output);
        final String errorCode = errorCodeOf(pending, capture, status);
        final String errorDetail = errorDetailOf(pending, status, lang);
        final long duration = pending.dispatchDurationMillis() + (capture == null ? 0L : capture.durationMillis());
        metrics.recordOutcome(status, output.size(), duration);
        sendOutcome(pending.dispatch(), OutcomeBuilder.outcome(current.server().id(), pending.requestId(), status,
                output, duration, errorCode, errorDetail));
        // Обычная жизнь команды — подробность для отладки: консоль сервера не должна превращаться в ленту
        // на каждую команду из Discord (итог всё равно уходит в Discord, аудит и /discordconsole status).
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Команда {} завершена со статусом {} ({} строк, {} мс)", pending.requestId(), status,
                    output.size(), duration);
        }
        if (!output.isEmpty()) {
            final ExecutionEcho echo = new ExecutionEcho(describeIssuer(pending.dispatch().issuer), pending.command(),
                    current.server().name(), pending.dispatch().targetDescription, output, status.name(), duration,
                    pending.requestId());
            announceResult(echo, current);
        }
        queue.complete(pending);
        drain();
    }

    private void announceResult(ExecutionEcho echo, PluginConfig current) {
        try {
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    visibility.echoResult(echo, current);
                } catch (RuntimeException failure) {
                    LOGGER.debug("Не удалось объявить результат команды", failure);
                }
            });
        } catch (RuntimeException notScheduled) {
            LOGGER.debug("Не удалось запланировать объявление результата: {}", notScheduled.getMessage());
        }
    }

    private ExecutionStatus statusOf(PendingExecution pending, CaptureOutcome capture, List<String> output) {
        if (pending.dispatchFailure() != null) {
            return ExecutionStatus.FAILED;
        }
        if (pending.dispatchSucceeded() || !output.isEmpty()) {
            return ExecutionStatus.SUCCESS;
        }
        if (capture != null && capture.reason() == CaptureSession.ReleaseReason.MAX_WAIT) {
            return ExecutionStatus.TIMEOUT;
        }
        return ExecutionStatus.FAILED;
    }

    private String errorCodeOf(PendingExecution pending, CaptureOutcome capture, ExecutionStatus status) {
        return switch (status) {
            case SUCCESS, DRY_RUN -> null;
            case TIMEOUT -> ErrorCode.TIMEOUT.name();
            case FAILED -> pending.dispatchFailure() == null ? ErrorCode.INVALID_COMMAND.name()
                    : ErrorCode.INTERNAL_ERROR.name();
            default -> status.name();
        };
    }

    private String errorDetailOf(PendingExecution pending, ExecutionStatus status, Messages lang) {
        return switch (status) {
            case TIMEOUT -> lang.format("plugin.command.timeout", config.get().capture().maxWaitMs());
            case FAILED -> pending.dispatchFailure() != null ? pending.dispatchFailure()
                    : lang.raw("plugin.command.unknown");
            default -> null;
        };
    }

    private void finishImmediately(PendingExecution pending, String detail) {
        if (!pending.beginFinishing()) {
            return;
        }
        sendOutcome(pending.dispatch(), OutcomeBuilder.outcome(config.get().server().id(), pending.requestId(),
                ExecutionStatus.CANCELLED, List.of(), 0L, ErrorCode.CONNECTION_LOST.name(), detail));
    }

    private void cancelTask(PendingExecution pending) {
        final BukkitTask task = pending.pollTask();
        if (task == null) {
            return;
        }
        try {
            task.cancel();
        } catch (IllegalStateException alreadyCancelled) {
            LOGGER.debug("Наблюдатель за выводом {} уже был отменён", pending.requestId());
        }
    }

    private void accept(PluginMessages.CommandDispatch dispatch, String serverId, boolean accepted, String reason) {
        final PluginMessages.CommandAccepted message = dispatch.correlate(new PluginMessages.CommandAccepted());
        message.serverId = serverId;
        message.accepted = accepted;
        message.reason = reason;
        message.acceptedAt = System.currentTimeMillis();
        message.queuedMillis = 0L;
        gateway.send(message);
    }

    private void refuse(PluginMessages.CommandDispatch dispatch, String serverId, String reason) {
        accept(dispatch, serverId, false, reason);
    }

    private void sendOutcome(PluginMessages.CommandDispatch dispatch, ServerOutcome outcome) {
        final PluginMessages.CommandOutcomeMessage message = dispatch.correlate(new PluginMessages.CommandOutcomeMessage());
        message.serverId = outcome.serverId();
        message.command = dispatch.command;
        message.outcome = outcome;
        gateway.send(message);
    }

    private static String describeIssuer(UserContext issuer) {
        if (issuer == null) {
            return "неизвестно";
        }
        final String described = issuer.describe();
        return described == null || described.isBlank() ? "неизвестно" : described;
    }
}