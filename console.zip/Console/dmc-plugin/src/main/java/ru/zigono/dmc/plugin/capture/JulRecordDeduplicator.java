package ru.zigono.dmc.plugin.capture;

import java.util.logging.LogRecord;

/**
 * Java Util Logging hands the very same {@link LogRecord} instance to every handler of a logger and of its
 * parents. This ring buffer recognises the records that were already processed, so a handler that is attached to
 * several loggers never reports the same message twice, without ever dropping legitimate repeated lines.
 *
 * @author Zigono
 */
public final class JulRecordDeduplicator {

    private final LogRecord[] ring;
    private int index;

    public JulRecordDeduplicator(int capacity) {
        this.ring = new LogRecord[Math.max(2, capacity)];
    }

    /**
     * @return {@code true} the first time this record instance is seen
     */
    public synchronized boolean firstSight(LogRecord record) {
        if (record == null) {
            return false;
        }
        for (LogRecord seen : ring) {
            if (seen == record) {
                return false;
            }
        }
        ring[index] = record;
        index = (index + 1) % ring.length;
        return true;
    }
}