package ru.zigono.dmc.plugin.visibility;

import ru.zigono.dmc.common.command.NormalizedCommand;

import java.util.List;

/**
 * Plain data of one announcement. Keeps the visibility layer free of any dependency on the execution engine.
 *
 * @author Zigono
 */
public record ExecutionEcho(String user, NormalizedCommand command, String server, String target, List<String> output,
                            String status, long durationMillis, String requestId) {

    public ExecutionEcho {
        output = output == null ? List.of() : List.copyOf(output);
    }

    public static ExecutionEcho command(String user, NormalizedCommand command, String server, String target,
                                        String requestId) {
        return new ExecutionEcho(user, command, server, target, List.of(), "", 0L, requestId);
    }
}