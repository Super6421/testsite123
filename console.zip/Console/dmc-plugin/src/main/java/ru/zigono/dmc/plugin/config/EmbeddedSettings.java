package ru.zigono.dmc.plugin.config;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Embedded ("all-in-one") mode of the plugin: the gateway and the Discord bot run inside the Minecraft server
 * process, so {@code plugins/DiscordMinecraftConsole/DiscordMinecraftConsole-<version>.jar} is everything an
 * administrator has to install. No second process, no TLS material and no exposed port are involved: the
 * control plane talks to the plugin over a loopback connection inside the same JVM.
 * <pre>
 * embedded:
 *   enabled: true
 *   discord:
 *     token: "${DISCORD_TOKEN:}"
 *   permissions:
 *     roles:
 *       123456789012345678: console.*
 * </pre>
 * <p>The gateway and the bot keep their own configuration files, they are generated from this section into the
 * {@code embedded/} directory on every start, so this file stays the single source of truth.</p>
 *
 * @author Zigono
 */
public record EmbeddedSettings(boolean enabled, String gatewayId, String controlClientId, DiscordSettings discord,
                               Map<String, Object> permissions, Map<String, Object> gatewayOverrides,
                               Map<String, Object> botOverrides, ServerTopology topology, String bindHost, int bindPort,
                               Path directory) {

    /** Directory below the plugin data directory that holds the generated files. */
    public static final String DEFAULT_DIRECTORY = "embedded";

    /** Адрес, на котором по умолчанию слушает встроенный шлюз: только этот же процесс. */
    public static final String DEFAULT_BIND_HOST = "127.0.0.1";

    /** Порт встроенного шлюза по умолчанию: свободный порт выбирает операционная система. */
    public static final int DEFAULT_BIND_PORT = 0;

    /** Statuses accepted by the Discord client. */
    public static final List<String> DISCORD_STATUSES = List.of("ONLINE", "IDLE", "DND", "INVISIBLE");

    public static EmbeddedSettings from(YamlConfig root, Path baseDirectory, String pluginLanguage) {
        final YamlConfig section = root.section("embedded");
        final boolean enabled = section.bool("enabled", false);
        final String directory = section.string("directory", DEFAULT_DIRECTORY).trim();
        final Path resolved = resolve(baseDirectory, directory.isEmpty() ? DEFAULT_DIRECTORY : directory);
        final YamlConfig network = section.section("network");
        final String bindHost = text(network.string("host", DEFAULT_BIND_HOST), DEFAULT_BIND_HOST);
        final int bindPort = network.integer("port", DEFAULT_BIND_PORT);
        if (bindPort < 0 || bindPort > 65535) {
            throw new ConfigException("embedded.network.port должен быть от 0 до 65535, а указано " + bindPort);
        }
        return new EmbeddedSettings(
                enabled,
                text(section.string("gateway_id", "dmc-embedded"), "dmc-embedded"),
                text(section.string("control_client_id", "discord-console"), "discord-console"),
                DiscordSettings.from(section.section("discord"), pluginLanguage),
                section.section("permissions").map(""),
                section.section("gateway_overrides").map(""),
                section.section("bot_overrides").map(""),
                ServerTopology.of(root),
                bindHost,
                bindPort,
                resolved);
    }

    /** @return the settings of a build where the embedded mode is switched off */
    public static EmbeddedSettings disabled(Path baseDirectory) {
        return new EmbeddedSettings(false, "dmc-embedded", "discord-console",
                DiscordSettings.from(YamlConfig.empty("disabled"), "en"), Map.of(), Map.of(), Map.of(),
                ServerTopology.of(YamlConfig.empty("disabled")), DEFAULT_BIND_HOST, DEFAULT_BIND_PORT,
                resolve(baseDirectory, DEFAULT_DIRECTORY));
    }

    /** @return {@code true} when the Discord bot can be started */
    public boolean botConfigured() {
        return enabled && discord.token() != null && !discord.token().isBlank();
    }

    public Path serverSecretFile() {
        return directory.resolve("server.secret");
    }

    public Path controlSecretFile() {
        return directory.resolve("control.secret");
    }

    public Path gatewayConfigFile() {
        return directory.resolve("gateway.yml");
    }

    public Path botConfigFile() {
        return directory.resolve("bot.yml");
    }

    /**
     * Файл с секретом сервера, который подключается к этому шлюзу по сети.
     * <p>Секрет создаётся при первом запуске и указывается потом в {@code security.server_secret}
     * конфигурации того сервера.</p>
     */
    public Path serverSecretFile(String serverId) {
        return directory.resolve("server-" + serverId + ".secret");
    }

    /** Directory the gateway keeps its database in. */
    public Path dataDirectory() {
        return directory.resolve("data");
    }

    private static Path resolve(Path baseDirectory, String value) {
        final Path path = Path.of(value);
        if (path.isAbsolute() || baseDirectory == null) {
            return path;
        }
        return baseDirectory.resolve(path);
    }

    private static String text(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    /** Discord side of the embedded mode: the bot the plugin runs for this Minecraft server. */
    public record DiscordSettings(String token, List<String> guilds, String activity, String status, String language,
                                  String auditChannelId, List<String> allowedChannels, List<String> deniedChannels) {

        static DiscordSettings from(YamlConfig section, String pluginLanguage) {
            final String status = section.string("status", "ONLINE").trim().toUpperCase(Locale.ROOT);
            if (!DISCORD_STATUSES.contains(status)) {
                throw new ConfigException("embedded.discord.status должен быть одним из " + DISCORD_STATUSES
                        + ", а указано '" + status + "'");
            }
            // An unresolved placeholder means the administrator did not set the variable yet. The Minecraft
            // server must still start, so the bot simply counts as not configured and the runtime says so.
            final String rawToken = section.string("token", "").trim();
            final String token = rawToken.contains("${") ? "" : rawToken;
            final String language = section.string("language", "").trim();
            return new DiscordSettings(token, values(section, "guilds"),
                    section.string("activity", "Minecraft Console").trim(), status,
                    language.isEmpty() ? pluginLanguage : language.toLowerCase(Locale.ROOT),
                    section.string("audit_channel_id", "").trim(),
                    values(section, "channels.allowed"),
                    values(section, "channels.denied"));
        }

        /**
         * Читает список идентификаторов. Пустая строка означает «список пуст», а не идентификатор "", поэтому
         * пустые значения отбрасываются; несколько идентификаторов можно перечислить через запятую.
         */
        private static List<String> values(YamlConfig section, String path) {
            final List<String> result = new ArrayList<>();
            for (String value : section.stringList(path, List.of())) {
                for (String part : value.split("[,;\\s]+")) {
                    final String trimmed = part.trim();
                    if (!trimmed.isEmpty() && !result.contains(trimmed)) {
                        result.add(trimmed);
                    }
                }
            }
            return List.copyOf(result);
        }
    }
}
