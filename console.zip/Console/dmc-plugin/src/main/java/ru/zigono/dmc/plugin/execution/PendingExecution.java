package ru.zigono.dmc.plugin.execution;

import org.bukkit.scheduler.BukkitTask;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.plugin.capture.CaptureSession;
import ru.zigono.dmc.protocol.message.PluginMessages;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Mutable state of one command that travels through the plugin: queued, executing, finishing. All fields that
 * cross threads are volatile, and {@link #finishing} makes the completion path run exactly once.
 *
 * @author Zigono
 */
public final class PendingExecution {

    private final PluginMessages.CommandDispatch dispatch;
    private final NormalizedCommand command;
    private final long enqueuedAt;
    private final AtomicBoolean finishing = new AtomicBoolean();

    private volatile long startedAt;
    private volatile long hardStopAt;
    private volatile CaptureSession session;
    private volatile BukkitTask pollTask;
    private volatile boolean dispatchSucceeded;
    private volatile String dispatchFailure;
    private volatile long dispatchDurationMillis;

    public PendingExecution(PluginMessages.CommandDispatch dispatch, NormalizedCommand command, long enqueuedAt) {
        this.dispatch = dispatch;
        this.command = command;
        this.enqueuedAt = enqueuedAt;
    }

    public PluginMessages.CommandDispatch dispatch() {
        return dispatch;
    }

    public String requestId() {
        return dispatch.getRequestId();
    }

    public String rawCommand() {
        return dispatch.command;
    }

    public NormalizedCommand command() {
        return command;
    }

    public long enqueuedAt() {
        return enqueuedAt;
    }

    public long queuedMillis() {
        return startedAt <= 0L ? 0L : Math.max(0L, startedAt - enqueuedAt);
    }

    public long startedAt() {
        return startedAt;
    }

    public void markStarted(long timestamp, long hardStopAt) {
        this.startedAt = timestamp;
        this.hardStopAt = hardStopAt;
    }

    public long hardStopAt() {
        return hardStopAt;
    }

    public CaptureSession session() {
        return session;
    }

    public void session(CaptureSession session) {
        this.session = session;
    }

    public BukkitTask pollTask() {
        return pollTask;
    }

    public void pollTask(BukkitTask task) {
        this.pollTask = task;
    }

    public void markDispatch(boolean succeeded, String failure, long durationMillis) {
        this.dispatchSucceeded = succeeded;
        this.dispatchFailure = failure;
        this.dispatchDurationMillis = durationMillis;
    }

    public boolean dispatchSucceeded() {
        return dispatchSucceeded;
    }

    public String dispatchFailure() {
        return dispatchFailure;
    }

    public long dispatchDurationMillis() {
        return dispatchDurationMillis;
    }

    /** @return {@code true} for the single caller that is allowed to finish this execution */
    public boolean beginFinishing() {
        return finishing.compareAndSet(false, true);
    }

    public boolean finishing() {
        return finishing.get();
    }

    public boolean neverStarted() {
        return startedAt <= 0L;
    }
}