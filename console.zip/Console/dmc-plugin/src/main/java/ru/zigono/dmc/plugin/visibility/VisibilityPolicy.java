package ru.zigono.dmc.plugin.visibility;

import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.NormalizedCommand;

import java.util.List;
import java.util.Locale;

/**
 * Decides who may see Discord Console activity on the Minecraft server.
 * <p>Rules, in order: the console sees everything; disabled visibility hides everything from players; the
 * administrative bypass node wins over the configured mode; then the mode {@code permission} / {@code default}
 * decides whether the base permission is required. Commands that are listed in {@code hidden_commands} are never
 * visible to anybody, not even to administrators, which is what protects credentials typed into Discord.</p>
 *
 * @author Zigono
 */
public final class VisibilityPolicy {

    /** Visibility mode of the plugin. */
    public enum Mode {
        DEFAULT,
        PERMISSION,
        NOBODY;

        static Mode parse(String value) {
            if (value == null) {
                return DEFAULT;
            }
            return switch (value.trim().toLowerCase(Locale.ROOT)) {
                case "permission" -> PERMISSION;
                case "nobody", "none", "off" -> NOBODY;
                default -> DEFAULT;
            };
        }
    }

    private final VisibilitySettings settings;
    private final VisibilityNodes nodes;
    private final Mode mode;
    private final List<CommandPolicyEngine.TokenPattern> hidden;

    public VisibilityPolicy(VisibilitySettings settings, VisibilityNodes nodes) {
        this.settings = settings;
        this.nodes = nodes == null ? VisibilityNodes.none() : nodes;
        this.mode = Mode.parse(settings.mode());
        this.hidden = CommandPolicyEngine.TokenPattern.listOf(settings.hiddenCommands());
    }

    public VisibilitySettings settings() {
        return settings;
    }

    public Mode mode() {
        return mode;
    }

    /** @return {@code true} when this command must never be echoed anywhere */
    public boolean hidden(NormalizedCommand command) {
        return command != null && hidden.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
    }

    /** @return {@code true} when the viewer passes the base gate of the configured mode */
    public boolean baseVisible(Viewer viewer) {
        if (viewer.console()) {
            return true;
        }
        if (!settings.enabled()) {
            return false;
        }
        if (viewer.bypass()) {
            return true;
        }
        return switch (mode) {
            case NOBODY -> false;
            case PERMISSION -> viewer.has(settings.permission());
            case DEFAULT -> settings.defaultVisible() || viewer.has(settings.permission());
        };
    }

    /** @return {@code true} when the viewer may see the command that was executed */
    public boolean maySeeCommands(Viewer viewer) {
        return baseVisible(viewer) && refinementAllows(viewer, nodes.commands());
    }

    /** @return {@code true} when the viewer may see the result of the command */
    public boolean maySeeResults(Viewer viewer) {
        return settings.showResults() && maySeeCommands(viewer) && refinementAllows(viewer, nodes.results());
    }

    /** @return {@code true} when the viewer may see the name of this server */
    public boolean maySeeServer(Viewer viewer) {
        return baseVisible(viewer) && refinementAllows(viewer, nodes.servers());
    }

    private boolean refinementAllows(Viewer viewer, String node) {
        if (node == null || node.isBlank()) {
            return true;
        }
        return viewer.bypass() || viewer.has(node);
    }

    /** @return the hidden command patterns, for logging and diagnostics */
    public List<String> hiddenPatterns() {
        return hidden.stream().map(CommandPolicyEngine.TokenPattern::raw).toList();
    }

    public String describe() {
        return "mode=" + mode.name().toLowerCase(Locale.ROOT) + ", enabled=" + settings.enabled()
                + ", default=" + settings.defaultVisible() + ", hidden=" + hiddenPatterns();
    }
}