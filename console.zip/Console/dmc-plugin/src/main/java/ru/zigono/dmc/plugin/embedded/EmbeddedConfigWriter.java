package ru.zigono.dmc.plugin.embedded;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;
import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.plugin.PluginBuild;
import ru.zigono.dmc.plugin.config.EmbeddedSettings;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.config.ServerTopology;
import ru.zigono.dmc.plugin.execution.PluginPolicy;
import ru.zigono.dmc.protocol.ProtocolVersion;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Writes the configuration files of the control plane and of the Discord bot that the embedded mode runs inside
 * the Minecraft server process.
 * <p>Both files are generated from the single {@code config.yml} of the plugin on every start, so an
 * administrator never has to keep three files in sync. Only the values this mode really needs are written: every
 * other key keeps the default of the component that reads it, which is why the generated files stay short and
 * cannot drift away from the code. The optional {@code embedded.gateway_overrides} and
 * {@code embedded.bot_overrides} sections are merged over the generated document for the cases that need more.</p>
 *
 * @author Zigono
 */
public final class EmbeddedConfigWriter {

    /** Адрес по умолчанию: встроенный шлюз доступен только этому же процессу. */
    public static final String LOOPBACK_HOST = "127.0.0.1";

    /** Port requested by the embedded listener: the operating system picks a free one. */
    public static final int EPHEMERAL_PORT = 0;

    /** Language directory of the bot relative to the directory of the generated {@code bot.yml}. */
    private static final String LANGUAGE_DIRECTORY = "../lang";

    private EmbeddedConfigWriter() {
    }

    /**
     * Writes {@code embedded/gateway.yml}: the whole server catalog of {@code config.yml} (разделы {@code mode},
     * {@code servers} и {@code groups}), one control client, its own database and, by default, a loopback listener
     * without TLS, because the traffic never leaves the machine.
     *
     * @param file          target file
     * @param config        plugin configuration the document is derived from
     * @param serverSecrets secret of every server of the catalog, keyed by its id
     * @param controlSecret secret the embedded Discord bot authenticates with
     */
    public static void writeGateway(Path file, PluginConfig config, Map<String, String> serverSecrets,
                                    String controlSecret) {
        final EmbeddedSettings embedded = config.embedded();
        final ServerTopology topology = embedded.topology();
        final Map<String, Object> document = new LinkedHashMap<>();
        document.put("protocol_version", ProtocolVersion.CURRENT);
        document.put("mode", topology.mode());
        document.put("gateway", map("id", embedded.gatewayId()));
        document.put("servers", topology.gatewayServers(serverSecrets));
        final Map<String, Object> groups = topology.gatewayGroups();
        if (!groups.isEmpty()) {
            document.put("groups", groups);
        }
        document.put("control", map("clients", map(embedded.controlClientId(), map("secret", controlSecret))));
        if (!embedded.permissions().isEmpty()) {
            document.put("permissions", copy(embedded.permissions()));
        }
        final Map<String, Object> guilds = guilds(embedded);
        if (!guilds.isEmpty()) {
            document.put("guilds", guilds);
        }
        document.put("security", security(config.root()));
        if (config.root().has("command_policies")) {
            document.put("command_policies", copyValue(config.root().raw("command_policies")));
        }
        document.put("database", map(
                "type", "sqlite",
                "sqlite", map("file", "data/gateway.db"),
                "retention", map("enabled", true, "days", 90, "security_days", 365, "interval_hours", 6)));
        document.put("redis", map("enabled", false));
        document.put("metrics", map("enabled", false));
        document.put("logging", map("debug", config.logging().debug()));
        document.put("network", map(
                "host", embedded.bindHost(),
                "port", embedded.bindPort(),
                "max_frame_bytes", TransportSettings.DEFAULT_MAX_FRAME_BYTES,
                "connect_timeout", "10s",
                "handshake_timeout", "15s",
                "idle_timeout", "120s",
                "shutdown_grace", "10s"));
        document.put("tls", map("enabled", false, "allow_insecure_transport", true));
        merge(document, copy(embedded.gatewayOverrides()));
        write(file, "gateway", document,
                "Шлюз (control plane) встроенного режима " + PluginBuild.NAME + " — автор: Zigono.\n"
                        + "Файл пересобирается из plugins/" + PluginBuild.NAME + "/config.yml при каждом запуске: правьте config.yml, а не этот файл.\n"
                        + "Список серверов и групп тоже берётся из config.yml (разделы servers и groups).\n"
                        + "Адрес и порт задаёт embedded.network в config.yml; по умолчанию это "
                        + LOOPBACK_HOST + ":0, то есть только этот же процесс.");
    }

    /**
     * Одиночный сервер: удобная форма для установки, где сеть состоит из одного сервера. Секрет применяется к
     * серверу, внутри которого работает плагин; сервер, объявленный дополнительно, в этой форме недопустим.
     */
    public static void writeGateway(Path file, PluginConfig config, String serverSecret, String controlSecret) {
        final Map<String, String> secrets = new LinkedHashMap<>();
        for (ServerTopology.Server server : config.embedded().topology().servers()) {
            secrets.put(server.id(), server.local() ? serverSecret : "");
        }
        writeGateway(file, config, secrets, controlSecret);
    }

    /**
     * Writes {@code embedded/bot.yml} for the Discord bot that runs inside the plugin.
     *
     * @param file          target file
     * @param config        plugin configuration the document is derived from
     * @param controlSecret secret the bot authenticates with on the control plane
     * @param port          port the embedded listener actually bound
     */
    public static void writeBot(Path file, PluginConfig config, String controlSecret, int port) {
        final EmbeddedSettings embedded = config.embedded();
        final EmbeddedSettings.DiscordSettings discord = embedded.discord();
        final Map<String, Object> document = new LinkedHashMap<>();
        document.put("language", discord.language());
        document.put("language_directory", LANGUAGE_DIRECTORY);
        document.put("discord", map(
                "token", discord.token(),
                "guilds", discord.guilds(),
                "register_guild_commands", true,
                "activity", discord.activity(),
                "status", discord.status(),
                "ready_timeout", "60s"));
        document.put("channels", map("allowed", discord.allowedChannels(), "denied", discord.deniedChannels()));
        if (!embedded.permissions().isEmpty()) {
            document.put("permissions", copy(embedded.permissions()));
        }
        final Map<String, Object> guilds = guilds(embedded);
        if (!guilds.isEmpty()) {
            document.put("guilds", guilds);
        }
        document.put("control", map(
                "client_id", embedded.controlClientId(),
                "secret", controlSecret,
                "request_timeout", "30s",
                "handshake_timeout", "15s",
                "ready_timeout", "20s",
                "reconnect_grace", "5s"));
        document.put("network", map(
                "host", LOOPBACK_HOST,
                "port", port,
                "max_frame_bytes", TransportSettings.DEFAULT_MAX_FRAME_BYTES,
                "connect_timeout", "10s",
                "handshake_timeout", "15s",
                "idle_timeout", "120s",
                "shutdown_grace", "10s"));
        document.put("tls", map("enabled", false, "allow_insecure_transport", true));
        document.put("logging", map("discord", map(
                "enabled", !discord.auditChannelId().isEmpty(),
                "channel_id", discord.auditChannelId(),
                "include_output", false,
                "include_roles", false)));
        final Map<String, Object> staff = staff(config.root());
        if (!staff.isEmpty()) {
            // Боту нужны только подписи привилегий и имена команд: сама LuckPerms-выдача остаётся в плагине.
            document.put("staff", staff);
        }
        merge(document, copy(embedded.botOverrides()));
        write(file, "bot", document,
                "Discord-бот встроенного режима " + PluginBuild.NAME + " — автор: Zigono.\n"
                        + "Файл пересобирается из plugins/" + PluginBuild.NAME + "/config.yml при каждом запуске: правьте config.yml, а не этот файл.");
    }

    /** Раздел {@code staff} переносится в bot.yml целиком: подписи привилегий и имена команд нужны боту. */
    private static Map<String, Object> staff(YamlConfig root) {
        return copy(root.sectionOrEmpty("staff").map(""));
    }

    /**
     * Repeats the command policy of the plugin in the configuration of the gateway: the gateway is the component
     * that answers {@code /console}, so it is the one that has to know which commands need a confirmation in
     * Discord and which are blocked.
     * <p>Only the keys the administrator really wrote are repeated, everything else keeps the default of the
     * gateway, which is the same default the plugin uses. The dangerous list is the exception: it is always
     * written, because the gateway is the component that asks for the confirmation.</p>
     */
    private static Map<String, Object> security(YamlConfig root) {
        final Map<String, Object> security = new LinkedHashMap<>();
        if (root.has("security.max_command_length")) {
            security.put("max_command_length",
                    root.integer("security.max_command_length", CommandNormalizer.DEFAULT_MAX_LENGTH));
        }
        if (root.has("security.blocked_sequences")) {
            security.put("blocked_sequences", new ArrayList<>(root.stringList("security.blocked_sequences", List.of())));
        }
        if (root.has("security.blocked_commands")) {
            security.put("blocked_commands", new ArrayList<>(root.stringList("security.blocked_commands", List.of())));
        }
        if (root.has("security.allowed_commands")) {
            security.put("allowed_commands", new ArrayList<>(root.stringList("security.allowed_commands", List.of())));
        }
        security.put("dangerous_commands", new ArrayList<>(root.stringList("security.dangerous_commands",
                PluginPolicy.DEFAULT_DANGEROUS_COMMANDS)));
        return security;
    }

    /**
     * @return the guild restrictions both components share: a per guild channel allow and deny list
     */
    private static Map<String, Object> guilds(EmbeddedSettings embedded) {
        final Map<String, Object> result = new LinkedHashMap<>();
        for (String guildId : embedded.discord().guilds()) {
            final Map<String, Object> channels = new LinkedHashMap<>();
            if (!embedded.discord().allowedChannels().isEmpty()) {
                channels.put("allowed", new ArrayList<>(embedded.discord().allowedChannels()));
            }
            if (!embedded.discord().deniedChannels().isEmpty()) {
                channels.put("denied", new ArrayList<>(embedded.discord().deniedChannels()));
            }
            result.put(guildId, channels.isEmpty() ? new LinkedHashMap<String, Object>() : map("channels", channels));
        }
        return result;
    }

    /** Writes the document unless the file already holds exactly the same content. */
    private static void write(Path file, String name, Map<String, Object> document, String header) {
        final StringBuilder text = new StringBuilder();
        for (String line : header.split("\n")) {
            text.append("# ").append(line).append(System.lineSeparator());
        }
        text.append(System.lineSeparator()).append(dump(document));
        final Path absolute = file.toAbsolutePath().normalize();
        try {
            if (Files.isRegularFile(absolute) && Files.readString(absolute, StandardCharsets.UTF_8).equals(text.toString())) {
                return;
            }
            final Path parent = absolute.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            Files.writeString(absolute, text.toString(), StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        } catch (IOException e) {
            throw new ConfigException("Не удалось записать сгенерированный файл " + name + " (" + absolute + ")", e);
        }
    }

    private static String dump(Map<String, Object> document) {
        final DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        options.setIndent(2);
        options.setIndicatorIndent(0);
        options.setWidth(120);
        options.setAllowUnicode(true);
        options.setSplitLines(false);
        return new Yaml(options).dump(document);
    }

    /**
     * Merges the administrator overrides over the generated document. Maps are merged key by key, every other
     * value replaces the generated one, so a single key can be overridden without repeating the whole section.
     */
    @SuppressWarnings("unchecked")
    private static void merge(Map<String, Object> target, Map<String, Object> overrides) {
        for (Map.Entry<String, Object> entry : overrides.entrySet()) {
            final Object current = target.get(entry.getKey());
            if (current instanceof Map<?, ?> currentMap && entry.getValue() instanceof Map<?, ?> overrideMap) {
                merge((Map<String, Object>) currentMap, (Map<String, Object>) overrideMap);
                continue;
            }
            target.put(entry.getKey(), entry.getValue());
        }
    }

    /** Deep copy of a raw configuration section into plain lists and maps. */
    private static Map<String, Object> copy(Map<String, Object> source) {
        final Map<String, Object> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(key, copyValue(value)));
        return result;
    }

    private static Object copyValue(Object value) {
        if (value instanceof Map<?, ?> map) {
            final Map<String, Object> result = new LinkedHashMap<>();
            map.forEach((key, item) -> result.put(String.valueOf(key), copyValue(item)));
            return result;
        }
        if (value instanceof List<?> list) {
            final List<Object> result = new ArrayList<>(list.size());
            for (Object element : list) {
                result.add(copyValue(element));
            }
            return result;
        }
        return value;
    }

    private static Map<String, Object> map(Object... keyValues) {
        if (keyValues.length % 2 != 0) {
            throw new IllegalArgumentException("map() требует пары ключ/значение");
        }
        final Map<String, Object> result = new LinkedHashMap<>();
        for (int index = 0; index < keyValues.length; index += 2) {
            result.put(String.valueOf(keyValues[index]), keyValues[index + 1]);
        }
        return result;
    }
}
