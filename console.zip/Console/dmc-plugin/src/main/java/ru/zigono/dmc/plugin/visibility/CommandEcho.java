package ru.zigono.dmc.plugin.visibility;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Formats the "who executed what" line. Supports the placeholders {@code {user}}, {@code {command}},
 * {@code {server}}, {@code {target}}, {@code {result}}, {@code {status}}, {@code {duration}}, legacy
 * ampersand colour codes and MiniMessage tags.
 *
 * @author Zigono
 */
public final class CommandEcho {

    private static final Pattern PLACEHOLDER = Pattern.compile("\\{([a-zA-Z0-9_]+)}");
    private static final Pattern MINI_MESSAGE = Pattern.compile("<[/!]?[a-zA-Z#][^<>]{0,64}>");
    private static final String LEGACY_CODES = "0123456789abcdefklmnorABCDEFKLMNOR";

    private CommandEcho() {
    }

    /**
     * Replaces every known placeholder. Unknown placeholders are left untouched, so a typo is visible instead of
     * silently producing an empty message.
     */
    public static String format(String pattern, Map<String, String> placeholders) {
        if (pattern == null || pattern.isEmpty()) {
            return "";
        }
        final Matcher matcher = PLACEHOLDER.matcher(pattern);
        final StringBuilder out = new StringBuilder();
        int last = 0;
        while (matcher.find()) {
            out.append(pattern, last, matcher.start());
            final String value = placeholders == null ? null : placeholders.get(matcher.group(1));
            out.append(value == null ? matcher.group(0) : value);
            last = matcher.end();
        }
        out.append(pattern.substring(last));
        return out.toString();
    }

    /** @return {@code true} when the pattern contains MiniMessage tags instead of (or besides) legacy codes */
    public static boolean looksLikeMiniMessage(String pattern) {
        return pattern != null && MINI_MESSAGE.matcher(pattern).find();
    }

    /** Converts {@code &a}-style colour codes into the section sign form understood by the server. */
    public static String legacyToSection(String text) {
        if (text == null || text.indexOf('&') < 0) {
            return text == null ? "" : text;
        }
        final StringBuilder out = new StringBuilder(text.length());
        for (int index = 0; index < text.length(); index++) {
            final char character = text.charAt(index);
            if (character == '&' && index + 1 < text.length()
                    && LEGACY_CODES.indexOf(text.charAt(index + 1)) >= 0) {
                out.append('\u00a7').append(text.charAt(index + 1));
                index++;
                continue;
            }
            out.append(character);
        }
        return out.toString();
    }

    /** Joins captured output into a single line suitable for an announcement. */
    public static String summarize(Iterable<String> lines, int maxLength) {
        final StringBuilder out = new StringBuilder();
        if (lines != null) {
            for (String line : lines) {
                if (line == null || line.isBlank()) {
                    continue;
                }
                if (out.length() > 0) {
                    out.append(" | ");
                }
                out.append(line.strip());
            }
        }
        final String text = out.toString();
        if (maxLength <= 0 || text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength) + "...";
    }
}