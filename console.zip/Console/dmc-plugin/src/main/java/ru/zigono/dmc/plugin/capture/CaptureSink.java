package ru.zigono.dmc.plugin.capture;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;

/**
 * Fan out point of the console: every log record of the server passes through here and is offered to the capture
 * sessions that are active at that moment. Records produced by the plugin itself are filtered out so its own
 * diagnostics never pollute a command result.
 *
 * @author Zigono
 */
public final class CaptureSink {

    private final List<CaptureSession> sessions = new CopyOnWriteArrayList<>();
    private final Predicate<String> excludedLogger;
    private final AtomicLong observed = new AtomicLong();
    private final AtomicLong captured = new AtomicLong();
    private volatile long lastObservedAt;
    private volatile String lastObservedMessage;

    public CaptureSink(Predicate<String> excludedLogger) {
        this.excludedLogger = excludedLogger == null ? ignored -> false : excludedLogger;
    }

    public void register(CaptureSession session) {
        if (session != null) {
            sessions.add(session);
        }
    }

    public void unregister(CaptureSession session) {
        sessions.remove(session);
    }

    public int activeCount() {
        return (int) sessions.stream().filter(CaptureSession::active).count();
    }

    public boolean anyActive() {
        for (CaptureSession session : sessions) {
            if (session.active()) {
                return true;
            }
        }
        return false;
    }

    /** Accepts one log record and feeds it to every active session. */
    public void accept(String loggerName, String level, String message) {
        if (message == null || message.isEmpty()) {
            return;
        }
        if (loggerName != null && excludedLogger.test(loggerName)) {
            return;
        }
        observed.incrementAndGet();
        lastObservedAt = System.currentTimeMillis();
        lastObservedMessage = message;
        for (CaptureSession session : sessions) {
            if (!session.active()) {
                continue;
            }
            if (session.accept(loggerName, level, message)) {
                captured.incrementAndGet();
            }
        }
    }

    public long observedRecords() {
        return observed.get();
    }

    public long capturedLines() {
        return captured.get();
    }

    public long lastObservedAt() {
        return lastObservedAt;
    }

    /** @return the last message that reached the sink, used by the startup diagnostics */
    public String lastObservedMessage() {
        return lastObservedMessage;
    }
}