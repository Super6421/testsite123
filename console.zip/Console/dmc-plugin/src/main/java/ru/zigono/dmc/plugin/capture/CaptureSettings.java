package ru.zigono.dmc.plugin.capture;

/**
 * Limits and timings of the console capture pipeline.
 *
 * @author Zigono
 */
public record CaptureSettings(boolean enabled, long quietPeriodMs, long maxWaitMs, int maxLines, int maxChars,
                              int maxLineLength) {

    public CaptureSettings {
        if (quietPeriodMs < 0) {
            quietPeriodMs = 0;
        }
        if (maxWaitMs <= 0) {
            maxWaitMs = 10_000L;
        }
        if (maxLines <= 0) {
            maxLines = 200;
        }
        if (maxChars <= 0) {
            maxChars = 60_000;
        }
        if (maxLineLength <= 0) {
            maxLineLength = 2048;
        }
    }

    /** @return the default limits used when the capture pipeline is disabled */
    public static CaptureSettings disabled() {
        return new CaptureSettings(false, 0L, 1L, 1, 1, 1);
    }
}