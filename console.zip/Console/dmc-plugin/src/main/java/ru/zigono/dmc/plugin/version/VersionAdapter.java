package ru.zigono.dmc.plugin.version;

/**
 * Isolates every version dependent call of the server API. The plugin talks to Paper 1.21 through the
 * {@code PaperVersionAdapter} and keeps a conservative Bukkit only fallback for other server builds.
 *
 * @author Zigono
 */
public interface VersionAdapter {

    /** Stable identifier of the adapter, used in logs and in {@code /discordconsole status}. */
    String id();

    /** Human readable description of the platform this adapter was selected for. */
    String describe();

    /** @return the server TPS, or {@code -1} when the platform cannot report it */
    double tps();

    /** @return the average tick time in milliseconds, or {@code -1} when the platform cannot report it */
    double mspt();

    /** @return the number of loaded worlds */
    int worldCount();

    /** @return the number of loaded chunks, or {@code -1} when unknown */
    int loadedChunks();

    /** @return the Minecraft version reported by the server, or {@code unknown} */
    String minecraftVersion();

    /** @return the server software name and version */
    String serverSoftware();
}