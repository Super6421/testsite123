package ru.zigono.dmc.plugin.visibility;

import java.util.List;

/**
 * Configuration of the in game visibility of Discord Console activity.
 *
 * @author Zigono
 */
public record VisibilitySettings(boolean enabled, String permission, String format, String mode, boolean defaultVisible,
                                 boolean showResults, String resultFormat, String serverFormat, String hiddenServerLabel,
                                 List<String> hiddenCommands) {

    /**
     * Commands whose output is never echoed in game or in the console, so a password typed through Discord cannot
     * end up in the chat. Used when {@code minecraft.visibility.hidden_commands} is absent.
     */
    public static final List<String> DEFAULT_HIDDEN_COMMANDS = List.of("login", "token", "password", "auth", "2fa");

    public VisibilitySettings {
        hiddenCommands = hiddenCommands == null ? List.of() : List.copyOf(hiddenCommands);
        if (hiddenServerLabel == null || hiddenServerLabel.isBlank()) {
            hiddenServerLabel = "***";
        }
    }

    /** Built in fallback used when neither the configuration nor the language file provides a format. */
    public static VisibilitySettings defaults() {
        return new VisibilitySettings(true, "discordconsole.monitor", null, "default", true, true, null, null, "***",
                DEFAULT_HIDDEN_COMMANDS);
    }
}