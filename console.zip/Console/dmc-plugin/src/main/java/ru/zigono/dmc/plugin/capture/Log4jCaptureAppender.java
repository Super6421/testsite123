package ru.zigono.dmc.plugin.capture;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.Property;

/**
 * Log4j2 appender installed on the root logger. Every log record of the server passes through it, which is how
 * the plugin sees the real console output of an executed command.
 *
 * @author Zigono
 */
public final class Log4jCaptureAppender extends AbstractAppender {

    private final CaptureSink sink;

    public Log4jCaptureAppender(String name, CaptureSink sink) {
        super(name, null, null, true, Property.EMPTY_ARRAY);
        this.sink = sink;
    }

    @Override
    public void append(LogEvent event) {
        if (event == null || !sink.anyActive()) {
            return;
        }
        final String message = event.getMessage() == null ? null : event.getMessage().getFormattedMessage();
        if (message == null || message.isEmpty()) {
            return;
        }
        sink.accept(event.getLoggerName(), event.getLevel() == null ? "INFO" : event.getLevel().name(), message);
    }
}