package ru.zigono.dmc.plugin.text;

import java.util.ArrayList;
import java.util.List;

/**
 * Normalizes text that comes from the Minecraft console or from Discord before it is stored, truncated or sent
 * over the wire. All length limits are applied on code points, so no surrogate pair is ever cut in half.
 *
 * @author Zigono
 */
public final class OutputSanitizer {

    private OutputSanitizer() {
    }

    /**
     * Removes carriage returns, ANSI escape sequences and ISO control characters from one console line.
     */
    public static String sanitize(String line) {
        if (line == null) {
            return "";
        }
        final StringBuilder out = new StringBuilder(line.length());
        for (int index = 0; index < line.length(); index++) {
            final char character = line.charAt(index);
            if (character == '\u001b') {
                index = skipAnsiSequence(line, index);
                continue;
            }
            if (character == '\r' || character == '\n') {
                continue;
            }
            if (Character.isISOControl(character) && character != '\t') {
                continue;
            }
            out.append(character);
        }
        return out.toString();
    }

    private static int skipAnsiSequence(String line, int start) {
        int index = start + 1;
        if (index < line.length() && line.charAt(index) == '[') {
            index++;
            while (index < line.length()) {
                final char character = line.charAt(index);
                if ((character >= '0' && character <= '9') || character == ';') {
                    index++;
                    continue;
                }
                return index;
            }
        }
        return start;
    }

    /** Splits a multi line text into sanitized, non blank lines. */
    public static List<String> lines(String text) {
        final List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return result;
        }
        for (String line : text.split("\n", -1)) {
            final String sanitized = sanitize(line);
            if (!sanitized.isBlank()) {
                result.add(sanitized);
            }
        }
        return result;
    }

    /**
     * Truncates the value to at most {@code maxCodePoints} code points, never splitting a surrogate pair.
     */
    public static String truncate(String value, int maxCodePoints) {
        if (value == null) {
            return "";
        }
        if (maxCodePoints <= 0) {
            return "";
        }
        final int codePoints = value.codePointCount(0, value.length());
        if (codePoints <= maxCodePoints) {
            return value;
        }
        final int end = value.offsetByCodePoints(0, maxCodePoints);
        if (end > 0 && end < value.length() && Character.isHighSurrogate(value.charAt(end - 1))
                && Character.isLowSurrogate(value.charAt(end))) {
            return value.substring(0, end - 1);
        }
        return value.substring(0, end);
    }

    /** @return the length of the value in code points */
    public static int length(String value) {
        return value == null ? 0 : value.codePointCount(0, value.length());
    }
}