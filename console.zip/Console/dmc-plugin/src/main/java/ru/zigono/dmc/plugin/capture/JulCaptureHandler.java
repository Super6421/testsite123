package ru.zigono.dmc.plugin.capture;

import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;

/**
 * Real Java Util Logging handler that feeds the console output of the server into the capture sink. Used as the
 * fallback backend when the Log4j2 appender cannot be installed.
 *
 * @author Zigono
 */
public final class JulCaptureHandler extends Handler {

    private static final Formatter FORMATTER = new SimpleFormatter();

    private final CaptureSink sink;
    private final JulRecordDeduplicator deduplicator;

    public JulCaptureHandler(CaptureSink sink, JulRecordDeduplicator deduplicator) {
        this.sink = sink;
        this.deduplicator = deduplicator;
    }

    @Override
    public void publish(LogRecord record) {
        if (record == null || !sink.anyActive()) {
            return;
        }
        if (!deduplicator.firstSight(record)) {
            return;
        }
        final StringBuilder message = new StringBuilder(FORMATTER.formatMessage(record));
        if (record.getThrown() != null) {
            message.append(' ').append(record.getThrown());
        }
        sink.accept(record.getLoggerName(), record.getLevel() == null ? "INFO" : record.getLevel().getName(),
                message.toString());
    }

    @Override
    public void flush() {
    }

    @Override
    public void close() {
    }
}