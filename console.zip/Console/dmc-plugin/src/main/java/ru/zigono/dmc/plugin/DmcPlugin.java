package ru.zigono.dmc.plugin;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.scheduler.BukkitTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.capture.ConsoleCapture;
import ru.zigono.dmc.plugin.command.DiscordConsoleCommand;
import ru.zigono.dmc.plugin.config.ConfigBootstrap;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.embedded.EmbeddedRuntime;
import ru.zigono.dmc.plugin.execution.CommandExecutionService;
import ru.zigono.dmc.plugin.execution.PluginPolicy;
import ru.zigono.dmc.plugin.gateway.GatewayConnection;
import ru.zigono.dmc.plugin.luckperms.LuckPermsIntegration;
import ru.zigono.dmc.plugin.metrics.PluginMetrics;
import ru.zigono.dmc.plugin.staff.LuckPermsStaffService;
import ru.zigono.dmc.plugin.version.VersionAdapter;
import ru.zigono.dmc.plugin.version.VersionAdapters;
import ru.zigono.dmc.plugin.visibility.VisibilityNodes;
import ru.zigono.dmc.plugin.visibility.VisibilityPolicy;
import ru.zigono.dmc.plugin.visibility.VisibilityService;
import ru.zigono.dmc.protocol.transport.TransportSettings;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;

/**
 * Paper entry point of Discord Minecraft Console.
 * <p>The plugin is the trusted executor of the system: it authenticates against the gateway with its own
 * identity and secret, executes commands on the server console and reports the real output. It never invents a
 * result: when the console produces nothing, the outcome says so.</p>
 * <p>By default ({@code embedded.enabled: true}) the gateway and the Discord bot run inside this very server
 * process, which is the deployment for a Minecraft server that only allows plugins - a game panel, for example.
 * With {@code embedded.enabled: false} the plugin is the client of an external gateway, as in the split
 * deployment.</p>
 *
 * @author Zigono
 */
public final class DmcPlugin extends JavaPlugin {

    private static final Logger LOGGER = LoggerFactory.getLogger(DmcPlugin.class);
    private static final String COMMAND_NAME = "discordconsole";

    private final AtomicReference<PluginConfig> config = new AtomicReference<>();
    private final AtomicReference<Messages> messages = new AtomicReference<>(Messages.of(java.util.Map.of()));
    private final AtomicReference<PluginPolicy> policy = new AtomicReference<>();
    private final AtomicReference<VisibilityPolicy> visibilityPolicy =
            new AtomicReference<>(new VisibilityPolicy(ru.zigono.dmc.plugin.visibility.VisibilitySettings.defaults(),
                    VisibilityNodes.none()));
    private final PluginMetrics metrics = new PluginMetrics();

    private ConfigBootstrap bootstrap;
    private EmbeddedRuntime embedded;
    private ConsoleCapture capture;
    private LuckPermsIntegration luckPerms;
    private LuckPermsStaffService staffService;
    private VisibilityService visibility;
    private GatewayConnection gateway;
    private CommandExecutionService executions;
    private VersionAdapter versionAdapter;
    private BukkitTask metricsTask;

    @Override
    public void onEnable() {
        bootstrap = new ConfigBootstrap(this, LOGGER);
        try {
            bootstrap.installDefaults();
            final PluginConfig loaded = bootstrap.load();
            final Messages loadedMessages = bootstrap.messages(loaded);
            applyConfiguration(loaded, loadedMessages);
            versionAdapter = VersionAdapters.select();
            if (loaded.embedded().enabled()) {
                embedded = new EmbeddedRuntime(loaded.embedded(), this::staffService);
                embedded.start(loaded);
            }
        } catch (ConfigException invalid) {
            LOGGER.error("Discord Minecraft Console отключён: {}", invalid.getMessage());
            LOGGER.error("Исправьте {} и перезапустите сервер.", bootstrap.configFile());
            if (embedded != null) {
                embedded.close();
                embedded = null;
            }
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        LOGGER.info("Платформа: {} ({})", versionAdapter.id(), versionAdapter.describe());
        capture = ConsoleCapture.install(Bukkit.getLogger(), getLogger().getName(), LOGGER);
        luckPerms = LuckPermsIntegration.create(LOGGER, config.get().luckPerms());
        staffService = new LuckPermsStaffService(LOGGER, config::get, () -> luckPerms);
        visibility = new VisibilityService(LOGGER, luckPerms, messages::get, visibilityPolicy::get);
        final Function<PluginConfig, TransportSettings> transport = embedded == null
                ? PluginConfig::transport : embedded::transportSettings;
        gateway = new GatewayConnection(this, config::get, messages::get, versionAdapter, metrics, transport);
        executions = new CommandExecutionService(this, config::get, messages::get, policy::get, visibility, gateway,
                capture.sink(), metrics);
        gateway.attach(executions, dispatch -> {
            gateway.markCommandReceived();
            executions.onDispatch(dispatch);
        });
        gateway.start();
        if (embedded != null) {
            embedded.startBot();
        }
        registerCommand();
        scheduleMetrics(config.get());
        LOGGER.info(messages.get().format("plugin.enabled", getDescription().getVersion()));
    }

    @Override
    public void onDisable() {
        if (metricsTask != null) {
            try {
                metricsTask.cancel();
            } catch (IllegalStateException alreadyCancelled) {
                LOGGER.debug("Задача метрик уже была отменена");
            }
            metricsTask = null;
        }
        if (executions != null) {
            executions.shutdown();
        }
        if (gateway != null) {
            gateway.close();
        }
        if (embedded != null) {
            embedded.close();
        }
        if (capture != null) {
            capture.close();
        }
        LOGGER.info(messages.get().raw("plugin.disabled"));
    }

    /**
     * Re-reads the configuration and applies it to every subsystem. Running commands keep working: they hold
     * their own immutable configuration snapshot.
     *
     * @return the revision of the new configuration
     */
    public synchronized String reloadConfiguration() {
        final PluginConfig previous = config.get();
        final PluginConfig updated = bootstrap.load();
        final Messages updatedMessages = bootstrap.messages(updated);
        applyConfiguration(updated, updatedMessages);
        if (executions != null) {
            executions.reconfigure(updated);
        }
        if (embedded != null) {
            embedded.reload(updated);
        }
        if (gateway != null) {
            gateway.reload(previous, updated);
        }
        scheduleMetrics(updated);
        LOGGER.info("Конфигурация перезагружена, ревизия {}", updated.revision());
        return updated.revision();
    }

    private void applyConfiguration(PluginConfig loaded, Messages loadedMessages) {
        config.set(loaded);
        messages.set(loadedMessages);
        policy.set(PluginPolicy.from(loaded.root()));
        visibilityPolicy.set(new VisibilityPolicy(loaded.visibility(), new VisibilityNodes(
                loaded.luckPerms().commandsPermission(), loaded.luckPerms().resultsPermission(),
                loaded.luckPerms().serversPermission())));
    }

    private void registerCommand() {
        final PluginCommand command = getCommand(COMMAND_NAME);
        if (command == null) {
            LOGGER.warn("Команда '{}' не объявлена в plugin.yml, /{} недоступна", COMMAND_NAME, COMMAND_NAME);
            return;
        }
        final DiscordConsoleCommand executor = new DiscordConsoleCommand(this);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    private void scheduleMetrics(PluginConfig current) {
        if (metricsTask != null) {
            try {
                metricsTask.cancel();
            } catch (IllegalStateException alreadyCancelled) {
                LOGGER.debug("Задача метрик уже была отменена");
            }
            metricsTask = null;
        }
        if (!current.metrics().enabled()) {
            return;
        }
        final long intervalTicks = Math.max(20L, current.metrics().logIntervalSeconds() * 20L);
        metricsTask = Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            // Счётчики нужны только для диагностики: в обычном режиме строка уходит в debug-журнал
            // (для продажи доступа к консоли важно, чтобы журнал сервера оставался чистым).
            LOGGER.debug(messages.get().format("plugin.metrics.line", metrics.commands(), metrics.succeeded(),
                    metrics.failed(), metrics.denied(), metrics.queueFull(),
                    gateway == null ? "неизвестно" : gateway.state().name().toLowerCase(java.util.Locale.ROOT),
                    metrics.averageDurationMillis()));
        }, intervalTicks, intervalTicks);
    }

    public PluginConfig config() {
        return config.get();
    }

    public Messages messages() {
        return messages.get();
    }

    public PluginPolicy policy() {
        return policy.get();
    }

    public VisibilityPolicy visibilityPolicy() {
        return visibilityPolicy.get();
    }

    public VisibilityService visibility() {
        return visibility;
    }

    public VersionAdapter versionAdapter() {
        return versionAdapter;
    }

    public ConsoleCapture capture() {
        return capture;
    }

    public LuckPermsIntegration luckPerms() {
        return luckPerms;
    }

    /**
     * @return сервис выдачи привилегий, который получает встроенный Discord-бот; {@code null} пока LuckPerms
     *         не подключён
     */
    public LuckPermsStaffService staffService() {
        return staffService;
    }

    public GatewayConnection gateway() {
        return gateway;
    }

    /** @return the embedded runtime, {@code null} when the plugin is the client of an external gateway */
    public EmbeddedRuntime embedded() {
        return embedded;
    }

    public CommandExecutionService executions() {
        return executions;
    }

    public PluginMetrics metrics() {
        return metrics;
    }
}