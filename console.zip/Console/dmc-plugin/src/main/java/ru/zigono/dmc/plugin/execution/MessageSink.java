package ru.zigono.dmc.plugin.execution;

import ru.zigono.dmc.protocol.Message;

/**
 * Minimal outbound port used by the execution service, implemented by the gateway connection.
 *
 * @author Zigono
 */
@FunctionalInterface
public interface MessageSink {

    /**
     * Sends a message to the gateway.
     *
     * @return {@code true} when the message was handed to the transport
     */
    boolean send(Message message);
}