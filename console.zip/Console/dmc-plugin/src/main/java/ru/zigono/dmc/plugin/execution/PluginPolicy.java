package ru.zigono.dmc.plugin.execution;

import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.ArrayList;
import java.util.List;

/**
 * Second, independent policy check on the Minecraft side. The gateway already authorized the command, but the
 * plugin re-normalizes and re-evaluates it, so a compromised or outdated gateway cannot push a blocked command
 * through. Permission checks stay on the gateway: this class only enforces the structural rules.
 *
 * @author Zigono
 */
public final class PluginPolicy {

    /**
     * Vanilla commands that change the state of the server and therefore require an explicit confirmation in
     * Discord. They are the default of {@code security.dangerous_commands}: the embedded mode generates the same
     * list into the configuration of the gateway, which is where the confirmation flow lives.
     */
    public static final List<String> DEFAULT_DANGEROUS_COMMANDS = List.of("stop", "restart", "reload", "op", "deop",
            "ban", "ban-ip", "kick", "whitelist off", "save-off");

    /**
     * Verdict of the plugin policy.
     *
     * @param denied               the command must not be executed
     * @param requiresConfirmation the command is dangerous according to this configuration
     * @param reason               human readable reason, empty when the command is allowed
     */
    public record Verdict(boolean denied, boolean requiresConfirmation, String reason, String matchedRule) {

        public static Verdict allow(String matchedRule, boolean requiresConfirmation) {
            return new Verdict(false, requiresConfirmation, "", matchedRule);
        }

        public static Verdict deny(String reason, String matchedRule) {
            return new Verdict(true, false, reason, matchedRule);
        }
    }

    private final CommandNormalizer normalizer;
    private final List<CommandPolicyEngine.TokenPattern> blocked;
    private final List<CommandPolicyEngine.TokenPattern> allowed;
    private final List<CommandPolicyEngine.TokenPattern> dangerous;
    private final List<CommandPolicyEngine.PolicyRule> rules;

    private PluginPolicy(CommandNormalizer normalizer, List<CommandPolicyEngine.TokenPattern> blocked,
                         List<CommandPolicyEngine.TokenPattern> allowed,
                         List<CommandPolicyEngine.TokenPattern> dangerous,
                         List<CommandPolicyEngine.PolicyRule> rules) {
        this.normalizer = normalizer;
        this.blocked = blocked;
        this.allowed = allowed;
        this.dangerous = dangerous;
        this.rules = rules;
    }

    /** Builds the policy from the same document the gateway uses, so both sides stay in sync. */
    public static PluginPolicy from(YamlConfig root) {
        final YamlConfig security = root.section("security");
        final CommandNormalizer normalizer = new CommandNormalizer(
                root.integer("security.max_command_length", CommandNormalizer.DEFAULT_MAX_LENGTH),
                root.stringList("security.blocked_sequences", CommandNormalizer.DEFAULT_BLOCKED_SEQUENCES));
        return new PluginPolicy(normalizer,
                CommandPolicyEngine.TokenPattern.listOf(security.stringList("blocked_commands", List.of())),
                CommandPolicyEngine.TokenPattern.listOf(security.stringList("allowed_commands", List.of())),
                CommandPolicyEngine.TokenPattern.listOf(security.stringList("dangerous_commands", DEFAULT_DANGEROUS_COMMANDS)),
                CommandPolicyEngine.from(root).rules());
    }

    public CommandNormalizer normalizer() {
        return normalizer;
    }

    public NormalizedCommand normalize(String raw) {
        return normalizer.normalize(raw);
    }

    public boolean isBlocked(NormalizedCommand command) {
        return matches(blocked, command);
    }

    public boolean isDangerous(NormalizedCommand command) {
        return matches(dangerous, command);
    }

    /**
     * Evaluates the structural rules: blocked list, whitelist, deny policies and the dangerous command marker.
     */
    public Verdict check(NormalizedCommand command) {
        if (command == null) {
            return Verdict.deny("empty command", null);
        }
        for (CommandPolicyEngine.TokenPattern pattern : blocked) {
            if (pattern.matches(command.tokens())) {
                return Verdict.deny("заблокировано через security.blocked_commands: " + pattern.raw(), pattern.raw());
            }
        }
        if (!allowed.isEmpty() && allowed.stream().noneMatch(pattern -> pattern.matches(command.tokens()))) {
            return Verdict.deny("не входит в security.allowed_commands", null);
        }
        final CommandPolicyEngine.PolicyRule matched = mostSpecific(command);
        if (matched != null && matched.deny()) {
            return Verdict.deny("запрещено через command_policies: " + matched.pattern().raw(), matched.pattern().raw());
        }
        final boolean confirmation = isDangerous(command) || (matched != null && matched.requireConfirmation());
        return Verdict.allow(matched == null ? null : matched.pattern().raw(), confirmation);
    }

    /** @return the deny/confirmation rules of the configuration, for diagnostics */
    public List<String> rules() {
        final List<String> result = new ArrayList<>();
        for (CommandPolicyEngine.PolicyRule rule : rules) {
            result.add((rule.deny() ? "deny " : "rule ") + rule.pattern().raw()
                    + (rule.requireConfirmation() ? " (confirmation)" : ""));
        }
        for (CommandPolicyEngine.TokenPattern pattern : blocked) {
            result.add("blocked " + pattern.raw());
        }
        for (CommandPolicyEngine.TokenPattern pattern : allowed) {
            result.add("allowed " + pattern.raw());
        }
        for (CommandPolicyEngine.TokenPattern pattern : dangerous) {
            result.add("dangerous " + pattern.raw());
        }
        return List.copyOf(result);
    }

    private CommandPolicyEngine.PolicyRule mostSpecific(NormalizedCommand command) {
        CommandPolicyEngine.PolicyRule matched = null;
        for (CommandPolicyEngine.PolicyRule rule : rules) {
            if (!rule.pattern().matches(command.tokens())) {
                continue;
            }
            if (matched == null || rule.pattern().specificity() > matched.pattern().specificity()) {
                matched = rule;
            }
        }
        return matched;
    }

    private static boolean matches(List<CommandPolicyEngine.TokenPattern> patterns, NormalizedCommand command) {
        if (command == null) {
            return true;
        }
        return patterns.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
    }
}