package ru.zigono.dmc.plugin.execution;

import ru.zigono.dmc.plugin.text.OutputSanitizer;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns captured console output into the immutable outcome that is sent back to the gateway. Applies the final
 * limits on the number of lines and characters and never splits a Unicode surrogate pair.
 *
 * @author Zigono
 */
public final class OutcomeBuilder {

    /** Final limits of one outcome. */
    public record Limits(int maxLines, int maxChars, int maxLineLength) {

        public static Limits defaults() {
            return new Limits(200, 60_000, 2048);
        }
    }

    /** Result of trimming a captured output. */
    public record Trimmed(List<String> lines, int droppedLines) {

        public Trimmed {
            lines = lines == null ? List.of() : List.copyOf(lines);
        }
    }

    private OutcomeBuilder() {
    }

    /**
     * Caps the output. The number of dropped lines is reported so the caller can add a localized marker.
     */
    public static Trimmed trim(List<String> lines, Limits limits) {
        final Limits effective = limits == null ? Limits.defaults() : limits;
        final List<String> result = new ArrayList<>();
        int characters = 0;
        int dropped = 0;
        for (String raw : lines) {
            if (result.size() >= effective.maxLines()) {
                dropped++;
                continue;
            }
            final String line = OutputSanitizer.truncate(OutputSanitizer.sanitize(raw), effective.maxLineLength());
            final int cost = line.length() + 1;
            if (characters + cost > effective.maxChars()) {
                dropped++;
                continue;
            }
            result.add(line);
            characters += cost;
        }
        return new Trimmed(result, dropped);
    }

    /** Builds the outcome sent to the gateway. */
    public static ServerOutcome outcome(String serverId, String requestId, ExecutionStatus status, List<String> lines,
                                        long durationMillis, String errorCode, String errorDetail) {
        return new ServerOutcome(serverId, status, lines, durationMillis, errorCode, errorDetail, requestId,
                System.currentTimeMillis());
    }
}