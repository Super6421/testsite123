package ru.zigono.dmc.plugin.version;

import org.bukkit.Bukkit;
import org.bukkit.World;

/**
 * Conservative fallback for server builds that do not provide the Paper tick API. Only calls that exist in the
 * plain Bukkit API are used; values that cannot be determined are reported as unknown instead of being faked.
 *
 * @author Zigono
 */
public final class LegacyVersionAdapter implements VersionAdapter {

    @Override
    public String id() {
        return "legacy-bukkit";
    }

    @Override
    public String describe() {
        return "Bukkit compatible fallback (no tick API)";
    }

    @Override
    public double tps() {
        return -1.0d;
    }

    @Override
    public double mspt() {
        return -1.0d;
    }

    @Override
    public int worldCount() {
        return Bukkit.getWorlds().size();
    }

    @Override
    public int loadedChunks() {
        int chunks = 0;
        for (World world : Bukkit.getWorlds()) {
            chunks += world.getLoadedChunks().length;
        }
        return chunks;
    }

    @Override
    public String minecraftVersion() {
        return Bukkit.getBukkitVersion();
    }

    @Override
    public String serverSoftware() {
        return Bukkit.getServer().getName() + " " + Bukkit.getVersion();
    }
}