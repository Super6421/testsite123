package ru.zigono.dmc.plugin.gateway;

/**
 * Immutable snapshot of the gateway connection, rendered by {@code /discordconsole status}.
 *
 * @author Zigono
 */
public record GatewayStatus(GatewayState state, String serverId, String host, int port, boolean tls, String gatewayId,
                            String gatewayVersion, String sessionId, String configRevision, int heartbeatIntervalSeconds,
                            long connectedAt, long lastHeartbeatAckAt, long latencyMillis, long heartbeatsSent,
                            long protocolViolations, long authenticationFailures, String lastError) {

    public boolean connected() {
        return state == GatewayState.ONLINE || state == GatewayState.DEGRADED;
    }
}