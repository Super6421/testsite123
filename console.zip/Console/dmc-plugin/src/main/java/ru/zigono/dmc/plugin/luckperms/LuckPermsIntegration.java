package ru.zigono.dmc.plugin.luckperms;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.slf4j.Logger;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.plugin.config.PluginConfig;

import java.util.UUID;

/**
 * Optional LuckPerms integration. LuckPerms is not a replacement for the Discord permissions: it only controls
 * who sees Discord Console activity inside Minecraft. When LuckPerms is absent the plugin degrades to the
 * standard Bukkit permission check and keeps working.
 *
 * @author Zigono
 */
public final class LuckPermsIntegration {

    private static final String PLUGIN_NAME = "LuckPerms";

    private final Logger logger;
    private final PluginConfig.LuckPermsSettings settings;
    private final LuckPermsBridge bridge;
    private final String description;
    private final String unavailableReason;

    private LuckPermsIntegration(Logger logger, PluginConfig.LuckPermsSettings settings, LuckPermsBridge bridge,
                                 String description, String unavailableReason) {
        this.logger = logger;
        this.settings = settings;
        this.bridge = bridge;
        this.description = description;
        this.unavailableReason = unavailableReason;
    }

    /**
     * Итог одного обращения к LuckPerms: получилось ли и изменилось ли что-нибудь на самом деле.
     *
     * @param detail понятная человеку причина отказа
     */
    public record Change(boolean success, boolean changed, String detail) {

        static Change ok(boolean changed) {
            return new Change(true, changed, "");
        }

        static Change failed(String detail) {
            return new Change(false, false, detail == null ? "LuckPerms отказал без объяснения" : detail);
        }

        static Change failed(RuntimeException failure) {
            return failed(failure.getMessage() == null ? failure.toString() : failure.getMessage());
        }
    }

    /** Creates the integration, degrading gracefully when LuckPerms is missing or broken. */
    public static LuckPermsIntegration create(Logger logger, PluginConfig.LuckPermsSettings settings) {
        if (settings == null || !settings.enabled()) {
            return new LuckPermsIntegration(logger, settings, null, "выключена в конфигурации",
                    "интеграция с LuckPerms выключена: включите luckperms.enabled в config.yml");
        }
        if (!Bukkit.getPluginManager().isPluginEnabled(PLUGIN_NAME)) {
            return new LuckPermsIntegration(logger, settings, null, "не установлен, использую права Bukkit",
                    "плагин LuckPerms не установлен на этом сервере");
        }
        try {
            final LuckPermsBridge bridge = new LuckPermsBridge();
            logger.info("Интеграция с LuckPerms активна (сервер '{}')", bridge.serverName());
            return new LuckPermsIntegration(logger, settings, bridge, "active (server " + bridge.serverName() + ")",
                    null);
        } catch (Throwable unavailable) {
            logger.warn("LuckPerms установлен, но его API недоступен ({}), использую права Bukkit",
                    unavailable.toString());
            return new LuckPermsIntegration(logger, settings, null, "unavailable, using Bukkit permissions",
                    "LuckPerms установлен, но его API недоступен: " + unavailable);
        }
    }

    /** @return {@code true}, когда привилегии можно выдавать: LuckPerms есть и его API отвечает */
    public boolean canManage() {
        return bridge != null;
    }

    /** @return причина, по которой выдача привилегий невозможна */
    public String unavailableReason() {
        return unavailableReason == null ? "LuckPerms недоступен" : unavailableReason;
    }

    /** Выдаёт игроку группу привилегии. */
    public Change grant(String nickname, String group, StaffConfig.Mode mode, String defaultGroup) {
        return change(nickname, group, true, mode, defaultGroup);
    }

    /** Снимает с игрока группу привилегии. */
    public Change revoke(String nickname, String group, StaffConfig.Mode mode, String defaultGroup) {
        return change(nickname, group, false, mode, defaultGroup);
    }

    private Change change(String nickname, String group, boolean grant, StaffConfig.Mode mode, String defaultGroup) {
        if (bridge == null) {
            return Change.failed(unavailableReason());
        }
        if (nickname == null || nickname.isBlank()) {
            return Change.failed("не указан ник игрока");
        }
        if (group == null || group.isBlank()) {
            return Change.failed("у привилегии не задана группа LuckPerms");
        }
        try {
            if (!bridge.groupExists(group)) {
                return Change.failed("группа '" + group + "' не найдена в LuckPerms: проверьте staff.ranks в config.yml");
            }
            final UUID uniqueId = bridge.lookupUniqueId(nickname);
            if (uniqueId == null) {
                return Change.failed("игрок '" + nickname + "' неизвестен LuckPerms: он ни разу не заходил на сервер");
            }
            return Change.ok(bridge.modifyGroup(uniqueId, group, grant, mode == StaffConfig.Mode.SET, defaultGroup));
        } catch (RuntimeException failure) {
            logger.warn("Не удалось {} привилегию '{}' игроку {}: {}", grant ? "выдать" : "снять", group, nickname,
                    failure.getMessage());
            return Change.failed(failure);
        }
    }

    public boolean available() {
        return bridge != null;
    }

    public String description() {
        return description;
    }

    public PluginConfig.LuckPermsSettings settings() {
        return settings;
    }

    /** Checks a permission node of a player, preferring LuckPerms over the Bukkit permission check. */
    public boolean has(Player player, String node) {
        if (player == null || node == null || node.isBlank()) {
            return false;
        }
        if (bridge != null) {
            try {
                return bridge.has(player, node);
            } catch (RuntimeException e) {
                logger.debug("Запрос к LuckPerms для '{}' не удался, использую права Bukkit", node, e);
            }
        }
        return player.hasPermission(node);
    }

    /** @return the primary LuckPerms group of the player, or {@code null} when unknown */
    public String primaryGroup(Player player) {
        if (bridge == null || player == null) {
            return null;
        }
        try {
            return bridge.primaryGroup(player);
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** @return {@code true} when the player passes the administrative bypass node */
    public boolean bypasses(Player player) {
        if (player == null) {
            return false;
        }
        if (player.isOp()) {
            return true;
        }
        return settings != null && settings.adminPermission() != null
                && has(player, settings.adminPermission());
    }

    /** @return the value of the optional {@code discordconsole.monitor.servers} node of a player */
    public boolean hasServersPermission(Player player) {
        return settings != null && settings.serversPermission() != null && has(player, settings.serversPermission());
    }
}