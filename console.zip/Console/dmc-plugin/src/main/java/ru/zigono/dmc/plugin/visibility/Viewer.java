package ru.zigono.dmc.plugin.visibility;

/**
 * One subject that may or may not see Discord Console activity: the server console, a player, or a player with
 * the administrative bypass node.
 *
 * @author Zigono
 */
public record Viewer(String name, boolean console, boolean bypass, PermissionView permissions) {

    public Viewer {
        if (permissions == null) {
            permissions = PermissionView.none();
        }
    }

    public boolean has(String node) {
        return node != null && !node.isBlank() && permissions.has(node);
    }

    /** The server console always sees everything that is not explicitly hidden. */
    public static Viewer serverConsole() {
        return new Viewer("console", true, true, PermissionView.all());
    }

    public static Viewer of(String name, boolean bypass, PermissionView permissions) {
        return new Viewer(name, false, bypass, permissions);
    }

    public static Viewer none(String name) {
        return new Viewer(name, false, false, PermissionView.none());
    }
}