package ru.zigono.dmc.plugin.config;

import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.staff.StaffConfig;
import ru.zigono.dmc.plugin.capture.CaptureSettings;
import ru.zigono.dmc.plugin.visibility.VisibilitySettings;
import ru.zigono.dmc.protocol.Secrets;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Typed, immutable view over the plugin configuration. A new instance is created on every hot reload and is
 * published through a volatile reference, so running commands always see a consistent snapshot.
 *
 * @author Zigono
 */
public final class PluginConfig {

    /** Supported values of {@code minecraft.visibility.mode}. */
    public static final Set<String> VISIBILITY_MODES = Set.of("default", "permission", "nobody");

    /** Languages shipped inside the jar. */
    public static final Set<String> BUNDLED_LANGUAGES = Set.of("en", "ru");

    private final YamlConfig root;
    private final Path baseDirectory;
    private final String revision;
    private final String language;
    private final EmbeddedSettings embedded;
    private final ServerSettings server;
    private final byte[] secret;
    private final CommandNormalizer normalizer;
    private final CommandPolicyEngine policyEngine;
    private final HeartbeatSettings heartbeat;
    private final ExecutionSettings execution;
    private final CaptureSettings capture;
    private final VisibilitySettings visibility;
    private final LuckPermsSettings luckPerms;
    private final StaffConfig staff;
    private final MetricsSettings metrics;
    private final LoggingSettings logging;
    private final TransportSettings transport;

    private PluginConfig(YamlConfig root, Path baseDirectory) {
        this.root = root;
        this.baseDirectory = baseDirectory;
        this.revision = root.fingerprint();
        this.language = resolveLanguage(root.string("language", "en"), baseDirectory);
        this.embedded = EmbeddedSettings.from(root, baseDirectory, this.language);

        final String serverId = requireText(root, "server.id");
        final ServerSettings parsedServer = new ServerSettings(serverId,
                root.string("server.name", serverId),
                root.string("server.description", ""));
        this.server = parsedServer;
        this.secret = readSecret(root, serverId, embedded.enabled() ? embedded.serverSecretFile() : null);

        final List<String> blockedSequences = root.stringList("security.blocked_sequences",
                CommandNormalizer.DEFAULT_BLOCKED_SEQUENCES);
        this.normalizer = new CommandNormalizer(
                root.integer("security.max_command_length", CommandNormalizer.DEFAULT_MAX_LENGTH), blockedSequences);
        this.policyEngine = CommandPolicyEngine.from(root);

        this.heartbeat = new HeartbeatSettings(
                root.duration("heartbeat.interval_seconds", java.time.Duration.ofSeconds(10)),
                root.duration("heartbeat.timeout_seconds", java.time.Duration.ofSeconds(30)),
                root.doubleValue("heartbeat.degraded_latency_ms", 2500.0d));
        this.staff = StaffConfig.from(root);
        this.execution = new ExecutionSettings(
                root.integer("execution.max_concurrent", 1),
                root.integer("execution.queue_size", 64),
                root.longValue("execution.queue_timeout_ms", 5000L),
                root.longValue("execution.default_timeout_ms", 30_000L),
                root.integer("execution.poll_interval_ticks", 1));
        this.capture = new CaptureSettings(
                root.bool("capture.enabled", true),
                root.longValue("capture.quiet_period_ms", 250L),
                root.longValue("capture.max_wait_ms", 10_000L),
                root.integer("capture.max_lines", 200),
                root.integer("capture.max_chars", 60_000),
                root.integer("capture.max_line_length", 2048));
        if (execution.maxConcurrent() < 1) {
            throw new ConfigException("execution.max_concurrent должен быть не меньше 1");
        }
        if (execution.queueSize() < 1) {
            throw new ConfigException("execution.queue_size должен быть не меньше 1");
        }
        if (capture.quietPeriodMs() < 0 || capture.maxWaitMs() <= 0) {
            throw new ConfigException("capture.quiet_period_ms не может быть отрицательным, а capture.max_wait_ms должен быть больше нуля");
        }

        final YamlConfig announcement = root.section("minecraft.discord_console_visibility");
        final YamlConfig visibilitySection = root.section("minecraft.visibility");
        final String mode = visibilitySection.string("mode", "default").trim().toLowerCase(Locale.ROOT);
        if (!VISIBILITY_MODES.contains(mode)) {
            throw new ConfigException("minecraft.visibility.mode должен быть одним из " + VISIBILITY_MODES + ", а указано '" + mode + "'");
        }
        this.visibility = new VisibilitySettings(
                announcement.bool("enabled", true),
                announcement.string("permission", "discordconsole.monitor"),
                announcement.string("format", ""),
                mode,
                visibilitySection.bool("default", true),
                visibilitySection.bool("show_results", true),
                visibilitySection.string("result_format", ""),
                visibilitySection.string("server_format", ""),
                visibilitySection.string("hidden_server_label", "***"),
                visibilitySection.stringList("hidden_commands", VisibilitySettings.DEFAULT_HIDDEN_COMMANDS));
        this.luckPerms = new LuckPermsSettings(
                root.bool("luckperms.enabled", true),
                node(root.string("luckperms.monitor_permission", "discordconsole.monitor")),
                node(root.string("luckperms.commands_permission", "")),
                node(root.string("luckperms.results_permission", "")),
                node(root.string("luckperms.servers_permission", "")),
                node(root.string("luckperms.admin_permission", "discordconsole.monitor.admin")));
        this.metrics = new MetricsSettings(root.bool("metrics.enabled", true),
                root.longValue("metrics.log_interval_seconds", 300L));
        this.logging = new LoggingSettings(root.bool("logging.debug", false), root.bool("logging.command_echo", true));
        this.transport = TransportSettings.from(root.section("network"), root.section("tls"), baseDirectory,
                parsedServer.id(), "plugin");
        if (!transport.tlsEnabled() && !embedded.enabled()) {
            throw new ConfigException("tls.enabled выключен: плагин не работает без шифрования канала. Включите tls или встроенный режим (embedded.enabled: true)");
        }
    }

    /** Loads the configuration from a YAML file. */
    public static PluginConfig load(Path file, Path baseDirectory) {
        final Path absolute = file.toAbsolutePath().normalize();
        final Path base = baseDirectory == null ? absolute.getParent() : baseDirectory;
        return new PluginConfig(YamlConfig.load(absolute, true), base);
    }

    /** Builds the configuration from an already parsed document, used by the reload path and by tests. */
    public static PluginConfig of(YamlConfig root, Path baseDirectory) {
        return new PluginConfig(root, baseDirectory);
    }

    private static String requireText(YamlConfig root, String path) {
        final String value = root.string(path, null);
        if (value == null || value.isBlank()) {
            throw new ConfigException("В конфигурации обязательно должно быть заполнено значение " + path);
        }
        return value.trim();
    }

    /**
     * Reads the shared secret of this server. A value written in the configuration wins; when it is absent the
     * embedded mode keeps a generated secret in {@code secretFile}, which is what lets a fresh installation run
     * without inventing a secret by hand.
     */
    private static byte[] readSecret(YamlConfig root, String serverId, Path secretFile) {
        final String raw = root.string("security.server_secret", null);
        if (raw == null || raw.isBlank()) {
            if (secretFile == null) {
                throw new ConfigException("Нужен security.server_secret: без него плагин не может пройти проверку подлинности");
            }
            return Secrets.decode(SecretFile.readOrCreate(secretFile), "server '" + serverId + "'");
        }
        if (raw.contains("${")) {
            throw new ConfigException("В security.server_secret осталась неразрешённая подстановка '"
                    + raw + "': задайте переменную окружения перед запуском сервера");
        }
        return Secrets.decode(raw, "server '" + serverId + "'");
    }

    private static String node(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return value.trim();
    }

    private static String resolveLanguage(String language, Path baseDirectory) {
        final String normalized = (language == null || language.isBlank() ? "en" : language)
                .trim().toLowerCase(Locale.ROOT);
        if (BUNDLED_LANGUAGES.contains(normalized)) {
            return normalized;
        }
        if (baseDirectory != null && Files.isRegularFile(baseDirectory.resolve("lang").resolve(normalized + ".yml"))) {
            return normalized;
        }
        throw new ConfigException("Для языка '" + normalized + "' нет файла lang/" + normalized + ".yml, доступны: "
                + BUNDLED_LANGUAGES);
    }

    public YamlConfig root() {
        return root;
    }

    public Path baseDirectory() {
        return baseDirectory;
    }

    public String revision() {
        return revision;
    }

    public String language() {
        return language;
    }

    /**
     * @return the settings of the embedded mode, in which the gateway and the Discord bot run inside this plugin
     */
    public EmbeddedSettings embedded() {
        return embedded;
    }

    public ServerSettings server() {
        return server;
    }

    public byte[] secret() {
        return secret.clone();
    }

    public CommandNormalizer normalizer() {
        return normalizer;
    }

    public CommandPolicyEngine policyEngine() {
        return policyEngine;
    }

    public HeartbeatSettings heartbeat() {
        return heartbeat;
    }

    public ExecutionSettings execution() {
        return execution;
    }

    public CaptureSettings capture() {
        return capture;
    }

    public VisibilitySettings visibility() {
        return visibility;
    }

    public LuckPermsSettings luckPerms() {
        return luckPerms;
    }

    /** Привилегии и иерархия выдачи: раздел {@code staff} конфигурации. */
    public StaffConfig staff() {
        return staff;
    }

    public MetricsSettings metrics() {
        return metrics;
    }

    public LoggingSettings logging() {
        return logging;
    }

    public TransportSettings transport() {
        return transport;
    }

    /** Identity of this Minecraft server. */
    public record ServerSettings(String id, String name, String description) {
    }

    /** Heartbeat pacing and the latency above which the plugin reports itself as degraded. */
    public record HeartbeatSettings(java.time.Duration interval, java.time.Duration timeout, double degradedLatencyMs) {
    }

    /** Plugin side execution queue. */
    public record ExecutionSettings(int maxConcurrent, int queueSize, long queueTimeoutMillis, long defaultTimeoutMillis,
                                    int pollIntervalTicks) {
    }

    /** LuckPerms nodes used for the in game visibility of Discord Console activity. */
    public record LuckPermsSettings(boolean enabled, String monitorPermission, String commandsPermission,
                                    String resultsPermission, String serversPermission, String adminPermission) {
    }

    /** Metrics switches. */
    public record MetricsSettings(boolean enabled, long logIntervalSeconds) {
    }

    /** Logging switches. */
    public record LoggingSettings(boolean debug, boolean commandEcho) {
    }
}
