package ru.zigono.dmc.plugin.capture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.spi.LoggerContext;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Handler;

/**
 * Installs the console capture pipeline.
 * <p>Preferred backend is a Log4j2 appender on the root logger, because Paper routes both the native Minecraft
 * logging and the Java Util Logging bridge through Log4j2. When that backend is unavailable the plugin attaches
 * a real Java Util Logging handler instead, so capture keeps working on other server builds.</p>
 *
 * @author Zigono
 */
public final class ConsoleCapture implements AutoCloseable {

    /** Name of the Log4j2 appender installed by the plugin. */
    public static final String APPENDER_NAME = "dmc-console-capture";

    private final CaptureSink sink;
    private final Logger logger;
    private volatile String backend;
    private final List<Runnable> uninstallers = new ArrayList<>();

    private ConsoleCapture(CaptureSink sink, Logger logger, String backend) {
        this.sink = sink;
        this.logger = logger;
        this.backend = backend;
    }

    /**
     * Installs the capture pipeline.
     *
     * @param bukkitLogger     logger returned by {@code Bukkit.getLogger()}
     * @param pluginLoggerName name of the plugin logger, excluded from capture
     * @param logger           plugin logger used for diagnostics
     */
    public static ConsoleCapture install(java.util.logging.Logger bukkitLogger, String pluginLoggerName, Logger logger) {
        final Predicate<String> excluded = name -> name == null
                || name.startsWith("ru.zigono.dmc.")
                || (pluginLoggerName != null && name.startsWith(pluginLoggerName));
        final ConsoleCapture capture = new ConsoleCapture(new CaptureSink(excluded), logger, "none");
        if (capture.installLog4j()) {
            capture.backend = "log4j2";
            logger.info("Сбор вывода консоли использует appender Log4j2 '{}'", APPENDER_NAME);
            return capture;
        }
        logger.warn("Сбор вывода Log4j2 недоступен, перехожу на обработчик Java Util Logging");
        if (capture.installJul(bukkitLogger)) {
            capture.backend = "jul";
            logger.info("Сбор вывода консоли использует обработчик Java Util Logging");
            return capture;
        }
        logger.error("Нет доступного механизма сбора вывода консоли, результаты команд будут пустыми");
        return capture;
    }

    private boolean installLog4j() {
        try {
            final LoggerContext context = LogManager.getContext(false);
            if (!(context instanceof org.apache.logging.log4j.core.LoggerContext core)) {
                return false;
            }
            final org.apache.logging.log4j.core.Logger root = core.getRootLogger();
            final Log4jCaptureAppender appender = new Log4jCaptureAppender(APPENDER_NAME, sink);
            appender.start();
            root.addAppender(appender);
            core.updateLoggers();
            if (!root.getAppenders().containsKey(APPENDER_NAME)) {
                root.removeAppender(appender);
                appender.stop();
                return false;
            }
            uninstallers.add(() -> {
                try {
                    root.removeAppender(appender);
                    appender.stop();
                    core.updateLoggers();
                } catch (RuntimeException e) {
                    logger.debug("Не удалось отсоединить appender сбора вывода", e);
                }
            });
            return true;
        } catch (Throwable unavailable) {
            logger.debug("Не удалось установить сбор вывода Log4j2: {}", unavailable.toString());
            return false;
        }
    }

    private boolean installJul(java.util.logging.Logger bukkitLogger) {
        final JulRecordDeduplicator deduplicator = new JulRecordDeduplicator(256);
        final List<java.util.logging.Logger> targets = new ArrayList<>();
        targets.add(java.util.logging.Logger.getLogger(""));
        if (bukkitLogger != null) {
            targets.add(bukkitLogger);
        }
        boolean installed = false;
        for (java.util.logging.Logger target : targets) {
            try {
                final Handler handler = new JulCaptureHandler(sink, deduplicator);
                handler.setLevel(java.util.logging.Level.ALL);
                target.addHandler(handler);
                uninstallers.add(() -> target.removeHandler(handler));
                installed = true;
            } catch (RuntimeException e) {
                logger.debug("Не удалось подключить обработчик JUL к логгеру '{}'", target.getName(), e);
            }
        }
        return installed;
    }

    public CaptureSink sink() {
        return sink;
    }

    /** @return {@code log4j2}, {@code jul} or {@code none} */
    public String backend() {
        return backend;
    }

    @Override
    public void close() {
        for (Runnable uninstaller : uninstallers) {
            try {
                uninstaller.run();
            } catch (RuntimeException e) {
                logger.debug("Не удалось удалить механизм сбора вывода", e);
            }
        }
        uninstallers.clear();
    }
}
