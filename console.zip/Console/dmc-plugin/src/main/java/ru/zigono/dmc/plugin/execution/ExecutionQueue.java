package ru.zigono.dmc.plugin.execution;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Plugin side FIFO. It limits how many executions run at the same time and how many may wait; beyond that limit
 * a command is refused honestly instead of being silently dropped. The type is intentionally free of any server
 * API so the ordering and saturation rules can be unit tested.
 *
 * @author Zigono
 */
public final class ExecutionQueue<T> {

    /** Result of submitting a command to the queue. */
    public enum SubmitResult {
        ACCEPTED,
        QUEUE_FULL,
        SHUTTING_DOWN
    }

    private final ArrayDeque<T> waiting = new ArrayDeque<>();
    private final Set<T> running = new LinkedHashSet<>();
    private volatile int maxConcurrent;
    private volatile int maxSize;
    private boolean closed;

    public ExecutionQueue(int maxConcurrent, int maxSize) {
        reconfigure(maxConcurrent, maxSize);
    }

    /** Applies hot reloaded limits. Commands that already wait keep their place. */
    public synchronized void reconfigure(int maxConcurrent, int maxSize) {
        this.maxConcurrent = Math.max(1, maxConcurrent);
        this.maxSize = Math.max(1, maxSize);
    }

    public int maxConcurrent() {
        return maxConcurrent;
    }

    public int maxSize() {
        return maxSize;
    }

    public synchronized SubmitResult submit(T item) {
        if (closed) {
            return SubmitResult.SHUTTING_DOWN;
        }
        if (item == null) {
            return SubmitResult.SHUTTING_DOWN;
        }
        if (waiting.size() >= maxSize) {
            return SubmitResult.QUEUE_FULL;
        }
        waiting.addLast(item);
        return SubmitResult.ACCEPTED;
    }

    /**
     * Takes the next command that may start, respecting the FIFO order and the concurrency limit.
     *
     * @return the next command, or {@code null} when nothing may start right now
     */
    public synchronized T next() {
        if (waiting.isEmpty() || running.size() >= maxConcurrent) {
            return null;
        }
        final T item = waiting.pollFirst();
        if (item != null) {
            running.add(item);
        }
        return item;
    }

    /** Marks a started command as finished. */
    public synchronized boolean complete(T item) {
        return running.remove(item);
    }

    /** @return the commands that wait for a free slot, in FIFO order */
    public synchronized List<T> drainWaiting() {
        final List<T> drained = new ArrayList<>(waiting);
        waiting.clear();
        return drained;
    }

    /** @return the commands that are currently executing */
    public synchronized List<T> running() {
        return new ArrayList<>(running);
    }

    public synchronized int depth() {
        return waiting.size();
    }

    public synchronized int runningCount() {
        return running.size();
    }

    /** Stops accepting new commands and forgets everything that waits. */
    public synchronized void shutdown() {
        closed = true;
        waiting.clear();
    }

    public synchronized boolean closed() {
        return closed;
    }
}