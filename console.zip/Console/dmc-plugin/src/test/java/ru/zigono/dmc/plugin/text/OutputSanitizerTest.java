package ru.zigono.dmc.plugin.text;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unicode safe truncation and control character stripping.
 *
 * @author Zigono
 */
class OutputSanitizerTest {

    @Test
    void stripsControlCharactersCarriageReturnsAndAnsiEscapes() {
        assertEquals("hello", OutputSanitizer.sanitize("\u0007he\u001b[31mllo\u0000\r"));
        assertEquals("keep\ttab", OutputSanitizer.sanitize("keep\ttab"));
    }

    @Test
    void splitsMultiLineTextAndDropsBlankLines() {
        assertEquals(List.of("one", "two"), OutputSanitizer.lines("one\r\ntwo\n \n"));
    }

    @Test
    void neverSplitsASurrogatePair() {
        final String emoji = "\uD83D\uDE00";
        assertEquals(emoji + emoji, OutputSanitizer.truncate(emoji + emoji + emoji, 2));
        assertEquals(emoji, OutputSanitizer.truncate(emoji + emoji, 1));
        assertEquals("a", OutputSanitizer.truncate("a" + emoji, 1));
        assertEquals("", OutputSanitizer.truncate(emoji, 0));
        assertEquals(3, OutputSanitizer.length(emoji + emoji + emoji));
    }

    @Test
    void keepsTextShorterThanTheLimitUntouched() {
        assertEquals("short", OutputSanitizer.truncate("short", 10));
        assertTrue(OutputSanitizer.truncate("", 10).isEmpty());
    }
}