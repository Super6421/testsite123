package ru.zigono.dmc.plugin.execution;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The plugin side policy: blocked commands, whitelist, deny rules, dangerous commands and normalization.
 *
 * @author Zigono
 */
class PluginPolicyTest {

    private static PluginPolicy policy() {
        final Map<String, Object> security = new LinkedHashMap<>();
        security.put("blocked_commands", List.of("stop"));
        security.put("allowed_commands", List.of());
        security.put("dangerous_commands", List.of("op", "reload"));
        final Map<String, Object> root = new LinkedHashMap<>();
        root.put("security", security);
        final Map<String, Object> rule = new LinkedHashMap<>();
        rule.put("deny", true);
        root.put("command_policies", Map.of("cmi heal", rule));
        return PluginPolicy.from(YamlConfig.of(root, "test-policy"));
    }

    @Test
    void blocksCommandsThatAreListedAsBlocked() {
        final PluginPolicy policy = policy();

        assertTrue(policy.isBlocked(policy.normalize("stop")));
        assertTrue(policy.check(policy.normalize("stop")).denied());
        assertFalse(policy.check(policy.normalize("say hi")).denied());
    }

    @Test
    void enforcesDenyPolicies() {
        final PluginPolicy policy = policy();
        final PluginPolicy.Verdict verdict = policy.check(policy.normalize("cmi heal Zigono"));

        assertTrue(verdict.denied());
        assertTrue(verdict.reason().contains("cmi heal"));
    }

    @Test
    void marksDangerousCommands() {
        final PluginPolicy policy = policy();
        final PluginPolicy.Verdict verdict = policy.check(policy.normalize("op Zigono"));

        assertFalse(verdict.denied());
        assertTrue(verdict.requiresConfirmation());
        assertTrue(policy.isDangerous(policy.normalize("reload")));
        assertFalse(policy.isDangerous(policy.normalize("say hi")));
    }

    @Test
    void enforcesTheWhitelistWhenItIsConfigured() {
        final Map<String, Object> security = new LinkedHashMap<>();
        security.put("allowed_commands", List.of("say *", "list"));
        final Map<String, Object> root = new LinkedHashMap<>();
        root.put("security", security);
        final PluginPolicy policy = PluginPolicy.from(YamlConfig.of(root, "test-whitelist"));

        assertFalse(policy.check(policy.normalize("say hello")).denied());
        assertTrue(policy.check(policy.normalize("kill @e")).denied());
    }

    @Test
    void rejectsCommandInjectionAndOversizedInput() {
        final PluginPolicy policy = policy();

        assertThrows(CommandException.class, () -> policy.normalize("say hi && stop"));
        assertThrows(CommandException.class, () -> policy.normalize("say hi\nstop"));
        assertThrows(CommandException.class, () -> policy.normalize("say \u200bhi"));
        assertThrows(CommandException.class, () -> policy.normalize("x".repeat(600)));
    }

    @Test
    void stripsTheLeadingSlashAndSplitsTokens() {
        final NormalizedCommand command = policy().normalize("/say hello world");

        assertEquals("say hello world", command.normalized());
        assertEquals("say", command.root());
        assertEquals(List.of("say", "hello", "world"), command.tokens());
    }

    @Test
    void describesTheConfiguredRules() {
        final List<String> rules = policy().rules();

        assertTrue(rules.contains("blocked stop"));
        assertTrue(rules.contains("dangerous op"));
        assertTrue(rules.stream().anyMatch(rule -> rule.startsWith("deny cmi heal")));
    }
}