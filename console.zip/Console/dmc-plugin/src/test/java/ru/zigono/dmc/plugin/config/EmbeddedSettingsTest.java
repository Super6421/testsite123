package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Rules of the {@code embedded} section: the mode is opt in, an unresolved token only disables the bot and the
 * generated files end up in the plugin data directory.
 *
 * @author Zigono
 */
class EmbeddedSettingsTest {

    @Test
    void isDisabledWhenTheSectionIsAbsent(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(YamlConfig.empty("test"), directory, "ru");

        assertFalse(settings.enabled());
        assertFalse(settings.botConfigured());
        assertEquals(directory.resolve("embedded"), settings.directory());
    }

    @Test
    void resolvesEveryPathInsideTheDataDirectory(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                """), directory, "ru");

        assertTrue(settings.enabled());
        assertTrue(settings.botConfigured());
        assertEquals(directory.resolve("embedded").resolve("server.secret"), settings.serverSecretFile());
        assertEquals(directory.resolve("embedded").resolve("control.secret"), settings.controlSecretFile());
        assertEquals(directory.resolve("embedded").resolve("gateway.yml"), settings.gatewayConfigFile());
        assertEquals(directory.resolve("embedded").resolve("bot.yml"), settings.botConfigFile());
        assertEquals(directory.resolve("embedded").resolve("data"), settings.dataDirectory());
        assertEquals("ru", settings.discord().language(), "the bot speaks the plugin language by default");
    }


    @Test
    void anEmptyListMeansEveryGuildAndChannel(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                    guilds: ""
                    channels:
                      allowed: ""
                """), directory, "ru");

        assertTrue(settings.discord().guilds().isEmpty(),
                "пустая строка не должна становиться идентификатором гильдии: иначе бот откажет всем");
        assertTrue(settings.discord().allowedChannels().isEmpty());
        assertTrue(settings.botConfigured());
    }

    @Test
    void severalIdsCanBeWrittenInOneLine(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                    guilds: "111, 222"
                    channels:
                      allowed: "333; 444"
                """), directory, "ru");

        assertEquals(java.util.List.of("111", "222"), settings.discord().guilds());
        assertEquals(java.util.List.of("333", "444"), settings.discord().allowedChannels());
    }

    @Test
    void keepsAnUnresolvedTokenOutOfTheWay(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  discord:
                    token: "${DISCORD_TOKEN:}"
                """), directory, "ru");

        assertTrue(settings.enabled());
        assertEquals("", settings.discord().token(), "an unresolved placeholder must not be used as a token");
        assertFalse(settings.botConfigured(), "the server must start even when the token is not there yet");
    }

    @Test
    void rejectsAnUnknownDiscordStatus(@TempDir Path directory) {
        final ConfigException failure = assertThrows(ConfigException.class, () -> EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                    status: FLYING
                """), directory, "ru"));

        assertTrue(failure.getMessage().contains("embedded.discord.status"), failure.getMessage());
    }

    @Test
    void readsTheAclAndTheOverridesAsRawSections(@TempDir Path directory) {
        final EmbeddedSettings settings = EmbeddedSettings.from(embedded("""
                embedded:
                  enabled: true
                  permissions:
                    roles:
                      "444":
                        allow: [ "console.*" ]
                  gateway_overrides:
                    queue:
                      max_size: 42
                """), directory, "en");

        assertEquals(1, settings.permissions().size());
        assertTrue(settings.permissions().containsKey("roles"));
        final Map<?, ?> queue = (Map<?, ?>) settings.gatewayOverrides().get("queue");
        assertEquals(42, queue.get("max_size"));
        assertTrue(settings.botOverrides().isEmpty());
        assertEquals("en", settings.discord().language());
    }

    @Test
    void keepsAManualSecretAndGeneratesTheMissingOne(@TempDir Path directory) throws Exception {
        final Path manual = directory.resolve("manual.yml");
        Files.writeString(manual, """
                server:
                  id: survival
                security:
                  server_secret: "0123456789abcdef0123456789abcdef"
                embedded:
                  enabled: true
                """);

        final PluginConfig config = PluginConfig.load(manual, directory);

        assertEquals(32, config.secret().length);
        assertFalse(Files.exists(directory.resolve("embedded").resolve("server.secret")),
                "a secret written by the administrator must not be replaced by a generated one");
    }

    @Test
    void generatesAndPersistsTheSecretWhenNoneIsConfigured(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("generated.yml");
        Files.writeString(file, """
                server:
                  id: survival
                embedded:
                  enabled: true
                """);

        final PluginConfig config = PluginConfig.load(file, directory);

        assertEquals(32, config.secret().length);
        assertTrue(Files.isRegularFile(directory.resolve("embedded").resolve("server.secret")));
        assertEquals(config.secret().length, SecretFile.read(directory.resolve("embedded").resolve("server.secret"))
                .substring(4).length() / 2);
    }

    @Test
    void stillRefusesToRunWithoutASecretWhenTheEmbeddedModeIsOff(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("external.yml");
        Files.writeString(file, """
                server:
                  id: survival
                embedded:
                  enabled: false
                """);

        final ConfigException failure = assertThrows(ConfigException.class, () -> PluginConfig.load(file, directory));

        assertTrue(failure.getMessage().contains("security.server_secret"), failure.getMessage());
    }

    private static YamlConfig embedded(String document) {
        return YamlConfig.parse(document, "test.yml", true);
    }
}
