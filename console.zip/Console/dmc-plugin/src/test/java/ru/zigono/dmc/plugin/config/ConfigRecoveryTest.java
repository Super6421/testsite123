package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * A hand-edited config.yml that no longer parses must never leave the server without the console: the broken file
 * is kept next to the original as config.yml.broken-&lt;date&gt; and the shipped default takes its place, so the
 * plugin still starts and the administrator can copy the values back.
 *
 * @author Zigono
 */
class ConfigRecoveryTest {

    /** An unterminated flow sequence: SnakeYAML refuses this file. */
    private static final String BROKEN = """
            language: ru
            embedded:
              enabled: true
              discord:
                guilds: [ 1289611519578869781
            """;

    @Test
    void aBrokenFileIsMovedAsideAndReplacedWithTheShippedDefault(@TempDir Path directory) throws IOException {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, BROKEN, StandardCharsets.UTF_8);
        assertThrows(ConfigException.class, () -> YamlConfig.parse(Files.readString(file), file.toString(), false),
                "the test input has to be broken YAML, otherwise this test proves nothing");

        final byte[] bundled = shippedDefault();
        final Path recovered = ConfigBootstrap.recoverMalformed(file, bundled, LoggerFactory.getLogger("test"));

        assertEquals(file, recovered, "the configuration is read from the same path afterwards");
        assertArrayEquals(bundled, Files.readAllBytes(recovered), "the shipped default replaces the broken file");

        final PluginConfig config = PluginConfig.of(YamlConfig.load(recovered, false), directory.resolve("data"));
        assertEquals("ru", config.language());
        assertTrue(config.embedded().enabled(), "the recovered configuration still starts the control plane");
        assertFalse(config.embedded().discord().guilds().isEmpty(), "the recovered file is the shipped one");
    }

    @Test
    void theBrokenContentIsKeptNextToTheOriginal(@TempDir Path directory) throws IOException {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, BROKEN, StandardCharsets.UTF_8);

        ConfigBootstrap.recoverMalformed(file, shippedDefault(), LoggerFactory.getLogger("test"));

        final List<Path> backups;
        try (Stream<Path> entries = Files.list(directory)) {
            backups = entries.filter(entry -> entry.getFileName().toString().startsWith("config.yml.broken-")).toList();
        }
        assertEquals(1, backups.size(), "exactly one backup is written: " + backups);
        assertEquals(BROKEN, Files.readString(backups.get(0)), "no value of the administrator is lost");
    }

    private static byte[] shippedDefault() throws IOException {
        try (InputStream stream = ConfigBootstrap.class.getClassLoader().getResourceAsStream("config.yml")) {
            assertNotNull(stream, "the plugin jar must contain the default config.yml");
            return stream.readAllBytes();
        }
    }
}
