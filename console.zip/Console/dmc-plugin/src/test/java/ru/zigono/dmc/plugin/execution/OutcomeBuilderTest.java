package ru.zigono.dmc.plugin.execution;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Limits and Unicode safety of the outcome that is sent back to the gateway.
 *
 * @author Zigono
 */
class OutcomeBuilderTest {

    @Test
    void capsTheNumberOfLinesAndReportsTheDroppedOnes() {
        final OutcomeBuilder.Trimmed trimmed = OutcomeBuilder.trim(List.of("one", "two", "three", "four"),
                new OutcomeBuilder.Limits(2, 1_000, 100));

        assertEquals(List.of("one", "two"), trimmed.lines());
        assertEquals(2, trimmed.droppedLines());
    }

    @Test
    void capsTheNumberOfCharacters() {
        // every line costs its length plus one separator, so a 14 character budget holds exactly two 6 character lines
        final OutcomeBuilder.Trimmed exact = OutcomeBuilder.trim(List.of("abcdef", "ghijkl", "mnopqr"),
                new OutcomeBuilder.Limits(10, 14, 100));
        assertEquals(List.of("abcdef", "ghijkl"), exact.lines());
        assertEquals(1, exact.droppedLines());

        final OutcomeBuilder.Trimmed capped = OutcomeBuilder.trim(List.of("abcdef", "ghijkl", "mnopqr"),
                new OutcomeBuilder.Limits(10, 13, 100));
        assertEquals(List.of("abcdef"), capped.lines());
        assertEquals(2, capped.droppedLines());
    }

    @Test
    void keepsUnicodeIntact() {
        final String emoji = "\uD83D\uDE00";
        final OutcomeBuilder.Trimmed trimmed = OutcomeBuilder.trim(List.of("ok " + emoji), OutcomeBuilder.Limits.defaults());

        assertEquals(List.of("ok " + emoji), trimmed.lines());
        assertEquals(0, trimmed.droppedLines());
    }

    @Test
    void sanitizesBeforeSending() {
        final OutcomeBuilder.Trimmed trimmed = OutcomeBuilder.trim(List.of("\u0007clean\u0000\r"),
                OutcomeBuilder.Limits.defaults());

        assertEquals(List.of("clean"), trimmed.lines());
    }

    @Test
    void buildsAnOutcomeWithAllFields() {
        final ServerOutcome outcome = OutcomeBuilder.outcome("survival", "req-1", ExecutionStatus.SUCCESS,
                List.of("done"), 42L, null, null);

        assertEquals("survival", outcome.serverId());
        assertEquals("req-1", outcome.requestId());
        assertEquals(ExecutionStatus.SUCCESS, outcome.status());
        assertEquals("done", outcome.outputAsText());
        assertEquals(42L, outcome.durationMillis());
        assertNull(outcome.errorCode());
        assertTrue(outcome.status().successful());
    }
}