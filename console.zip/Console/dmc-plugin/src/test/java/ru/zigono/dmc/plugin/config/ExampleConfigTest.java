package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.EnvSubstitutor;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Guards the production example {@code config/plugin.example.yml}: the file that is copied to every Minecraft
 * server must load through the real plugin configuration before it is documented.
 *
 * @author Zigono
 */
class ExampleConfigTest {

    private static final String BACKSLASH = String.valueOf((char) 92);

    private static final String SERVER_SECRET = "0123456789abcdef0123456789abcdef";

    @Test
    void loadsTheDocumentedProductionExample() {
        final Path file = example("plugin.example.yml");
        final PluginConfig config = PluginConfig.of(resolved(file, Map.of(
                "DMC_SERVER_ID", "survival",
                "DMC_SERVER_SECRET", SERVER_SECRET,
                "TLS_KEYSTORE_PASSWORD", "changeit",
                "TLS_KEY_PASSWORD", "changeit",
                "TLS_TRUSTSTORE_PASSWORD", "changeit")), file.getParent());

        assertEquals("ru", config.language());
        assertEquals("survival", config.server().id());
        assertEquals("Survival", config.server().name());
        assertArrayEquals(SERVER_SECRET.getBytes(StandardCharsets.UTF_8), config.secret());
        assertEquals(8443, config.transport().port());
        assertTrue(config.transport().tlsEnabled());
        assertEquals(file.getParent().resolve("tls").resolve("client.p12"), config.transport().keyStore());
        assertEquals(Duration.ofSeconds(10), config.heartbeat().interval());
        assertEquals(Duration.ofSeconds(30), config.heartbeat().timeout());
        assertEquals(1, config.execution().maxConcurrent());
        assertEquals(64, config.execution().queueSize());
        assertEquals(30_000L, config.execution().defaultTimeoutMillis());
        assertTrue(config.capture().enabled());
        assertEquals(200, config.capture().maxLines());
        assertEquals(60_000, config.capture().maxChars());
        assertEquals("default", config.visibility().mode());
        assertEquals("discordconsole.monitor", config.visibility().permission());
        assertEquals(List.of("login", "token", "password", "auth", "2fa"),
                config.visibility().hiddenCommands());
        assertTrue(config.luckPerms().enabled());
        assertEquals("discordconsole.monitor", config.luckPerms().monitorPermission());
        assertTrue(config.metrics().enabled());
        assertEquals(300L, config.metrics().logIntervalSeconds());
        assertTrue(config.logging().commandEcho());
        assertThrows(CommandException.class,
                () -> config.normalizer().normalize("say " + BACKSLASH + "x"),
                "the documented blocked sequences must reject the literal backslash-x");
        assertThrows(CommandException.class, () -> config.normalizer().normalize("say a && b"),
                "the documented blocked sequences must reject command chaining");
    }

    @Test
    void loadsTheDocumentedEmbeddedExample() {
        final Path file = example("plugin-embedded.example.yml");
        final PluginConfig config = PluginConfig.of(resolved(file, Map.of(
                "DISCORD_TOKEN", "test-token",
                "DMC_SERVER_SECRET", SERVER_SECRET)), file.getParent());

        assertEquals("ru", config.language());
        assertTrue(config.embedded().enabled(), "the panel hosting example has to run everything in the plugin");
        assertEquals("test-token", config.embedded().discord().token());
        assertEquals(List.of("111111111111111111"), config.embedded().discord().guilds());
        assertEquals("111111111111111177", config.embedded().discord().auditChannelId());
        assertEquals(List.of("111111111111111198"), config.embedded().discord().deniedChannels());
        assertTrue(config.embedded().permissions().containsKey("roles"),
                "the ACL is declared in the plugin configuration");
        assertEquals("dmc-embedded", config.embedded().gatewayId());
        assertEquals("discord-console", config.embedded().controlClientId());
        assertEquals("survival", config.server().id());
        assertEquals(SERVER_SECRET, new String(config.secret(), StandardCharsets.UTF_8));
        assertTrue(config.embedded().botConfigured());
    }

    /**
     * @return the example from the repository root, walking up from the module directory
     */
    private static Path example(String name) {
        Path directory = Path.of("").toAbsolutePath();
        while (directory != null) {
            final Path candidate = directory.resolve("config").resolve(name);
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
            directory = directory.getParent();
        }
        assumeTrue(false, "config/" + name + " is not part of this checkout");
        throw new IllegalStateException("config/" + name + " is missing");
    }

    /**
     * Applies a deterministic environment to the example, the way a production start resolves it.
     */
    private static YamlConfig resolved(Path file, Map<String, String> environment) {
        final YamlConfig document = YamlConfig.load(file, false);
        final Map<String, Object> values = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : document.asMap().entrySet()) {
            values.put(entry.getKey(),
                    EnvSubstitutor.apply(entry.getValue(), environment, document.source(), false));
        }
        return YamlConfig.of(values, document.source());
    }
}
