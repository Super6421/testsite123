package ru.zigono.dmc.plugin.visibility;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.command.NormalizedCommand;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Visibility rules, including the hard rule that hidden commands never leak.
 *
 * @author Zigono
 */
class VisibilityPolicyTest {

    private static final String MONITOR = "discordconsole.monitor";
    private static final String ADMIN = "discordconsole.monitor.admin";

    private static NormalizedCommand command(String raw) {
        final List<String> tokens = List.of(raw.split("\\s+"));
        return new NormalizedCommand(raw, raw, tokens.get(0), tokens);
    }

    private static VisibilitySettings settings(String mode, boolean defaultValue, List<String> hidden) {
        return new VisibilitySettings(true, MONITOR, "&f{user}: {command}", mode, defaultValue, true,
                "&fresult: {result}", null, "***", hidden);
    }

    private static Viewer player(String name, String... nodes) {
        return Viewer.of(name, false, PermissionView.of(Set.of(nodes)));
    }

    @Test
    void hiddenCommandsAreNeverVisible() {
        final VisibilityPolicy policy = new VisibilityPolicy(settings("default", true, List.of("login", "token")),
                VisibilityNodes.none());

        assertTrue(policy.hidden(command("login Zigono secret")));
        assertTrue(policy.hidden(command("token")));
        assertFalse(policy.hidden(command("say hi")));
    }

    @Test
    void permissionModeRequiresThePermissionNode() {
        final VisibilityPolicy policy = new VisibilityPolicy(settings("permission", true, List.of()),
                VisibilityNodes.none());

        assertTrue(policy.maySeeCommands(player("Zigono", MONITOR)));
        assertFalse(policy.maySeeCommands(player("Guest")));
        assertTrue(policy.maySeeCommands(Viewer.serverConsole()));
    }

    @Test
    void defaultModeShowsActivityWhenTheDefaultFlagIsSet() {
        final VisibilityPolicy open = new VisibilityPolicy(settings("default", true, List.of()),
                VisibilityNodes.none());
        assertTrue(open.maySeeCommands(player("Guest")));

        final VisibilityPolicy closed = new VisibilityPolicy(settings("default", false, List.of()),
                VisibilityNodes.none());
        assertFalse(closed.maySeeCommands(player("Guest")));
        assertTrue(closed.maySeeCommands(player("Staff", MONITOR)));
    }

    @Test
    void nobodyModeHidesActivityFromEveryPlayerButNotFromTheConsole() {
        final VisibilityPolicy policy = new VisibilityPolicy(settings("nobody", true, List.of()),
                VisibilityNodes.none());

        assertFalse(policy.maySeeCommands(player("Guest")));
        assertFalse(policy.maySeeCommands(player("Staff", MONITOR)));
        assertTrue(policy.maySeeCommands(Viewer.serverConsole()));
    }

    @Test
    void administrativeBypassWinsOverTheMode() {
        final VisibilityPolicy policy = new VisibilityPolicy(settings("nobody", false, List.of("login")),
                VisibilityNodes.none());
        final Viewer administrator = Viewer.of("Admin", true, PermissionView.none());

        assertTrue(policy.maySeeCommands(administrator));
        assertTrue(policy.hidden(command("login")));
    }

    @Test
    void disablingVisibilityHidesEverythingFromPlayers() {
        final VisibilityPolicy policy = new VisibilityPolicy(
                new VisibilitySettings(false, MONITOR, null, "default", true, true, null, null, "***", List.of()),
                VisibilityNodes.none());

        assertFalse(policy.maySeeCommands(player("Guest")));
        assertFalse(policy.maySeeCommands(Viewer.of("Admin", true, PermissionView.none())));
        assertTrue(policy.maySeeCommands(Viewer.serverConsole()));
    }

    @Test
    void optionalRefinementNodesRestrictContent() {
        final VisibilitySettings settings = settings("default", true, List.of());
        final VisibilityPolicy policy = new VisibilityPolicy(settings,
                new VisibilityNodes("discordconsole.monitor.commands", "discordconsole.monitor.results",
                        "discordconsole.monitor.servers"));

        assertFalse(policy.maySeeCommands(player("Guest")));
        assertTrue(policy.maySeeCommands(player("Guest", "discordconsole.monitor.commands")));
        assertFalse(policy.maySeeResults(player("Guest", "discordconsole.monitor.commands")));
        assertTrue(policy.maySeeResults(player("Guest", "discordconsole.monitor.commands",
                "discordconsole.monitor.results")));
        assertFalse(policy.maySeeServer(player("Guest", "discordconsole.monitor.commands")));
        assertTrue(policy.maySeeServer(player("Guest", "discordconsole.monitor.commands",
                "discordconsole.monitor.servers")));
        assertTrue(policy.maySeeCommands(Viewer.of("Admin", true, PermissionView.none())));
    }

    @Test
    void resultsFollowTheShowResultsSwitch() {
        final VisibilitySettings off = new VisibilitySettings(true, MONITOR, null, "default", true, false, null, null,
                "***", List.of());
        final VisibilityPolicy policy = new VisibilityPolicy(off, VisibilityNodes.none());

        assertTrue(policy.maySeeCommands(player("Guest")));
        assertFalse(policy.maySeeResults(player("Guest")));
    }

    @Test
    void administrativeNodeIsReportedInTheDescription() {
        final VisibilityPolicy policy = new VisibilityPolicy(settings("permission", false, List.of("login")),
                VisibilityNodes.none());

        assertTrue(policy.describe().contains("mode=permission"));
        assertTrue(policy.describe().contains("login"));
        assertTrue(ADMIN.endsWith("admin"));
    }
}