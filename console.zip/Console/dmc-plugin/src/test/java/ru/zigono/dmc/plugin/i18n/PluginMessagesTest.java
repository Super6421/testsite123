package ru.zigono.dmc.plugin.i18n;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.i18n.Messages;
import ru.zigono.dmc.plugin.config.ConfigBootstrap;

import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The message catalog of the plugin: the same keys in every language, and a catalog that stays usable even when
 * the data directory cannot be written.
 *
 * @author Zigono
 */
class PluginMessagesTest {

    private static final Path LANGUAGE_DIRECTORY = Path.of("src", "main", "resources", "plugin-lang");

    @Test
    void definesTheSameKeysInEveryLanguage() {
        assertEquals(new TreeSet<>(keys("en.yml").keySet()), new TreeSet<>(keys("ru.yml").keySet()));
    }

    @Test
    void resolvesTheBundledCatalogWithoutTheExternalFiles(@TempDir Path directory) {
        final Messages messages = Messages.load("ru", directory.resolve("absent"),
                ConfigBootstrap.LANG_RESOURCE_DIRECTORY);

        assertTrue(messages.has("plugin.status.header"));
        assertTrue(messages.has("common.yes"), "the shared catalog must stay available");
        assertFalse(messages.format("plugin.status.header").isBlank());
    }

    private static Map<String, String> keys(String file) {
        final Map<String, String> result = new LinkedHashMap<>();
        flatten("", YamlConfig.load(LANGUAGE_DIRECTORY.resolve(file), false).asMap(), result);
        assertFalse(result.isEmpty());
        return result;
    }

    private static void flatten(String prefix, Map<String, Object> values, Map<String, String> target) {
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            final String key = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            if (entry.getValue() instanceof Map<?, ?> nested) {
                final Map<String, Object> copy = new LinkedHashMap<>();
                nested.forEach((name, value) -> copy.put(String.valueOf(name), value));
                flatten(key, copy, target);
            } else {
                target.put(key, String.valueOf(entry.getValue()));
            }
        }
    }
}
