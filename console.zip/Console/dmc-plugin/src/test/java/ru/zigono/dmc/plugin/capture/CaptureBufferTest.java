package ru.zigono.dmc.plugin.capture;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Behaviour of the bounded capture buffer.
 *
 * @author Zigono
 */
class CaptureBufferTest {

    @Test
    void keepsLinesUntilTheLineLimitIsReached() {
        final CaptureBuffer buffer = new CaptureBuffer(3, 1000);

        assertTrue(buffer.append("first"));
        assertTrue(buffer.append("second"));
        assertTrue(buffer.append("third"));

        assertEquals(List.of("first", "second", "third"), buffer.lines());
        assertFalse(buffer.truncated());
        assertEquals(0, buffer.droppedLines());
    }

    @Test
    void dropsEveryLineAboveTheLineLimitAndCountsThem() {
        final CaptureBuffer buffer = new CaptureBuffer(2, 1000);
        buffer.append("first");
        buffer.append("second");

        assertFalse(buffer.append("third"));
        assertFalse(buffer.append("fourth"));

        assertEquals(List.of("first", "second"), buffer.lines());
        assertTrue(buffer.truncated());
        assertTrue(buffer.saturated());
        assertEquals(2, buffer.droppedLines());
    }

    @Test
    void truncatesTheLineThatDoesNotFitIntoTheCharacterBudget() {
        final CaptureBuffer buffer = new CaptureBuffer(10, 20);
        assertTrue(buffer.append("abcde"));
        assertTrue(buffer.append("fghij"));
        assertTrue(buffer.append("klmno"));

        assertFalse(buffer.append("pqrst"));

        assertEquals(List.of("abcde", "fghij", "klmno", "p"), buffer.lines());
        assertTrue(buffer.truncated());
        assertEquals(1, buffer.droppedLines());
        assertEquals("abcde\nfghij\nklmno\np", buffer.text());
    }

    @Test
    void reportsAnEmptyBuffer() {
        final CaptureBuffer buffer = new CaptureBuffer(5, 5);

        assertTrue(buffer.empty());
        assertEquals(0, buffer.size());
        assertEquals("", buffer.text());
    }
}