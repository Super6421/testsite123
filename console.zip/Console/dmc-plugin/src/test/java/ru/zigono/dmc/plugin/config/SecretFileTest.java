package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.protocol.Secrets;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The embedded mode generates its own secrets, so the file has to be created once, reused afterwards and be
 * strong enough for the protocol minimum.
 *
 * @author Zigono
 */
class SecretFileTest {

    @Test
    void generatesAProtocolReadySecretOnceAndReusesIt(@TempDir Path directory) {
        final Path file = directory.resolve("nested").resolve("server.secret");

        final String generated = SecretFile.readOrCreate(file);
        final String again = SecretFile.readOrCreate(file);

        assertTrue(Files.isRegularFile(file), "the secret file must be created");
        assertTrue(generated.startsWith("hex:"), generated);
        assertEquals(generated, again, "the second start must reuse the secret of the first one");
        assertEquals(SecretFile.SECRET_BYTES, Secrets.decode(generated, "test").length);
    }

    @Test
    void encodesADecodedSecretBackIntoTheConfigurationForm() {
        final byte[] secret = "0123456789abcdef0123456789abcdef".getBytes(StandardCharsets.UTF_8);

        final String encoded = SecretFile.encode(secret);

        assertArrayEquals(secret, Secrets.decode(encoded, "test"));
    }

    @Test
    void rejectsAnEmptySecretFile(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("server.secret");
        Files.writeString(file, "   \n", StandardCharsets.UTF_8);

        final ConfigException failure = assertThrows(ConfigException.class, () -> SecretFile.read(file));

        assertTrue(failure.getMessage().contains("пуст"), failure.getMessage());
    }

    @Test
    void writesTheSecretWithOwnerOnlyPermissionsWhereTheSystemSupportsIt(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("control.secret");

        SecretFile.write(file, "hex:0011223344556677889900112233445566778899001122334455667788990011");

        assertEquals("hex:0011223344556677889900112233445566778899001122334455667788990011",
                Files.readString(file, StandardCharsets.UTF_8).trim());
        try {
            assertTrue(Files.getPosixFilePermissions(file).stream()
                            .noneMatch(permission -> permission.name().startsWith("GROUP")
                                    || permission.name().startsWith("OTHERS")),
                    "group and other bits must be cleared");
        } catch (UnsupportedOperationException windows) {
            // Windows: the file already lives inside the server directory.
        }
    }
}
