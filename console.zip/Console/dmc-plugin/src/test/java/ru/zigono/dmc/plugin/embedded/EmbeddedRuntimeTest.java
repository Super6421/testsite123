package ru.zigono.dmc.plugin.embedded;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.plugin.config.SecretFile;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.Secrets;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.TransportClient;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Starts the embedded mode for real: an in process gateway, the generated configuration, and two protocol peers
 * that authenticate over the loopback listener exactly like the plugin and the Discord bot do.
 *
 * @author Zigono
 */
class EmbeddedRuntimeTest {

    @Test
    void runsTheControlPlaneOfThisServerInProcess(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, """
                language: ru
                server:
                  id: survival
                  name: Survival
                  description: Test server
                embedded:
                  enabled: true
                  permissions:
                    roles:
                      "444":
                        allow: [ "console.*" ]
                """);
        final PluginConfig config = PluginConfig.load(file, directory);
        assertTrue(config.embedded().enabled());
        assertEquals(32, config.secret().length, "the embedded mode generates the server secret");

        final EmbeddedRuntime runtime = new EmbeddedRuntime(config.embedded());
        try {
            runtime.start(config);

            assertTrue(runtime.running());
            assertTrue(runtime.port() > 0, "the listener must report the port it bound");
            assertTrue(Files.isRegularFile(config.embedded().gatewayConfigFile()));

            final GatewayConfig gateway = GatewayConfig.load(config.embedded().gatewayConfigFile());
            assertArrayEquals(config.secret(), gateway.serverSecrets().get("survival"),
                    "the gateway authenticates this server with the very secret the plugin uses");

            final Peer plugin = new Peer(settings(runtime, config, "survival", "plugin"),
                    KeyResolver.single("survival", config.secret()), "plugin", "survival");
            plugin.start();
            assertTrue(plugin.awaitAuthentication(), "the plugin role must authenticate over the loopback");

            final String controlSecret = SecretFile.read(config.embedded().controlSecretFile());
            final Peer control = new Peer(settings(runtime, config, "discord-console", "control"),
                    KeyResolver.single("discord-console", Secrets.decode(controlSecret, "test")), "control", null);
            control.start();
            assertTrue(control.awaitAuthentication(), "the control role must authenticate over the loopback");

            assertEquals(runtime.port(), runtime.status().port());
            assertEquals(EmbeddedRuntime.BotState.DISABLED, runtime.status().botState(),
                    "without a Discord token the bot stays off, the server keeps running");

            plugin.close();
            control.close();
        } finally {
            runtime.close();
        }
        assertFalse(runtime.running(), "closing the runtime must stop the in process control plane");
    }

    @Test
    void generatesTheBotConfigurationTogetherWithTheControlPlane(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, """
                server:
                  id: survival
                  name: Survival
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                """);
        final PluginConfig config = PluginConfig.load(file, directory);
        final EmbeddedRuntime runtime = new EmbeddedRuntime(config.embedded());
        try {
            runtime.start(config);
            final Path botFile = config.embedded().botConfigFile();

            assertTrue(Files.isRegularFile(botFile), "a configured token produces the bot configuration");
            assertEquals(runtime.port(), BotConfig.load(botFile).transport().port());
        } finally {
            runtime.close();
        }
    }

    /** The settings of a peer that talks to the embedded listener of this process. */
    private static TransportSettings settings(EmbeddedRuntime runtime, PluginConfig config, String clientId,
                                              String role) {
        final YamlConfig network = YamlConfig.parse("host: 127.0.0.1\nport: " + runtime.port() + "\n", "test", true);
        final YamlConfig tls = YamlConfig.parse("enabled: false\nallow_insecure_transport: true\n", "test", true);
        return TransportSettings.from(network, tls, config.embedded().directory(), clientId, role);
    }

    /** Protocol peer that performs the handshake the way the plugin and the bot do. */
    private static final class Peer implements TransportClient.Listener {

        private final TransportClient client;
        private final String role;
        private final String serverId;
        private final CountDownLatch authenticated = new CountDownLatch(1);

        private Peer(TransportSettings settings, KeyResolver keys, String role, String serverId) {
            this.client = new TransportClient(settings, keys, this);
            this.role = role;
            this.serverId = serverId;
        }

        void start() {
            client.start();
        }

        boolean awaitAuthentication() throws InterruptedException {
            return authenticated.await(15, TimeUnit.SECONDS);
        }

        void close() {
            client.close();
        }

        @Override
        public void onConnected(Connection connection) {
            final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
            hello.role = role;
            hello.agentName = "DiscordMinecraftConsole";
            hello.agentVersion = "1.0.0";
            hello.platform = "test";
            hello.serverId = serverId;
            hello.capabilities = List.of("commands");
            client.send(hello);
        }

        @Override
        public void onMessage(Connection connection, Message message) {
            if (message instanceof HandshakeMessages.HelloAck ack) {
                final HandshakeMessages.AuthRequest auth = ack.correlate(new HandshakeMessages.AuthRequest());
                auth.role = role;
                auth.serverId = serverId;
                auth.challenge = ack.challenge;
                auth.agentVersion = "1.0.0";
                client.send(auth);
                return;
            }
            if (message instanceof HandshakeMessages.AuthResult result && result.authenticated) {
                authenticated.countDown();
            }
        }

        @Override
        public void onDisconnected(Throwable cause) {
        }
    }
}
