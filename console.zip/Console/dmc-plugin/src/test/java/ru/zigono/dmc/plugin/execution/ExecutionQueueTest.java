package ru.zigono.dmc.plugin.execution;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Ordering, saturation and concurrency limits of the plugin side FIFO.
 *
 * @author Zigono
 */
class ExecutionQueueTest {

    @Test
    void keepsFifoOrderAndRefusesCommandsAboveTheLimit() {
        final ExecutionQueue<String> queue = new ExecutionQueue<>(1, 2);

        assertEquals(ExecutionQueue.SubmitResult.ACCEPTED, queue.submit("first"));
        assertEquals(ExecutionQueue.SubmitResult.ACCEPTED, queue.submit("second"));
        assertEquals(ExecutionQueue.SubmitResult.QUEUE_FULL, queue.submit("third"));

        assertEquals("first", queue.next());
        assertNull(queue.next());
        queue.complete("first");
        assertEquals("second", queue.next());
        queue.complete("second");
        assertNull(queue.next());
    }

    @Test
    void runsSeveralCommandsInParallelWhenConfigured() {
        final ExecutionQueue<String> queue = new ExecutionQueue<>(2, 10);
        queue.submit("a");
        queue.submit("b");
        queue.submit("c");

        assertEquals("a", queue.next());
        assertEquals("b", queue.next());
        assertNull(queue.next());
        assertEquals(2, queue.runningCount());

        queue.complete("a");
        assertEquals("c", queue.next());
    }

    @Test
    void drainsWaitingCommandsOnShutdown() {
        final ExecutionQueue<String> queue = new ExecutionQueue<>(1, 10);
        queue.submit("a");
        queue.submit("b");
        queue.submit("c");
        assertEquals("a", queue.next());

        final List<String> waiting = queue.drainWaiting();
        assertEquals(List.of("b", "c"), waiting);
        assertEquals(0, queue.depth());

        queue.shutdown();
        assertEquals(ExecutionQueue.SubmitResult.SHUTTING_DOWN, queue.submit("d"));
        assertTrue(queue.closed());
        assertNull(queue.next());
    }

    @Test
    void appliesHotReloadedLimits() {
        final ExecutionQueue<String> queue = new ExecutionQueue<>(1, 1);
        queue.reconfigure(3, 5);

        assertEquals(3, queue.maxConcurrent());
        assertEquals(5, queue.maxSize());
        queue.submit("a");
        queue.submit("b");
        assertEquals(ExecutionQueue.SubmitResult.ACCEPTED, queue.submit("c"));
        assertEquals(3, queue.depth());
        queue.shutdown();
        assertEquals(ExecutionQueue.SubmitResult.SHUTTING_DOWN, queue.submit("d"));
    }

    @Test
    void completeIgnoresCommandsThatNeverStarted() {
        final ExecutionQueue<String> queue = new ExecutionQueue<>(1, 5);
        queue.submit("a");
        queue.next();

        assertEquals(false, queue.complete("b"));
        assertEquals(true, queue.complete("a"));
        assertEquals(0, queue.runningCount());
    }
}