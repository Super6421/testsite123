package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.perm.PermissionConfig;
import ru.zigono.dmc.common.perm.PermissionSet;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The configuration shipped inside the plugin jar is the file every server installs, so it has to parse and to
 * produce a working configuration without any help: the embedded mode generates every secret it needs.
 *
 * @author Zigono
 */
class PluginConfigResourceTest {

    private static final Path SHIPPED = Path.of("src", "main", "resources", "config.yml");

    @Test
    void theShippedConfigurationStartsWithoutAnyEnvironment(@TempDir Path directory) {
        assertTrue(Files.isRegularFile(SHIPPED), "the plugin must ship a default config.yml");

        final PluginConfig config = PluginConfig.of(YamlConfig.load(SHIPPED, false), directory);

        assertEquals("ru", config.language(), "the shipped configuration is Russian");
        assertEquals("main", config.server().id());
        assertEquals("Мой сервер", config.server().name());
        assertEquals(32, config.secret().length, "the embedded mode generates the server secret itself");
        assertEquals(8443, config.transport().port());
        assertTrue(config.transport().tlsEnabled());
        assertTrue(config.capture().enabled());
        assertTrue(config.embedded().enabled(), "a panel install must run the control plane inside the plugin");
        assertTrue(config.embedded().botConfigured(), "the shipped configuration carries a bot token");
        assertEquals(java.util.List.of("1289611519578869781"), config.embedded().discord().guilds());
        assertEquals(java.util.List.of("1549232811741806723"), config.embedded().discord().allowedChannels());
        assertEquals("1549248345615245352", config.embedded().discord().auditChannelId(),
                "канал логов поставляется заполненным");
        assertTrue(config.policyEngine().rules().isEmpty(), "no command policy is required to start");
        assertTrue(config.staff().enabled(), "команды персонала включены в поставляемой конфигурации");
        assertEquals("персонал-выдать", config.staff().grantCommand());
        assertEquals("персонал-снять", config.staff().removeCommand());
        assertTrue(config.staff().allows(java.util.List.of("1390285875169988638"), "director"),
                "роль полного доступа выдаёт любую настроенную привилегию");
        assertEquals(java.util.List.of("helper", "moderator", "sr_moderator"),
                config.staff().allowedRanks(java.util.List.of("1390285875169988638")).stream()
                        .map(ru.zigono.dmc.common.staff.StaffConfig.Rank::key).limit(3).toList(),
                "порядок привилегий совпадает с конфигурацией");
    }

    @Test
    void theShippedConfigurationCarriesReadyPermissionsForEveryRole() {
        final PluginConfig config = PluginConfig.of(YamlConfig.load(SHIPPED, false), null);
        final Map<String, Object> permissions = config.embedded().permissions();

        // Плагин переносит раздел в сгенерированные gateway.yml и bot.yml без изменений.
        final PermissionConfig acl = PermissionConfig.from(
                YamlConfig.of(Map.of("permissions", permissions), "config.yml#embedded.permissions"), Set.of());

        final PermissionSet helper = acl.resolve(null, List.of("1313262203415040111"), "0");
        assertTrue(helper.allows("console.execute"), "хелпер выполняет разрешённые ему команды");
        assertTrue(helper.allows("console.command.kick.steve"), "запись kick разрешает команду с игроком");
        assertTrue(helper.allows("console.command.mute.steve"), "и запись mute тоже");
        assertTrue(helper.allows("console.server.lobby"), "server:* открывает всю сеть");
        assertFalse(helper.allows("console.command.stop"), "опасные команды хелперу не выданы");
        assertFalse(helper.allows("console.admin.reload"), "административные действия хелперу не выданы");

        final PermissionSet director = acl.resolve(null, List.of("1312150264568090725"), "0");
        assertTrue(director.allows("console.command.stop"), "у директора полный доступ к консоли");
        assertTrue(director.allows("console.admin.reload"));

        assertTrue(config.staff().rank("kurator").isPresent(), "куратор объявлен среди привилегий");
        assertFalse(config.staff().allows(List.of("1312150613726859264"), "helper"),
                "администратор привилегий не выдаёт: его роль в access не указана");
        assertTrue(config.staff().allows(List.of("1318649917299753070"), "sr_moderator"));
        assertFalse(config.staff().allows(List.of("1318649917299753070"), "administrator"),
                "гл. администратор выдаёт только до ст. модератора");
        assertTrue(config.staff().allows(List.of("1313262901301215323"), "sr_administrator"));
        assertFalse(config.staff().allows(List.of("1313262901301215323"), "chief_administrator"));
        assertTrue(config.staff().allows(List.of("1483533660782198876"), "chief_administrator"));
        assertFalse(config.staff().allows(List.of("1483533660782198876"), "supervisor"));
        assertTrue(config.staff().allows(List.of("1312150264568090725"), "supervisor"));
        assertFalse(config.staff().allows(List.of("1312150264568090725"), "director"));
        assertTrue(config.staff().allows(List.of("1390285875169988638"), "director"));
    }

    @Test
    void bypassesNothingByDefaultButStillRefusesTheLiteralBackslashX(@TempDir Path directory) {
        final PluginConfig config = PluginConfig.of(YamlConfig.load(SHIPPED, false), directory);

        assertThrows(CommandException.class, () -> config.normalizer().normalize("say \\x"),
                "the default blocked sequences must reject the literal backslash-x");
        assertEquals("say hello", config.normalizer().normalize("say hello").normalized());
    }

    @Test
    void refusesAPlaceholderThatNoOneResolved(@TempDir Path directory) throws Exception {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, """
                language: ru
                server:
                  id: main
                security:
                  server_secret: "${DMC_SERVER_SECRET:}"
                embedded:
                  enabled: false
                """);

        final ConfigException failure = assertThrows(ConfigException.class,
                () -> PluginConfig.of(YamlConfig.load(file, false), directory));

        assertTrue(failure.getMessage().contains("DMC_SERVER_SECRET"), failure.getMessage());
    }
}
