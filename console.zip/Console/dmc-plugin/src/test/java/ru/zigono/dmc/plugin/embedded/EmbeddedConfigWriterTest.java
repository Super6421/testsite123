package ru.zigono.dmc.plugin.embedded;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.bot.config.BotConfig;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.plugin.config.PluginConfig;
import ru.zigono.dmc.protocol.Secrets;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The files the embedded mode generates are the configuration of two other components, so the only useful test
 * is the strict one: generate them and load them back through their real parsers.
 *
 * @author Zigono
 */
class EmbeddedConfigWriterTest {

    private static final String SERVER_SECRET =
            "hex:0011223344556677889900112233445566778899001122334455667788990011";
    private static final String CONTROL_SECRET =
            "hex:ffeeddccbbaa99887766554433221100ffeeddccbbaa99887766554433221100";
    private static final int PORT = 45_678;

    @Test
    void generatesAGatewayConfigurationTheGatewayAccepts(@TempDir Path directory) throws Exception {
        final PluginConfig config = pluginConfig(directory);

        EmbeddedConfigWriter.writeGateway(config.embedded().gatewayConfigFile(), config, SERVER_SECRET,
                CONTROL_SECRET);
        final GatewayConfig gateway = GatewayConfig.load(config.embedded().gatewayConfigFile());

        assertTrue(gateway.catalog().singleServerMode(), "the embedded gateway serves one server");
        assertEquals("dmc-embedded", gateway.gatewayId());
        assertArrayEquals(Secrets.decode(SERVER_SECRET, "test"), gateway.serverSecrets().get("survival"),
                "the gateway must accept exactly the secret of the plugin");
        assertArrayEquals(Secrets.decode(CONTROL_SECRET, "test"), gateway.controlSecrets().get("discord-console"));
        assertEquals(0, gateway.transport().port(), "the listener asks the operating system for a free port");
        assertFalse(gateway.transport().tlsEnabled());
        assertTrue(gateway.transport().allowInsecureTransport(),
                "the loopback listener has to opt in to an unencrypted transport explicitly");
        assertEquals(EmbeddedConfigWriter.LOOPBACK_HOST, gateway.transport().host());
        assertFalse(gateway.metrics().enabled(), "the embedded mode must not open a second port");
        assertFalse(gateway.redis().enabled());
        assertTrue(gateway.database().sqliteFile().endsWith(Path.of("data", "gateway.db")),
                gateway.database().sqliteFile().toString());
        assertEquals(42, gateway.queue().maxSize(), "gateway_overrides must win over the generated value");
        assertTrue(gateway.permissions().globalRoles().containsKey("444"), "the ACL must reach the gateway");
        assertFalse(gateway.restrictions().allowsChannel("111", "333"), "the denied channel must stay denied");
        assertTrue(gateway.restrictions().allowsChannel("111", "999"));
        assertTrue(gateway.policy().dangerousPatterns().contains("stop"),
                "the gateway has to know which commands need a confirmation in Discord");
    }

    @Test
    void generatesABotConfigurationTheBotAccepts(@TempDir Path directory) throws Exception {
        final PluginConfig config = pluginConfig(directory);

        EmbeddedConfigWriter.writeBot(config.embedded().botConfigFile(), config, CONTROL_SECRET, PORT);
        final BotConfig bot = BotConfig.load(config.embedded().botConfigFile());

        assertEquals("test-token", bot.discord().token());
        assertEquals(java.util.List.of("111"), bot.discord().guildIds());
        assertEquals("Minecraft Console", bot.discord().activity());
        assertEquals("ONLINE", bot.discord().status());
        assertEquals("discord-console", bot.control().clientId());
        assertArrayEquals(Secrets.decode(CONTROL_SECRET, "test"), bot.controlSecret());
        assertEquals(PORT, bot.transport().port(), "the bot must talk to the listener that was just bound");
        assertEquals(EmbeddedConfigWriter.LOOPBACK_HOST, bot.transport().host());
        assertFalse(bot.transport().tlsEnabled());
        assertTrue(bot.channels().allows("111", "999"));
        assertFalse(bot.channels().allows("111", "333"), "the denied channel must stay denied");
        assertTrue(bot.audit().enabled(), "a configured audit channel turns the Discord audit on");
        assertEquals("222", bot.audit().channelId());
        assertTrue(bot.shortcuts().alias("heal").isPresent(), "bot_overrides must reach the bot");
        assertEquals(config.embedded().directory().resolve("../lang"), bot.languageDirectory());
        assertEquals("ru", bot.language());
        assertTrue(bot.staff().enabled(), "раздел staff обязан дойти до бота");
        assertEquals(ru.zigono.dmc.common.staff.StaffConfig.Mode.ADD, bot.staff().mode());
        assertEquals("Хелпер", bot.staff().rank("helper").orElseThrow().name());
        assertTrue(bot.staff().allows(java.util.List.of("555"), "helper"));
        assertFalse(bot.staff().allows(java.util.List.of("556"), "helper"));
        assertEquals("персонал-выдать", bot.staff().grantCommand());
    }

    @Test
    void rewritesTheFilesOnlyWhenSomethingChanged(@TempDir Path directory) throws Exception {
        final PluginConfig config = pluginConfig(directory);
        final Path botFile = config.embedded().botConfigFile();

        EmbeddedConfigWriter.writeBot(botFile, config, CONTROL_SECRET, PORT);
        final String first = Files.readString(botFile, StandardCharsets.UTF_8);
        EmbeddedConfigWriter.writeBot(botFile, config, CONTROL_SECRET, PORT);

        assertEquals(first, Files.readString(botFile, StandardCharsets.UTF_8));
        assertTrue(first.startsWith("# Discord-бот встроенного режима DiscordMinecraftConsole — автор: Zigono"),
                first.lines().findFirst().orElse(""));
        assertTrue(first.contains("port: " + PORT));

        EmbeddedConfigWriter.writeBot(botFile, config, CONTROL_SECRET, PORT + 1);

        assertTrue(Files.readString(botFile, StandardCharsets.UTF_8).contains("port: " + (PORT + 1)),
                "a new port has to reach the file");
    }


    @Test
    void writesEveryServerAndGroupOfTheNetwork(@TempDir Path directory) throws Exception {
        final PluginConfig config = networkConfig(directory);

        EmbeddedConfigWriter.writeGateway(config.embedded().gatewayConfigFile(), config,
                java.util.Map.of("survival", SERVER_SECRET, "lobby", CONTROL_SECRET), CONTROL_SECRET);
        final GatewayConfig gateway = GatewayConfig.load(config.embedded().gatewayConfigFile());

        assertFalse(gateway.catalog().singleServerMode(), "сеть серверов не должна прятать выбор сервера");
        assertEquals(java.util.Set.of("survival", "lobby"),
                java.util.Set.copyOf(gateway.catalog().enabledServerIds()));
        assertEquals(java.util.List.of("survival", "lobby"), gateway.catalog().groupServers("all"));
        assertEquals("Лобби", gateway.catalog().displayName("lobby"));
        assertTrue(gateway.catalog().find("hub").isPresent(), "псевдоним из config.yml обязан дойти до шлюза");
        assertArrayEquals(Secrets.decode(SERVER_SECRET, "test"), gateway.serverSecrets().get("survival"));
        assertArrayEquals(Secrets.decode(CONTROL_SECRET, "test"), gateway.serverSecrets().get("lobby"),
                "у каждого сервера сети свой секрет");
        assertEquals("0.0.0.0", gateway.transport().host(), "адрес из config.yml обязан дойти до шлюза");
        assertEquals(8443, gateway.transport().port());
    }

    private static PluginConfig networkConfig(Path directory) throws Exception {
        final Path file = directory.resolve("network.yml");
        Files.writeString(file, """
                language: ru
                server:
                  id: survival
                  name: Survival
                security:
                  server_secret: "0123456789abcdef0123456789abcdef"
                mode: multi
                servers:
                  survival:
                    aliases: "smp, world"
                  lobby:
                    name: "Лобби"
                    aliases: hub
                groups:
                  all: "survival, lobby"
                embedded:
                  enabled: true
                  network:
                    host: 0.0.0.0
                    port: 8443
                  discord:
                    token: "test-token"
                """);
        return PluginConfig.load(file, directory);
    }

    private static PluginConfig pluginConfig(Path directory) throws Exception {
        final Path file = directory.resolve("config.yml");
        Files.writeString(file, """
                language: ru
                server:
                  id: survival
                  name: Survival
                  description: Test server
                security:
                  server_secret: "0123456789abcdef0123456789abcdef"
                embedded:
                  enabled: true
                  discord:
                    token: "test-token"
                    guilds: [ "111" ]
                    activity: "Minecraft Console"
                    status: ONLINE
                    audit_channel_id: "222"
                    channels:
                      denied: [ "333" ]
                  permissions:
                    roles:
                      "444":
                        allow: [ "console.*" ]
                  gateway_overrides:
                    queue:
                      max_size: 42
                  bot_overrides:
                    aliases:
                      heal:
                        command: "cmi heal {player}"
                staff:
                  enabled: true
                  mode: add
                  ranks:
                    helper:
                      name: "Хелпер"
                      group: "helper"
                  access:
                    "555": "helper"
                """);
        return PluginConfig.load(file, directory);
    }
}
