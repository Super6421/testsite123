package ru.zigono.dmc.plugin.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Каталог серверов читается из одного config.yml: разделы servers и groups плюс раздел server для сервера,
 * внутри которого работает плагин.
 *
 * @author Zigono
 */
class ServerTopologyTest {

    @Test
    void alwaysContainsTheServerOfThisProcess() {
        final ServerTopology topology = ServerTopology.of(document(
                "server:",
                "  id: survival",
                "  name: Survival"));

        assertEquals(1, topology.servers().size());
        assertEquals("survival", topology.servers().get(0).id());
        assertTrue(topology.servers().get(0).local());
        assertEquals("single", topology.mode());
        assertTrue(topology.groups().isEmpty());
    }

    @Test
    void readsSeveralServersAndGroupsFromTheSameDocument() {
        final ServerTopology topology = ServerTopology.of(document(
                "server:",
                "  id: survival",
                "servers:",
                "  survival:",
                "    aliases: \"smp, world\"",
                "  lobby:",
                "    name: Lobby",
                "    description: Второй сервер сети",
                "    aliases: [ \"hub\" ]",
                "groups:",
                "  all: \"survival, lobby\""));

        assertEquals(List.of("survival", "lobby"), topology.servers().stream()
                .map(ServerTopology.Server::id).toList());
        assertTrue(topology.multi());
        assertEquals("multi", topology.mode());
        assertEquals(List.of("smp", "world"), topology.servers().get(0).aliases());
        assertEquals("Lobby", topology.servers().get(1).name());
        assertEquals(List.of("survival", "lobby"), topology.groups().get("all"));
        assertEquals(List.of("lobby"), topology.extraServers().stream()
                .map(ServerTopology.Server::id).toList());
    }

    @Test
    void keepsSingleModeWhenTheAdministratorSaysSo() {
        final ServerTopology topology = ServerTopology.of(document(
                "mode: single",
                "server:",
                "  id: survival",
                "servers:",
                "  lobby:",
                "    aliases: hub"));

        assertFalse(topology.multi());
        assertEquals("single", topology.mode());
    }

    @Test
    void refusesAGroupThatPointsToAnUnknownServer() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> ServerTopology.of(document(
                "server:",
                "  id: survival",
                "groups:",
                "  all: \"survival, lobby\"")));

        assertTrue(failure.getMessage().contains("lobby"), failure.getMessage());
    }

    @Test
    void refusesAnAliasThatCollidesWithAnotherServer() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> ServerTopology.of(document(
                "server:",
                "  id: survival",
                "servers:",
                "  lobby:",
                "    aliases: survival")));

        assertTrue(failure.getMessage().contains("псевдоним"), failure.getMessage());
    }

    @Test
    void refusesAnUnknownMode() {
        final ConfigException failure = assertThrows(ConfigException.class,
                () -> ServerTopology.of(document("mode: network")));

        assertTrue(failure.getMessage().contains("mode"), failure.getMessage());
    }

    private static YamlConfig document(String... lines) {
        return YamlConfig.parse(String.join("\n", lines), "config.yml", false);
    }
}
