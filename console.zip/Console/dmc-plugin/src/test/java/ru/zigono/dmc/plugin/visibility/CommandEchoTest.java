package ru.zigono.dmc.plugin.visibility;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Placeholder substitution, legacy colour codes and MiniMessage detection.
 *
 * @author Zigono
 */
class CommandEchoTest {

    @Test
    void replacesKnownPlaceholders() {
        final String pattern = "&7[&9Discord&7] &f{user} &7executed &f{command} &7on &f{server}";

        final String rendered = CommandEcho.format(pattern, Map.of(
                "user", "Zigono", "command", "cmi heal Steve", "server", "Survival"));

        assertEquals("&7[&9Discord&7] &fZigono &7executed &fcmi heal Steve &7on &fSurvival", rendered);
    }

    @Test
    void leavesUnknownPlaceholdersVisible() {
        assertEquals("hello {unknown}", CommandEcho.format("hello {unknown}", Map.of("user", "Zigono")));
        assertEquals("", CommandEcho.format(null, Map.of()));
    }

    @Test
    void convertsLegacyColourCodes() {
        assertEquals("\u00a77[\u00a79Discord\u00a77] hi", CommandEcho.legacyToSection("&7[&9Discord&7] hi"));
        assertEquals("&znotacode", CommandEcho.legacyToSection("&znotacode"));
        assertEquals("", CommandEcho.legacyToSection(null));
    }

    @Test
    void detectsMiniMessagePatterns() {
        assertTrue(CommandEcho.looksLikeMiniMessage("<gold>hello</gold>"));
        assertTrue(CommandEcho.looksLikeMiniMessage("<#ff0000>red"));
        assertFalse(CommandEcho.looksLikeMiniMessage("&7legacy"));
        assertFalse(CommandEcho.looksLikeMiniMessage(null));
    }

    @Test
    void summarizesCapturedOutput() {
        assertEquals("one | two", CommandEcho.summarize(List.of("one", "", " two "), 100));
        assertEquals("abcd...", CommandEcho.summarize(List.of("abcdefgh"), 4));
        assertEquals("", CommandEcho.summarize(List.of("  ", ""), 10));
    }
}