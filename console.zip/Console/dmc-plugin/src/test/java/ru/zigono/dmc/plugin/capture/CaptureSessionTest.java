package ru.zigono.dmc.plugin.capture;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Quiet period, hard stop, saturation and sanitization of a capture session, driven by a controllable clock.
 *
 * @author Zigono
 */
class CaptureSessionTest {

    private final AtomicLong clock = new AtomicLong(1_000L);

    private CaptureSession session(CaptureSettings settings) {
        return new CaptureSession("request-1", "say hello", settings, clock::get);
    }

    private static CaptureSettings settings(long quietPeriod, long maxWait, int maxLines, int maxChars, int maxLine) {
        return new CaptureSettings(true, quietPeriod, maxWait, maxLines, maxChars, maxLine);
    }

    @Test
    void finishesAfterTheQuietPeriod() {
        final CaptureSession session = session(settings(200L, 5_000L, 10, 1_000, 100));
        assertTrue(session.accept("Minecraft", "INFO", "hello world"));

        clock.addAndGet(50L);
        assertFalse(session.shouldFinish(clock.get()));

        clock.addAndGet(200L);
        assertTrue(session.shouldFinish(clock.get()));

        final CaptureOutcome outcome = session.release(CaptureSession.ReleaseReason.QUIET);
        assertEquals(List.of("hello world"), outcome.lines());
        assertEquals(CaptureSession.ReleaseReason.QUIET, outcome.reason());
        assertFalse(outcome.truncated());
        assertTrue(outcome.durationMillis() >= 250L);
    }

    @Test
    void finishesAtTheHardStopEvenWithoutOutput() {
        final CaptureSession session = session(settings(200L, 1_000L, 10, 1_000, 100));

        clock.addAndGet(999L);
        assertFalse(session.shouldFinish(clock.get()));

        clock.addAndGet(1L);
        assertTrue(session.shouldFinish(clock.get()));
        assertTrue(session.hardStopReached(clock.get()));

        final CaptureOutcome outcome = session.release(CaptureSession.ReleaseReason.MAX_WAIT);
        assertTrue(outcome.empty());
        assertEquals(CaptureSession.ReleaseReason.MAX_WAIT, outcome.reason());
    }

    @Test
    void releasesItselfWhenTheLineLimitIsReached() {
        final CaptureSession session = session(settings(200L, 5_000L, 2, 1_000, 100));
        assertTrue(session.accept("Minecraft", "INFO", "one"));
        assertTrue(session.accept("Minecraft", "INFO", "two"));

        assertFalse(session.accept("Minecraft", "INFO", "three"));

        assertFalse(session.active());
        assertEquals(CaptureSession.ReleaseReason.SATURATED, session.releaseReason());
        final CaptureOutcome outcome = session.outcome();
        assertEquals(2, outcome.lineCount());
        assertTrue(outcome.truncated());
        assertEquals(1, outcome.droppedLines());
    }

    @Test
    void truncatesVeryLongLinesAndStripsControlCharacters() {
        final CaptureSession session = session(settings(200L, 5_000L, 10, 1_000, 5));
        assertTrue(session.accept("Minecraft", "INFO", "abcdefghij"));
        assertTrue(session.accept("Minecraft", "WARN", "\u0007ok\u0000\r"));

        final CaptureOutcome outcome = session.release(CaptureSession.ReleaseReason.QUIET);
        assertEquals(List.of("abcde", "ok"), outcome.lines());
    }

    @Test
    void ignoresBlankLinesAndReportsReleasedSessionAsInactive() {
        final CaptureSession session = session(settings(200L, 5_000L, 10, 1_000, 100));
        assertFalse(session.accept("Minecraft", "INFO", "   "));

        session.release(CaptureSession.ReleaseReason.QUIET);
        assertFalse(session.active());
        assertFalse(session.accept("Minecraft", "INFO", "after release"));
        assertTrue(session.shouldFinish(clock.get()));
    }

    @Test
    void disabledCaptureIsReleasedImmediately() {
        final CaptureSession session = session(CaptureSettings.disabled());

        assertFalse(session.active());
        assertFalse(session.accept("Minecraft", "INFO", "hello"));
        assertEquals(CaptureSession.ReleaseReason.DISABLED, session.releaseReason());
    }

    @Test
    void cancelKeepsWhatWasCaptured() {
        final CaptureSession session = session(settings(200L, 5_000L, 10, 1_000, 100));
        session.accept("Minecraft", "INFO", "partial");

        final CaptureOutcome outcome = session.cancel();

        assertEquals(List.of("partial"), outcome.lines());
        assertEquals(CaptureSession.ReleaseReason.CANCELLED, outcome.reason());
    }
}