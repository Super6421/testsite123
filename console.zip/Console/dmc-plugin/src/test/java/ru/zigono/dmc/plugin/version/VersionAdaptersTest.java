package ru.zigono.dmc.plugin.version;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Adapter selection for the supported platforms.
 *
 * @author Zigono
 */
class VersionAdaptersTest {

    @Test
    void selectsThePaperAdapterForModernVersions() {
        final VersionAdapter adapter = VersionAdapters.select("1.21.1-R0.1-SNAPSHOT");

        assertEquals("paper-1.21", adapter.id());
        assertTrue(adapter.describe().contains("Paper"));
    }

    @Test
    void selectsTheLegacyAdapterForOlderOrUnknownVersions() {
        assertEquals("legacy-bukkit", VersionAdapters.select("1.20.4-R0.1-SNAPSHOT").id());
        assertEquals("legacy-bukkit", VersionAdapters.select("1.16.5-R0.1-SNAPSHOT").id());
        assertEquals("legacy-bukkit", VersionAdapters.select("not-a-version").id());
        assertEquals("legacy-bukkit", VersionAdapters.select(null).id());
        assertEquals("legacy-bukkit", VersionAdapters.select("").id());
    }

    @Test
    void detectsPaperOnTheClasspath() {
        assertTrue(VersionAdapters.paperPresent());
    }

    @Test
    void parsesVersionStrings() {
        assertEquals(1, VersionAdapters.parse("1.21.1-R0.1-SNAPSHOT")[0]);
        assertEquals(21, VersionAdapters.parse("1.21.1-R0.1-SNAPSHOT")[1]);
        assertEquals(2, VersionAdapters.parse("2.0")[0]);
        assertEquals(0, VersionAdapters.parse("1")[1]);
        assertNull(VersionAdapters.parse("abc"));
        assertNull(VersionAdapters.parse(null));
    }

    @Test
    void reportsWhichVersionsThePaperAdapterSupports() {
        assertTrue(PaperVersionAdapter.supports(1, 21));
        assertTrue(PaperVersionAdapter.supports(2, 0));
        assertFalse(PaperVersionAdapter.supports(1, 20));
    }
}