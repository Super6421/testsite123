const fs = require("fs");
console.log(fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/perm/Permission.java","utf8"));