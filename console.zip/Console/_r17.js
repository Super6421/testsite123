const fs = require("fs");
const t = fs.readFileSync("dmc-common/src/main/java/ru/zigono/dmc/common/staff/StaffConfig.java","utf8").split("\n");
console.log(t.slice(139, 215).map((l,i)=>(140+i)+": "+l).join("\n"));