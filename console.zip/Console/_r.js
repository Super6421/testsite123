const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/resources/config.yml","utf8").split("\n");
console.log(t.map((l,i)=>(i+1)+": "+l).join("\n"));