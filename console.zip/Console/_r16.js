const fs = require("fs");
const t = fs.readFileSync("dmc-plugin/src/main/java/ru/zigono/dmc/plugin/config/ServerTopology.java","utf8");
console.log(t);