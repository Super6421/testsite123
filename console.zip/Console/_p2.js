const fs = require("fs");
const file = "dmc-common/src/test/java/ru/zigono/dmc/common/perm/PermissionConfigSyntaxTest.java";
const t = fs.readFileSync(file, "utf8");
const anchor = `        assertTrue(config.resolve(null, List.of(), "3").allows("console.history"));
    }
}`;
if (!t.includes(anchor)) throw new Error("якорь не найден");
const addition = `        assertTrue(config.resolve(null, List.of(), "3").allows("console.history"));
    }

    @Test
    void understandsCommandsLuckPermsPermissionsServersAndGroups() {
        final PermissionConfig config = PermissionConfig.from(YamlConfig.parse(
                """
                permissions:
                  roles:
                    1: "console.read, kick, mute %player%, /tempban"
                    2: "essentials.heal, perm:worldedit.wand"
                    3: "server:survival, group:all, server:*"
                    4:
                      allow: console.execute
                      deny: kick
                """, "test.yml", false), Set.of());

        final PermissionSet commands = config.resolve(null, List.of("1"), "0");
        assertTrue(commands.allows("console.read"), "права консоли читаются как раньше");
        assertTrue(commands.allows("console.command.kick.steve"), "запись kick разрешает команду с аргументом");
        assertTrue(commands.allows("console.command.mute.steve"), "аргументы внутри записи не мешают");
        assertTrue(commands.allows("console.command.tempban.steve"), "слэш и cmd: — та же самая запись");
        assertFalse(commands.allows("console.command.ban.steve"), "чужая команда не разрешена");

        final PermissionSet permissions = config.resolve(null, List.of("2"), "0");
        assertTrue(permissions.allows("essentials.heal"), "право LuckPerms выдаётся как есть");
        assertTrue(permissions.allows("console.command.heal.steve"), "и разрешает команду в своём конце");
        assertTrue(permissions.allows("console.command.wand.steve"), "явная форма perm: работает так же");

        final PermissionSet targets = config.resolve(null, List.of("3"), "0");
        assertTrue(targets.allows("console.server.survival"));
        assertTrue(targets.allows("console.server.lobby"), "server:* — все серверы сети");
        assertTrue(targets.allows("console.group.all"));

        final PermissionSet denied = config.resolve(null, List.of("4"), "0");
        assertTrue(denied.allows("console.execute"));
        assertTrue(denied.denies("console.command.kick.steve"), "запрет команды действует и с аргументами");
    }
}`;
fs.writeFileSync(file, t.replace(anchor, addition), "utf8");
console.log("тест добавлен");