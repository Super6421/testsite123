const fs = require("fs");
const t = fs.readFileSync("dmc-gateway/src/main/java/ru/zigono/dmc/gateway/api/ControlApi.java","utf8").split("\n");
console.log(t.slice(150, 250).map((l,i)=>(151+i)+": "+l).join("\n"));