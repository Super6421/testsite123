package ru.zigono.dmc.gateway.config;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.EnvSubstitutor;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

/**
 * Guards the production example {@code config/gateway.example.yml}: the gateway must be able to start with the
 * documented file, so the example is loaded through the real parser and the real validators.
 *
 * @author Zigono
 */
class ExampleConfigTest {

    private static final String BACKSLASH = String.valueOf((char) 92);

    private static final String CONTROL_SECRET = "0123456789abcdef0123456789abcdef";

    @Test
    void loadsTheDocumentedProductionExample() {
        final Path file = example("gateway.example.yml");
        final GatewayConfig config = GatewayConfig.of(resolved(file, Map.of(
                "DMC_LOBBY_SECRET", "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f",
                "DMC_SURVIVAL_SECRET", "1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f",
                "DMC_SKYBLOCK_SECRET", "2f2f2f2f2f2f2f2f2f2f2f2f2f2f2f2f",
                "DMC_CONTROL_SECRET", CONTROL_SECRET,
                "POSTGRES_PASSWORD", "example-password",
                "TLS_KEYSTORE_PASSWORD", "changeit",
                "TLS_TRUSTSTORE_PASSWORD", "changeit")), file.getParent());

        assertEquals("gateway-1", config.gatewayId());
        assertEquals(Set.of("lobby", "survival", "skyblock"), Set.copyOf(config.catalog().enabledServerIds()));
        assertTrue(config.catalog().hasGroup("survival-network"));
        assertEquals(List.of("survival", "skyblock"), config.catalog().groupServers("survival-network"));
        assertEquals(Set.of("discord-bot"), config.controlSecrets().keySet());
        assertArrayEquals(CONTROL_SECRET.getBytes(StandardCharsets.UTF_8),
                config.controlSecrets().get("discord-bot"));
        assertEquals(3, config.serverSecrets().size());
        assertEquals(8443, config.transport().port());
        assertTrue(config.transport().tlsEnabled());
        assertEquals(1_048_576, config.transport().maxFrameBytes());
        assertTrue(config.metrics().enabled());
        assertEquals(9100, config.metrics().port());
        assertEquals("/metrics", config.metrics().path());
        assertEquals("postgresql", config.database().type());
        assertEquals(90, config.database().retentionDays());
        assertEquals(365, config.database().securityRetentionDays());
        assertFalse(config.redis().enabled());
        assertEquals("dmc:", config.redis().keyPrefix());
        assertFalse(config.emergencyModeStartsEnabled());
        assertThrows(CommandException.class,
                () -> config.normalizer().normalize("say " + BACKSLASH + "x"),
                "the documented blocked sequences must reject the literal backslash-x");
        assertThrows(CommandException.class, () -> config.normalizer().normalize("stop; stop"),
                "the documented blocked sequences must reject command chaining");
    }

    /**
     * @return the example from the repository root, walking up from the module directory
     */
    private static Path example(String name) {
        Path directory = Path.of("").toAbsolutePath();
        while (directory != null) {
            final Path candidate = directory.resolve("config").resolve(name);
            if (Files.isRegularFile(candidate)) {
                return candidate;
            }
            directory = directory.getParent();
        }
        assumeTrue(false, "config/" + name + " is not part of this checkout");
        throw new IllegalStateException("config/" + name + " is missing");
    }

    /**
     * Applies a deterministic environment to the example, the way a production start resolves it.
     */
    private static YamlConfig resolved(Path file, Map<String, String> environment) {
        final YamlConfig document = YamlConfig.load(file, false);
        final Map<String, Object> values = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : document.asMap().entrySet()) {
            values.put(entry.getKey(),
                    EnvSubstitutor.apply(entry.getValue(), environment, document.source(), false));
        }
        return YamlConfig.of(values, document.source());
    }
}
