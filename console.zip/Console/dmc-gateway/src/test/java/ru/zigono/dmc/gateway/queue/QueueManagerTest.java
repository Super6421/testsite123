package ru.zigono.dmc.gateway.queue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Multi server execution policy: {@code execution}, {@code failure_policy} and dry run.
 *
 * @author Zigono
 */
class QueueManagerTest {

    private static final UserContext USER = UserContext.of("user", "Zigono", "guild", "channel");
    private static final CommandVisibility VISIBILITY = new CommandVisibility(true, true, null, null, null, null);

    /** Records the server each command went to and answers after a fixed delay. */
    private static final class RecordingDispatcher implements CommandDispatcher {

        private final List<String> servers = Collections.synchronizedList(new ArrayList<>());
        private final Function<String, ServerOutcome> answer;
        private final long delayMillis;
        private final AtomicInteger calls = new AtomicInteger();

        RecordingDispatcher(Function<String, ServerOutcome> answer, long delayMillis) {
            this.answer = answer;
            this.delayMillis = delayMillis;
        }

        @Override
        public boolean available(String serverId) {
            return true;
        }

        @Override
        public Optional<Dispatch> dispatch(QueuedCommand command) {
            calls.incrementAndGet();
            servers.add(command.serverId());
            final ServerOutcome outcome = answer.apply(command.serverId());
            return Optional.of(new Dispatch(
                    CompletableFuture.supplyAsync(() -> {
                        sleep(delayMillis);
                        return outcome;
                    }),
                    CompletableFuture.completedFuture(true)));
        }

        @Override
        public void onDisconnect(String serverId, String reason) {
        }

        int calls() {
            return calls.get();
        }
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
    }

    private static QueueManager manager(GatewayConfig config, CommandDispatcher dispatcher) {
        return new QueueManager(config, new RetryPolicy(config.retry()), dispatcher, new Metrics());
    }

    @Test
    @DisplayName("execution: parallel runs every server at the same time")
    void parallelRunsEveryServerAtOnce(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        final RecordingDispatcher dispatcher = new RecordingDispatcher(
                server -> ServerOutcome.success(server, List.of("ok"), 200L, "request"), 200L);
        final QueueManager manager = manager(config, dispatcher);
        final long started = System.currentTimeMillis();
        final List<ServerOutcome> outcomes = manager.execute(new QueueManager.ExecutionRequest("request",
                List.of("survival", "lobby", "skyblock"), "say hi", USER, VISIBILITY, false, 5_000L)).join();
        final long elapsed = System.currentTimeMillis() - started;
        assertEquals(3, outcomes.size());
        assertTrue(outcomes.stream().allMatch(outcome -> outcome.status() == ExecutionStatus.SUCCESS));
        assertTrue(elapsed < 550L, "parallel execution took " + elapsed + " ms");
        manager.close();
    }

    @Test
    @DisplayName("execution: sequential runs one server after another")
    void sequentialRunsServersOneByOne(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.configWith(directory,
                "execution: parallel", "execution: sequential");
        final RecordingDispatcher dispatcher = new RecordingDispatcher(
                server -> ServerOutcome.success(server, List.of("ok"), 200L, "request"), 200L);
        final QueueManager manager = manager(config, dispatcher);
        final long started = System.currentTimeMillis();
        final List<ServerOutcome> outcomes = manager.execute(new QueueManager.ExecutionRequest("request",
                List.of("survival", "lobby", "skyblock"), "say hi", USER, VISIBILITY, false, 10_000L)).join();
        final long elapsed = System.currentTimeMillis() - started;
        assertEquals(3, outcomes.size());
        assertTrue(elapsed >= 550L, "sequential execution took only " + elapsed + " ms");
        assertEquals(List.of("survival", "lobby", "skyblock"), dispatcher.servers);
        manager.close();
    }

    @Test
    @DisplayName("failure_policy: stop cancels the remaining servers")
    void stopPolicyCancelsRemainingServers(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.configWith(directory,
                "execution: parallel", "execution: sequential",
                "failure_policy: continue", "failure_policy: stop");
        final RecordingDispatcher dispatcher = new RecordingDispatcher(server -> "survival".equals(server)
                ? ServerOutcome.failure(server, ExecutionStatus.FAILED, "FAILED", "nope")
                : ServerOutcome.success(server, List.of("ok"), 1L, "request"), 1L);
        final QueueManager manager = manager(config, dispatcher);
        final List<ServerOutcome> outcomes = manager.execute(new QueueManager.ExecutionRequest("request",
                List.of("survival", "lobby", "skyblock"), "say hi", USER, VISIBILITY, false, 10_000L)).join();
        assertEquals(ExecutionStatus.FAILED, outcomes.get(0).status());
        assertEquals(ExecutionStatus.CANCELLED, outcomes.get(1).status());
        assertEquals(ExecutionStatus.CANCELLED, outcomes.get(2).status());
        assertEquals(1, dispatcher.calls(), "servers after the failure must not be contacted");
        manager.close();
    }

    @Test
    @DisplayName("failure_policy: continue still runs every server")
    void continuePolicyRunsEveryServer(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        final RecordingDispatcher dispatcher = new RecordingDispatcher(server -> "survival".equals(server)
                ? ServerOutcome.failure(server, ExecutionStatus.FAILED, "FAILED", "nope")
                : ServerOutcome.success(server, List.of("ok"), 1L, "request"), 1L);
        final QueueManager manager = manager(config, dispatcher);
        final List<ServerOutcome> outcomes = manager.execute(new QueueManager.ExecutionRequest("request",
                List.of("survival", "lobby"), "say hi", USER, VISIBILITY, false, 10_000L)).join();
        assertEquals(2, outcomes.size());
        assertEquals(ExecutionStatus.FAILED, outcomes.get(0).status());
        assertEquals(ExecutionStatus.SUCCESS, outcomes.get(1).status());
        assertEquals(2, dispatcher.calls());
        manager.close();
    }

    @Test
    @DisplayName("a dry run never contacts a Minecraft server")
    void dryRunNeverContactsServers(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        final RecordingDispatcher dispatcher = new RecordingDispatcher(
                server -> ServerOutcome.success(server, List.of("ok"), 1L, "request"), 1L);
        final QueueManager manager = manager(config, dispatcher);
        final List<ServerOutcome> outcomes = manager.execute(new QueueManager.ExecutionRequest("request",
                List.of("survival", "lobby"), "stop", USER, VISIBILITY, true, 10_000L)).join();
        assertEquals(2, outcomes.size());
        assertTrue(outcomes.stream().allMatch(outcome -> outcome.status() == ExecutionStatus.DRY_RUN));
        assertEquals(0, dispatcher.calls(), "a dry run must never reach the plugin");
        manager.close();
    }

    @Test
    @DisplayName("different servers are served by different queues")
    void usesOneQueuePerServer(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        final RecordingDispatcher dispatcher = new RecordingDispatcher(
                server -> ServerOutcome.success(server, List.of("ok"), 1L, "request"), 1L);
        final QueueManager manager = manager(config, dispatcher);
        manager.execute(new QueueManager.ExecutionRequest("request", List.of("survival", "lobby"), "say hi",
                USER, VISIBILITY, false, 10_000L)).join();
        assertTrue(manager.queue("survival") != manager.queue("lobby"));
        assertEquals(0, manager.totalQueueSize());
        manager.close();
    }
}