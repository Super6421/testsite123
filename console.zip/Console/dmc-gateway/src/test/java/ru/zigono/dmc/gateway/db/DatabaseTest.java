package ru.zigono.dmc.gateway.db;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;
import ru.zigono.dmc.protocol.dto.HistoryEntry;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Database bootstrap: migrations, audit trail, immutable security audit and retention.
 *
 * @author Zigono
 */
class DatabaseTest {

    private static AuditRepository.AuditRecord record(String requestId, String serverId, String command, long at) {
        return new AuditRepository.AuditRecord(requestId, "user-1", "Zigono", "guild-1", "channel-1", null, null,
                List.of("role-1"), "survival", serverId, command, command, "SUCCESS", 12L, "ok", null, null, false, at);
    }

    private static List<String> tables(Database database) throws Exception {
        final List<String> names = new ArrayList<>();
        try (Connection connection = database.connection();
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(
                     "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name")) {
            while (result.next()) {
                names.add(result.getString(1));
            }
        }
        return names;
    }

    @Test
    @DisplayName("migrations create every table the gateway needs")
    void appliesMigrations(@TempDir Path directory) throws Exception {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            final List<String> names = tables(database);
            assertTrue(names.contains("schema_migrations"));
            assertTrue(names.contains("audit_log"));
            assertTrue(names.contains("security_audit"));
            assertTrue(names.contains("server_metadata"));
            assertTrue(names.contains("gateway_state"));
            assertEquals("sqlite", database.dialect());
            assertTrue(database.healthy());
        }
    }

    @Test
    @DisplayName("migrations are idempotent")
    void migrationsAreIdempotent(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            database.migrate();
            database.migrate();
            assertEquals(1, MigrationRunner.discover("sqlite").size());
        }
    }

    @Test
    @DisplayName("the audit trail can be searched by command, server and status")
    void storesAndSearchesAudit(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            final AuditRepository repository = new AuditRepository(database);
            final long now = System.currentTimeMillis();
            repository.insert(record("r1", "survival", "cmi heal Zigono", now - 1_000L));
            repository.insert(record("r2", "lobby", "say hello", now));

            assertEquals(2, repository.count(AuditRepository.HistoryQuery.of(null, null, null, null, null, null,
                    50, 0)));

            final List<HistoryEntry> byServer = repository.search(AuditRepository.HistoryQuery.of("survival", null,
                    null, null, null, null, 50, 0));
            assertEquals(1, byServer.size());
            assertEquals("cmi heal Zigono", byServer.get(0).command());

            final List<HistoryEntry> byFragment = repository.search(AuditRepository.HistoryQuery.of(null, null,
                    "say", null, null, null, 50, 0));
            assertEquals(1, byFragment.size());

            final List<HistoryEntry> newestFirst = repository.search(AuditRepository.HistoryQuery.of(null, null,
                    null, null, null, null, 50, 0));
            assertEquals("say hello", newestFirst.get(0).command());
        }
    }

    @Test
    @DisplayName("the security audit is append only and readable")
    void storesSecurityAudit(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            final SecurityAuditRepository repository = new SecurityAuditRepository(database);
            repository.insert(SecurityEvent.of("PROTOCOL_VIOLATION", SecurityEvent.Severity.CRITICAL, "bad frame"));
            repository.insert(SecurityEvent.of("DANGEROUS_COMMAND", SecurityEvent.Severity.WARNING, "stop"));
            final List<SecurityEvent> events = repository.recent(10);
            assertEquals(2, events.size());
            assertTrue(events.stream().anyMatch(event -> event.severity() == SecurityEvent.Severity.CRITICAL));
        }
    }

    @Test
    @DisplayName("retention removes outdated records but keeps the recent ones")
    void retentionRemovesOldRecords(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            final AuditRepository repository = new AuditRepository(database);
            final SecurityAuditRepository security = new SecurityAuditRepository(database);
            final long now = System.currentTimeMillis();
            final long ancient = now - java.time.Duration.ofDays(400).toMillis();
            repository.insert(record("old", "survival", "ancient", ancient));
            repository.insert(record("new", "survival", "recent", now));
            security.insert(new SecurityEvent(null, "OLD", SecurityEvent.Severity.INFO, null, null, null, null,
                    null, null, null, "ancient", ancient));
            security.insert(new SecurityEvent(null, "NEW", SecurityEvent.Severity.INFO, null, null, null, null,
                    null, null, null, "recent", now));

            final RetentionService retention = new RetentionService(config.database(), repository, security);
            assertEquals(1, retention.run());

            final List<HistoryEntry> remaining = repository.search(AuditRepository.HistoryQuery.of(null, null, null,
                    null, null, null, 50, 0));
            assertEquals(1, remaining.size());
            assertEquals("recent", remaining.get(0).command());
            assertEquals(1, security.recent(10).size());
            retention.close();
        }
    }

    @Test
    @DisplayName("the emergency switch state survives a restart")
    void emergencyStateIsPersisted(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        try (Database database = Database.open(config.database())) {
            new ru.zigono.dmc.gateway.EmergencySwitch(true, new StateRepository(database)).set(true);
        }
        try (Database database = Database.open(config.database())) {
            final ru.zigono.dmc.gateway.EmergencySwitch emergency =
                    new ru.zigono.dmc.gateway.EmergencySwitch(false, new StateRepository(database));
            assertTrue(emergency.enabled(), "emergency mode must not silently disappear on restart");
        }
    }
}