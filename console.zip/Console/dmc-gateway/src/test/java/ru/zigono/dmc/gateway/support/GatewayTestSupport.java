package ru.zigono.dmc.gateway.support;

import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Shared helpers for the gateway test suite.
 *
 * @author Zigono
 */
public final class GatewayTestSupport {

    public static final String CONFIG_RESOURCE = "gateway-test.yml";

    private GatewayTestSupport() {
    }

    /** Reads a classpath resource as UTF-8 text. */
    public static String read(String resource) {
        try (var stream = GatewayTestSupport.class.getClassLoader().getResourceAsStream(resource)) {
            if (stream == null) {
                throw new IllegalStateException("Missing test resource " + resource);
            }
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8).replace("\r\n", "\n");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /** Materializes the standard test configuration inside {@code directory} and loads it. */
    public static GatewayConfig config(Path directory) {
        return write(directory, read(CONFIG_RESOURCE));
    }

    /** Materializes the standard test configuration after applying the given replacements. */
    public static GatewayConfig configWith(Path directory, String... replacements) {
        String yaml = read(CONFIG_RESOURCE);
        for (int index = 0; index + 1 < replacements.length; index += 2) {
            yaml = yaml.replace(replacements[index], replacements[index + 1]);
        }
        return write(directory, yaml);
    }

    /**
     * Writes the given YAML into {@code directory/gateway.yml}, pointing the SQLite file at the directory, and
     * loads it as a {@link GatewayConfig}.
     */
    public static GatewayConfig write(Path directory, String yaml) {
        try {
            Files.createDirectories(directory);
            final String database = directory.resolve("dmc.db").toAbsolutePath().toString().replace('\\', '/');
            final Path file = directory.resolve("gateway.yml");
            Files.writeString(file, yaml.replace("data/test.db", database), StandardCharsets.UTF_8);
            return GatewayConfig.load(file);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}