package ru.zigono.dmc.gateway.queue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * The retry policy must never replay a command that may already have changed the world.
 *
 * @author Zigono
 */
class RetryPolicyTest {

    private static RetryPolicy policy(boolean enabled, int attempts) {
        return new RetryPolicy(new GatewayConfig.RetrySettings(enabled, attempts, Duration.ofMillis(5)));
    }

    @Test
    @DisplayName("a command that was never handed to the plugin is retried")
    void retriesUndeliveredCommands() {
        final RetryPolicy policy = policy(true, 3);
        assertTrue(policy.canRetry(1, false, RetryPolicy.AttemptResult.NOT_DISPATCHED, false));
        assertTrue(policy.canRetry(1, false, RetryPolicy.AttemptResult.DISPATCH_FAILED, false));
        assertTrue(policy.canRetry(1, false, RetryPolicy.AttemptResult.SERVER_OFFLINE, false));
    }

    @Test
    @DisplayName("an accepted command is never retried, even when the result is unknown")
    void neverRetriesAcceptedCommands() {
        final RetryPolicy policy = policy(true, 5);
        assertFalse(policy.canRetry(1, true, RetryPolicy.AttemptResult.ACCEPTED_UNKNOWN, false));
        assertFalse(policy.canRetry(1, true, RetryPolicy.AttemptResult.DISPATCH_FAILED, false));
        assertFalse(policy.canRetry(1, true, RetryPolicy.AttemptResult.NOT_DISPATCHED, false));
    }

    @Test
    @DisplayName("the attempt budget and the enabled flag are honoured")
    void honoursBudget() {
        assertFalse(policy(true, 3).canRetry(3, false, RetryPolicy.AttemptResult.DISPATCH_FAILED, false));
        assertTrue(policy(true, 3).canRetry(2, false, RetryPolicy.AttemptResult.DISPATCH_FAILED, false));
        assertFalse(policy(false, 3).canRetry(1, false, RetryPolicy.AttemptResult.DISPATCH_FAILED, false));
        assertFalse(policy(true, 3).canRetry(1, false, RetryPolicy.AttemptResult.DISPATCH_FAILED, true));
    }

    @Test
    @DisplayName("a completed attempt is never retried")
    void neverRetriesCompletedAttempts() {
        final RetryPolicy policy = policy(true, 3);
        assertFalse(policy.canRetry(1, false, RetryPolicy.AttemptResult.SUCCESS, false));
        assertFalse(policy.canRetry(1, false, RetryPolicy.AttemptResult.FAILED, false));
    }
}