package ru.zigono.dmc.gateway.queue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Behaviour of the per server FIFO queue: ordering, capacity, retry safety and disconnect handling.
 *
 * @author Zigono
 */
class ServerQueueTest {

    private static final UserContext USER = UserContext.of("user", "Zigono", "guild", "channel");
    private static final CommandVisibility VISIBILITY = new CommandVisibility(true, true, null, null, null, null);

    private static GatewayConfig.QueueSettings queue(int maxSize, String onDisconnect) {
        return new GatewayConfig.QueueSettings(true, maxSize, Duration.ofSeconds(5), onDisconnect,
                Duration.ofSeconds(1));
    }

    private static RetryPolicy retry(boolean enabled, int attempts) {
        return new RetryPolicy(new GatewayConfig.RetrySettings(enabled, attempts, Duration.ofMillis(5)));
    }

    private static QueuedCommand command(String value) {
        return new QueuedCommand("request", "survival", value, USER, VISIBILITY, 3_000L, false);
    }

    private static ServerOutcome success(String serverId, String requestId) {
        return ServerOutcome.success(serverId, List.of("ok"), 1L, requestId);
    }

    /** Test double for the transport boundary: it records calls and answers with a scripted result. */
    private static final class ScriptedDispatcher implements CommandDispatcher {

        private final Function<QueuedCommand, Optional<Dispatch>> script;
        private final List<String> dispatched = Collections.synchronizedList(new ArrayList<>());
        private final AtomicInteger calls = new AtomicInteger();
        private volatile boolean available = true;

        ScriptedDispatcher(Function<QueuedCommand, Optional<Dispatch>> script) {
            this.script = script;
        }

        /** A dispatcher that accepts every command immediately and answers with a real success outcome. */
        static ScriptedDispatcher accepting() {
            return new ScriptedDispatcher(command -> Optional.of(accept(
                    success("survival", command.requestId()))));
        }

        static Dispatch accept(ServerOutcome outcome) {
            return new Dispatch(CompletableFuture.completedFuture(outcome), CompletableFuture.completedFuture(true));
        }

        static Dispatch lose(ServerOutcome outcome, Throwable cause) {
            final CompletableFuture<ServerOutcome> result = new CompletableFuture<>();
            result.completeExceptionally(cause);
            return new Dispatch(result, CompletableFuture.completedFuture(true));
        }

        static Dispatch reject(ServerOutcome outcome) {
            return new Dispatch(CompletableFuture.completedFuture(outcome), CompletableFuture.completedFuture(false));
        }

        @Override
        public boolean available(String serverId) {
            return available;
        }

        @Override
        public Optional<Dispatch> dispatch(QueuedCommand command) {
            dispatched.add(command.command());
            calls.incrementAndGet();
            return script.apply(command);
        }

        @Override
        public void onDisconnect(String serverId, String reason) {
        }

        void availability(boolean value) {
            this.available = value;
        }

        int calls() {
            return calls.get();
        }
    }

    @Test
    @DisplayName("commands of one server are executed in submission order")
    void preservesFifoOrder() throws Exception {
        final ScriptedDispatcher dispatcher = ScriptedDispatcher.accepting();
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 3), dispatcher,
                new Metrics());
        final CountDownLatch done = new CountDownLatch(5);
        for (int index = 0; index < 5; index++) {
            queue.submit(command("say message-" + index)).thenRun(done::countDown);
        }
        assertTrue(done.await(10, TimeUnit.SECONDS), "all commands must complete");
        assertEquals(List.of("say message-0", "say message-1", "say message-2", "say message-3", "say message-4"),
                dispatcher.dispatched);
        queue.close();
    }

    @Test
    @DisplayName("a full queue is reported as QUEUE_FULL instead of blocking")
    void rejectsWhenFull() throws Exception {
        final CountDownLatch firstStarted = new CountDownLatch(1);
        final CountDownLatch release = new CountDownLatch(1);
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> {
            firstStarted.countDown();
            awaitQuietly(release);
            return Optional.of(ScriptedDispatcher.accept(success("survival", command.requestId())));
        });
        final ServerQueue queue = new ServerQueue("survival", queue(2, "cancel"), retry(true, 3), dispatcher,
                new Metrics());
        final CompletableFuture<ServerOutcome> running = queue.submit(command("say running"));
        assertTrue(firstStarted.await(5, TimeUnit.SECONDS), "the worker must pick up the first command");
        final CompletableFuture<ServerOutcome> second = queue.submit(command("say second"));
        final CompletableFuture<ServerOutcome> third = queue.submit(command("say third"));
        final CompletableFuture<ServerOutcome> overflow = queue.submit(command("say overflow"));
        assertEquals(ExecutionStatus.QUEUE_FULL, overflow.get(5, TimeUnit.SECONDS).status());
        release.countDown();
        assertEquals(ExecutionStatus.SUCCESS, running.get(5, TimeUnit.SECONDS).status());
        assertEquals(ExecutionStatus.SUCCESS, second.get(5, TimeUnit.SECONDS).status());
        assertEquals(ExecutionStatus.SUCCESS, third.get(5, TimeUnit.SECONDS).status());
        queue.close();
    }

    @Test
    @DisplayName("a command that was never handed over is retried and can still succeed")
    void retriesUndeliveredCommand() throws Exception {
        final AtomicInteger attempts = new AtomicInteger();
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> {
            if (attempts.incrementAndGet() == 1) {
                return Optional.empty();
            }
            return Optional.of(ScriptedDispatcher.accept(success("survival", command.requestId())));
        });
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 3), dispatcher,
                new Metrics());
        final ServerOutcome outcome = queue.submit(command("say hello")).get(10, TimeUnit.SECONDS);
        assertEquals(ExecutionStatus.SUCCESS, outcome.status());
        assertEquals(2, attempts.get());
        queue.close();
    }

    @Test
    @DisplayName("a command that was accepted is never replayed when its result is lost")
    void neverReplaysAcceptedCommand() throws Exception {
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> Optional.of(
                ScriptedDispatcher.lose(success("survival", command.requestId()),
                        new IllegalStateException("connection reset"))));
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 5), dispatcher,
                new Metrics());
        final ServerOutcome outcome = queue.submit(command("stop")).get(10, TimeUnit.SECONDS);
        assertEquals(ExecutionStatus.UNKNOWN, outcome.status());
        assertEquals(1, dispatcher.calls(), "an accepted command must not be replayed");
        queue.close();
    }

    @Test
    @DisplayName("a rejected command is reported without a retry")
    void reportsRejectedCommand() throws Exception {
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> Optional.of(
                ScriptedDispatcher.reject(ServerOutcome.failure("survival", ExecutionStatus.FAILED,
                        "INTERNAL_ERROR", "the plugin rejected the command"))));
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 5), dispatcher,
                new Metrics());
        final ServerOutcome outcome = queue.submit(command("say hi")).get(10, TimeUnit.SECONDS);
        assertEquals(ExecutionStatus.FAILED, outcome.status());
        assertEquals(1, dispatcher.calls());
        queue.close();
    }

    @Test
    @DisplayName("on_disconnect: cancel resolves queued commands with OFFLINE")
    void cancelsQueuedCommandsOnDisconnect() throws Exception {
        final CountDownLatch firstStarted = new CountDownLatch(1);
        final CountDownLatch release = new CountDownLatch(1);
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> {
            firstStarted.countDown();
            awaitQuietly(release);
            return Optional.of(ScriptedDispatcher.accept(success("survival", command.requestId())));
        });
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 3), dispatcher,
                new Metrics());
        queue.submit(command("say running"));
        assertTrue(firstStarted.await(5, TimeUnit.SECONDS));
        final CompletableFuture<ServerOutcome> queued = queue.submit(command("say queued"));
        queue.submit(command("say queued-2"));
        queue.onDisconnect("connection closed");
        assertEquals(ExecutionStatus.OFFLINE, queued.get(5, TimeUnit.SECONDS).status());
        release.countDown();
        queue.close();
    }

    @Test
    @DisplayName("on_disconnect: hold keeps waiting for the server to come back")
    void holdsCommandsOnDisconnect() throws Exception {
        final ScriptedDispatcher dispatcher = ScriptedDispatcher.accepting();
        dispatcher.availability(false);
        final ServerQueue queue = new ServerQueue("survival", queue(10, "hold"), retry(true, 3), dispatcher,
                new Metrics());
        final CompletableFuture<ServerOutcome> pending = queue.submit(command("say later"));
        queue.onDisconnect("connection closed");
        Thread.sleep(120L);
        assertFalse(pending.isDone(), "on_disconnect: hold must keep the command");
        dispatcher.availability(true);
        queue.onReconnect();
        assertEquals(ExecutionStatus.SUCCESS, pending.get(10, TimeUnit.SECONDS).status());
        queue.close();
    }

    @Test
    @DisplayName("shutdown cancels everything that is still pending")
    void shutdownCancelsPendingCommands() throws Exception {
        final CountDownLatch firstStarted = new CountDownLatch(1);
        final CountDownLatch release = new CountDownLatch(1);
        final ScriptedDispatcher dispatcher = new ScriptedDispatcher(command -> {
            firstStarted.countDown();
            awaitQuietly(release);
            return Optional.of(ScriptedDispatcher.accept(success("survival", command.requestId())));
        });
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 3), dispatcher,
                new Metrics());
        queue.submit(command("say running"));
        assertTrue(firstStarted.await(5, TimeUnit.SECONDS));
        final CompletableFuture<ServerOutcome> queued = queue.submit(command("say queued"));
        queue.close();
        assertEquals(ExecutionStatus.CANCELLED, queued.get(5, TimeUnit.SECONDS).status());
        release.countDown();
    }

    @Test
    @DisplayName("an outcome carries the request id of the submission")
    void keepsRequestCorrelation() throws Exception {
        final ServerQueue queue = new ServerQueue("survival", queue(10, "cancel"), retry(true, 3),
                ScriptedDispatcher.accepting(), new Metrics());
        final ServerOutcome outcome = queue.submit(command("say hi")).get(5, TimeUnit.SECONDS);
        assertNull(outcome.errorCode());
        assertEquals("request", outcome.requestId());
        queue.close();
    }

    private static void awaitQuietly(CountDownLatch latch) {
        try {
            latch.await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}