package ru.zigono.dmc.gateway;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.MessageTypes;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.TransportClient;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.charset.StandardCharsets;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * End to end test over real sockets: a Minecraft plugin and a control client authenticate against a running
 * gateway, a Discord command travels through the whole pipeline and the real result comes back.
 * <p>Nothing here is simulated except the Minecraft side of the plugin, which is a real protocol peer.</p>
 *
 * @author Zigono
 */
class GatewayPipelineIntegrationTest {

    private static final byte[] SURVIVAL_KEY = "survival-secret-000000000000000".getBytes(StandardCharsets.UTF_8);
    private static final byte[] LOBBY_KEY = "lobby-secret-00000000000000000".getBytes(StandardCharsets.UTF_8);
    private static final byte[] BOT_KEY = "control-secret-0000000000000000".getBytes(StandardCharsets.UTF_8);

    private static int freePort() throws Exception {
        try (ServerSocket socket = new ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }

    private static TransportSettings settings(int port, String clientId, String role) {
        return new TransportSettings(false, true, "127.0.0.1", port, null, null, null, null, null, null, null, null,
                false, List.of("TLSv1.3"), 1_048_576, Duration.ofSeconds(5), Duration.ofSeconds(5),
                Duration.ofSeconds(30), Duration.ofSeconds(2), Duration.ofMillis(100), Duration.ofSeconds(2), 2.0d,
                2, clientId, role);
    }

    /** A real protocol peer that behaves like the Paper plugin. */
    private static final class MinecraftPeer implements TransportClient.Listener {

        private final TransportClient client;
        private final String serverId;
        private final CountDownLatch authenticated = new CountDownLatch(1);
        private final List<String> executed = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
        private final AtomicInteger accepted = new AtomicInteger();
        private volatile ExecutionStatus scripted = ExecutionStatus.SUCCESS;

        MinecraftPeer(String serverId, byte[] secret, int port) {
            this.serverId = serverId;
            this.client = new TransportClient(settings(port, serverId, "plugin"),
                    KeyResolver.single(serverId, secret), this);
        }

        void start() {
            client.start();
        }

        boolean awaitAuthentication() throws InterruptedException {
            return authenticated.await(15, TimeUnit.SECONDS);
        }

        void sendHeartbeat(PluginMessages.Heartbeat heartbeat) {
            client.send(heartbeat);
        }

        void scripted(ExecutionStatus status) {
            this.scripted = status;
        }

        int acceptedCount() {
            return accepted.get();
        }

        List<String> executed() {
            return List.copyOf(executed);
        }

        void close() {
            client.close();
        }

        @Override
        public void onConnected(Connection connection) {
            final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
            hello.role = "plugin";
            hello.agentName = "DiscordMinecraftConsole";
            hello.agentVersion = "1.0.0";
            hello.platform = "Paper 1.21.1";
            hello.serverId = serverId;
            hello.capabilities = List.of("commands", "console-capture", "heartbeat");
            client.send(hello);
        }

        @Override
        public void onMessage(Connection connection, Message message) {
            if (message instanceof HandshakeMessages.HelloAck ack) {
                final HandshakeMessages.AuthRequest auth = ack.correlate(new HandshakeMessages.AuthRequest());
                auth.role = "plugin";
                auth.serverId = serverId;
                auth.challenge = ack.challenge;
                auth.agentVersion = "1.0.0";
                client.send(auth);
                return;
            }
            if (message instanceof HandshakeMessages.AuthResult result) {
                if (result.authenticated) {
                    authenticated.countDown();
                }
                return;
            }
            if (message instanceof PluginMessages.CommandDispatch dispatch) {
                accepted.incrementAndGet();
                final PluginMessages.CommandAccepted ack = dispatch.correlate(new PluginMessages.CommandAccepted());
                ack.serverId = serverId;
                ack.accepted = true;
                ack.acceptedAt = System.currentTimeMillis();
                client.send(ack);

                executed.add(dispatch.command);
                final PluginMessages.CommandOutcomeMessage outcome =
                        dispatch.correlate(new PluginMessages.CommandOutcomeMessage());
                outcome.serverId = serverId;
                outcome.command = dispatch.command;
                outcome.outcome = scripted == ExecutionStatus.SUCCESS
                        ? ServerOutcome.success(serverId, List.of("[Server] healed Zigono"), 4L,
                        dispatch.getRequestId())
                        : ServerOutcome.failure(serverId, scripted, scripted.name(), "scripted " + scripted);
                client.send(outcome);
                return;
            }
            if (message instanceof HandshakeMessages.Ping ping) {
                final HandshakeMessages.Pong pong = ping.correlate(new HandshakeMessages.Pong());
                pong.sentAt = ping.sentAt;
                pong.sequence = ping.sequence;
                pong.serverTime = System.currentTimeMillis();
                client.send(pong);
            }
        }

        @Override
        public void onDisconnected(Throwable cause) {
        }
    }

    /** A real protocol peer that behaves like the Discord bot. */
    private static final class ControlPeer implements TransportClient.Listener {

        private final TransportClient client;
        private final CountDownLatch authenticated = new CountDownLatch(1);

        ControlPeer(String clientId, byte[] secret, int port) {
            this.client = new TransportClient(settings(port, clientId, "control"),
                    KeyResolver.single(clientId, secret), this);
        }

        void start() {
            client.start();
        }

        boolean awaitAuthentication() throws InterruptedException {
            return authenticated.await(15, TimeUnit.SECONDS);
        }

        TransportClient client() {
            return client;
        }

        void close() {
            client.close();
        }

        @Override
        public void onConnected(Connection connection) {
            final HandshakeMessages.Hello hello = new HandshakeMessages.Hello();
            hello.role = "control";
            hello.agentName = "dmc-bot";
            hello.agentVersion = "1.0.0";
            hello.platform = "JDA 5.6.1";
            client.send(hello);
        }

        @Override
        public void onMessage(Connection connection, Message message) {
            if (message instanceof HandshakeMessages.HelloAck ack) {
                final HandshakeMessages.AuthRequest auth = ack.correlate(new HandshakeMessages.AuthRequest());
                auth.role = "control";
                auth.challenge = ack.challenge;
                auth.agentVersion = "1.0.0";
                client.send(auth);
                return;
            }
            if (message instanceof HandshakeMessages.AuthResult result && result.authenticated) {
                authenticated.countDown();
            }
        }

        @Override
        public void onDisconnected(Throwable cause) {
        }
    }

    private static ControlMessages.ExecuteRequest execute(String userId, TargetSelection target, String command) {
        final ControlMessages.ExecuteRequest request = new ControlMessages.ExecuteRequest();
        request.user = new UserContext(userId, userId, "999999999999999999", "555555555555555555", null, null,
                List.of(), List.of(), List.of());
        request.target = target;
        request.command = command;
        request.timeoutMillis = 10_000L;
        request.issuedAt = System.currentTimeMillis();
        return request;
    }

    private static TargetSelection server(String id) {
        return new TargetSelection(id, List.of(), null, false);
    }

    private static ControlMessages.ExecuteResponse send(ControlPeer bot, ControlMessages.ExecuteRequest request)
            throws Exception {
        final Message response = bot.client().request(request, Duration.ofSeconds(15)).get(20, TimeUnit.SECONDS);
        assertTrue(response instanceof ControlMessages.ExecuteResponse,
                "unexpected response " + MessageTypes.nameOf(response.getClass()));
        return (ControlMessages.ExecuteResponse) response;
    }

    @Test
    @DisplayName("Discord to Minecraft and back: a real command is executed and the real result returned")
    void executesRealCommand(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final MinecraftPeer plugin = new MinecraftPeer("survival", SURVIVAL_KEY, port);
        final ControlPeer bot = new ControlPeer("bot", BOT_KEY, port);
        try {
            plugin.start();
            assertTrue(plugin.awaitAuthentication(), "the plugin must authenticate");
            bot.start();
            assertTrue(bot.awaitAuthentication(), "the bot must authenticate");
            waitFor(() -> gateway.registry().state("survival").status() != ServerStatus.OFFLINE);

            final ControlMessages.ExecuteResponse response = send(bot,
                    execute("user-operator", server("survival"), "cmi heal Zigono"));
            assertNull(response.errorCode);
            assertEquals(1, response.outcomes.size());
            assertEquals(ExecutionStatus.SUCCESS, response.outcomes.get(0).status());
            assertEquals(List.of("[Server] healed Zigono"), response.outcomes.get(0).output());
            assertEquals(List.of("cmi heal Zigono"), plugin.executed());
        } finally {
            bot.close();
            plugin.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("an offline server is reported honestly instead of being answered with a fake result")
    void reportsOfflineServer(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final ControlPeer bot = new ControlPeer("bot", BOT_KEY, port);
        try {
            bot.start();
            assertTrue(bot.awaitAuthentication());
            final ControlMessages.ExecuteResponse response = send(bot,
                    execute("user-operator", server("survival"), "cmi heal Zigono"));
            assertEquals(1, response.outcomes.size());
            assertEquals(ExecutionStatus.OFFLINE, response.outcomes.get(0).status());
            assertEquals("SERVER_OFFLINE", response.outcomes.get(0).errorCode());
        } finally {
            bot.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("a command is broadcast to several Minecraft servers at once")
    void broadcastsToSeveralServers(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final MinecraftPeer survival = new MinecraftPeer("survival", SURVIVAL_KEY, port);
        final MinecraftPeer lobby = new MinecraftPeer("lobby", LOBBY_KEY, port);
        final ControlPeer bot = new ControlPeer("bot", BOT_KEY, port);
        try {
            survival.start();
            lobby.start();
            assertTrue(survival.awaitAuthentication());
            assertTrue(lobby.awaitAuthentication());
            bot.start();
            assertTrue(bot.awaitAuthentication());

            final ControlMessages.ExecuteResponse response = send(bot, execute("user-operator",
                    new TargetSelection(null, List.of("survival", "lobby"), null, false), "cmi heal Zigono"));
            assertNull(response.errorCode);
            assertEquals(2, response.outcomes.size());
            assertTrue(response.outcomes.stream().allMatch(outcome -> outcome.status() == ExecutionStatus.SUCCESS));
            assertEquals(List.of("cmi heal Zigono"), survival.executed());
            assertEquals(List.of("cmi heal Zigono"), lobby.executed());
        } finally {
            bot.close();
            lobby.close();
            survival.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("a dangerous command needs a confirmation round trip before it reaches the server")
    void confirmationRoundTrip(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final MinecraftPeer plugin = new MinecraftPeer("survival", SURVIVAL_KEY, port);
        final ControlPeer bot = new ControlPeer("bot", BOT_KEY, port);
        try {
            plugin.start();
            assertTrue(plugin.awaitAuthentication());
            bot.start();
            assertTrue(bot.awaitAuthentication());

            final ControlMessages.ExecuteResponse challenge = send(bot,
                    execute("user-operator", server("survival"), "stop"));
            assertEquals("CONFIRMATION_REQUIRED", challenge.errorCode);
            assertNotNull(challenge.confirmationId);
            assertEquals(0, plugin.acceptedCount(), "an unconfirmed command must never reach the server");

            final ControlMessages.ExecuteRequest confirmed = execute("user-operator", server("survival"), "stop");
            confirmed.confirmed = true;
            confirmed.confirmationId = challenge.confirmationId;
            final ControlMessages.ExecuteResponse response = send(bot, confirmed);
            assertNull(response.errorCode);
            assertEquals(ExecutionStatus.SUCCESS, response.outcomes.get(0).status());
            assertEquals(1, plugin.acceptedCount());
        } finally {
            bot.close();
            plugin.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("a heartbeat reaches the gateway and marks the server online")
    void heartbeatMarksServerOnline(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final MinecraftPeer plugin = new MinecraftPeer("survival", SURVIVAL_KEY, port);
        final ControlPeer bot = new ControlPeer("bot", BOT_KEY, port);
        try {
            plugin.start();
            assertTrue(plugin.awaitAuthentication());
            bot.start();
            assertTrue(bot.awaitAuthentication());

            final PluginMessages.Heartbeat heartbeat = new PluginMessages.Heartbeat();
            heartbeat.status = "ONLINE";
            heartbeat.queuedCommands = 0;
            heartbeat.metrics = new ru.zigono.dmc.protocol.dto.ServerMetrics("survival", "1.21.1", "Paper", "1.0.0",
                    3, 100, 20.0d, 4.5d, 42L, 1024L, 4096L, 0.1d, "world", 64, System.currentTimeMillis());
            plugin.sendHeartbeat(heartbeat);

            waitFor(() -> gateway.registry().state("survival").status() == ServerStatus.ONLINE);

            final ControlMessages.StatusRequest request = new ControlMessages.StatusRequest();
            request.user = new UserContext("user-operator", "user-operator", "999999999999999999",
                    "555555555555555555", null, null, List.of(), List.of(), List.of());
            final Message response = bot.client().request(request, Duration.ofSeconds(10)).get(15, TimeUnit.SECONDS);
            final ControlMessages.StatusResponse status = (ControlMessages.StatusResponse) response;
            final ControlMessages.ServerStatusEntry survival = status.servers.stream()
                    .filter(entry -> "survival".equals(entry.id())).findFirst().orElseThrow();
            assertEquals("ONLINE", survival.status());
        } finally {
            bot.close();
            plugin.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("an invalid signature from a peer is rejected and recorded")
    void rejectsInvalidSignature(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final ControlPeer impostor = new ControlPeer("bot", "wrong-secret-0000000000000000".getBytes(
                StandardCharsets.UTF_8), port);
        try {
            impostor.start();
            assertFalse(impostor.awaitAuthentication(), "a peer with a wrong secret must not authenticate");
            waitFor(() -> gateway.metrics().counter("protocol_violations") > 0
                    || gateway.metrics().counter("rejected_connections_total") > 0);
        } finally {
            impostor.close();
            gateway.close();
        }
    }

    @Test
    @DisplayName("a reconnect re-establishes the plugin session without losing the queue")
    void reconnectsAfterDrop(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory, "port: 18443", "port: " + port);
        final Gateway gateway = new Gateway(config.sourceFile());
        gateway.start();
        final MinecraftPeer first = new MinecraftPeer("survival", SURVIVAL_KEY, port);
        try {
            first.start();
            assertTrue(first.awaitAuthentication());
            first.close();
            waitFor(() -> gateway.registry().state("survival").status() == ServerStatus.OFFLINE);

            final MinecraftPeer second = new MinecraftPeer("survival", SURVIVAL_KEY, port);
            try {
                second.start();
                assertTrue(second.awaitAuthentication(), "the replacement session must authenticate");
                waitFor(() -> gateway.registry().state("survival").status() != ServerStatus.OFFLINE);
            } finally {
                second.close();
            }
        } finally {
            gateway.close();
        }
    }


    private static void waitFor(java.util.function.BooleanSupplier condition) throws InterruptedException {
        final long deadline = System.currentTimeMillis() + 15_000L;
        while (System.currentTimeMillis() < deadline) {
            if (condition.getAsBoolean()) {
                return;
            }
            Thread.sleep(50L);
        }
        assertTrue(condition.getAsBoolean(), "the condition was not met in time");
    }
}