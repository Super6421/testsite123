package ru.zigono.dmc.gateway.api;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Dangerous command confirmations: bound to the initiator, single use and time limited.
 *
 * @author Zigono
 */
class ConfirmationRegistryTest {

    private static final Duration TTL = Duration.ofSeconds(5);
    private static final UserContext ZIGONO = UserContext.of("1", "Zigono", "guild", "channel");
    private static final UserContext INTRUDER = UserContext.of("2", "Intruder", "guild", "channel");
    private static final TargetSelection SURVIVAL = new TargetSelection("survival", List.of(), null, false);

    @Test
    @DisplayName("a fresh token is accepted exactly once")
    void acceptsTokenOnce() {
        final ConfirmationRegistry registry = new ConfirmationRegistry();
        final ConfirmationRegistry.Verdict issued = registry.issue(ZIGONO, SURVIVAL, "stop", TTL);
        assertFalse(issued.accepted());
        assertNotNull(issued.token());
        assertTrue(issued.expiresAt() > System.currentTimeMillis());

        final ConfirmationRegistry.Verdict first = registry.consume(issued.token(), ZIGONO, SURVIVAL, "stop", TTL);
        assertTrue(first.accepted());
        assertNull(first.token());

        final ConfirmationRegistry.Verdict replay = registry.consume(issued.token(), ZIGONO, SURVIVAL, "stop", TTL);
        assertFalse(replay.accepted(), "a confirmation token must be single use");
        assertNotNull(replay.token());
    }

    @Test
    @DisplayName("only the initiator may confirm")
    void bindsTokenToInitiator() {
        final ConfirmationRegistry registry = new ConfirmationRegistry();
        final ConfirmationRegistry.Verdict issued = registry.issue(ZIGONO, SURVIVAL, "stop", TTL);
        final ConfirmationRegistry.Verdict verdict = registry.consume(issued.token(), INTRUDER, SURVIVAL, "stop", TTL);
        assertFalse(verdict.accepted());
        assertTrue(verdict.reason().contains("confirmation"));
    }

    @Test
    @DisplayName("a token cannot be reused for another command or another target")
    void bindsTokenToCommandAndTarget() {
        final ConfirmationRegistry registry = new ConfirmationRegistry();
        final ConfirmationRegistry.Verdict issued = registry.issue(ZIGONO, SURVIVAL, "stop", TTL);
        assertFalse(registry.consume(issued.token(), ZIGONO, SURVIVAL, "restart", TTL).accepted());

        final ConfirmationRegistry.Verdict other = registry.issue(ZIGONO, SURVIVAL, "stop", TTL);
        assertFalse(registry.consume(other.token(), ZIGONO, new TargetSelection("lobby", List.of(), null, false),
                "stop", TTL).accepted());
    }

    @Test
    @DisplayName("an expired token is refused and replaced")
    void refusesExpiredToken() throws Exception {
        final ConfirmationRegistry registry = new ConfirmationRegistry();
        final ConfirmationRegistry.Verdict issued = registry.issue(ZIGONO, SURVIVAL, "stop", Duration.ofMillis(1));
        Thread.sleep(20L);
        final ConfirmationRegistry.Verdict verdict = registry.consume(issued.token(), ZIGONO, SURVIVAL, "stop", TTL);
        assertFalse(verdict.accepted());
        assertNotNull(verdict.token());
        assertEquals(1, registry.size(), "the expired entry must have been replaced");
    }

    @Test
    @DisplayName("a missing or unknown token issues a fresh challenge")
    void issuesFreshChallengeForUnknownToken() {
        final ConfirmationRegistry registry = new ConfirmationRegistry();
        assertNotNull(registry.consume(null, ZIGONO, SURVIVAL, "stop", TTL).token());
        assertNotNull(registry.consume("   ", ZIGONO, SURVIVAL, "stop", TTL).token());
        assertNotNull(registry.consume("01JUNKNOWNTOKEN", ZIGONO, SURVIVAL, "stop", TTL).token());
    }

    @Test
    @DisplayName("the registry is bounded so a hostile client cannot exhaust memory")
    void isBounded() {
        final ConfirmationRegistry registry = new ConfirmationRegistry(4);
        for (int index = 0; index < 8; index++) {
            registry.issue(ZIGONO, SURVIVAL, "stop-" + index, TTL);
        }
        assertTrue(registry.size() <= 4, "registry size was " + registry.size());
    }
}