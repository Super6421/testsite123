package ru.zigono.dmc.gateway.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;

import java.nio.file.Path;
import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Parsing and validation of {@code gateway.yml}. Every option is configuration driven, so this test pins the
 * contract between the file and the typed view.
 *
 * @author Zigono
 */
class GatewayConfigTest {

    @Test
    @DisplayName("the catalog, groups and aliases are parsed")
    void parsesCatalog(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertEquals("gateway-test", config.gatewayId());
        assertEquals(java.util.Set.of("survival", "lobby", "skyblock"),
                new java.util.LinkedHashSet<>(config.catalog().enabledServerIds()));
        assertTrue(config.catalog().exists("surv"));
        assertEquals("survival", config.catalog().find("surv").orElseThrow().id());
        assertEquals(List.of("lobby", "survival"), config.catalog().groupServers("public"));
        assertFalse(config.catalog().singleServerMode());
    }

    @Test
    @DisplayName("the ACL resolves users, roles and guild scoped assignments")
    void parsesPermissions(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        final PermissionSet admin = config.permissions().resolve(null, List.of(), "user-admin");
        assertTrue(admin.allows("console.execute"));
        assertTrue(admin.allows("console.server.skyblock"));

        final PermissionSet operator = config.permissions().resolve(null, List.of(), "user-operator");
        assertTrue(operator.allows("console.server.survival"));
        assertFalse(operator.allows("console.server.skyblock"));

        final PermissionSet denied = config.permissions().resolve(null, List.of(), "user-denied");
        assertTrue(denied.allows("console.execute"));
        assertFalse(denied.allows("console.server.skyblock"), "deny must win over the wildcard allow");
        assertFalse(denied.allows("console.command.stop"));

        final PermissionSet guildRole = config.permissions().resolve("111111111111111111",
                List.of("role-guild"), "stranger");
        assertTrue(guildRole.allows("console.execute"));
        final PermissionSet outsideGuild = config.permissions().resolve("999", List.of("role-guild"), "stranger");
        assertFalse(outsideGuild.allows("console.execute"), "guild roles must not leak into another guild");
    }

    @Test
    @DisplayName("policy, aliases and templates are parsed")
    void parsesPolicyAndShortcuts(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertTrue(config.policy().dangerousPatterns().contains("stop"));
        assertEquals(3, config.policy().rules().size());
        assertEquals("cmi heal {player}", config.shortcuts().alias("heal").orElseThrow().command());
        assertEquals("console.alias.heal", config.shortcuts().alias("heal").orElseThrow().permission());
        assertEquals("cmi warn {player} {reason}", config.shortcuts().template("warn").orElseThrow().command());
    }

    @Test
    @DisplayName("queue, retry, broadcast, confirmation and response settings are parsed")
    void parsesOperationalSettings(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertTrue(config.queue().enabled());
        assertEquals(100, config.queue().maxSize());
        assertEquals(Duration.ofSeconds(5), config.queue().timeout());
        assertEquals("cancel", config.queue().onDisconnect());
        assertEquals(3, config.retry().maxAttempts());
        assertEquals(Duration.ofMillis(10), config.retry().delay());
        assertEquals("parallel", config.broadcast().execution());
        assertEquals("continue", config.broadcast().failurePolicy());
        assertEquals("per_server", config.broadcast().responseMode());
        assertEquals(1900, config.responses().maxMessageLength());
        assertEquals(10_000, config.responses().attachmentThreshold());
        assertTrue(config.confirmation().enabled());
        assertEquals(Duration.ofSeconds(2), config.confirmation().timeout());
        assertEquals(Duration.ofSeconds(10), config.heartbeat().interval());
    }

    @Test
    @DisplayName("database, redis and metrics settings are parsed")
    void parsesInfrastructureSettings(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertEquals("sqlite", config.database().type());
        assertFalse(config.database().retentionEnabled());
        assertEquals(30, config.database().retentionDays());
        assertEquals(90, config.database().securityRetentionDays());
        assertFalse(config.redis().enabled());
        assertFalse(config.metrics().enabled());
        assertEquals("text", config.logging().format());
        assertFalse(config.logging().connections());
    }

    @Test
    @DisplayName("channel restrictions are parsed per guild")
    void parsesChannelRestrictions(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertTrue(config.restrictions().allowsChannel("111111111111111111", "222222222222222222"));
        assertFalse(config.restrictions().allowsChannel("111111111111111111", "999999999999999999"));
    }

    @Test
    @DisplayName("secrets are decoded and never stored in clear text by accident")
    void readsSecrets(@TempDir Path directory) {
        final GatewayConfig config = GatewayTestSupport.config(directory);
        assertEquals(3, config.serverSecrets().size());
        assertEquals(2, config.controlSecrets().size());
        assertEquals(31, config.serverSecrets().get("survival").length);
        assertTrue(config.secretValues().contains("survival-secret-000000000000000"));
    }

    @Test
    @DisplayName("the configuration revision changes with the content")
    void computesRevision(@TempDir Path directory) {
        final GatewayConfig first = GatewayTestSupport.config(directory);
        final GatewayConfig identical = GatewayTestSupport.config(directory);
        assertEquals(first.revision(), identical.revision());
        final GatewayConfig changed = GatewayTestSupport.configWith(directory, "gateway-test", "gateway-other");
        assertFalse(first.revision().equals(changed.revision()));
    }

    @Test
    @DisplayName("an unsupported protocol version is rejected at startup")
    void rejectsUnknownProtocolVersion(@TempDir Path directory) {
        assertThrows(ConfigException.class,
                () -> GatewayTestSupport.configWith(directory, "protocol_version: 1", "protocol_version: 99"));
    }

    @Test
    @DisplayName("a control client is mandatory")
    void requiresControlClient(@TempDir Path directory) {
        assertThrows(ConfigException.class, () -> GatewayTestSupport.configWith(directory,
                "control:\n  clients:\n    bot:\n      secret: \"control-secret-0000000000000000\"",
                "control:\n  clients: {}"));
    }

    @Test
    @DisplayName("an enabled server without a secret is rejected")
    void requiresServerSecret(@TempDir Path directory) {
        assertThrows(ConfigException.class, () -> GatewayTestSupport.configWith(directory,
                "    secret: \"skyblock-secret-000000000000000\"", "    secret: \"\""));
    }

    @Test
    @DisplayName("plain transport must be enabled explicitly")
    void requiresExplicitInsecureOptIn(@TempDir Path directory) {
        assertThrows(ConfigException.class, () -> GatewayTestSupport.configWith(directory,
                "allow_insecure_transport: true", "allow_insecure_transport: false"));
    }

    @Test
    @DisplayName("invalid enumerations are rejected")
    void rejectsInvalidEnums(@TempDir Path directory) {
        assertThrows(ConfigException.class,
                () -> GatewayTestSupport.configWith(directory, "on_disconnect: cancel", "on_disconnect: explode"));
        assertThrows(ConfigException.class,
                () -> GatewayTestSupport.configWith(directory, "execution: parallel", "execution: random"));
        assertThrows(ConfigException.class, () -> GatewayTestSupport.configWith(directory,
                "failure_policy: continue", "failure_policy: maybe"));
    }

    @Test
    @DisplayName("a group that references an unknown server is rejected")
    void rejectsUnknownGroupMember(@TempDir Path directory) {
        assertThrows(ConfigException.class,
                () -> GatewayTestSupport.configWith(directory, "servers: [ lobby, survival ]",
                        "servers: [ lobby, ghost ]"));
    }

    @Test
    @DisplayName("a shortcut with a placeholder that is not declared is rejected")
    void rejectsUndeclaredPlaceholder(@TempDir Path directory) {
        assertThrows(ConfigException.class, () -> GatewayTestSupport.configWith(directory,
                "command: \"cmi heal {player}\"", "command: \"cmi heal {victim}\""));
    }
}