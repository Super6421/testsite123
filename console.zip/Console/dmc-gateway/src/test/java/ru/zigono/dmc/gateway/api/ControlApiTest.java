package ru.zigono.dmc.gateway.api;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.common.rate.InMemoryRateBackend;
import ru.zigono.dmc.common.rate.RateLimiter;
import ru.zigono.dmc.gateway.EmergencySwitch;
import ru.zigono.dmc.gateway.auth.AuthorizationService;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.db.AuditRepository;
import ru.zigono.dmc.gateway.db.Database;
import ru.zigono.dmc.gateway.db.SecurityAuditRepository;
import ru.zigono.dmc.gateway.db.SecurityEvent;
import ru.zigono.dmc.gateway.db.StateRepository;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.queue.CommandDispatcher;
import ru.zigono.dmc.gateway.queue.QueuedCommand;
import ru.zigono.dmc.gateway.queue.QueueManager;
import ru.zigono.dmc.gateway.queue.RetryPolicy;
import ru.zigono.dmc.gateway.registry.PluginRegistry;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.HistoryEntry;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * End to end exercise of the authoritative control pipeline: permissions, normalization, injection protection,
 * policy, rate limit, dangerous command confirmation, dry run and audit.
 *
 * @author Zigono
 */
class ControlApiTest {

    /** Test double for the Minecraft transport: answers with a real {@link ServerOutcome}. */
    private static final class FakeMinecraft implements CommandDispatcher {

        private final List<QueuedCommand> received = Collections.synchronizedList(new ArrayList<>());
        private final AtomicInteger calls = new AtomicInteger();
        private volatile ExecutionStatus status = ExecutionStatus.SUCCESS;

        @Override
        public boolean available(String serverId) {
            return true;
        }

        @Override
        public Optional<Dispatch> dispatch(QueuedCommand command) {
            calls.incrementAndGet();
            received.add(command);
            final ServerOutcome outcome = status == ExecutionStatus.SUCCESS
                    ? ServerOutcome.success(command.serverId(), List.of("healed Zigono"), 3L, command.requestId())
                    : ServerOutcome.failure(command.serverId(), status, status.name(), "scripted " + status);
            return Optional.of(new Dispatch(CompletableFuture.completedFuture(outcome),
                    CompletableFuture.completedFuture(true)));
        }

        @Override
        public void onDisconnect(String serverId, String reason) {
        }

        int calls() {
            return calls.get();
        }
    }

    private Database database;
    private GatewayConfig config;
    private ControlApi api;
    private FakeMinecraft minecraft;
    private EmergencySwitch emergency;
    private AuditRepository auditRepository;
    private SecurityAuditRepository securityAuditRepository;

    @BeforeEach
    void setUp(@TempDir Path directory) {
        config = GatewayTestSupport.config(directory);
        database = Database.open(config.database());
        auditRepository = new AuditRepository(database);
        securityAuditRepository = new SecurityAuditRepository(database);
        minecraft = new FakeMinecraft();
        final PluginRegistry registry = new PluginRegistry(config.catalog(), config.heartbeat(), ignored -> { });
        final AuthorizationService authorization = new AuthorizationService(() -> config,
                serverId -> ServerStatus.ONLINE);
        final QueueManager queueManager = new QueueManager(config, new RetryPolicy(config.retry()), minecraft,
                new Metrics());
        emergency = new EmergencySwitch(false, new StateRepository(database));
        api = new ControlApi(() -> config, authorization, queueManager, registry, auditRepository,
                securityAuditRepository, new RateLimiter(config.rateLimit(), new InMemoryRateBackend()), new Metrics(),
                emergency, new GatewayControlService() {
                    @Override
                    public ReloadResult reload() {
                        return new ReloadResult(true, config.revision(), List.of("policy", "permissions"), null);
                    }

                    @Override
                    public String configRevision() {
                        return config.revision();
                    }
                });
        api.rateLimiter().reset("user:user-operator");
    }

    @AfterEach
    void tearDown() {
        if (database != null) {
            database.close();
        }
    }

    private static UserContext user(String id) {
        return new UserContext(id, id, "999999999999999999", "555555555555555555", null, null, List.of(), List.of(),
                List.of());
    }

    private static UserContext guildUser(String id) {
        return new UserContext(id, id, "111111111111111111", "222222222222222222", null, null, List.of("role-guild"),
                List.of(), List.of());
    }

    private ControlMessages.ExecuteResponse execute(UserContext user, TargetSelection target, String command) {
        return execute(user, target, command, false, false, null);
    }

    private ControlMessages.ExecuteResponse execute(UserContext user, TargetSelection target, String command,
                                                    boolean dryRun, boolean confirmed, String confirmationId) {
        final ControlMessages.ExecuteRequest request = new ControlMessages.ExecuteRequest();
        request.setRequestId(ru.zigono.dmc.common.util.Ids.ulid());
        request.setClientId("bot");
        request.user = user;
        request.target = target;
        request.command = command;
        request.dryRun = dryRun;
        request.confirmed = confirmed;
        request.confirmationId = confirmationId;
        request.timeoutMillis = 5_000L;
        return (ControlMessages.ExecuteResponse) api.handle(request);
    }

    private static TargetSelection server(String id) {
        return new TargetSelection(id, List.of(), null, false);
    }

    @Test
    @DisplayName("an authorized command really reaches the Minecraft server")
    void executesAuthorizedCommand() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                "cmi heal Zigono");
        assertNull(response.errorCode);
        assertEquals(1, response.outcomes.size());
        assertEquals(ExecutionStatus.SUCCESS, response.outcomes.get(0).status());
        assertEquals(List.of("healed Zigono"), response.outcomes.get(0).output());
        assertEquals(1, minecraft.calls());
        assertEquals("cmi heal Zigono", minecraft.received.get(0).command());
    }

    @Test
    @DisplayName("a user without console.execute is denied and nothing is dispatched")
    void deniesWithoutExecutePermission() {
        final ControlMessages.ExecuteResponse response = execute(user("user-readonly"), server("survival"),
                "cmi heal Zigono");
        assertEquals("PERMISSION_DENIED", response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("server level permissions are enforced on the gateway")
    void deniesForbiddenServer() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("skyblock"),
                "cmi heal Zigono");
        assertEquals("PERMISSION_DENIED", response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a deny rule wins over a wildcard allow")
    void denyWinsOverWildcard() {
        final ControlMessages.ExecuteResponse response = execute(user("user-denied"), server("skyblock"),
                "cmi heal Zigono");
        assertEquals("PERMISSION_DENIED", response.errorCode);
    }

    @Test
    @DisplayName("privilege escalation through a role id cannot cross the guild boundary")
    void guildRoleDoesNotLeakOutsideItsGuild() {
        assertEquals("PERMISSION_DENIED", execute(user("nobody"), server("survival"), "cmi heal Zigono").errorCode);
        final ControlMessages.ExecuteResponse inGuild = execute(guildUser("somebody"), server("survival"),
                "cmi heal Zigono");
        assertNull(inGuild.errorCode, "the guild role must grant access inside its guild");
    }

    @Test
    @DisplayName("command injection is rejected before anything is queued")
    void rejectsCommandInjection() {
        final String[] payloads = {
                "say hello && op Zigono",
                "say hello; stop",
                "say $(whoami)",
                "cmi heal `whoami`",
                "say hello || stop",
                "say hello \\x41",
                "say hello\u0000world"
        };
        for (String payload : payloads) {
            final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                    payload);
            assertEquals("INVALID_COMMAND", response.errorCode, "payload must be rejected: " + payload);
        }
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a command outside the derived permission is denied")
    void deniesCommandWithoutDerivedPermission() {
        final ControlMessages.ExecuteResponse response = execute(guildUser("somebody"), server("survival"),
                "op Zigono");
        assertTrue("POLICY_DENIED".equals(response.errorCode) || "PERMISSION_DENIED".equals(response.errorCode),
                "unexpected code " + response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a dangerous command requires a confirmation that only the initiator can use")
    void dangerousCommandRequiresConfirmation() {
        final ControlMessages.ExecuteResponse challenge = execute(user("user-operator"), server("survival"), "stop");
        assertEquals("CONFIRMATION_REQUIRED", challenge.errorCode);
        assertNotNull(challenge.confirmationId);
        assertTrue(challenge.confirmationExpiresAt > System.currentTimeMillis());
        assertEquals(0, minecraft.calls());

        final ControlMessages.ExecuteResponse denied = execute(user("user-admin"), server("survival"), "stop",
                false, true, challenge.confirmationId);
        assertEquals("CONFIRMATION_REQUIRED", denied.errorCode, "another user must not be able to confirm");
        assertEquals(0, minecraft.calls());

        final ControlMessages.ExecuteResponse executed = execute(user("user-operator"), server("survival"), "stop",
                false, true, challenge.confirmationId);
        assertNull(executed.errorCode);
        assertEquals(ExecutionStatus.SUCCESS, executed.outcomes.get(0).status());
        assertEquals(1, minecraft.calls());
    }

    @Test
    @DisplayName("a confirmation token cannot be replayed")
    void confirmationIsSingleUse() {
        final ControlMessages.ExecuteResponse challenge = execute(user("user-operator"), server("survival"), "stop");
        assertNull(execute(user("user-operator"), server("survival"), "stop", false, true,
                challenge.confirmationId).errorCode);
        final ControlMessages.ExecuteResponse replay = execute(user("user-operator"), server("survival"), "stop",
                false, true, challenge.confirmationId);
        assertEquals("CONFIRMATION_REQUIRED", replay.errorCode);
        assertEquals(1, minecraft.calls());
    }

    @Test
    @DisplayName("a confirmation for another command or server is refused")
    void confirmationIsBoundToTheRequest() {
        final ControlMessages.ExecuteResponse challenge = execute(user("user-operator"), server("survival"), "stop");
        final ControlMessages.ExecuteResponse mismatched = execute(user("user-operator"), server("lobby"), "stop",
                false, true, challenge.confirmationId);
        assertEquals("CONFIRMATION_REQUIRED", mismatched.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a dry run reports the checks without executing anything")
    void dryRunReportsChecks() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                "cmi heal Zigono", true, false, null);
        assertNull(response.errorCode);
        assertTrue(response.dryRun);
        assertEquals(ExecutionStatus.DRY_RUN, response.outcomes.get(0).status());
        assertEquals(6, response.dryRunChecks.size());
        assertTrue(response.dryRunChecks.stream().anyMatch(check -> check.startsWith("подтверждение:")));
        assertEquals(0, minecraft.calls(), "a dry run must never execute the command");
    }

    @Test
    @DisplayName("a dry run of a dangerous command reports that a confirmation would be required")
    void dryRunOfDangerousCommandReportsConfirmation() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"), "stop",
                true, false, null);
        assertTrue(response.dryRunChecks.stream().anyMatch(check -> check.equals("подтверждение: требуется")));
        assertTrue(response.dryRunSummary.contains("после подтверждения"));
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a configured alias is expanded and its own permission is enforced")
    void expandsConfiguredAlias() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                "heal Zigono");
        assertNull(response.errorCode);
        assertEquals("cmi heal Zigono", minecraft.received.get(0).command());
    }

    @Test
    @DisplayName("an alias without its permission is denied")
    void deniesAliasWithoutPermission() {
        final ControlMessages.ExecuteResponse response = execute(guildUser("somebody"), server("survival"),
                "heal Zigono");
        assertEquals("PERMISSION_DENIED", response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("a configured template is expanded from named parameters")
    void expandsConfiguredTemplate() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                "warn Zigono reason=griefing");
        assertNull(response.errorCode);
        assertEquals("cmi warn Zigono griefing", minecraft.received.get(0).command());
    }

    @Test
    @DisplayName("an injected template value is rejected before expansion")
    void rejectsInjectedTemplateValue() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"), server("survival"),
                "warn Zigono reason=hello World!");
        assertEquals("INVALID_COMMAND", response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("the emergency kill switch blocks ordinary users")
    void emergencySwitchBlocksUsers() {
        emergency.set(true);
        try {
            final ControlMessages.ExecuteResponse response = execute(guildUser("somebody"), server("survival"),
                    "cmi heal Zigono");
            assertEquals("EMERGENCY_MODE", response.errorCode);
            assertEquals(0, minecraft.calls());
        } finally {
            emergency.set(false);
        }
    }

    @Test
    @DisplayName("every attempt is written to the audit trail")
    void writesAuditRecords() {
        execute(user("user-operator"), server("survival"), "cmi heal Zigono");
        execute(user("user-operator"), server("survival"), "cmi heal Zigono");
        final List<HistoryEntry> history = auditRepository.search(AuditRepository.HistoryQuery.of(null, null, null,
                null, null, null, 10, 0));
        assertEquals(2, history.size());
        assertEquals("cmi heal Zigono", history.get(0).command());
    }

    @Test
    @DisplayName("security relevant refusals are written to the immutable security audit")
    void writesSecurityAuditForRefusals() {
        execute(user("user-readonly"), server("survival"), "cmi heal Zigono");
        execute(user("user-operator"), server("survival"), "say hello; stop");
        final List<SecurityEvent> events = securityAuditRepository.recent(10);
        assertTrue(events.stream().anyMatch(event -> event.eventType().equals("PERMISSION_DENIED")));
        assertTrue(events.stream().anyMatch(event -> event.eventType().equals("INVALID_COMMAND")));
    }

    @Test
    @DisplayName("permission aware targets view only lists servers the user may address")
    void buildsPermissionAwareTargetsView() {
        final ControlMessages.TargetsRequest request = new ControlMessages.TargetsRequest();
        request.setRequestId(ru.zigono.dmc.common.util.Ids.ulid());
        request.user = user("user-operator");
        final ControlMessages.TargetsResponse response = (ControlMessages.TargetsResponse) api.handle(request);
        final List<String> ids = response.view.servers().stream().map(TargetsView -> TargetsView.id()).toList();
        assertTrue(ids.contains("survival"));
        assertTrue(ids.contains("lobby"));
        assertFalse(ids.contains("skyblock"), "skyblock was not granted to this user");
        assertFalse(response.view.capabilities().broadcastAll());
    }

    @Test
    @DisplayName("a full broadcast is denied without console.broadcast.all")
    void deniesBroadcastAllWithoutPermission() {
        final ControlMessages.ExecuteResponse response = execute(user("user-operator"),
                new TargetSelection(null, List.of(), null, true), "cmi heal Zigono");
        assertEquals("PERMISSION_DENIED", response.errorCode);
        assertEquals(0, minecraft.calls());
    }

    @Test
    @DisplayName("rate limits are enforced per user")
    void enforcesRateLimit(@TempDir Path directory) {
        final GatewayConfig tight = GatewayTestSupport.configWith(directory,
                "requests: 1000", "requests: 2");
        final Database tightDatabase = Database.open(tight.database());
        try {
            final PluginRegistry registry = new PluginRegistry(tight.catalog(), tight.heartbeat(), ignored -> { });
            final QueueManager queueManager = new QueueManager(tight, new RetryPolicy(tight.retry()), minecraft,
                    new Metrics());
            final ControlApi limited = new ControlApi(() -> tight,
                    new AuthorizationService(() -> tight, serverId -> ServerStatus.ONLINE), queueManager, registry,
                    new AuditRepository(tightDatabase), new SecurityAuditRepository(tightDatabase),
                    new RateLimiter(tight.rateLimit(), new InMemoryRateBackend()), new Metrics(),
                    new EmergencySwitch(false, null), new GatewayControlService() {
                        @Override
                        public ReloadResult reload() {
                            return new ReloadResult(true, tight.revision(), List.of(), null);
                        }

                        @Override
                        public String configRevision() {
                            return tight.revision();
                        }
                    });
            final UserContext operator = user("user-operator");
            for (int index = 0; index < 2; index++) {
                final ControlMessages.ExecuteRequest request = new ControlMessages.ExecuteRequest();
                request.user = operator;
                request.target = server("survival");
                request.command = "cmi heal Zigono";
                request.timeoutMillis = 5_000L;
                assertNull(((ControlMessages.ExecuteResponse) limited.handle(request)).errorCode,
                        "attempt " + index + " must pass");
            }
            final ControlMessages.ExecuteRequest request = new ControlMessages.ExecuteRequest();
            request.user = operator;
            request.target = server("survival");
            request.command = "cmi heal Zigono";
            request.timeoutMillis = 5_000L;
            final ControlMessages.ExecuteResponse blocked = (ControlMessages.ExecuteResponse) limited.handle(request);
            assertEquals("RATE_LIMIT", blocked.errorCode);
        } finally {
            tightDatabase.close();
        }
    }
}