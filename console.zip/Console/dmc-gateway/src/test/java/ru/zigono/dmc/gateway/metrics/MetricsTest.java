package ru.zigono.dmc.gateway.metrics;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.support.GatewayTestSupport;

import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Prometheus exposition and the health probes exposed by the admin HTTP server.
 *
 * @author Zigono
 */
class MetricsTest {

    private static int freePort() throws Exception {
        try (ServerSocket socket = new ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }

    @Test
    @DisplayName("counters, gauges and latency buckets are rendered in the Prometheus format")
    void rendersPrometheusFormat() {
        final Metrics metrics = new Metrics();
        metrics.increment(Metrics.COMMANDS_TOTAL);
        metrics.increment(Metrics.COMMANDS_TOTAL);
        metrics.increment(Metrics.COMMANDS_SUCCESS_TOTAL);
        metrics.gauge(Metrics.CONNECTED_SERVERS, () -> 2);
        metrics.recordLatency(12L);
        metrics.recordLatency(400L);

        final String rendered = metrics.render();
        assertTrue(rendered.contains("dmc_commands_total 2"));
        assertTrue(rendered.contains("dmc_commands_success_total 1"));
        assertTrue(rendered.contains("dmc_connected_servers 2"));
        assertTrue(rendered.contains("dmc_command_latency_count 2"));
        assertTrue(rendered.contains("dmc_command_latency_bucket{le=\"25\"} 1"));
        assertTrue(rendered.contains("dmc_command_latency_bucket{le=\"+Inf\"} 2"));
        assertTrue(rendered.contains("# HELP dmc_uptime_seconds"));
        assertEquals(2L, metrics.snapshot().get(Metrics.COMMANDS_TOTAL));
    }

    @Test
    @DisplayName("the admin server answers /metrics, /health, /health/live and /health/ready")
    void servesAdminEndpoints(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory,
                "port: 0", "port: " + port,
                "enabled: false\n  host: 127.0.0.1", "enabled: true\n  host: 127.0.0.1");
        final Metrics metrics = new Metrics();
        metrics.increment(Metrics.AUTHENTICATION_FAILURES);
        try (AdminHttpServer server = new AdminHttpServer(config, metrics, () -> true, () -> true)) {
            server.start();
            final HttpClient client = HttpClient.newHttpClient();
            final HttpResponse<String> body = client.send(
                    HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/metrics")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            assertEquals(200, body.statusCode());
            assertTrue(body.body().contains("dmc_authentication_failures 1"));

            final HttpResponse<String> health = client.send(
                    HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/health")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            assertEquals(200, health.statusCode());
            assertTrue(health.body().contains("\"status\":\"UP\""));
            assertTrue(health.body().contains("\"ready\":true"));

            final HttpResponse<String> live = client.send(
                    HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/health/live")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            assertEquals(200, live.statusCode());
        }
    }

    @Test
    @DisplayName("a failed readiness probe returns 503")
    void reportsUnready(@TempDir Path directory) throws Exception {
        final int port = freePort();
        final GatewayConfig config = GatewayTestSupport.configWith(directory,
                "port: 0", "port: " + port,
                "enabled: false\n  host: 127.0.0.1", "enabled: true\n  host: 127.0.0.1");
        try (AdminHttpServer server = new AdminHttpServer(config, new Metrics(), () -> true, () -> false)) {
            server.start();
            final HttpResponse<String> ready = HttpClient.newHttpClient().send(
                    HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/health/ready")).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            assertEquals(503, ready.statusCode());
            assertTrue(ready.body().contains("DOWN"));
        }
    }
}