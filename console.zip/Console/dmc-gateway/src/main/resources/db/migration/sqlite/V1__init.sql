-- Discord Minecraft Console Gateway - SQLite schema
-- Author: Zigono

CREATE TABLE IF NOT EXISTS schema_migrations (
    version TEXT PRIMARY KEY,
    applied_epoch_ms INTEGER NOT NULL
)
;

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT NOT NULL,
    user_id TEXT,
    username TEXT,
    guild_id TEXT,
    channel_id TEXT,
    message_id TEXT,
    interaction_id TEXT,
    roles TEXT,
    target TEXT,
    server_id TEXT,
    command TEXT,
    normalized_command TEXT,
    status TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    response TEXT,
    error_code TEXT,
    error_detail TEXT,
    dry_run INTEGER NOT NULL DEFAULT 0,
    created_epoch_ms INTEGER NOT NULL
)
;

CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log (created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log (user_id, created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_server ON audit_log (server_id, created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_request ON audit_log (request_id)
;

CREATE TABLE IF NOT EXISTS security_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id TEXT,
    event_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    user_id TEXT,
    username TEXT,
    guild_id TEXT,
    channel_id TEXT,
    server_id TEXT,
    client_id TEXT,
    remote_address TEXT,
    detail TEXT,
    created_epoch_ms INTEGER NOT NULL
)
;

CREATE INDEX IF NOT EXISTS idx_security_created ON security_audit (created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_security_type ON security_audit (event_type, created_epoch_ms)
;

CREATE TABLE IF NOT EXISTS server_metadata (
    server_id TEXT PRIMARY KEY,
    name TEXT,
    last_status TEXT,
    minecraft_version TEXT,
    plugin_version TEXT,
    last_seen_epoch_ms INTEGER,
    updated_epoch_ms INTEGER NOT NULL
)
;

CREATE TABLE IF NOT EXISTS gateway_state (
    state_key TEXT PRIMARY KEY,
    state_value TEXT,
    updated_epoch_ms INTEGER NOT NULL
)
;