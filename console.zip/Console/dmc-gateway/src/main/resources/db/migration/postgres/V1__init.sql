-- Discord Minecraft Console Gateway - PostgreSQL schema
-- Author: Zigono

CREATE TABLE IF NOT EXISTS schema_migrations (
    version VARCHAR(64) PRIMARY KEY,
    applied_epoch_ms BIGINT NOT NULL
)
;

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    request_id VARCHAR(64) NOT NULL,
    user_id VARCHAR(64),
    username VARCHAR(128),
    guild_id VARCHAR(64),
    channel_id VARCHAR(64),
    message_id VARCHAR(64),
    interaction_id VARCHAR(64),
    roles TEXT,
    target VARCHAR(512),
    server_id VARCHAR(64),
    command TEXT,
    normalized_command TEXT,
    status VARCHAR(32) NOT NULL,
    duration_ms BIGINT NOT NULL DEFAULT 0,
    response TEXT,
    error_code VARCHAR(64),
    error_detail TEXT,
    dry_run BOOLEAN NOT NULL DEFAULT FALSE,
    created_epoch_ms BIGINT NOT NULL
)
;

CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log (created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log (user_id, created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_server ON audit_log (server_id, created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_audit_request ON audit_log (request_id)
;

CREATE TABLE IF NOT EXISTS security_audit (
    id BIGSERIAL PRIMARY KEY,
    request_id VARCHAR(64),
    event_type VARCHAR(64) NOT NULL,
    severity VARCHAR(16) NOT NULL,
    user_id VARCHAR(64),
    username VARCHAR(128),
    guild_id VARCHAR(64),
    channel_id VARCHAR(64),
    server_id VARCHAR(64),
    client_id VARCHAR(64),
    remote_address VARCHAR(64),
    detail TEXT,
    created_epoch_ms BIGINT NOT NULL
)
;

CREATE INDEX IF NOT EXISTS idx_security_created ON security_audit (created_epoch_ms)
;

CREATE INDEX IF NOT EXISTS idx_security_type ON security_audit (event_type, created_epoch_ms)
;

CREATE TABLE IF NOT EXISTS server_metadata (
    server_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(128),
    last_status VARCHAR(32),
    minecraft_version VARCHAR(64),
    plugin_version VARCHAR(64),
    last_seen_epoch_ms BIGINT,
    updated_epoch_ms BIGINT NOT NULL
)
;

CREATE TABLE IF NOT EXISTS gateway_state (
    state_key VARCHAR(64) PRIMARY KEY,
    state_value TEXT,
    updated_epoch_ms BIGINT NOT NULL
)
;