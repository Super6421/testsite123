package ru.zigono.dmc.gateway.db;

/**
 * A security relevant event. Security audit records are append only and are never exposed for deletion through
 * Discord commands.
 *
 * @author Zigono
 */
public record SecurityEvent(String requestId, String eventType, Severity severity, String userId, String username,
                            String guildId, String channelId, String serverId, String clientId, String remoteAddress,
                            String detail, long createdEpochMs) {

    public enum Severity {
        INFO,
        WARNING,
        CRITICAL
    }

    public static SecurityEvent of(String eventType, Severity severity, String detail) {
        return new SecurityEvent(null, eventType, severity, null, null, null, null, null, null, null, detail,
                System.currentTimeMillis());
    }
}