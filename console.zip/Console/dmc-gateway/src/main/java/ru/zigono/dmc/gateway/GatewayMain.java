package ru.zigono.dmc.gateway;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.OutputStreamAppender;
import ch.qos.logback.core.encoder.Encoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.certs.CertificateTool;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.common.logging.JsonLogEncoder;
import ru.zigono.dmc.protocol.ProtocolVersion;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Command line entry point of the gateway.
 * <pre>
 * java -jar dmc-gateway.jar run   [--config config/gateway.yml]
 * java -jar dmc-gateway.jar certs [--out tls] [--hosts localhost,10.0.0.5] [--clients survival,lobby] [--password secret] [--days 825]
 * java -jar dmc-gateway.jar version
 * </pre>
 *
 * @author Zigono
 */
public final class GatewayMain {

    public static void main(String[] args) throws Exception {
        final String command = args.length == 0 ? "run" : args[0];
        switch (command) {
            case "run" -> run(args);
            case "certs" -> certificates(args);
            case "version" -> System.out.println(GatewayBuild.describe());
            case "help", "--help", "-h" -> usage();
            default -> {
                usage();
                System.exit(2);
            }
        }
    }

    private static void run(String[] args) throws Exception {
        final Path configFile = Path.of(option(args, "--config", "config/gateway.yml"));
        final GatewayConfig probe = GatewayConfig.load(configFile);
        configureLogRedaction(probe.secretValues());
        final Logger logger = LoggerFactory.getLogger(GatewayMain.class);
        logger.info("{}", GatewayBuild.describe());
        logger.info("Загружена конфигурация {} (ревизия {})", configFile.toAbsolutePath(), probe.revision());
        final Gateway gateway = new Gateway(configFile);
        gateway.start();
        Thread.currentThread().join();
    }

    private static void certificates(String[] args) {
        final CertificateTool.Options options = new CertificateTool.Options(
                Path.of(option(args, "--out", "tls")),
                listOption(args, "--hosts", List.of("localhost")),
                listOption(args, "--clients", List.of()),
                option(args, "--password", "changeit").toCharArray(),
                Integer.parseInt(option(args, "--days", "825")));
        new CertificateTool().generate(options);
    }

    /**
     * Installs the configured secrets in the log encoder so they are redacted even when they leak into an
     * exception message or a stack trace.
     */
    private static void configureLogRedaction(List<String> secrets) {
        if (!(LoggerFactory.getILoggerFactory() instanceof LoggerContext context)) {
            return;
        }
        final List<String> all = new ArrayList<>(secrets);
        Iterator<Appender<ILoggingEvent>> appenders = context.getLogger("ROOT").iteratorForAppenders();
        while (appenders.hasNext()) {
            final Appender<ILoggingEvent> appender = appenders.next();
            if (appender instanceof OutputStreamAppender<ILoggingEvent> streamAppender) {
                final Encoder<ILoggingEvent> encoder = streamAppender.getEncoder();
                if (encoder instanceof JsonLogEncoder jsonEncoder) {
                    jsonEncoder.setSecrets(all);
                }
            }
        }
    }

    private static String option(String[] args, String name, String fallback) {
        for (int i = 0; i < args.length - 1; i++) {
            if (args[i].equals(name)) {
                return args[i + 1];
            }
        }
        return fallback;
    }

    private static List<String> listOption(String[] args, String name, List<String> fallback) {
        final String raw = option(args, name, null);
        if (raw == null || raw.isBlank()) {
            return fallback;
        }
        final List<String> values = new ArrayList<>();
        for (String value : raw.split(",")) {
            if (!value.isBlank()) {
                values.add(value.trim());
            }
        }
        return values;
    }

    private static void usage() {
        System.out.println(GatewayBuild.describe());
        System.out.println("Protocol version " + ProtocolVersion.describe());
        System.out.println();
        System.out.println("Usage:");
        System.out.println("  run    [--config config/gateway.yml]");
        System.out.println("  certs  [--out tls] [--hosts localhost,10.0.0.5] [--clients survival,lobby] [--password password] [--days 825]");
        System.out.println("  version");
    }
}