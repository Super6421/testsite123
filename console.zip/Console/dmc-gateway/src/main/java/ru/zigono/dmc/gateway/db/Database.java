package ru.zigono.dmc.gateway.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * JDBC access layer. SQLite and PostgreSQL are both supported through HikariCP; migrations are applied on
 * startup and every query is executed off the network threads.
 *
 * @author Zigono
 */
public final class Database implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(Database.class);

    private final GatewayConfig.DatabaseSettings settings;
    private final HikariDataSource dataSource;
    private final AtomicBoolean closed = new AtomicBoolean();

    private Database(GatewayConfig.DatabaseSettings settings, HikariDataSource dataSource) {
        this.settings = settings;
        this.dataSource = dataSource;
    }

    public static Database open(GatewayConfig.DatabaseSettings settings) {
        if (!settings.postgresql()) {
            final Path file = settings.sqliteFile().toAbsolutePath();
            try {
                if (file.getParent() != null) {
                    Files.createDirectories(file.getParent());
                }
            } catch (java.io.IOException e) {
                throw new IllegalStateException("Не удалось создать каталог базы данных " + file.getParent(), e);
            }
        }
        final HikariConfig hikari = new HikariConfig();
        hikari.setPoolName("dmc-" + settings.type());
        hikari.setMaximumPoolSize(settings.postgresql() ? Math.max(2, settings.poolSize()) : 4);
        hikari.setMinimumIdle(settings.postgresql() ? 1 : 1);
        hikari.setConnectionTimeout(Duration.ofSeconds(10).toMillis());
        hikari.setValidationTimeout(Duration.ofSeconds(5).toMillis());
        hikari.setMaxLifetime(Duration.ofMinutes(30).toMillis());
        if (settings.postgresql()) {
            hikari.setJdbcUrl("jdbc:postgresql://" + settings.host() + ":" + settings.port() + "/" + settings.database());
            hikari.setUsername(settings.username());
            hikari.setPassword(settings.password() == null ? "" : settings.password());
            hikari.addDataSourceProperty("reWriteBatchedInserts", "true");
            hikari.addDataSourceProperty("applicationName", "dmc-gateway");
        } else {
            hikari.setJdbcUrl("jdbc:sqlite:" + settings.sqliteFile().toAbsolutePath());
            hikari.setAutoCommit(true);
            hikari.addDataSourceProperty("busy_timeout", "5000");
            hikari.addDataSourceProperty("journal_mode", "WAL");
            hikari.addDataSourceProperty("synchronous", "NORMAL");
        }
        final Database database = new Database(settings, new HikariDataSource(hikari));
        database.migrate();
        return database;
    }

    public GatewayConfig.DatabaseSettings settings() {
        return settings;
    }

    public String dialect() {
        return settings.postgresql() ? "postgres" : "sqlite";
    }

    /**
     * Applies every migration found in {@code db/migration/&lt;dialect&gt;} that has not been applied yet.
     */
    public void migrate() {
        try (Connection connection = dataSource.getConnection()) {
            createMigrationTable(connection);
            final java.util.List<String> migrations = MigrationRunner.discover(dialect());
            for (String migration : migrations) {
                final String version = MigrationRunner.versionOf(migration);
                if (isApplied(connection, version)) {
                    continue;
                }
                final String sql = MigrationRunner.read(dialect(), migration);
                connection.setAutoCommit(false);
                try (Statement statement = connection.createStatement()) {
                    for (String part : MigrationRunner.split(sql)) {
                        statement.execute(part);
                    }
                    try (PreparedStatement insert = connection.prepareStatement(
                            "INSERT INTO schema_migrations (version, applied_epoch_ms) VALUES (?, ?)")) {
                        insert.setString(1, version);
                        insert.setLong(2, System.currentTimeMillis());
                        insert.executeUpdate();
                    }
                    connection.commit();
                    LOGGER.info("Применена миграция базы данных {} ({})", version, dialect());
                } catch (SQLException e) {
                    connection.rollback();
                    throw new IllegalStateException("Миграция " + version + " не удалась", e);
                } finally {
                    connection.setAutoCommit(true);
                }
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось применить миграции базы данных", e);
        }
    }

    private void createMigrationTable(Connection connection) throws SQLException {
        final String sql = settings.postgresql()
                ? "CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(64) PRIMARY KEY, applied_epoch_ms BIGINT NOT NULL)"
                : "CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_epoch_ms INTEGER NOT NULL)";
        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }

    private boolean isApplied(Connection connection, String version) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT 1 FROM schema_migrations WHERE version = ?")) {
            statement.setString(1, version);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    public Connection connection() throws SQLException {
        return dataSource.getConnection();
    }

    /**
     * @return {@code true} when the database answers a trivial query
     */
    public boolean healthy() {
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement()) {
            statement.setQueryTimeout(5);
            statement.execute("SELECT 1");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    @Override
    public void close() {
        if (closed.compareAndSet(false, true)) {
            dataSource.close();
            LOGGER.info("Пул соединений с базой данных закрыт");
        }
    }
}