package ru.zigono.dmc.gateway.queue;

import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.time.Duration;

/**
 * Retry policy. A command is retried only when it is certain that it never reached the Minecraft server:
 * a network error before the plugin accepted it, a server that was offline, or a full queue. A command that
 * was accepted but whose result is unknown is never replayed, because it may already have changed the world.
 *
 * @author Zigono
 */
public final class RetryPolicy {

    /**
     * Outcome of one attempt from the point of view of retry safety.
     */
    public enum AttemptResult {
        SUCCESS,
        NOT_DISPATCHED,
        DISPATCH_FAILED,
        SERVER_OFFLINE,
        ACCEPTED_UNKNOWN,
        FAILED
    }

    private final GatewayConfig.RetrySettings settings;

    public RetryPolicy(GatewayConfig.RetrySettings settings) {
        this.settings = settings;
    }

    public boolean enabled() {
        return settings.enabled();
    }

    public int maxAttempts() {
        return settings.maxAttempts();
    }

    /**
     * @param attempt      number of attempts already made
     * @param accepted     whether the plugin accepted the command
     * @param result       attempt result
     * @param cancelled    whether the queue was cancelled (for example by the shutdown policy)
     */
    public boolean canRetry(int attempt, boolean accepted, AttemptResult result, boolean cancelled) {
        if (!settings.enabled() || cancelled || accepted) {
            return false;
        }
        if (attempt >= settings.maxAttempts()) {
            return false;
        }
        return result == AttemptResult.NOT_DISPATCHED || result == AttemptResult.DISPATCH_FAILED
                || result == AttemptResult.SERVER_OFFLINE;
    }

    public Duration delay() {
        return settings.delay();
    }
}