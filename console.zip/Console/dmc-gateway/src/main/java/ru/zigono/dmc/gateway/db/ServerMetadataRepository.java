package ru.zigono.dmc.gateway.db;

import ru.zigono.dmc.protocol.dto.ServerMetrics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Persists the last known state of every Minecraft server so {@code /servers} can show history across restarts.
 *
 * @author Zigono
 */
public final class ServerMetadataRepository {

    private final Database database;

    public ServerMetadataRepository(Database database) {
        this.database = database;
    }

    public void upsert(String serverId, String name, String status, ServerMetrics metrics) {
        final String sql = """
                INSERT INTO server_metadata (server_id, name, last_status, minecraft_version, plugin_version,
                                             last_seen_epoch_ms, updated_epoch_ms)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(server_id) DO UPDATE SET name = excluded.name,
                                                     last_status = excluded.last_status,
                                                     minecraft_version = excluded.minecraft_version,
                                                     plugin_version = excluded.plugin_version,
                                                     last_seen_epoch_ms = excluded.last_seen_epoch_ms,
                                                     updated_epoch_ms = excluded.updated_epoch_ms""";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(
                     sql)) {
            statement.setString(1, serverId);
            statement.setString(2, name);
            statement.setString(3, status);
            statement.setString(4, metrics == null ? null : metrics.minecraftVersion());
            statement.setString(5, metrics == null ? null : metrics.pluginVersion());
            statement.setLong(6, metrics == null ? 0L : metrics.collectedAt());
            statement.setLong(7, System.currentTimeMillis());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось сохранить метаданные сервера " + serverId, e);
        }
    }
}