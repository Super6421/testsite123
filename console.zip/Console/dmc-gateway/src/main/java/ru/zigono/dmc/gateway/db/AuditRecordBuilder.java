package ru.zigono.dmc.gateway.db;

import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Mutable builder for {@link AuditRepository.AuditRecord}: a request produces one record per Minecraft server,
 * and every record shares the identity and request fields.
 *
 * @author Zigono
 */
public final class AuditRecordBuilder {

    private String requestId;
    private String userId;
    private String username;
    private String guildId;
    private String channelId;
    private String messageId;
    private String interactionId;
    private List<String> roles = new ArrayList<>();
    private String target;
    private String serverId;
    private String command;
    private String normalizedCommand;
    private String status;
    private long durationMs;
    private String response;
    private String errorCode;
    private String errorDetail;
    private boolean dryRun;
    private long createdEpochMs = System.currentTimeMillis();

    public AuditRecordBuilder requestId(String value) {
        this.requestId = value;
        return this;
    }

    public AuditRecordBuilder user(UserContext user) {
        if (user != null) {
            this.userId = user.userId();
            this.username = user.username();
            this.guildId = user.guildId();
            this.channelId = user.channelId();
            this.messageId = user.messageId();
            this.interactionId = user.interactionId();
            this.roles = new ArrayList<>(user.roleIds());
        }
        return this;
    }

    public AuditRecordBuilder target(String value) {
        this.target = value;
        return this;
    }

    public AuditRecordBuilder serverId(String value) {
        this.serverId = value;
        return this;
    }

    public AuditRecordBuilder command(String value) {
        this.command = value;
        return this;
    }

    public AuditRecordBuilder normalizedCommand(String value) {
        this.normalizedCommand = value;
        return this;
    }

    public AuditRecordBuilder status(String value) {
        this.status = value;
        return this;
    }

    public AuditRecordBuilder durationMs(long value) {
        this.durationMs = value;
        return this;
    }

    public AuditRecordBuilder response(String value) {
        this.response = value;
        return this;
    }

    public AuditRecordBuilder errorCode(String value) {
        this.errorCode = value;
        return this;
    }

    public AuditRecordBuilder errorDetail(String value) {
        this.errorDetail = value;
        return this;
    }

    public AuditRecordBuilder dryRun(boolean value) {
        this.dryRun = value;
        return this;
    }

    public AuditRecordBuilder createdEpochMs(long value) {
        this.createdEpochMs = value;
        return this;
    }

    public AuditRepository.AuditRecord build() {
        return new AuditRepository.AuditRecord(requestId, userId, username, guildId, channelId, messageId,
                interactionId, roles, target, serverId, command, normalizedCommand,
                status == null ? "UNKNOWN" : status, durationMs, response, errorCode, errorDetail, dryRun,
                createdEpochMs);
    }
}