package ru.zigono.dmc.gateway.net;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.queue.CommandDispatcher;
import ru.zigono.dmc.gateway.queue.QueuedCommand;
import ru.zigono.dmc.gateway.registry.PluginRegistry;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.transport.Connection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Delivers commands to Minecraft plugins and correlates their acceptance and result messages.
 *
 * @author Zigono
 */
public final class PluginCommandDispatcher implements CommandDispatcher {

    private static final Logger LOGGER = LoggerFactory.getLogger(PluginCommandDispatcher.class);

    private final PluginRegistry registry;
    private final Metrics metrics;
    private final Map<String, Pending> pending = new ConcurrentHashMap<>();

    public PluginCommandDispatcher(PluginRegistry registry, Metrics metrics) {
        this.registry = registry;
        this.metrics = metrics;
    }

    private record Pending(String serverId, CompletableFuture<ServerOutcome> outcome, CompletableFuture<Boolean> accepted) {
    }

    @Override
    public boolean available(String serverId) {
        return registry.connection(serverId).isPresent();
    }

    @Override
    public Optional<Dispatch> dispatch(QueuedCommand command) {
        final Connection connection = registry.connection(command.serverId()).orElse(null);
        if (connection == null) {
            return Optional.empty();
        }
        final CompletableFuture<ServerOutcome> outcome = new CompletableFuture<>();
        final CompletableFuture<Boolean> accepted = new CompletableFuture<>();
        final Pending pendingDispatch = new Pending(command.serverId(), outcome, accepted);
        pending.put(command.executionId(), pendingDispatch);

        final PluginMessages.CommandDispatch message = new PluginMessages.CommandDispatch();
        message.setClientId(command.serverId());
        message.setRequestId(command.executionId());
        message.serverId = command.serverId();
        message.command = command.command();
        message.targetDescription = command.serverId();
        message.issuer = command.issuer();
        message.visibility = command.visibility();
        message.issuedAt = System.currentTimeMillis();
        message.timeoutMillis = command.timeoutMillis();
        message.attempt = command.attempt();
        try {
            connection.send(message);
        } catch (RuntimeException e) {
            pending.remove(command.executionId());
            outcome.completeExceptionally(e);
            LOGGER.debug("Отправка {} в {} не удалась до записи кадра: {}", command.executionId(),
                    command.serverId(), e.getMessage());
            return Optional.of(new Dispatch(outcome, accepted));
        }
        return Optional.of(new Dispatch(outcome, accepted));
    }

    /**
     * Called when a plugin confirms that it took a command from the connection.
     */
    public void onAccepted(String serverId, String executionId, boolean accepted, String reason) {
        final Pending pendingDispatch = pending.get(executionId);
        if (pendingDispatch == null) {
            return;
        }
        if (accepted) {
            pendingDispatch.accepted().complete(true);
        } else {
            pending.remove(executionId);
            pendingDispatch.accepted().complete(false);
            pendingDispatch.outcome().complete(ServerOutcome.failure(serverId,
                    ru.zigono.dmc.protocol.dto.ExecutionStatus.FAILED,
                    ru.zigono.dmc.common.errors.ErrorCode.INTERNAL_ERROR.name(),
                    reason == null ? "плагин отклонил команду" : reason));
        }
    }

    /**
     * Called when a plugin reports the real result of an execution.
     */
    public void onOutcome(String serverId, String executionId, ServerOutcome outcome) {
        final Pending pendingDispatch = pending.remove(executionId);
        if (pendingDispatch == null) {
            LOGGER.debug("Поздний результат для неизвестного выполнения {} на {}", executionId, serverId);
            return;
        }
        pendingDispatch.accepted().complete(true);
        pendingDispatch.outcome().complete(outcome);
    }

    @Override
    public void onDisconnect(String serverId, String reason) {
        final List<String> affected = new ArrayList<>();
        for (Map.Entry<String, Pending> entry : pending.entrySet()) {
            if (entry.getValue().serverId().equals(serverId)) {
                affected.add(entry.getKey());
            }
        }
        for (String executionId : affected) {
            final Pending pendingDispatch = pending.remove(executionId);
            if (pendingDispatch != null) {
                pendingDispatch.outcome().completeExceptionally(
                        new ru.zigono.dmc.protocol.ProtocolException(ru.zigono.dmc.common.errors.ErrorCode.CONNECTION_LOST,
                                "соединение с " + serverId + " потеряно: " + reason));
            }
        }
        if (!affected.isEmpty()) {
            LOGGER.info("Завершено незавершённых команд {} ({} шт.) после отключения", affected.size(), serverId);
        }
    }

    public int pendingCount() {
        return pending.size();
    }

    public int pendingCount(String serverId) {
        return (int) pending.values().stream().filter(entry -> entry.serverId().equals(serverId)).count();
    }
}