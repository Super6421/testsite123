package ru.zigono.dmc.gateway.queue;

import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * One command waiting for or executing on a single Minecraft server.
 *
 * @author Zigono
 */
public final class QueuedCommand {

    private final String executionId = Ids.ulid();
    private final String requestId;
    private final String serverId;
    private final String command;
    private final UserContext issuer;
    private final CommandVisibility visibility;
    private final long timeoutMillis;
    private final boolean dryRun;
    private final long enqueuedAt = System.currentTimeMillis();
    private final CompletableFuture<ServerOutcome> result = new CompletableFuture<>();
    private final AtomicBoolean accepted = new AtomicBoolean();
    private final AtomicBoolean finished = new AtomicBoolean();
    private final AtomicInteger attempt = new AtomicInteger(1);

    public QueuedCommand(String requestId, String serverId, String command, UserContext issuer,
                         CommandVisibility visibility, long timeoutMillis, boolean dryRun) {
        this.requestId = requestId == null ? executionId : requestId;
        this.serverId = serverId;
        this.command = command;
        this.issuer = issuer;
        this.visibility = visibility;
        this.timeoutMillis = timeoutMillis;
        this.dryRun = dryRun;
    }

    public String executionId() {
        return executionId;
    }

    public String requestId() {
        return requestId;
    }

    public String serverId() {
        return serverId;
    }

    public String command() {
        return command;
    }

    public UserContext issuer() {
        return issuer;
    }

    public CommandVisibility visibility() {
        return visibility;
    }

    public long timeoutMillis() {
        return timeoutMillis;
    }

    public boolean dryRun() {
        return dryRun;
    }

    public long enqueuedAt() {
        return enqueuedAt;
    }

    public CompletableFuture<ServerOutcome> result() {
        return result;
    }

    public boolean accepted() {
        return accepted.get();
    }

    public void markAccepted() {
        accepted.set(true);
    }

    public boolean finished() {
        return finished.get();
    }

    public int attempt() {
        return attempt.get();
    }

    public int nextAttempt() {
        return attempt.incrementAndGet();
    }

    /**
     * Completes the command exactly once.
     *
     * @return {@code true} when this call completed the command
     */
    public boolean complete(ServerOutcome outcome) {
        if (finished.compareAndSet(false, true)) {
            result.complete(outcome);
            return true;
        }
        return false;
    }

    public long remainingMillis() {
        return timeoutMillis - (System.currentTimeMillis() - enqueuedAt);
    }
}