package ru.zigono.dmc.gateway.db;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Discovers and reads versioned SQL migrations bundled with the gateway.
 * Resources live in {@code db/migration/<dialect>/V<version>__<name>.sql}.
 *
 * @author Zigono
 */
public final class MigrationRunner {

    private static final String[] KNOWN_MIGRATIONS = {
            "V1__init.sql"
    };

    private MigrationRunner() {
    }

    public static List<String> discover(String dialect) {
        final List<String> migrations = new ArrayList<>(List.of(KNOWN_MIGRATIONS));
        migrations.sort(Comparator.naturalOrder());
        for (String migration : migrations) {
            if (MigrationRunner.class.getClassLoader()
                    .getResource("db/migration/" + dialect + "/" + migration) == null) {
                throw new IllegalStateException("Отсутствует встроенная миграция db/migration/" + dialect + "/" + migration);
            }
        }
        return List.copyOf(migrations);
    }

    public static String versionOf(String migration) {
        final int end = migration.indexOf("__");
        final String raw = end < 0 ? migration : migration.substring(0, end);
        return raw.startsWith("V") ? raw.substring(1) : raw;
    }

    public static String read(String dialect, String migration) {
        try (InputStream stream = MigrationRunner.class.getClassLoader()
                .getResourceAsStream("db/migration/" + dialect + "/" + migration)) {
            if (stream == null) {
                throw new IllegalStateException("Миграция не найдена: " + migration);
            }
            return new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Splits a migration file into individual statements: statements are separated by a line containing only
     * {@code ;}. This keeps triggers and multi line statements intact.
     */
    public static List<String> split(String sql) {
        final List<String> statements = new ArrayList<>();
        final StringBuilder current = new StringBuilder();
        for (String line : sql.split("\n")) {
            final String trimmed = line.trim();
            if (trimmed.startsWith("--") || trimmed.isEmpty()) {
                continue;
            }
            if (trimmed.equals(";")) {
                add(statements, current);
                continue;
            }
            current.append(line).append('\n');
            if (trimmed.endsWith(";")) {
                current.setLength(current.length() - 2);
                add(statements, current);
            }
        }
        add(statements, current);
        return statements;
    }

    private static void add(List<String> statements, StringBuilder current) {
        final String statement = current.toString().trim();
        current.setLength(0);
        if (!statement.isEmpty()) {
            statements.add(statement);
        }
    }
}