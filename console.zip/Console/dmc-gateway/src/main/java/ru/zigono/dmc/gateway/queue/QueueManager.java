package ru.zigono.dmc.gateway.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns one {@link ServerQueue} per server and implements the broadcast execution policy
 * ({@code parallel} or {@code sequential}, {@code continue} or {@code stop}).
 *
 * @author Zigono
 */
public final class QueueManager implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(QueueManager.class);

    private volatile GatewayConfig config;
    private final RetryPolicy retryPolicy;
    private final CommandDispatcher dispatcher;
    private final Metrics metrics;
    private final Map<String, ServerQueue> queues = new ConcurrentHashMap<>();

    public QueueManager(GatewayConfig config, RetryPolicy retryPolicy, CommandDispatcher dispatcher, Metrics metrics) {
        this.config = config;
        this.retryPolicy = retryPolicy;
        this.dispatcher = dispatcher;
        this.metrics = metrics;
    }

    /**
     * One broadcast request.
     */
    public record ExecutionRequest(String requestId, List<String> servers, String command, UserContext issuer,
                                   CommandVisibility visibility, boolean dryRun, long timeoutMillis) {
    }

    /**
     * Applies a hot reloaded configuration. Existing queues pick up the new settings; capacity changes take
     * effect for queues that are currently idle.
     */
    public void applyConfig(GatewayConfig updated) {
        this.config = updated;
    }

    public ServerQueue queue(String serverId) {
        return queues.computeIfAbsent(serverId,
                id -> new ServerQueue(id, config.queue(), retryPolicy, dispatcher, metrics));
    }

    public int totalQueueSize() {
        return queues.values().stream().mapToInt(ServerQueue::size).sum();
    }

    public boolean idle() {
        return queues.values().stream().allMatch(ServerQueue::idle);
    }

    public void onServerDisconnected(String serverId, String reason) {
        final ServerQueue queue = queues.get(serverId);
        if (queue != null) {
            queue.onDisconnect(reason);
        }
    }

    public void onServerReconnected(String serverId) {
        final ServerQueue queue = queues.get(serverId);
        if (queue != null) {
            queue.onReconnect();
        }
    }

    /**
     * Executes a command on all selected servers according to the configured policy.
     */
    public CompletableFuture<List<ServerOutcome>> execute(ExecutionRequest request) {
        if (request.dryRun()) {
            final List<ServerOutcome> outcomes = new ArrayList<>(request.servers().size());
            for (String serverId : request.servers()) {
                outcomes.add(new ServerOutcome(serverId, ExecutionStatus.DRY_RUN, List.of(), 0L, null,
                        "пробный запуск: команда не отправлена на сервер", request.requestId(), System.currentTimeMillis()));
            }
            return CompletableFuture.completedFuture(outcomes);
        }
        final String execution = config.broadcast().execution();
        if ("sequential".equals(execution)) {
            return executeSequentially(request);
        }
        return executeInParallel(request);
    }

    private CompletableFuture<List<ServerOutcome>> executeInParallel(ExecutionRequest request) {
        final List<CompletableFuture<ServerOutcome>> futures = new ArrayList<>();
        for (String serverId : request.servers()) {
            futures.add(submit(request, serverId));
        }
        return CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new))
                .thenApply(ignored -> collect(futures));
    }

    private CompletableFuture<List<ServerOutcome>> executeSequentially(ExecutionRequest request) {
        final List<ServerOutcome> outcomes = java.util.Collections.synchronizedList(new ArrayList<>());
        CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
        final boolean stopOnFailure = "stop".equals(config.broadcast().failurePolicy());
        for (String serverId : request.servers()) {
            chain = chain.thenCompose(ignored -> {
                if (stopOnFailure && hasFailure(outcomes)) {
                    outcomes.add(ServerOutcome.failure(serverId, ExecutionStatus.CANCELLED, "CANCELLED",
                            "skipped because a previous server failed"));
                    return CompletableFuture.completedFuture(null);
                }
                return submit(request, serverId).thenAccept(outcomes::add);
            });
        }
        return chain.thenApply(ignored -> new ArrayList<>(outcomes));
    }

    private CompletableFuture<ServerOutcome> submit(ExecutionRequest request, String serverId) {
        final QueuedCommand command = new QueuedCommand(request.requestId(), serverId, request.command(),
                request.issuer(), request.visibility(), request.timeoutMillis(), request.dryRun());
        LOGGER.debug("Команда {} поставлена в очередь для {}: {}", command.executionId(), serverId, request.command());
        return queue(serverId).submit(command);
    }

    private List<ServerOutcome> collect(List<CompletableFuture<ServerOutcome>> futures) {
        final List<ServerOutcome> outcomes = new ArrayList<>(futures.size());
        for (CompletableFuture<ServerOutcome> future : futures) {
            try {
                outcomes.add(future.join());
            } catch (RuntimeException e) {
                outcomes.add(ServerOutcome.failure("unknown", ExecutionStatus.FAILED, "INTERNAL_ERROR",
                        String.valueOf(e.getMessage())));
            }
        }
        return outcomes;
    }

    private boolean hasFailure(List<ServerOutcome> outcomes) {
        synchronized (outcomes) {
            for (ServerOutcome outcome : outcomes) {
                if (!outcome.status().successful()) {
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public void close() {
        queues.values().forEach(ServerQueue::close);
        queues.clear();
        LOGGER.info("Все очереди серверов остановлены");
    }
}