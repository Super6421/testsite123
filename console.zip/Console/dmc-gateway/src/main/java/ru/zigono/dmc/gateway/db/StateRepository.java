package ru.zigono.dmc.gateway.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * Small key/value store for gateway state that must survive a restart, for example the emergency kill switch.
 *
 * @author Zigono
 */
public final class StateRepository {

    private final Database database;

    public StateRepository(Database database) {
        this.database = database;
    }

    public Optional<String> get(String key) {
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT state_value FROM gateway_state WHERE state_key = ?")) {
            statement.setString(1, key);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? Optional.ofNullable(result.getString(1)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось прочитать состояние шлюза " + key, e);
        }
    }

    public void set(String key, String value) {
        final String sql = """
                INSERT INTO gateway_state (state_key, state_value, updated_epoch_ms) VALUES (?, ?, ?)
                ON CONFLICT(state_key) DO UPDATE SET state_value = excluded.state_value,
                                                     updated_epoch_ms = excluded.updated_epoch_ms""";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, key);
            statement.setString(2, value);
            statement.setLong(3, System.currentTimeMillis());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось записать состояние шлюза " + key, e);
        }
    }
}