package ru.zigono.dmc.gateway.certs;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.ExtendedKeyUsage;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.OutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

/**
 * Generates the TLS material of a deployment: a certificate authority, the gateway certificate and one client
 * certificate per Minecraft server, all stored as PKCS12 keystores plus PEM files for inspection.
 * <p>Run with {@code java -jar dmc-gateway.jar certs --out tls --hosts localhost,10.0.0.5 --clients survival,lobby}</p>
 *
 * @author Zigono
 */
public final class CertificateTool {

    private static final Logger LOGGER = LoggerFactory.getLogger(CertificateTool.class);

    private final SecureRandom random = new SecureRandom();

    public record Options(Path outputDirectory, List<String> hosts, List<String> clients, char[] password, int days) {
    }

    public void generate(Options options) {
        try {
            Files.createDirectories(options.outputDirectory());
            final KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(4096);
            final KeyPair authorityKeys = generator.generateKeyPair();
            final X500Name authorityName = new X500Name("CN=Discord Minecraft Console CA, O=Zigono");
            final X509Certificate authority = selfSigned(authorityName, authorityName, authorityKeys, options.days() * 5,
                    true, null);

            writePem(options.outputDirectory().resolve("ca.crt"), "CERTIFICATE", authority.getEncoded());
            store(options.outputDirectory().resolve("ca.p12"), "ca", authorityKeys.getPrivate(), authority,
                    options.password());

            final KeyPair gatewayKeys = keys(generator, 2048);
            final X509Certificate gateway = issued(authorityName, authorityKeys, "CN=dmc-gateway, O=Zigono",
                    gatewayKeys, options.days(), options.hosts(), false, null);
            writePem(options.outputDirectory().resolve("gateway.crt"), "CERTIFICATE", gateway.getEncoded());
            writePem(options.outputDirectory().resolve("gateway.key"), "PRIVATE KEY", gatewayKeys.getPrivate().getEncoded());
            store(options.outputDirectory().resolve("gateway.p12"), "gateway", gatewayKeys.getPrivate(), gateway,
                    options.password());
            store(options.outputDirectory().resolve("truststore.p12"), null, null, authority, options.password());

            for (String client : options.clients()) {
                final KeyPair clientKeys = keys(generator, 2048);
                final X509Certificate certificate = issued(authorityName, authorityKeys,
                        "CN=" + client + ", O=Zigono", clientKeys, options.days(), List.of(client), true,
                        KeyPurposeId.id_kp_clientAuth);
                store(options.outputDirectory().resolve("client-" + client + ".p12"), client,
                        clientKeys.getPrivate(), new Certificate[]{certificate, authority}, options.password());
                LOGGER.info("Сгенерирован клиентский сертификат для '{}'", client);
            }
            LOGGER.info("TLS-материалы записаны в {}", options.outputDirectory().toAbsolutePath());
        } catch (Exception e) {
            throw new IllegalStateException("Не удалось сгенерировать TLS-материалы", e);
        }
    }

    private KeyPair keys(KeyPairGenerator generator, int size) throws Exception {
        generator.initialize(size);
        return generator.generateKeyPair();
    }

    private X509Certificate selfSigned(X500Name subject, X500Name issuer, KeyPair keys, int days, boolean isCa,
                                       KeyPurposeId purpose) throws Exception {
        return issued(issuer, keys, subject.toString(), keys, days, List.of("localhost"), isCa, purpose);
    }

    private X509Certificate issued(X500Name issuerName, KeyPair issuerKeys, String subjectName, KeyPair subjectKeys,
                                   int days, List<String> hosts, boolean isCa, KeyPurposeId purpose) throws Exception {
        final X500Name subject = new X500Name(subjectName);
        final Instant now = Instant.now();
        final JcaX509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(issuerName,
                new BigInteger(96, random),
                Date.from(now.minus(1, ChronoUnit.HOURS)),
                Date.from(now.plus(days, ChronoUnit.DAYS)),
                subject,
                subjectKeys.getPublic());
        builder.addExtension(Extension.basicConstraints, true, new BasicConstraints(isCa));
        final List<GeneralName> names = new java.util.ArrayList<>();
        for (String host : hosts) {
            names.add(isIpAddress(host) ? new GeneralName(GeneralName.iPAddress, host)
                    : new GeneralName(GeneralName.dNSName, host));
        }
        builder.addExtension(Extension.subjectAlternativeName, false,
                new GeneralNames(names.toArray(GeneralName[]::new)));
        if (purpose != null) {
            builder.addExtension(Extension.extendedKeyUsage, false, new ExtendedKeyUsage(purpose));
        }
        final ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(issuerKeys.getPrivate());
        return new JcaX509CertificateConverter().getCertificate(builder.build(signer));
    }

    private boolean isIpAddress(String host) {
        return host.matches("^\\d{1,3}(\\.\\d{1,3}){3}$") || host.contains(":");
    }

    private void store(Path path, String alias, java.security.PrivateKey key, Certificate certificate, char[] password)
            throws Exception {
        store(path, alias, key, certificate == null ? new Certificate[0] : new Certificate[]{certificate}, password);
    }

    private void store(Path path, String alias, java.security.PrivateKey key, Certificate[] chain, char[] password)
            throws Exception {
        final KeyStore keyStore = KeyStore.getInstance("PKCS12");
        keyStore.load(null, password);
        if (alias != null && key != null) {
            keyStore.setKeyEntry(alias, key, password, chain);
        } else if (chain.length > 0) {
            keyStore.setCertificateEntry("ca", chain[chain.length - 1]);
        }
        try (OutputStream out = Files.newOutputStream(path)) {
            keyStore.store(out, password);
        }
    }

    private void writePem(Path path, String type, byte[] der) throws Exception {
        final String base64 = java.util.Base64.getMimeEncoder(64, "\n".getBytes(StandardCharsets.US_ASCII))
                .encodeToString(der);
        final String pem = "-----BEGIN " + type + "-----\n" + base64 + "\n-----END " + type + "-----\n";
        Files.writeString(path, pem, StandardCharsets.US_ASCII);
    }
}