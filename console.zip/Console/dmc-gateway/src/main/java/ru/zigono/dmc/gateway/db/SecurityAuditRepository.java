package ru.zigono.dmc.gateway.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Append only security audit. Records are written for dangerous commands, authentication failures, policy
 * violations and any protocol level security event; they are never deleted by a Discord command.
 *
 * @author Zigono
 */
public final class SecurityAuditRepository {

    private final Database database;

    public SecurityAuditRepository(Database database) {
        this.database = database;
    }

    public void insert(SecurityEvent event) {
        final String sql = """
                INSERT INTO security_audit (request_id, event_type, severity, user_id, username, guild_id, channel_id,
                                            server_id, client_id, remote_address, detail, created_epoch_ms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, event.requestId());
            statement.setString(2, event.eventType());
            statement.setString(3, event.severity().name());
            statement.setString(4, event.userId());
            statement.setString(5, event.username());
            statement.setString(6, event.guildId());
            statement.setString(7, event.channelId());
            statement.setString(8, event.serverId());
            statement.setString(9, event.clientId());
            statement.setString(10, event.remoteAddress());
            statement.setString(11, event.detail());
            statement.setLong(12, event.createdEpochMs());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось записать аудит безопасности", e);
        }
    }

    public List<SecurityEvent> recent(int limit) {
        final String sql = """
                SELECT request_id, event_type, severity, user_id, username, guild_id, channel_id, server_id, client_id,
                       remote_address, detail, created_epoch_ms
                FROM security_audit ORDER BY created_epoch_ms DESC, id DESC LIMIT ?""";
        final List<SecurityEvent> events = new ArrayList<>();
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, Math.max(1, Math.min(limit, 500)));
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    events.add(new SecurityEvent(
                            result.getString("request_id"),
                            result.getString("event_type"),
                            SecurityEvent.Severity.valueOf(result.getString("severity")),
                            result.getString("user_id"),
                            result.getString("username"),
                            result.getString("guild_id"),
                            result.getString("channel_id"),
                            result.getString("server_id"),
                            result.getString("client_id"),
                            result.getString("remote_address"),
                            result.getString("detail"),
                            result.getLong("created_epoch_ms")));
                }
            }
            return events;
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось прочитать аудит безопасности", e);
        }
    }

    /**
     * Applies the (separate, usually much longer) retention policy of the security audit.
     *
     * @return number of removed records
     */
    public int purgeOlderThan(long epochMillis, int batchLimit) {
        final String sql = "DELETE FROM security_audit WHERE id IN (SELECT id FROM security_audit WHERE created_epoch_ms < ? LIMIT ?)";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, epochMillis);
            statement.setInt(2, batchLimit);
            return statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось применить политику хранения аудита безопасности", e);
        }
    }
}