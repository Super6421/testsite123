package ru.zigono.dmc.gateway.net;

import ru.zigono.dmc.gateway.queue.CommandDispatcher;
import ru.zigono.dmc.gateway.queue.QueuedCommand;
import ru.zigono.dmc.gateway.redis.RedisCoordinator;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.PluginMessages;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * Dispatcher used for horizontal scaling: commands for servers connected to this instance go through the local
 * plugin connection, commands for servers connected to another instance are published over Redis.
 * <p>A remote dispatch completes the "accepted" future immediately, because after publishing there is no way to
 * know whether the remote plugin already started executing: the command must therefore never be retried.</p>
 *
 * @author Zigono
 */
public final class ClusterCommandDispatcher implements CommandDispatcher {

    private final PluginCommandDispatcher local;
    private final RedisCoordinator redis;

    public ClusterCommandDispatcher(PluginCommandDispatcher local, RedisCoordinator redis) {
        this.local = local;
        this.redis = redis;
    }

    @Override
    public boolean available(String serverId) {
        return local.available(serverId) || redis != null;
    }

    @Override
    public Optional<Dispatch> dispatch(QueuedCommand command) {
        if (local.available(command.serverId())) {
            return local.dispatch(command);
        }
        if (redis == null) {
            return Optional.empty();
        }
        final PluginMessages.CommandDispatch message = new PluginMessages.CommandDispatch();
        message.setClientId(command.serverId());
        message.setRequestId(command.executionId());
        message.serverId = command.serverId();
        message.command = command.command();
        message.targetDescription = command.serverId();
        message.issuer = command.issuer();
        message.visibility = command.visibility();
        message.issuedAt = System.currentTimeMillis();
        message.timeoutMillis = command.timeoutMillis();
        message.attempt = command.attempt();
        final CompletableFuture<ServerOutcome> outcome = redis.route(message,
                java.time.Duration.ofMillis(Math.max(1000L, command.timeoutMillis())));
        final CompletableFuture<Boolean> accepted = CompletableFuture.completedFuture(true);
        return Optional.of(new Dispatch(outcome, accepted));
    }

    @Override
    public void onDisconnect(String serverId, String reason) {
        local.onDisconnect(serverId, reason);
    }

    public PluginCommandDispatcher local() {
        return local;
    }

    public Optional<RedisCoordinator> redis() {
        return Optional.ofNullable(redis);
    }
}