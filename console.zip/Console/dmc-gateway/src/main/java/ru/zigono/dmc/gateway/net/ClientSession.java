package ru.zigono.dmc.gateway.net;

import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.transport.Connection;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Server side state of one inbound connection: which identity it proved, which role it has and whether the
 * handshake completed.
 *
 * @author Zigono
 */
public final class ClientSession {

    /** Handshake states, in order. */
    public enum State {
        CONNECTED,
        HELLO_RECEIVED,
        AUTHENTICATED,
        REJECTED
    }

    /** Roles a peer may claim. */
    public static final String ROLE_PLUGIN = "plugin";
    public static final String ROLE_CONTROL = "control";

    private final Connection connection;
    private final String sessionId = Ids.ulid();
    private final AtomicReference<State> state = new AtomicReference<>(State.CONNECTED);
    private final long connectedAt = System.currentTimeMillis();
    private volatile String role;
    private volatile String clientId;
    private volatile String serverId;
    private volatile String challenge;
    private volatile String agentVersion;
    private volatile String platform;

    public ClientSession(Connection connection) {
        this.connection = connection;
    }

    public Connection connection() {
        return connection;
    }

    public String sessionId() {
        return sessionId;
    }

    public State state() {
        return state.get();
    }

    public void state(State value) {
        state.set(value);
    }

    public String role() {
        return role;
    }

    public void role(String value) {
        this.role = value;
    }

    public String clientId() {
        return clientId;
    }

    public void clientId(String value) {
        this.clientId = value;
    }

    public String serverId() {
        return serverId;
    }

    public void serverId(String value) {
        this.serverId = value;
    }

    public String challenge() {
        return challenge;
    }

    public void challenge(String value) {
        this.challenge = value;
    }

    public String agentVersion() {
        return agentVersion;
    }

    public void agentVersion(String value) {
        this.agentVersion = value;
    }

    public String platform() {
        return platform;
    }

    public void platform(String value) {
        this.platform = value;
    }

    public long connectedAt() {
        return connectedAt;
    }

    public boolean authenticated() {
        return state.get() == State.AUTHENTICATED;
    }

    public boolean plugin() {
        return ROLE_PLUGIN.equals(role);
    }

    @Override
    public String toString() {
        return "ClientSession[" + sessionId + ", state=" + state.get() + ", client=" + clientId + ", role=" + role
                + ", server=" + serverId + "]";
    }
}