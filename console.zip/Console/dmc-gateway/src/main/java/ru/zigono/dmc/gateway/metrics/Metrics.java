package ru.zigono.dmc.gateway.metrics;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Supplier;

/**
 * In process metrics registry with a Prometheus text exposition format. Metric names follow the specification:
 * {@code commands_total}, {@code commands_success_total}, {@code commands_failed_total},
 * {@code commands_denied_total}, {@code command_latency}, {@code connected_servers}, {@code offline_servers},
 * {@code queue_size}, {@code rate_limit_hits}, {@code authentication_failures}.
 *
 * @author Zigono
 */
public final class Metrics {

    public static final String COMMANDS_TOTAL = "commands_total";
    public static final String COMMANDS_SUCCESS_TOTAL = "commands_success_total";
    public static final String COMMANDS_FAILED_TOTAL = "commands_failed_total";
    public static final String COMMANDS_DENIED_TOTAL = "commands_denied_total";
    public static final String COMMAND_LATENCY = "command_latency";
    public static final String CONNECTED_SERVERS = "connected_servers";
    public static final String OFFLINE_SERVERS = "offline_servers";
    public static final String QUEUE_SIZE = "queue_size";
    public static final String RATE_LIMIT_HITS = "rate_limit_hits";
    public static final String AUTHENTICATION_FAILURES = "authentication_failures";
    public static final String REPLAY_REJECTIONS = "replay_rejections";
    public static final String PROTOCOL_VIOLATIONS = "protocol_violations";
    public static final String AUDIT_WRITE_FAILURES = "audit_write_failures";

    private static final long[] LATENCY_BUCKETS = {5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10_000};

    private final ConcurrentMap<String, LongAdder> counters = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Supplier<Number>> gauges = new ConcurrentHashMap<>();
    private final LongAdder[] buckets = new LongAdder[LATENCY_BUCKETS.length];
    private final LongAdder latencyCount = new LongAdder();
    private final LongAdder latencySum = new LongAdder();
    private final LongAdder latencyMax = new LongAdder();
    private final long startedAt = System.currentTimeMillis();

    public Metrics() {
        for (int i = 0; i < buckets.length; i++) {
            buckets[i] = new LongAdder();
        }
    }

    public void increment(String name) {
        add(name, 1L);
    }

    public void add(String name, long value) {
        counters.computeIfAbsent(name, ignored -> new LongAdder()).add(value);
    }

    public long counter(String name) {
        final LongAdder adder = counters.get(name);
        return adder == null ? 0L : adder.sum();
    }

    public void gauge(String name, Supplier<Number> supplier) {
        gauges.put(name, supplier);
    }

    public void recordLatency(long millis) {
        latencyCount.increment();
        latencySum.add(millis);
        latencyMax.add(millis);
        for (int i = 0; i < LATENCY_BUCKETS.length; i++) {
            if (millis <= LATENCY_BUCKETS[i]) {
                buckets[i].increment();
            }
        }
    }

    public long latencyCount() {
        return latencyCount.sum();
    }

    public long uptimeSeconds() {
        return (System.currentTimeMillis() - startedAt) / 1000L;
    }

    /**
     * @return the metrics in Prometheus text exposition format (version 0.0.4)
     */
    public String render() {
        final StringBuilder out = new StringBuilder(2048);
        out.append("# HELP dmc_uptime_seconds Gateway uptime in seconds\n");
        out.append("# TYPE dmc_uptime_seconds gauge\n");
        out.append("dmc_uptime_seconds ").append(uptimeSeconds()).append('\n');

        counters.forEach((name, adder) -> {
            out.append("# TYPE dmc_").append(name).append(" counter\n");
            out.append("dmc_").append(name).append(' ').append(adder.sum()).append('\n');
        });
        gauges.forEach((name, supplier) -> {
            out.append("# TYPE dmc_").append(name).append(" gauge\n");
            out.append("dmc_").append(name).append(' ').append(value(supplier)).append('\n');
        });

        out.append("# TYPE dmc_").append(COMMAND_LATENCY).append(" summary\n");
        double cumulative = 0;
        for (int i = 0; i < LATENCY_BUCKETS.length; i++) {
            cumulative = buckets[i].sum();
            out.append("dmc_").append(COMMAND_LATENCY).append("_bucket{le=\"")
                    .append(LATENCY_BUCKETS[i]).append("\"} ").append((long) cumulative).append('\n');
        }
        out.append("dmc_").append(COMMAND_LATENCY).append("_bucket{le=\"+Inf\"} ")
                .append(latencyCount.sum()).append('\n');
        out.append("dmc_").append(COMMAND_LATENCY).append("_count ").append(latencyCount.sum()).append('\n');
        out.append("dmc_").append(COMMAND_LATENCY).append("_sum ").append(latencySum.sum()).append('\n');
        out.append("dmc_").append(COMMAND_LATENCY).append("_max ").append(latencyMax.sum()).append('\n');
        return out.toString();
    }

    private double value(Supplier<Number> supplier) {
        final Number number = supplier.get();
        return number == null ? 0d : number.doubleValue();
    }

    public Map<String, Long> snapshot() {
        final Map<String, Long> snapshot = new ConcurrentHashMap<>();
        counters.forEach((name, adder) -> snapshot.put(name, adder.sum()));
        return snapshot;
    }

    public IdempotentRegistrar registrar() {
        return this::gauge;
    }

    /** Functional alias used to keep gauge registration compact. */
    @FunctionalInterface
    public interface IdempotentRegistrar {
        void gauge(String name, Supplier<Number> supplier);
    }
}