package ru.zigono.dmc.gateway.net;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.security.IpAllowlist;
import ru.zigono.dmc.common.target.ServerCatalog;
import ru.zigono.dmc.common.util.Hashing;
import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.gateway.api.ControlApi;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.db.SecurityAuditRepository;
import ru.zigono.dmc.gateway.db.SecurityEvent;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.queue.QueueManager;
import ru.zigono.dmc.gateway.registry.PluginRegistry;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.MessageTypes;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.ProtocolVersion;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.message.HandshakeMessages;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.transport.Connection;
import ru.zigono.dmc.protocol.transport.ConnectionHandler;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

/**
 * Handshake, authentication and message routing for every inbound connection.
 * <p>No message is processed before the peer proved possession of its shared secret; after that the connection
 * is pinned to that identity by the transport codec, so it can never speak for somebody else.</p>
 *
 * @author Zigono
 */
public final class GatewayConnectionHandler implements ConnectionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GatewayConnectionHandler.class);

    private final Supplier<GatewayConfig> configSupplier;
    private final PluginRegistry registry;
    private final PluginCommandDispatcher dispatcher;
    private final QueueManager queueManager;
    private final ControlApi controlApi;
    private final Metrics metrics;
    private final SecurityAuditRepository securityAudit;
    private final IpAllowlist allowlist;
    private final Map<String, ClientSession> sessions = new ConcurrentHashMap<>();

    public GatewayConnectionHandler(Supplier<GatewayConfig> configSupplier, PluginRegistry registry,
                                    PluginCommandDispatcher dispatcher, QueueManager queueManager, ControlApi controlApi,
                                    Metrics metrics, SecurityAuditRepository securityAudit, IpAllowlist allowlist) {
        this.configSupplier = configSupplier;
        this.registry = registry;
        this.dispatcher = dispatcher;
        this.queueManager = queueManager;
        this.controlApi = controlApi;
        this.metrics = metrics;
        this.securityAudit = securityAudit;
        this.allowlist = allowlist;
    }

    @Override
    public void onOpen(Connection connection) {
        if (!allowlist.allows(connection.remoteAddress())) {
            metrics.increment("rejected_connections_total");
            recordSecurity(SecurityEvent.Severity.CRITICAL, "IP_NOT_ALLOWED", connection, null,
                    "соединение из " + connection.remoteAddress() + " отсутствует в allowlist");
            connection.close();
            return;
        }
        sessions.put(connection.id(), new ClientSession(connection));
        if (configSupplier.get().logging().connections()) {
            LOGGER.info("Соединение открыто: {} от {}", connection.id(), connection.remoteAddress());
        }
    }

    @Override
    public void onMessage(Connection connection, Message message) {
        final ClientSession session = sessions.computeIfAbsent(connection.id(), id -> new ClientSession(connection));
        try {
            switch (session.state()) {
                case CONNECTED -> handleHello(session, message);
                case HELLO_RECEIVED -> handleAuth(session, message);
                case AUTHENTICATED -> handleAuthenticated(session, message);
                case REJECTED -> connection.close();
            }
        } catch (ProtocolException e) {
            metrics.increment(ErrorCode.AUTHENTICATION_FAILED == e.code() ? Metrics.AUTHENTICATION_FAILURES
                    : Metrics.PROTOCOL_VIOLATIONS);
            recordSecurity(SecurityEvent.Severity.CRITICAL, "PROTOCOL_VIOLATION", connection, session,
                    e.getMessage());
            reject(session, e.code(), e.getMessage());
        } catch (RuntimeException e) {
            LOGGER.error("Непредвиденная ошибка при обработке {} от {}", MessageTypes.nameOf(message.getClass()),
                    connection.remoteAddress(), e);
            metrics.increment("handler_failures_total");
            connection.close();
        }
    }

    private void handleHello(ClientSession session, Message message) {
        if (!(message instanceof HandshakeMessages.Hello hello)) {
            throw new ProtocolException(ErrorCode.PROTOCOL_ERROR,
                    "expected HELLO but received " + MessageTypes.nameOf(message.getClass()));
        }
        final GatewayConfig config = configSupplier.get();
        if (!ProtocolVersion.isCompatible(hello.getProtocolVersion())) {
            throw new ProtocolException(ErrorCode.PROTOCOL_ERROR,
                    "peer speaks protocol version " + hello.getProtocolVersion() + ", эта сборка шлюза поддерживает "
                            + ProtocolVersion.describe());
        }
        final String clientId = session.connection().clientId();
        if (clientId == null || clientId.isBlank()) {
            throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED,
                    "HELLO without a cryptographically verified sender identity");
        }
        final String role = resolveRole(config, clientId, hello);
        session.clientId(clientId);
        session.role(role);
        session.serverId(hello.serverId);
        session.agentVersion(hello.agentVersion);
        session.platform(hello.platform);
        session.challenge(Ids.nonce(24));
        session.state(ClientSession.State.HELLO_RECEIVED);

        final HandshakeMessages.HelloAck ack = message.correlate(new HandshakeMessages.HelloAck());
        ack.setClientId(clientId);
        ack.gatewayId = config.gatewayId();
        ack.gatewayVersion = ru.zigono.dmc.gateway.GatewayBuild.VERSION;
        ack.minSupportedProtocolVersion = ProtocolVersion.MIN_SUPPORTED;
        ack.maxSupportedProtocolVersion = ProtocolVersion.CURRENT;
        ack.heartbeatIntervalSeconds = (int) config.heartbeat().interval().toSeconds();
        ack.challenge = session.challenge();
        ack.configRevision = config.revision();
        ack.emergencyMode = false;
        ack.serverTime = System.currentTimeMillis();
        session.connection().send(ack);
    }

    private String resolveRole(GatewayConfig config, String clientId, HandshakeMessages.Hello hello) {
        final String claimed = hello.role == null ? "" : hello.role.toLowerCase(java.util.Locale.ROOT);
        final ServerCatalog.ServerDefinition server = config.catalog().find(clientId).orElse(null);
        if (server != null) {
            if (!claimed.isEmpty() && !claimed.equals(ClientSession.ROLE_PLUGIN)) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED,
                        "server '" + clientId + "' должен подключаться в роли 'plugin'");
            }
            if (!server.enabled()) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "server '" + clientId + "' выключен");
            }
            if (hello.serverId != null && !hello.serverId.isBlank() && !hello.serverId.equalsIgnoreCase(server.id())) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED,
                        "plugin identity '" + clientId + "' не может заявлять сервер '" + hello.serverId + "'");
            }
            return ClientSession.ROLE_PLUGIN;
        }
        if (config.controlSecrets().containsKey(clientId)) {
            if (!claimed.isEmpty() && !claimed.equals(ClientSession.ROLE_CONTROL)) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED,
                        "control client '" + clientId + "' должен подключаться в роли 'control'");
            }
            return ClientSession.ROLE_CONTROL;
        }
        throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "неизвестный id клиента '" + clientId + "'");
    }

    private void handleAuth(ClientSession session, Message message) {
        if (!(message instanceof HandshakeMessages.AuthRequest auth)) {
            throw new ProtocolException(ErrorCode.PROTOCOL_ERROR,
                    "expected AUTH but received " + MessageTypes.nameOf(message.getClass()));
        }
        final GatewayConfig config = configSupplier.get();
        if (auth.challenge == null || session.challenge() == null
                || !Hashing.constantTimeEquals(auth.challenge, session.challenge())) {
            throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "authentication challenge mismatch");
        }
        final String clientId = session.clientId();
        final boolean plugin = ClientSession.ROLE_PLUGIN.equals(session.role());
        final String serverId;
        if (plugin) {
            final ServerCatalog.ServerDefinition definition = config.catalog().find(clientId).orElseThrow(
                    () -> new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "неизвестный сервер '" + clientId + "'"));
            if (!definition.enabled()) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "server '" + definition.id() + "' выключен");
            }
            serverId = definition.id();
        } else {
            if (!config.controlSecrets().containsKey(clientId)) {
                throw new ProtocolException(ErrorCode.AUTHENTICATION_FAILED, "неизвестный управляющий клиент '" + clientId + "'");
            }
            serverId = null;
        }
        session.state(ClientSession.State.AUTHENTICATED);
        session.connection().bind(clientId);
        session.connection().setRole(session.role());
        session.connection().attributes().put("sessionId", session.sessionId());

        if (plugin) {
            final boolean first = registry.register(serverId, session.connection());
            queueManager.onServerReconnected(serverId);
            metrics.increment("plugin_connections_total");
            if (config.logging().connections()) {
                LOGGER.info("Minecraft-сервер '{}' прошёл аутентификацию (сессия {}, агент {}{})", serverId, session.sessionId(),
                        auth.agentVersion, first ? "" : ", заменяю существующее соединение");
            }
        } else if (config.logging().connections()) {
            LOGGER.info("Управляющий клиент '{}' прошёл аутентификацию (сессия {}, агент {})", clientId, session.sessionId(),
                    auth.agentVersion);
        }

        final HandshakeMessages.AuthResult result = message.correlate(new HandshakeMessages.AuthResult());
        result.setClientId(clientId);
        result.authenticated = true;
        result.sessionId = session.sessionId();
        result.serverId = serverId;
        result.gatewayId = config.gatewayId();
        result.configRevision = config.revision();
        result.heartbeatIntervalSeconds = (int) config.heartbeat().interval().toSeconds();
        result.message = "authenticated";
        result.serverTime = System.currentTimeMillis();
        session.connection().send(result);
    }

    private void handleAuthenticated(ClientSession session, Message message) {
        if (ClientSession.ROLE_PLUGIN.equals(session.role())) {
            handlePluginMessage(session, message);
            return;
        }
        if (message instanceof HandshakeMessages.Ping ping) {
            session.connection().send(pong(session, ping));
            return;
        }
        final Message response = controlApi.handle(message);
        if (response != null) {
            response.setClientId(session.clientId());
            session.connection().send(response);
        }
    }

    private void handlePluginMessage(ClientSession session, Message message) {
        final String serverId = session.serverId();
        if (message instanceof PluginMessages.Heartbeat heartbeat) {
            registry.heartbeat(serverId, heartbeat.metrics, heartbeat.status, heartbeat.queuedCommands);
            final PluginMessages.HeartbeatAck ack = message.correlate(new PluginMessages.HeartbeatAck());
            ack.setClientId(serverId);
            ack.heartbeatIntervalSeconds = (int) configSupplier.get().heartbeat().interval().toSeconds();
            ack.serverTime = System.currentTimeMillis();
            ack.sequence = heartbeat.sequence;
            session.connection().send(ack);
            return;
        }
        if (message instanceof PluginMessages.CommandAccepted accepted) {
            dispatcher.onAccepted(serverId, message.getRequestId(), accepted.accepted, accepted.reason);
            return;
        }
        if (message instanceof PluginMessages.CommandOutcomeMessage outcome) {
            dispatcher.onOutcome(serverId, message.getRequestId(), outcome.outcome);
            return;
        }
        if (message instanceof HandshakeMessages.Ping ping) {
            session.connection().send(pong(session, ping));
            return;
        }
        throw new ProtocolException(ErrorCode.PROTOCOL_ERROR,
                "plugin '" + serverId + "' sent an unexpected message " + MessageTypes.nameOf(message.getClass()));
    }

    private HandshakeMessages.Pong pong(ClientSession session, HandshakeMessages.Ping ping) {
        final HandshakeMessages.Pong pong = ping.correlate(new HandshakeMessages.Pong());
        pong.setClientId(ping.getClientId());
        pong.sentAt = ping.sentAt;
        pong.sequence = ping.sequence;
        pong.serverTime = System.currentTimeMillis();
        final long rtt = System.currentTimeMillis() - ping.sentAt;
        session.connection().setLatencyMillis(Math.max(0L, rtt));
        if (session.serverId() != null) {
            registry.state(session.serverId()).latencyMillis(Math.max(0L, rtt));
        }
        return pong;
    }

    private void reject(ClientSession session, ErrorCode code, String detail) {
        session.state(ClientSession.State.REJECTED);
        metrics.increment(Metrics.AUTHENTICATION_FAILURES);
        try {
            if (session.connection().open()) {
                final HandshakeMessages.AuthResult failure = new HandshakeMessages.AuthResult();
                failure.setClientId(session.clientId());
                failure.setRequestId(Ids.ulid());
                failure.authenticated = false;
                failure.errorCode = code.name();
                failure.errorDetail = detail;
                failure.serverTime = System.currentTimeMillis();
                session.connection().send(failure);
            }
        } catch (RuntimeException ignored) {
            LOGGER.debug("Не удалось отправить отказ {}", session.connection().remoteAddress());
        }
        session.connection().close();
    }

    @Override
    public void onClose(Connection connection) {
        final ClientSession session = sessions.remove(connection.id());
        if (session == null) {
            return;
        }
        final GatewayConfig config = configSupplier.get();
        if (ClientSession.ROLE_PLUGIN.equals(session.role()) && session.serverId() != null) {
            registry.unregister(session.serverId(), connection);
            dispatcher.onDisconnect(session.serverId(), "connection closed");
            queueManager.onServerDisconnected(session.serverId(), "connection closed");
            registry.state(session.serverId()).status(ServerStatus.OFFLINE);
            if (config.logging().connections()) {
                LOGGER.info("Minecraft-сервер '{}' отключился", session.serverId());
            }
        } else if (config.logging().connections()) {
            LOGGER.info("Управляющий клиент '{}' отключился", session.clientId());
        }
    }

    @Override
    public void onFailure(Connection connection, Throwable cause) {
        final ClientSession session = sessions.get(connection.id());
        if (cause instanceof ProtocolException protocolException) {
            metrics.increment(Metrics.PROTOCOL_VIOLATIONS);
            recordSecurity(SecurityEvent.Severity.WARNING, "TRANSPORT_VIOLATION", connection, session,
                    protocolException.getMessage());
            return;
        }
        if (configSupplier.get().logging().errors()) {
            LOGGER.warn("Соединение {} завершилось ошибкой: {}", connection.id(), cause == null ? "неизвестно" : cause.getMessage());
        }
    }

    private void recordSecurity(SecurityEvent.Severity severity, String eventType, Connection connection,
                                ClientSession session, String detail) {
        try {
            securityAudit.insert(new SecurityEvent(null, eventType, severity,
                    null, null, null, null,
                    session == null ? null : session.serverId(),
                    session == null ? connection.clientId() : session.clientId(),
                    connection.remoteAddress(), detail, System.currentTimeMillis()));
        } catch (RuntimeException e) {
            LOGGER.error("Не удалось записать аудит безопасности", e);
        }
    }

    public List<ClientSession> sessions() {
        return List.copyOf(sessions.values());
    }

    public int pluginSessionCount() {
        return (int) sessions.values().stream().filter(ClientSession::authenticated).filter(ClientSession::plugin).count();
    }
}