package ru.zigono.dmc.gateway.api;

import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.UserContext;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Issues and validates the confirmation tokens used for dangerous commands.
 * <p>A token is bound to the requesting Discord user, the target selection, the normalized command and a
 * deadline. It is single use: the moment it is accepted it is removed, so a replayed confirmation is rejected.
 * Tokens are validated on the gateway and never on the Discord client, therefore a compromised bot cannot skip
 * the confirmation step of the pipeline.</p>
 *
 * @author Zigono
 */
public final class ConfirmationRegistry {

    /**
     * Outcome of a confirmation attempt.
     *
     * @param accepted  {@code true} when the token was valid and has been consumed
     * @param token     a freshly issued token, present when {@code accepted} is {@code false}
     * @param reason    human readable rejection reason
     * @param expiresAt epoch milliseconds at which the freshly issued token expires
     */
    public record Verdict(boolean accepted, String token, String reason, long expiresAt) {

        public static Verdict confirmed() {
            return new Verdict(true, null, "confirmed", 0L);
        }

        public static Verdict rejected(String token, String reason, long expiresAt) {
            return new Verdict(false, token, reason, expiresAt);
        }
    }

    private record Pending(String userKey, String targetKey, String command, long expiresAt) {
    }

    private final Map<String, Pending> pending = new ConcurrentHashMap<>();
    private final int maxEntries;

    public ConfirmationRegistry() {
        this(4096);
    }

    public ConfirmationRegistry(int maxEntries) {
        this.maxEntries = maxEntries;
    }

    /**
     * Issues a token for a dangerous command.
     *
     * @param user      requesting user
     * @param target    resolved target selection
     * @param command   normalized command
     * @param timeout   validity window
     */
    public Verdict issue(UserContext user, TargetSelection target, String command, Duration timeout) {
        purge();
        if (pending.size() >= maxEntries) {
            purgeExpired();
        }
        if (pending.size() >= maxEntries) {
            return Verdict.rejected(null, "too many pending confirmations, retry later",
                    System.currentTimeMillis());
        }
        final long expiresAt = System.currentTimeMillis() + Math.max(1L, timeout.toMillis());
        final String token = Ids.ulid();
        pending.put(token, new Pending(userKey(user), targetKey(target), command, expiresAt));
        return Verdict.rejected(token, "command requires confirmation", expiresAt);
    }

    /**
     * Validates and consumes a token. A missing, expired, replayed or mismatching token is rejected and a new
     * token is issued so the user can simply confirm again.
     *
     * @param token   token presented by the client, may be {@code null}
     * @param user    requesting user
     * @param target  resolved target selection
     * @param command normalized command
     * @param timeout validity window used for the replacement token
     */
    public Verdict consume(String token, UserContext user, TargetSelection target, String command, Duration timeout) {
        purge();
        if (token == null || token.isBlank()) {
            return issue(user, target, command, timeout);
        }
        final Pending entry = pending.get(token);
        if (entry == null || entry.expiresAt() < System.currentTimeMillis()) {
            return issue(user, target, command, timeout);
        }
        if (!entry.userKey().equals(userKey(user))) {
            return issue(user, target, command, timeout);
        }
        if (!entry.targetKey().equals(targetKey(target)) || !entry.command().equals(command)) {
            return issue(user, target, command, timeout);
        }
        if (!pending.remove(token, entry)) {
            return issue(user, target, command, timeout);
        }
        return Verdict.confirmed();
    }

    /** Drops expired entries. */
    public void purge() {
        final long now = System.currentTimeMillis();
        pending.entrySet().removeIf(entry -> entry.getValue().expiresAt() < now);
    }

    private void purgeExpired() {
        purge();
    }

    public int size() {
        return pending.size();
    }

    private static String userKey(UserContext user) {
        return user == null ? "anonymous" : user.userId() + "@" + user.guildId();
    }

    private static String targetKey(TargetSelection target) {
        return target == null ? "none" : target.describe() + "|" + target.server() + "|" + target.group() + "|"
                + target.all() + "|" + target.servers();
    }
}