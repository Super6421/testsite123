package ru.zigono.dmc.gateway.auth;

import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.Permission;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.common.target.ServerCatalog;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Authoritative authorization: resolves the effective Discord permissions of a user and turns them into the
 * list of servers, groups and capabilities the user may use. The bot renders this view, the gateway enforces it.
 *
 * @author Zigono
 */
public final class AuthorizationService {

    private final Supplier<GatewayConfig> configSupplier;

    public AuthorizationService(Supplier<GatewayConfig> configSupplier, ServerStatusLookup statusLookup) {
        this.configSupplier = configSupplier;
        this.statusLookup = statusLookup;
    }

    /** Supplies the current status of a server for the UI view. */
    @FunctionalInterface
    public interface ServerStatusLookup {
        ServerStatus statusOf(String serverId);
    }

    private final ServerStatusLookup statusLookup;

    public PermissionSet permissionsOf(UserContext user) {
        final GatewayConfig config = configSupplier.get();
        if (user == null || user.userId() == null) {
            return PermissionSet.empty();
        }
        final PermissionSet fromConfig = config.permissions().resolve(user.guildId(), user.roleIds(), user.userId());
        final PermissionSet carried = PermissionSet.of(user.permissions(), user.deniedPermissions());
        return fromConfig.merge(carried);
    }

    /**
     * Validates guild and channel restrictions.
     *
     * @throws CommandException when the interaction came from a forbidden place
     */
    public void checkContext(UserContext user) {
        final GatewayConfig config = configSupplier.get();
        if (user == null || user.userId() == null) {
            throw new CommandException(ErrorCode.AUTHENTICATION_FAILED, "request without a user identity");
        }
        if (user.guildId() == null && !config.restrictions().allowedChannels().isEmpty()) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED, "для команд консоли требуется гильдия");
        }
        if (!config.restrictions().allowsChannel(user.guildId(), user.channelId())) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED,
                    "channel " + user.channelId() + " не разрешён для команд консоли");
        }
    }

    /**
     * Builds the permission aware UI view for the bot.
     */
    public TargetsView view(UserContext user) {
        final GatewayConfig config = configSupplier.get();
        final PermissionSet permissions = permissionsOf(user);
        final ServerCatalog catalog = config.catalog();
        final boolean broadcastAll = permissions.allows(Permission.BROADCAST_ALL);
        final List<TargetsView.ServerOption> servers = new ArrayList<>();
        for (ServerCatalog.ServerDefinition server : catalog.servers()) {
            final boolean accessible = server.enabled()
                    && (permissions.allows(Permission.server(server.id())) || broadcastAll);
            if (!accessible || (!permissions.allows(Permission.SERVERS) && !permissions.allows(Permission.READ))) {
                continue;
            }
            servers.add(new TargetsView.ServerOption(server.id(), server.displayName(),
                    statusLookup.statusOf(server.id()), server.enabled()));
        }
        final List<TargetsView.GroupOption> groups = new ArrayList<>();
        for (var entry : catalog.groups().entrySet()) {
            if (!permissions.allows(Permission.group(entry.getKey())) && !broadcastAll) {
                continue;
            }
            final List<String> visible = entry.getValue().stream()
                    .filter(id -> permissions.allows(Permission.server(id)) || broadcastAll)
                    .toList();
            if (!visible.isEmpty()) {
                groups.add(new TargetsView.GroupOption(entry.getKey(), visible));
            }
        }
        final TargetsView.Capabilities capabilities = new TargetsView.Capabilities(
                permissions.allows(Permission.READ),
                permissions.allows(Permission.EXECUTE),
                permissions.allows(Permission.DRY_RUN) || permissions.allows(Permission.EXECUTE),
                permissions.allows(Permission.BROADCAST),
                broadcastAll,
                permissions.allows(Permission.STATUS),
                permissions.allows(Permission.HISTORY),
                permissions.allows("console.admin.reload"),
                permissions.allows("console.emergency.*") || permissions.allows("console.admin.emergency"));
        return new TargetsView(catalog.singleServerMode(),
                catalog.onlyServer().map(ServerCatalog.ServerDefinition::id).orElse(null),
                servers, groups, capabilities, config.revision(), System.currentTimeMillis());
    }

    public GatewayConfig config() {
        return configSupplier.get();
    }
}
