package ru.zigono.dmc.gateway.registry;

import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerStatus;

/**
 * Live view of one configured Minecraft server.
 *
 * @author Zigono
 */
public final class ServerRuntimeState {

    private final String serverId;
    private final String name;
    private volatile ServerStatus status;
    private volatile ServerMetrics metrics;
    private volatile long lastHeartbeatAt;
    private volatile long connectedAt;
    private volatile String connectionId;
    private volatile String sessionId;
    private volatile String errorDetail;
    private volatile int queueDepth;
    private volatile long latencyMillis = -1L;

    public ServerRuntimeState(String serverId, String name) {
        this.serverId = serverId;
        this.name = name;
        this.status = ServerStatus.OFFLINE;
    }

    public String serverId() {
        return serverId;
    }

    public String name() {
        return name;
    }

    public ServerStatus status() {
        return status;
    }

    public void status(ServerStatus status) {
        this.status = status;
    }

    public ServerMetrics metrics() {
        return metrics;
    }

    public void metrics(ServerMetrics metrics) {
        this.metrics = metrics;
    }

    public long lastHeartbeatAt() {
        return lastHeartbeatAt;
    }

    public void lastHeartbeatAt(long value) {
        this.lastHeartbeatAt = value;
    }

    public long connectedAt() {
        return connectedAt;
    }

    public void connectedAt(long value) {
        this.connectedAt = value;
    }

    public String connectionId() {
        return connectionId;
    }

    public void connectionId(String value) {
        this.connectionId = value;
    }

    public String sessionId() {
        return sessionId;
    }

    public void sessionId(String value) {
        this.sessionId = value;
    }

    public String errorDetail() {
        return errorDetail;
    }

    public void errorDetail(String value) {
        this.errorDetail = value;
    }

    public int queueDepth() {
        return queueDepth;
    }

    public void queueDepth(int value) {
        this.queueDepth = value;
    }

    public long latencyMillis() {
        return latencyMillis;
    }

    public void latencyMillis(long value) {
        this.latencyMillis = value;
    }

    public boolean available() {
        return status.available();
    }
}