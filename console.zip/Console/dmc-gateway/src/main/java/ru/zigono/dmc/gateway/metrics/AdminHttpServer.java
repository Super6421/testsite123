package ru.zigono.dmc.gateway.metrics;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.function.BooleanSupplier;

/**
 * Observability endpoint: Prometheus metrics plus health, readiness and liveness probes.
 * Uses the JDK HTTP server so the gateway keeps a minimal dependency surface.
 *
 * @author Zigono
 */
public final class AdminHttpServer implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminHttpServer.class);

    private final HttpServer server;
    private final Metrics metrics;
    private final BooleanSupplier liveness;
    private final BooleanSupplier readiness;

    public AdminHttpServer(GatewayConfig config, Metrics metrics, BooleanSupplier liveness, BooleanSupplier readiness) {
        this.metrics = metrics;
        this.liveness = liveness;
        this.readiness = readiness;
        try {
            this.server = HttpServer.create(new InetSocketAddress(config.metrics().host(), config.metrics().port()), 0);
        } catch (IOException e) {
            throw new IllegalStateException("Не удалось привязать эндпоинт метрик к "
                    + config.metrics().host() + ":" + config.metrics().port(), e);
        }
        server.setExecutor(Executors.newFixedThreadPool(2, runnable -> {
            final Thread thread = new Thread(runnable, "dmc-admin-http");
            thread.setDaemon(true);
            return thread;
        }));
        server.createContext(config.metrics().path(), exchange -> respond(exchange, "text/plain; version=0.0.4",
                metrics.render(), 200));
        server.createContext("/health", exchange -> {
            final boolean ready = readiness.getAsBoolean();
            final boolean live = liveness.getAsBoolean();
            final String body = "{\"status\":\"" + (ready && live ? "UP" : "DOWN") + "\",\"live\":" + live
                    + ",\"ready\":" + ready + ",\"uptime_seconds\":" + metrics.uptimeSeconds() + "}";
            respond(exchange, "application/json", body + "\n", ready && live ? 200 : 503);
        });
        server.createContext("/health/live", exchange ->
                respond(exchange, "application/json", "{\"status\":\"" + (liveness.getAsBoolean() ? "UP" : "DOWN") + "\"}\n",
                        liveness.getAsBoolean() ? 200 : 503));
        server.createContext("/health/ready", exchange ->
                respond(exchange, "application/json", "{\"status\":\"" + (readiness.getAsBoolean() ? "UP" : "DOWN") + "\"}\n",
                        readiness.getAsBoolean() ? 200 : 503));
    }

    public void start() {
        server.start();
        LOGGER.info("Метрики и проверка состояния доступны на http://{}:{}{}",
                server.getAddress().getHostString(), server.getAddress().getPort(), "/metrics");
    }

    public int port() {
        return server.getAddress().getPort();
    }

    private void respond(HttpExchange exchange, String contentType, String body, int status) throws IOException {
        try {
            final byte[] payload = body.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", contentType);
            exchange.sendResponseHeaders(status, payload.length);
            try (OutputStream out = exchange.getResponseBody()) {
                out.write(payload);
            }
        } finally {
            exchange.close();
        }
    }

    @Override
    public void close() {
        server.stop(1);
        LOGGER.info("Эндпоинт метрик остановлен");
    }
}