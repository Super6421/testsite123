package ru.zigono.dmc.gateway.api;

import java.util.List;

/**
 * Operations the control API needs from the gateway runtime itself (hot reload, revisions).
 *
 * @author Zigono
 */
public interface GatewayControlService {

    /**
     * @param reloaded reload succeeded
     * @param revision new configuration revision
     * @param sections sections that were refreshed
     * @param error    failure detail when {@code reloaded} is {@code false}
     */
    record ReloadResult(boolean reloaded, String revision, List<String> sections, String error) {
    }

    ReloadResult reload();

    String configRevision();
}