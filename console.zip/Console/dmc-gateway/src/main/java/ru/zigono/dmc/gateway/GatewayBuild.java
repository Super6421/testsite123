package ru.zigono.dmc.gateway;

/**
 * Static build information of the gateway.
 *
 * @author Zigono
 */
public final class GatewayBuild {

    public static final String NAME = "Discord Minecraft Console Gateway";
    public static final String VERSION = "1.0.0";
    public static final String AUTHOR = "Zigono";

    private GatewayBuild() {
    }

    public static String describe() {
        return NAME + " " + VERSION + " (protocol " + ru.zigono.dmc.protocol.ProtocolVersion.describe()
                + ") by " + AUTHOR;
    }
}