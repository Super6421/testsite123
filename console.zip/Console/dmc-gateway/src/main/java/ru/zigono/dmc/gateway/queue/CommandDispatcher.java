package ru.zigono.dmc.gateway.queue;

import ru.zigono.dmc.protocol.dto.ServerOutcome;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/**
 * Abstraction between the queue and the Minecraft connections, so the queue can be tested without sockets.
 *
 * @author Zigono
 */
public interface CommandDispatcher {

    /** @return {@code true} when the server currently has an authenticated, usable connection */
    boolean available(String serverId);

    /**
     * Hands the command to the Minecraft plugin.
     *
     * @return empty when the command could not be handed over at all (safe to retry), otherwise the handle
     */
    Optional<Dispatch> dispatch(QueuedCommand command);

    /** Called when a server connection went away, so in flight commands can be resolved. */
    void onDisconnect(String serverId, String reason);

    /**
     * Handle of a dispatched command.
     *
     * @param outcome  real result reported by the Minecraft server
     * @param accepted completes with {@code true} as soon as the plugin confirmed that it picked the command up;
     *                 a command that was never accepted has not been executed and may be retried safely
     */
    record Dispatch(CompletableFuture<ServerOutcome> outcome, CompletableFuture<Boolean> accepted) {
    }
}