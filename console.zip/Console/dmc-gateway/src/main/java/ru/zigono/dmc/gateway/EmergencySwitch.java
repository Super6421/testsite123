package ru.zigono.dmc.gateway;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.db.StateRepository;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Global emergency kill switch. While it is active only holders of {@code console.emergency.*} may execute
 * commands. The state is persisted so a restart cannot silently lift an emergency.
 *
 * @author Zigono
 */
public final class EmergencySwitch {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmergencySwitch.class);
    private static final String STATE_KEY = "emergency_mode";

    private final AtomicBoolean enabled;
    private final StateRepository stateRepository;

    public EmergencySwitch(boolean configuredDefault, StateRepository stateRepository) {
        this.stateRepository = stateRepository;
        final boolean persisted = stateRepository == null ? configuredDefault
                : stateRepository.get(STATE_KEY).map(Boolean::parseBoolean).orElse(configuredDefault);
        this.enabled = new AtomicBoolean(persisted);
        if (persisted) {
            LOGGER.warn("Аварийный режим АКТИВЕН: обычные команды консоли заблокированы");
        }
    }

    public boolean enabled() {
        return enabled.get();
    }

    public void set(boolean value) {
        enabled.set(value);
        if (stateRepository != null) {
            stateRepository.set(STATE_KEY, Boolean.toString(value));
        }
        LOGGER.warn("Аварийный режим {}", value ? "ВКЛЮЧЁН" : "выключен");
    }
}