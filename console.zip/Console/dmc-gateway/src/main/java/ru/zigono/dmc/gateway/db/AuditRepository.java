package ru.zigono.dmc.gateway.db;

import ru.zigono.dmc.protocol.dto.HistoryEntry;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Audit trail of every command that reached the gateway, and the source of the {@code /console-history} view.
 *
 * @author Zigono
 */
public final class AuditRepository {

    private final Database database;

    public AuditRepository(Database database) {
        this.database = database;
    }

    /**
     * One audit record. Field names follow the specification so the stored data and the documentation match.
     */
    public record AuditRecord(String requestId, String userId, String username, String guildId, String channelId,
                              String messageId, String interactionId, List<String> roles, String target, String serverId,
                              String command, String normalizedCommand, String status, long durationMs, String response,
                              String errorCode, String errorDetail, boolean dryRun, long createdEpochMs) {

        public AuditRecord {
            roles = roles == null ? List.of() : List.copyOf(roles);
        }
    }

    /** Filters of a history query. */
    public record HistoryQuery(String serverId, String userId, String username, String commandFragment, String status,
                               Long fromEpochMs, Long toEpochMs, int limit, int offset) {

        public static HistoryQuery of(String serverId, String username, String commandFragment, String status,
                                      Long from, Long to, int limit, int offset) {
            return new HistoryQuery(serverId, null, username, commandFragment, status, from, to,
                    Math.min(Math.max(limit, 1), 200), Math.max(offset, 0));
        }
    }

    public void insert(AuditRecord record) {
        insertAll(List.of(record));
    }

    public void insertAll(List<AuditRecord> records) {
        if (records.isEmpty()) {
            return;
        }
        final String sql = """
                INSERT INTO audit_log (request_id, user_id, username, guild_id, channel_id, message_id, interaction_id,
                                       roles, target, server_id, command, normalized_command, status, duration_ms,
                                       response, error_code, error_detail, dry_run, created_epoch_ms)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (AuditRecord record : records) {
                statement.setString(1, record.requestId());
                statement.setString(2, record.userId());
                statement.setString(3, record.username());
                statement.setString(4, record.guildId());
                statement.setString(5, record.channelId());
                statement.setString(6, record.messageId());
                statement.setString(7, record.interactionId());
                statement.setString(8, String.join(",", record.roles()));
                statement.setString(9, record.target());
                statement.setString(10, record.serverId());
                statement.setString(11, record.command());
                statement.setString(12, record.normalizedCommand());
                statement.setString(13, record.status());
                statement.setLong(14, record.durationMs());
                statement.setString(15, record.response());
                statement.setString(16, record.errorCode());
                statement.setString(17, record.errorDetail());
                statement.setBoolean(18, record.dryRun());
                statement.setLong(19, record.createdEpochMs());
                statement.addBatch();
            }
            statement.executeBatch();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось записать журнал аудита", e);
        }
    }

    public List<HistoryEntry> search(HistoryQuery query) {
        final StringBuilder sql = new StringBuilder("""
                SELECT request_id, user_id, username, guild_id, channel_id, target, server_id, command, status,
                       duration_ms, response, error_code, dry_run, created_epoch_ms
                FROM audit_log WHERE 1 = 1""");
        final List<Object> parameters = new ArrayList<>();
        appendFilters(sql, parameters, query);
        sql.append(" ORDER BY created_epoch_ms DESC, id DESC LIMIT ? OFFSET ?");
        parameters.add(query.limit());
        parameters.add(query.offset());
        final List<HistoryEntry> entries = new ArrayList<>();
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            bind(statement, parameters);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    entries.add(new HistoryEntry(
                            result.getString("request_id"),
                            result.getString("user_id"),
                            result.getString("username"),
                            result.getString("guild_id"),
                            result.getString("channel_id"),
                            result.getString("target"),
                            result.getString("server_id"),
                            result.getString("command"),
                            result.getString("status"),
                            result.getLong("duration_ms"),
                            result.getString("response"),
                            result.getString("error_code"),
                            result.getBoolean("dry_run"),
                            result.getLong("created_epoch_ms")));
                }
            }
            return entries;
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось получить историю команд", e);
        }
    }

    public long count(HistoryQuery query) {
        final StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM audit_log WHERE 1 = 1");
        final List<Object> parameters = new ArrayList<>();
        appendFilters(sql, parameters, query);
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql.toString())) {
            bind(statement, parameters);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? result.getLong(1) : 0L;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось подсчитать историю команд", e);
        }
    }

    private void appendFilters(StringBuilder sql, List<Object> parameters, HistoryQuery query) {
        if (query.serverId() != null && !query.serverId().isBlank()) {
            sql.append(" AND server_id = ?");
            parameters.add(query.serverId());
        }
        if (query.userId() != null && !query.userId().isBlank()) {
            sql.append(" AND user_id = ?");
            parameters.add(query.userId());
        }
        if (query.username() != null && !query.username().isBlank()) {
            sql.append(" AND LOWER(username) = ?");
            parameters.add(query.username().toLowerCase(java.util.Locale.ROOT));
        }
        if (query.commandFragment() != null && !query.commandFragment().isBlank()) {
            sql.append(" AND LOWER(command) LIKE ?");
            parameters.add("%" + query.commandFragment().toLowerCase(java.util.Locale.ROOT) + "%");
        }
        if (query.status() != null && !query.status().isBlank()) {
            sql.append(" AND status = ?");
            parameters.add(query.status());
        }
        if (query.fromEpochMs() != null) {
            sql.append(" AND created_epoch_ms >= ?");
            parameters.add(query.fromEpochMs());
        }
        if (query.toEpochMs() != null) {
            sql.append(" AND created_epoch_ms <= ?");
            parameters.add(query.toEpochMs());
        }
    }

    private void bind(PreparedStatement statement, List<Object> parameters) throws SQLException {
        for (int i = 0; i < parameters.size(); i++) {
            statement.setObject(i + 1, parameters.get(i));
        }
    }

    /**
     * Deletes audit records older than the retention window.
     *
     * @return number of deleted rows
     */
    public int purgeOlderThan(long epochMillis, int batchLimit) {
        final String sql = "DELETE FROM audit_log WHERE id IN (SELECT id FROM audit_log WHERE created_epoch_ms < ? LIMIT ?)";
        try (Connection connection = database.connection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(1, epochMillis);
            statement.setInt(2, batchLimit);
            return statement.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Не удалось применить политику хранения аудита", e);
        }
    }
}