package ru.zigono.dmc.gateway.redis;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.pubsub.RedisPubSubAdapter;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.sync.RedisPubSubCommands;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.PluginMessages;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Cross instance coordination: when the plugin of a server is connected to another gateway instance, the
 * command is published on that server's channel and the result is published back on the requester's channel.
 * This is what allows several gateway instances to run behind the same Discord bot.
 *
 * @author Zigono
 */
public final class RedisCoordinator implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(RedisCoordinator.class);

    private final RedisClient client;
    private final StatefulRedisPubSubConnection<String, String> subscriber;
    private final StatefulRedisPubSubConnection<String, String> publisher;
    private final RedisPubSubCommands<String, String> publishCommands;
    private final String instanceId;
    private final String prefix;
    private final Map<String, PendingRoute> pendingRoutes = new ConcurrentHashMap<>();
    private final Map<String, Consumer<PluginMessages.CommandDispatch>> localHandlers = new ConcurrentHashMap<>();

    private record PendingRoute(CompletableFuture<ServerOutcome> outcome, long deadline) {
    }

    public RedisCoordinator(GatewayConfig.RedisSettings settings, String instanceId,
                            Consumer<PluginMessages.CommandDispatch> localDispatch,
                            java.util.function.BiConsumer<String, ServerOutcome> onRemoteOutcome) {
        final RedisURI.Builder uri = RedisURI.builder(RedisURI.create(settings.uri()));
        if (settings.password() != null && !settings.password().isBlank()) {
            uri.withPassword(settings.password().toCharArray());
        }
        uri.withTimeout(settings.timeout());
        this.instanceId = instanceId;
        this.prefix = settings.keyPrefix();
        this.client = RedisClient.create(uri.build());
        this.subscriber = client.connectPubSub();
        this.publisher = client.connectPubSub();
        this.publishCommands = publisher.sync();
        subscriber.addListener(new RedisPubSubAdapter<>() {
            @Override
            public void message(String channel, String message) {
                handleMessage(channel, message, localDispatch, onRemoteOutcome);
            }
        });
        subscriber.sync().psubscribe(prefix + "route:*", prefix + "result:*");
        LOGGER.info("Межэкземплярная координация включена через Redis по адресу {}", settings.uri());
    }

    private void handleMessage(String channel, String message, Consumer<PluginMessages.CommandDispatch> localDispatch,
                               java.util.function.BiConsumer<String, ServerOutcome> onRemoteOutcome) {
        try {
            if (channel.startsWith(prefix + "route:")) {
                final PluginMessages.CommandDispatch dispatch = ru.zigono.dmc.common.util.Json.read(message,
                        PluginMessages.CommandDispatch.class);
                localDispatch.accept(dispatch);
                return;
            }
            final ResultEnvelope envelope = ru.zigono.dmc.common.util.Json.read(message, ResultEnvelope.class);
            final PendingRoute pending = pendingRoutes.remove(envelope.requestId());
            if (pending != null) {
                pending.outcome().complete(envelope.outcome());
            }
            onRemoteOutcome.accept(envelope.serverId(), envelope.outcome());
        } catch (RuntimeException e) {
            LOGGER.warn("Не удалось обработать сообщение координации Redis из {}: {}", channel, e.getMessage());
        }
    }

    /** Envelope used on the result channel. */
    public record ResultEnvelope(String requestId, String serverId, ServerOutcome outcome) {
    }

    /**
     * Publishes a dispatch to the instance that owns the server.
     */
    public CompletableFuture<ServerOutcome> route(PluginMessages.CommandDispatch dispatch, Duration timeout) {
        final CompletableFuture<ServerOutcome> future = new CompletableFuture<>();
        pendingRoutes.put(dispatch.getRequestId(), new PendingRoute(future,
                System.currentTimeMillis() + timeout.toMillis()));
        publishCommands.publish(prefix + "route:" + dispatch.serverId,
                ru.zigono.dmc.common.util.Json.write(dispatch));
        future.orTimeout(timeout.toMillis(), TimeUnit.MILLISECONDS);
        return future;
    }

    /**
     * Publishes a result back to the instance that requested the execution.
     */
    public void publishResult(String requestId, String serverId, ServerOutcome outcome) {
        publishCommands.publish(prefix + "result:" + requestId,
                ru.zigono.dmc.common.util.Json.write(new ResultEnvelope(requestId, serverId, outcome)));
    }

    /** Registers the outcome handler used when a locally connected plugin reports a result. */
    public void registerLocalHandler(String serverId, boolean ownerOfServer) {
        if (ownerOfServer) {
            localHandlers.put(serverId, ignored -> { });
        } else {
            localHandlers.remove(serverId);
        }
    }

    public boolean owns(String serverId) {
        return localHandlers.containsKey(serverId);
    }

    public Optional<String> instanceId() {
        return Optional.of(instanceId);
    }

    public int pendingRouteCount() {
        return pendingRoutes.size();
    }

    @Override
    public void close() {
        try {
            subscriber.sync().punsubscribe(prefix + "route:*", prefix + "result:*");
        } catch (RuntimeException e) {
            LOGGER.debug("Не удалось отписаться: {}", e.getMessage());
        }
        subscriber.close();
        publisher.close();
        client.shutdown(Duration.ZERO, Duration.ofSeconds(2));
        LOGGER.info("Межэкземплярная координация остановлена");
    }
}
