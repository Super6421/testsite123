package ru.zigono.dmc.gateway.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.time.Duration;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * Applies the retention policy: old audit records are removed, security audit records follow their own, usually
 * much longer, retention window and are never removed through a Discord command.
 *
 * @author Zigono
 */
public final class RetentionService implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(RetentionService.class);
    private static final int BATCH_LIMIT = 5_000;

    private final GatewayConfig.DatabaseSettings settings;
    private final AuditRepository auditRepository;
    private final SecurityAuditRepository securityAuditRepository;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
        final Thread thread = new Thread(runnable, "dmc-retention");
        thread.setDaemon(true);
        return thread;
    });
    private ScheduledFuture<?> task;

    public RetentionService(GatewayConfig.DatabaseSettings settings, AuditRepository auditRepository,
                            SecurityAuditRepository securityAuditRepository) {
        this.settings = settings;
        this.auditRepository = auditRepository;
        this.securityAuditRepository = securityAuditRepository;
    }

    public void start() {
        if (!settings.retentionEnabled()) {
            LOGGER.info("Политика хранения отключена");
            return;
        }
        final Duration interval = settings.retentionInterval();
        task = scheduler.scheduleWithFixedDelay(this::run, 1, Math.max(1, interval.toMinutes()), TimeUnit.MINUTES);
        LOGGER.info("Политика хранения активна: аудит {} дн., аудит безопасности {} дн.",
                settings.retentionDays(), settings.securityRetentionDays());
    }

    /**
     * Runs one retention pass; also used by tests.
     *
     * @return number of removed audit records
     */
    public int run() {
        final long now = System.currentTimeMillis();
        int removedAudit = 0;
        int removedSecurity = 0;
        try {
            final long auditThreshold = now - Duration.ofDays(settings.retentionDays()).toMillis();
            int batch;
            do {
                batch = auditRepository.purgeOlderThan(auditThreshold, BATCH_LIMIT);
                removedAudit += batch;
            } while (batch == BATCH_LIMIT && removedAudit < 1_000_000);

            if (settings.securityRetentionDays() > 0) {
                final long securityThreshold = now - Duration.ofDays(settings.securityRetentionDays()).toMillis();
                do {
                    batch = securityAuditRepository.purgeOlderThan(securityThreshold, BATCH_LIMIT);
                    removedSecurity += batch;
                } while (batch == BATCH_LIMIT && removedSecurity < 1_000_000);
            }
            if (removedAudit > 0 || removedSecurity > 0) {
                LOGGER.info("Политика хранения удалила записей: аудит {}, аудит безопасности {}", removedAudit, removedSecurity);
            }
        } catch (RuntimeException e) {
            LOGGER.error("Не удалось выполнить проход по политике хранения", e);
        }
        return removedAudit;
    }

    @Override
    public void close() {
        if (task != null) {
            task.cancel(false);
        }
        scheduler.shutdownNow();
    }
}