package ru.zigono.dmc.gateway.registry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.target.ServerCatalog;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.transport.Connection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Tracks which Minecraft servers are connected, their heartbeat and their last known metrics, and detects
 * servers that went silent.
 *
 * @author Zigono
 */
public final class PluginRegistry {

    private static final Logger LOGGER = LoggerFactory.getLogger(PluginRegistry.class);

    private final Map<String, Connection> connections = new ConcurrentHashMap<>();
    private final Map<String, ServerRuntimeState> states = new ConcurrentHashMap<>();
    private final GatewayConfig.HeartbeatSettings heartbeatSettings;
    private final Consumer<StaleServer> onStale;

    /**
     * Notification that a server stopped answering heartbeats.
     */
    public record StaleServer(String serverId, ServerStatus status) {
    }

    public PluginRegistry(ServerCatalog catalog, GatewayConfig.HeartbeatSettings heartbeatSettings,
                          Consumer<StaleServer> onStale) {
        this.heartbeatSettings = heartbeatSettings;
        this.onStale = onStale == null ? ignored -> { } : onStale;
        catalog.servers().forEach(server -> states.put(server.id(), new ServerRuntimeState(server.id(), server.displayName())));
    }

    /**
     * Adds states for servers that appeared in the configuration after a hot reload.
     */
    public void ensureServers(ServerCatalog catalog) {
        catalog.servers().forEach(server -> states.computeIfAbsent(server.id(),
                id -> new ServerRuntimeState(id, server.displayName())));
    }

    public boolean register(String serverId, Connection connection) {
        final ServerRuntimeState state = state(serverId);
        final Connection previous = connections.put(serverId, connection);
        if (previous != null && previous != connection && previous.open()) {
            LOGGER.warn("Сервер {} переподключился, пока прежнее соединение ещё было открыто; закрываю старое",
                    serverId);
            previous.close();
        }
        state.connectionId(connection.id());
        state.connectedAt(System.currentTimeMillis());
        state.lastHeartbeatAt(System.currentTimeMillis());
        state.status(ServerStatus.CONNECTING);
        state.errorDetail(null);
        return previous == null || previous == connection;
    }

    public void unregister(String serverId, Connection connection) {
        final Connection current = connections.get(serverId);
        if (current != null && current.id().equals(connection.id()) && connections.remove(serverId, current)) {
            final ServerRuntimeState state = state(serverId);
            state.status(ServerStatus.OFFLINE);
            state.connectionId(null);
        }
    }

    public void markAuthenticationFailed(String serverId, String detail) {
        final ServerRuntimeState state = state(serverId);
        state.status(ServerStatus.AUTH_FAILED);
        state.errorDetail(detail);
    }

    public Optional<Connection> connection(String serverId) {
        return Optional.ofNullable(connections.get(serverId)).filter(Connection::open);
    }

    public boolean connected(String serverId) {
        return connection(serverId).isPresent();
    }

    public ServerRuntimeState state(String serverId) {
        return states.computeIfAbsent(serverId, id -> new ServerRuntimeState(id, id));
    }

    public List<ServerRuntimeState> states() {
        final List<ServerRuntimeState> result = new ArrayList<>(states.values());
        result.sort(Comparator.comparing(ServerRuntimeState::serverId));
        return result;
    }

    public List<ServerRuntimeState> states(Collection<String> serverIds) {
        final List<ServerRuntimeState> result = new ArrayList<>();
        for (String serverId : serverIds) {
            result.add(state(serverId));
        }
        return result;
    }

    public void heartbeat(String serverId, ServerMetrics metrics, String status, int queuedCommands) {
        final ServerRuntimeState state = state(serverId);
        state.lastHeartbeatAt(System.currentTimeMillis());
        if (metrics != null) {
            state.metrics(metrics);
        }
        state.queueDepth(queuedCommands);
        if (status != null) {
            try {
                state.status(ServerStatus.valueOf(status));
            } catch (IllegalArgumentException e) {
                state.status(ServerStatus.ONLINE);
            }
        } else if (state.status() == ServerStatus.CONNECTING || state.status() == ServerStatus.DEGRADED) {
            state.status(ServerStatus.ONLINE);
        }
    }

    /**
     * Marks servers that stopped sending heartbeats as degraded and then offline.
     */
    public void tick() {
        final long now = System.currentTimeMillis();
        final long timeout = heartbeatSettings.timeout().toMillis();
        for (ServerRuntimeState state : states.values()) {
            final Connection connection = connections.get(state.serverId());
            if (connection == null || !connection.open()) {
                if (state.status() != ServerStatus.OFFLINE && state.status() != ServerStatus.AUTH_FAILED) {
                    state.status(ServerStatus.OFFLINE);
                    onStale.accept(new StaleServer(state.serverId(), ServerStatus.OFFLINE));
                }
                continue;
            }
            if (state.lastHeartbeatAt() == 0L) {
                continue;
            }
            final long silence = now - state.lastHeartbeatAt();
            if (silence > timeout * 2L) {
                if (state.status() != ServerStatus.OFFLINE) {
                    state.status(ServerStatus.OFFLINE);
                    state.errorDetail("нет heartbeat от " + silence + " ms");
                    onStale.accept(new StaleServer(state.serverId(), ServerStatus.OFFLINE));
                }
            } else if (silence > timeout && state.status() == ServerStatus.ONLINE) {
                state.status(ServerStatus.DEGRADED);
                state.errorDetail("heartbeat задержан на " + silence + " ms");
                onStale.accept(new StaleServer(state.serverId(), ServerStatus.DEGRADED));
            }
        }
    }

    public int connectedCount() {
        return (int) states.values().stream().filter(ServerRuntimeState::available).count();
    }

    public int offlineCount() {
        return (int) states.values().stream().filter(state -> !state.available()).count();
    }

    public void clear() {
        connections.clear();
    }
}