package ru.zigono.dmc.gateway.redis;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.rate.RateBackend;
import ru.zigono.dmc.gateway.config.GatewayConfig;

import java.time.Duration;

/**
 * Distributed rate limit backend. Counters live in Redis so every gateway instance applies the same quota,
 * which is what makes horizontal scaling safe.
 *
 * @author Zigono
 */
public final class RedisRateBackend implements RateBackend {

    private static final Logger LOGGER = LoggerFactory.getLogger(RedisRateBackend.class);

    private final RedisClient client;
    private final StatefulRedisConnection<String, String> connection;
    private final RedisCommands<String, String> commands;
    private final String prefix;

    public RedisRateBackend(GatewayConfig.RedisSettings settings) {
        final RedisURI.Builder uri = RedisURI.builder(RedisURI.create(settings.uri()));
        if (settings.password() != null && !settings.password().isBlank()) {
            uri.withPassword(settings.password().toCharArray());
        }
        uri.withTimeout(settings.timeout());
        this.client = RedisClient.create(uri.build());
        this.connection = client.connect();
        this.commands = connection.sync();
        this.prefix = settings.keyPrefix() + "rate:";
        LOGGER.info("Распределённое ограничение частоты включено через Redis по адресу {}", settings.uri());
    }

    @Override
    public boolean tryAcquire(String key, int limit, long windowMillis) {
        if (limit <= 0 || windowMillis <= 0) {
            return true;
        }
        final String redisKey = prefix + key;
        final Long current = commands.incr(redisKey);
        if (current == null) {
            return true;
        }
        if (current == 1L) {
            commands.pexpire(redisKey, windowMillis);
        }
        return current <= limit;
    }

    @Override
    public long retryAfterMillis(String key, int limit, long windowMillis) {
        final Long ttl = commands.pttl(prefix + key);
        return ttl == null || ttl < 0 ? 0L : ttl;
    }

    @Override
    public void reset(String key) {
        commands.del(prefix + key);
    }

    public boolean healthy() {
        try {
            return "PONG".equalsIgnoreCase(commands.ping());
        } catch (RuntimeException e) {
            return false;
        }
    }

    @Override
    public void close() {
        try {
            connection.close();
        } finally {
            client.shutdown(Duration.ZERO, Duration.ofSeconds(2));
        }
    }
}
