package ru.zigono.dmc.gateway.queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.ServerOutcome;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Per server FIFO queue. Order is guaranteed inside one server while different servers are processed in
 * parallel, exactly as required by the specification.
 *
 * @author Zigono
 */
public final class ServerQueue implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServerQueue.class);
    private static final long POLL_INTERVAL_MILLIS = 200L;

    private final String serverId;
    private volatile GatewayConfig.QueueSettings settings;
    private final RetryPolicy retryPolicy;
    private final CommandDispatcher dispatcher;
    private final Metrics metrics;
    private volatile LinkedBlockingQueue<QueuedCommand> queue;
    private final AtomicBoolean running = new AtomicBoolean(true);
    private final Thread worker;
    private volatile boolean disconnected;
    private volatile String disconnectReason;
    private volatile long disconnectedAt;

    public ServerQueue(String serverId, GatewayConfig.QueueSettings settings, RetryPolicy retryPolicy,
                       CommandDispatcher dispatcher, Metrics metrics) {
        this.serverId = serverId;
        this.settings = settings;
        this.retryPolicy = retryPolicy;
        this.dispatcher = dispatcher;
        this.metrics = metrics;
        this.queue = new LinkedBlockingQueue<>(Math.max(1, settings.maxSize()));
        this.worker = Thread.ofVirtual().name("dmc-queue-" + serverId).unstarted(this::loop);
        this.worker.start();
    }

    public String serverId() {
        return serverId;
    }

    /**
     * Applies hot reloaded queue settings. The capacity of the pending queue is swapped as soon as the queue is idle.
     */
    public synchronized void reconfigure(GatewayConfig.QueueSettings updated) {
        this.settings = updated;
        if (queue.isEmpty() && queue.remainingCapacity() + queue.size() != Math.max(1, updated.maxSize())) {
            final LinkedBlockingQueue<QueuedCommand> replacement = new LinkedBlockingQueue<>(Math.max(1, updated.maxSize()));
            queue.drainTo(replacement);
            this.queue = replacement;
        }
    }

    public int size() {
        return queue.size();
    }

    public boolean idle() {
        return queue.isEmpty();
    }

    /**
     * Queues a command.
     *
     * @return the future completed with the real result, or a future already failed with {@code QUEUE_FULL}
     */
    public CompletableFuture<ServerOutcome> submit(QueuedCommand command) {
        if (!settings.enabled()) {
            CompletableFuture<ServerOutcome> direct = new CompletableFuture<>();
            Thread.ofVirtual().name("dmc-direct-" + serverId).start(() -> direct.complete(run(command)));
            return direct;
        }
        if (!queue.offer(command)) {
            final ServerOutcome outcome = ServerOutcome.failure(serverId, ExecutionStatus.QUEUE_FULL,
                    ErrorCode.QUEUE_FULL.name(), "очередь " + serverId + " заполнена");
            command.complete(outcome);
            return command.result();
        }
        return command.result();
    }

    public void onDisconnect(String reason) {
        disconnected = true;
        disconnectReason = reason;
        disconnectedAt = System.currentTimeMillis();
        if ("cancel".equals(settings.onDisconnect())) {
            final List<QueuedCommand> pending = new ArrayList<>();
            queue.drainTo(pending);
            for (QueuedCommand command : pending) {
                command.complete(ServerOutcome.failure(serverId, ExecutionStatus.OFFLINE,
                        ErrorCode.SERVER_OFFLINE.name(), "server disconnected: " + reason));
            }
            if (!pending.isEmpty()) {
                LOGGER.info("Отменено {} команд в очереди {} из-за отключения сервера", pending.size(), serverId);
            }
        }
    }

    public void onReconnect() {
        disconnected = false;
        disconnectReason = null;
        disconnectedAt = 0L;
    }

    private void loop() {
        while (running.get()) {
            try {
                final QueuedCommand command = queue.poll(POLL_INTERVAL_MILLIS, TimeUnit.MILLISECONDS);
                if (command == null) {
                    continue;
                }
                if (command.finished()) {
                    continue;
                }
                command.complete(run(command));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } catch (RuntimeException e) {
                LOGGER.error("Непредвиденная ошибка в обработчике очереди {}", serverId, e);
            }
        }
    }

    /**
     * Executes one command with the retry semantics of {@link RetryPolicy}.
     */
    private ServerOutcome run(QueuedCommand command) {
        final long startedAt = System.currentTimeMillis();
        while (running.get() && !command.finished()) {
            if (!availableWithPolicy(command)) {
                return ServerOutcome.failure(serverId, ExecutionStatus.OFFLINE, ErrorCode.SERVER_OFFLINE.name(),
                        "server " + serverId + " не подключён" + (disconnectReason == null ? "" : ": " + disconnectReason));
            }
            final Optional<CommandDispatcher.Dispatch> handle = dispatcher.dispatch(command);
            if (handle.isEmpty()) {
                if (retryPolicy.canRetry(command.attempt(), command.accepted(), RetryPolicy.AttemptResult.DISPATCH_FAILED, false)) {
                    command.nextAttempt();
                    sleep(retryPolicy.delay().toMillis());
                    continue;
                }
                return ServerOutcome.failure(serverId, ExecutionStatus.FAILED, ErrorCode.CONNECTION_LOST.name(),
                        "команду не удалось передать в " + serverId);
            }
            final CommandDispatcher.Dispatch dispatch = handle.get();
            dispatch.accepted().thenRun(command::markAccepted);
            final ServerOutcome outcome;
            try {
                outcome = dispatch.outcome().get(Math.max(1L, command.timeoutMillis()), TimeUnit.MILLISECONDS);
            } catch (TimeoutException e) {
                if (!command.accepted()
                        && retryPolicy.canRetry(command.attempt(), false, RetryPolicy.AttemptResult.NOT_DISPATCHED, false)) {
                    command.nextAttempt();
                    sleep(retryPolicy.delay().toMillis());
                    continue;
                }
                return ServerOutcome.failure(serverId, ExecutionStatus.TIMEOUT, ErrorCode.TIMEOUT.name(),
                        command.accepted()
                                ? "сервер не сообщил результат за " + command.timeoutMillis() + " ms"
                                : "сервер не принял команду за " + command.timeoutMillis() + " ms");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return ServerOutcome.failure(serverId, ExecutionStatus.CANCELLED, ErrorCode.CONNECTION_LOST.name(),
                        "ожидание результата было прервано");
            } catch (ExecutionException e) {
                final boolean accepted = command.accepted();
                final RetryPolicy.AttemptResult result = accepted ? RetryPolicy.AttemptResult.ACCEPTED_UNKNOWN
                        : RetryPolicy.AttemptResult.DISPATCH_FAILED;
                if (retryPolicy.canRetry(command.attempt(), accepted, result, false)) {
                    command.nextAttempt();
                    sleep(retryPolicy.delay().toMillis());
                    continue;
                }
                return accepted
                        ? ServerOutcome.failure(serverId, ExecutionStatus.UNKNOWN, ErrorCode.CONNECTION_LOST.name(),
                        "результат неизвестен: соединение потеряно после запуска команды")
                        : ServerOutcome.failure(serverId, ExecutionStatus.FAILED, ErrorCode.CONNECTION_LOST.name(),
                        "команду не удалось доставить в " + serverId);
            }
            if (outcome != null) {
                metrics.recordLatency(System.currentTimeMillis() - startedAt);
                return outcome;
            }
            return ServerOutcome.failure(serverId, ExecutionStatus.UNKNOWN, ErrorCode.INTERNAL_ERROR.name(),
                    "результат не получен");
        }
        return ServerOutcome.failure(serverId, ExecutionStatus.CANCELLED, ErrorCode.CONNECTION_LOST.name(),
                "очередь завершает работу");
    }

    private boolean availableWithPolicy(QueuedCommand command) {
        final long deadline = command.enqueuedAt() + command.timeoutMillis()
                + ("hold".equals(settings.onDisconnect()) ? settings.disconnectHold().toMillis() : 0L);
        while (running.get() && !dispatcher.available(serverId)) {
            if (System.currentTimeMillis() >= deadline) {
                return false;
            }
            if ("cancel".equals(settings.onDisconnect()) && disconnected) {
                return false;
            }
            sleep(Math.min(POLL_INTERVAL_MILLIS, Math.max(1L, deadline - System.currentTimeMillis())));
        }
        return dispatcher.available(serverId);
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(Math.max(1L, millis));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void close() {
        running.set(false);
        if (worker != null) {
            worker.interrupt();
        }
        final List<QueuedCommand> pending = new ArrayList<>();
        queue.drainTo(pending);
        for (QueuedCommand command : pending) {
            command.complete(ServerOutcome.failure(serverId, ExecutionStatus.CANCELLED, ErrorCode.CONNECTION_LOST.name(),
                    "шлюз завершает работу"));
        }
    }
}