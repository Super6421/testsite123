package ru.zigono.dmc.gateway.config;

import ru.zigono.dmc.common.command.CommandNormalizer;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.CommandShortcuts;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.perm.PermissionConfig;
import ru.zigono.dmc.common.rate.RateLimitSettings;
import ru.zigono.dmc.common.target.ServerCatalog;
import ru.zigono.dmc.protocol.transport.TransportSettings;

import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Typed view over {@code gateway.yml}. Every component of the control plane is configured here: the ACL is
 * authoritative on the gateway, the bot only renders it.
 *
 * @author Zigono
 */
public final class GatewayConfig {

    public static final Set<String> BROADCAST_EXECUTION = Set.of("parallel", "sequential");
    public static final Set<String> BROADCAST_FAILURE_POLICY = Set.of("continue", "stop");
    public static final Set<String> BROADCAST_RESPONSE_MODE = Set.of("per_server", "summary", "combined");
    public static final Set<String> DISCONNECT_POLICIES = Set.of("cancel", "hold", "retry");
    public static final Set<String> DATABASE_TYPES = Set.of("sqlite", "postgresql");

    private final YamlConfig root;
    private final Path sourceFile;
    private final Path baseDirectory;

    private final String gatewayId;
    private final ServerCatalog catalog;
    private final PermissionConfig permissions;
    private final CommandPolicyEngine policy;
    private final CommandNormalizer normalizer;
    private final CommandShortcuts shortcuts;
    private final RateLimitSettings rateLimit;
    private final QueueSettings queue;
    private final RetrySettings retry;
    private final HeartbeatSettings heartbeat;
    private final BroadcastSettings broadcast;
    private final ResponseSettings responses;
    private final ConfirmationSettings confirmation;
    private final DatabaseSettings database;
    private final RedisSettings redis;
    private final MetricsSettings metrics;
    private final LoggingSettings logging;
    private final TransportSettings transport;
    private final RestrictionSettings restrictions;
    private final Map<String, byte[]> serverSecrets;
    private final Map<String, byte[]> controlSecrets;

    private GatewayConfig(YamlConfig root, Path sourceFile, Path baseDirectory) {
        this.root = root;
        this.sourceFile = sourceFile;
        this.baseDirectory = baseDirectory;
        this.gatewayId = root.string("gateway.id", "gateway-1");
        this.catalog = ServerCatalog.from(root);
        this.catalog.enabledServers().forEach(server -> {
            final String secret = root.string("servers." + server.id() + ".secret", null);
            if (secret == null || secret.isBlank()) {
                throw new ConfigException("Сервер '" + server.id() + "' включён, но для него не задан секрет");
            }
        });
        this.serverSecrets = readSecrets(root, "servers");
        this.controlSecrets = readSecrets(root, "control.clients");
        if (controlSecrets.isEmpty()) {
            throw new ConfigException("Нужно настроить хотя бы одного управляющего клиента (Discord-бота) в control.clients");
        }
        final Set<String> guildIds = new LinkedHashSet<>(root.section("guilds").keys(""));
        this.permissions = PermissionConfig.from(root, guildIds);
        this.policy = CommandPolicyEngine.from(root);
        final List<String> blockedSequences = root.stringList("security.blocked_sequences",
                CommandNormalizer.DEFAULT_BLOCKED_SEQUENCES);
        this.normalizer = new CommandNormalizer(
                root.integer("security.max_command_length", CommandNormalizer.DEFAULT_MAX_LENGTH), blockedSequences);
        this.shortcuts = CommandShortcuts.from(root, this.normalizer);
        this.rateLimit = RateLimitSettings.from(root);
        this.queue = QueueSettings.from(this, root.section("queue"));
        this.retry = RetrySettings.from(root.section("retry"));
        this.heartbeat = HeartbeatSettings.from(root.section("heartbeat"));
        this.broadcast = BroadcastSettings.from(root.section("broadcast"), root);
        this.responses = ResponseSettings.from(root.section("responses"));
        this.confirmation = ConfirmationSettings.from(root.section("confirmation"));
        this.database = DatabaseSettings.from(root.section("database"), baseDirectory);
        this.redis = RedisSettings.from(root.section("redis"));
        this.metrics = MetricsSettings.from(root.section("metrics"));
        this.logging = LoggingSettings.from(root.section("logging"));
        this.transport = TransportSettings.from(root.section("network"), root.section("tls"), baseDirectory, null, "gateway");
        this.restrictions = RestrictionSettings.from(root, guildIds);
        final int protocolVersion = root.integer("protocol_version", ru.zigono.dmc.protocol.ProtocolVersion.CURRENT);
        if (protocolVersion != ru.zigono.dmc.protocol.ProtocolVersion.CURRENT) {
            throw new ConfigException("protocol_version " + protocolVersion + " не поддерживается сборкой шлюза "
                    + ru.zigono.dmc.protocol.ProtocolVersion.CURRENT);
        }
    }

    public static GatewayConfig load(Path file) {
        final Path absolute = file.toAbsolutePath();
        final YamlConfig config = YamlConfig.load(absolute);
        final Path baseDirectory = absolute.getParent() == null ? Path.of(".") : absolute.getParent();
        return new GatewayConfig(config, absolute, baseDirectory);
    }

    public static GatewayConfig of(YamlConfig config, Path baseDirectory) {
        return new GatewayConfig(config, Path.of(config.source()), baseDirectory);
    }

    private static Map<String, byte[]> readSecrets(YamlConfig root, String section) {
        final Map<String, byte[]> result = new LinkedHashMap<>();
        final YamlConfig secrets = root.section(section);
        for (String id : secrets.keys("")) {
            final String value = secrets.string(id + ".secret", null);
            if (value == null || value.isBlank()) {
                continue;
            }
            result.put(id, ru.zigono.dmc.protocol.Secrets.decode(value, section + "." + id));
        }
        return Map.copyOf(result);
    }

    public YamlConfig root() {
        return root;
    }

    public Path sourceFile() {
        return sourceFile;
    }

    public Path baseDirectory() {
        return baseDirectory;
    }

    public String gatewayId() {
        return gatewayId;
    }

    public String revision() {
        return root.fingerprint().substring(0, 12);
    }

    public ServerCatalog catalog() {
        return catalog;
    }

    public PermissionConfig permissions() {
        return permissions;
    }

    public CommandPolicyEngine policy() {
        return policy;
    }

    public CommandNormalizer normalizer() {
        return normalizer;
    }

    /** Configured Discord aliases and templates. */
    public CommandShortcuts shortcuts() {
        return shortcuts;
    }

    public RateLimitSettings rateLimit() {
        return rateLimit;
    }

    public QueueSettings queue() {
        return queue;
    }

    public RetrySettings retry() {
        return retry;
    }

    public HeartbeatSettings heartbeat() {
        return heartbeat;
    }

    public BroadcastSettings broadcast() {
        return broadcast;
    }

    public ResponseSettings responses() {
        return responses;
    }

    public ConfirmationSettings confirmation() {
        return confirmation;
    }

    public DatabaseSettings database() {
        return database;
    }

    public RedisSettings redis() {
        return redis;
    }

    public MetricsSettings metrics() {
        return metrics;
    }

    public LoggingSettings logging() {
        return logging;
    }

    public TransportSettings transport() {
        return transport;
    }

    public RestrictionSettings restrictions() {
        return restrictions;
    }

    public Map<String, byte[]> serverSecrets() {
        return serverSecrets;
    }

    public Map<String, byte[]> controlSecrets() {
        return controlSecrets;
    }

    /**
     * @return every configured value of a secret bearing key, used to redact log output
     */
    public java.util.List<String> secretValues() {
        final java.util.List<String> secrets = new java.util.ArrayList<>();
        collectSecrets("", root.asMap(), secrets);
        return java.util.List.copyOf(secrets);
    }

    private static void collectSecrets(String prefix, Map<String, Object> values, java.util.List<String> target) {
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            final String key = entry.getKey().toLowerCase(Locale.ROOT);
            final Object value = entry.getValue();
            if (value instanceof Map<?, ?> nested) {
                final Map<String, Object> converted = new LinkedHashMap<>();
                nested.forEach((nestedKey, nestedValue) -> converted.put(String.valueOf(nestedKey), nestedValue));
                collectSecrets(prefix + entry.getKey() + ".", converted, target);
            } else if (value instanceof String text && !text.isBlank()
                    && (key.endsWith("secret") || key.endsWith("password") || key.endsWith("token"))) {
                target.add(text);
            }
        }
    }

    public boolean emergencyModeStartsEnabled() {
        return root.bool("emergency.enabled", false);
    }

    /** Queue configuration of a Minecraft server. */
    public record QueueSettings(boolean enabled, int maxSize, Duration timeout, String onDisconnect, Duration disconnectHold) {

        static QueueSettings from(GatewayConfig config, YamlConfig section) {
            final String onDisconnect = section.string("on_disconnect", "cancel").trim().toLowerCase(Locale.ROOT);
            if (!DISCONNECT_POLICIES.contains(onDisconnect)) {
                throw new ConfigException("queue.on_disconnect должен быть одним из " + DISCONNECT_POLICIES);
            }
            final int maxSize = section.integer("max_size", 1000);
            if (maxSize <= 0) {
                throw new ConfigException("queue.max_size должен быть положительным");
            }
            return new QueueSettings(section.bool("enabled", true), maxSize,
                    section.duration("timeout_seconds", Duration.ofSeconds(30)),
                    onDisconnect, section.duration("hold_timeout", Duration.ofMinutes(5)));
        }
    }

    /** Retry policy for safe network failures only. */
    public record RetrySettings(boolean enabled, int maxAttempts, Duration delay) {

        static RetrySettings from(YamlConfig section) {
            final int attempts = section.integer("max_attempts", 3);
            if (attempts < 1) {
                throw new ConfigException("retry.max_attempts должен быть не меньше 1");
            }
            return new RetrySettings(section.bool("enabled", true), attempts,
                    Duration.ofMillis(Math.max(1L, section.integer("delay_ms", 1000))));
        }
    }

    /** Heartbeat expectations for Minecraft servers. */
    public record HeartbeatSettings(Duration interval, Duration timeout) {

        static HeartbeatSettings from(YamlConfig section) {
            return new HeartbeatSettings(section.duration("interval_seconds", Duration.ofSeconds(10)),
                    section.duration("timeout_seconds", Duration.ofSeconds(30)));
        }
    }

    /** Multi server execution policy. */
    public record BroadcastSettings(String execution, String failurePolicy, String responseMode) {

        static BroadcastSettings from(YamlConfig section, YamlConfig root) {
            final String execution = section.string("execution", "parallel").toLowerCase(Locale.ROOT);
            final String failure = section.string("failure_policy", "continue").toLowerCase(Locale.ROOT);
            final String mode = section.string("response_mode", "per_server").toLowerCase(Locale.ROOT);
            root.requireEnum("broadcast.execution", execution, BROADCAST_EXECUTION);
            root.requireEnum("broadcast.failure_policy", failure, BROADCAST_FAILURE_POLICY);
            root.requireEnum("broadcast.response_mode", mode, BROADCAST_RESPONSE_MODE);
            return new BroadcastSettings(execution, failure, mode);
        }
    }

    /** Response rendering limits negotiated with the bot. */
    public record ResponseSettings(int maxMessageLength, String largeOutputMode, int attachmentThreshold) {

        static ResponseSettings from(YamlConfig section) {
            return new ResponseSettings(section.integer("max_message_length", 1900),
                    section.string("large_output.mode", "split"),
                    section.integer("large_output.attachment_threshold", 10_000));
        }
    }

    /** Dangerous command confirmation. */
    public record ConfirmationSettings(boolean enabled, Duration timeout) {

        static ConfirmationSettings from(YamlConfig section) {
            return new ConfirmationSettings(section.bool("enabled", true),
                    section.duration("timeout_seconds", Duration.ofSeconds(30)));
        }
    }

    /** Database configuration. */
    public record DatabaseSettings(String type, Path sqliteFile, String host, int port, String database, String username,
                                   String password, int poolSize, boolean retentionEnabled, int retentionDays,
                                   int securityRetentionDays, Duration retentionInterval) {

        static DatabaseSettings from(YamlConfig section, Path baseDirectory) {
            final String type = section.string("type", "sqlite").toLowerCase(Locale.ROOT);
            if (!DATABASE_TYPES.contains(type)) {
                throw new ConfigException("database.type должен быть одним из " + DATABASE_TYPES);
            }
            final Path sqlite = baseDirectory.resolve(section.string("sqlite.file", "data/dmc.db")).normalize();
            return new DatabaseSettings(type, sqlite,
                    section.string("postgresql.host", "localhost"),
                    section.integer("postgresql.port", 5432),
                    section.string("postgresql.database", "dmc"),
                    section.string("postgresql.username", "dmc"),
                    section.string("postgresql.password", null),
                    section.integer("postgresql.pool_size", 10),
                    section.bool("retention.enabled", true),
                    section.integer("retention.days", 90),
                    section.integer("retention.security_days", 365),
                    Duration.ofHours(Math.max(1L, section.integer("retention.interval_hours", 6))));
        }

        public boolean postgresql() {
            return "postgresql".equals(type);
        }
    }

    /** Optional Redis configuration for horizontal scaling. */
    public record RedisSettings(boolean enabled, String uri, String password, String keyPrefix, Duration timeout) {

        static RedisSettings from(YamlConfig section) {
            return new RedisSettings(section.bool("enabled", false),
                    section.string("uri", "redis://127.0.0.1:6379"),
                    section.string("password", null),
                    section.string("key_prefix", "dmc:"),
                    section.duration("timeout", Duration.ofSeconds(2)));
        }
    }

    /** Observability endpoint configuration. */
    public record MetricsSettings(boolean enabled, String host, int port, String path, boolean exposeInternals) {

        static MetricsSettings from(YamlConfig section) {
            return new MetricsSettings(section.bool("enabled", true),
                    section.string("host", "127.0.0.1"),
                    section.integer("port", 9100),
                    section.string("path", "/metrics"),
                    section.bool("expose_internals", false));
        }
    }

    /** Logging switches. */
    public record LoggingSettings(boolean commands, boolean successfulCommands, boolean failedCommands, boolean deniedCommands,
                                  boolean securityEvents, boolean authentication, boolean connections, boolean errors,
                                  boolean debug, String format) {

        static LoggingSettings from(YamlConfig section) {
            return new LoggingSettings(
                    section.bool("commands", true),
                    section.bool("successful_commands", true),
                    section.bool("failed_commands", true),
                    section.bool("denied_commands", true),
                    section.bool("security_events", true),
                    section.bool("authentication", true),
                    section.bool("connections", true),
                    section.bool("errors", true),
                    section.bool("debug", false),
                    section.string("format", "json").toLowerCase(Locale.ROOT));
        }
    }

    /** Guild and channel restrictions. */
    public record RestrictionSettings(Map<String, Set<String>> allowedChannels, Map<String, Set<String>> deniedChannels,
                                      Map<String, Set<String>> allowedGuilds) {

        static RestrictionSettings from(YamlConfig root, Set<String> guildIds) {
            final Map<String, Set<String>> allowed = new LinkedHashMap<>();
            final Map<String, Set<String>> denied = new LinkedHashMap<>();
            final Map<String, Set<String>> guilds = new LinkedHashMap<>();
            for (String guildId : guildIds) {
                final Set<String> allowedForGuild = new LinkedHashSet<>(root.stringList("guilds." + guildId + ".channels.allowed", List.of()));
                final Set<String> deniedForGuild = new LinkedHashSet<>(root.stringList("guilds." + guildId + ".channels.denied", List.of()));
                allowed.put(guildId, Set.copyOf(allowedForGuild));
                denied.put(guildId, Set.copyOf(deniedForGuild));
                guilds.put(guildId, Set.copyOf(root.stringList("guilds." + guildId + ".allowed_servers", List.of())));
            }
            return new RestrictionSettings(Map.copyOf(allowed), Map.copyOf(denied), Map.copyOf(guilds));
        }

        /**
         * @return {@code true} when the channel may be used for console commands
         */
        public boolean allowsChannel(String guildId, String channelId) {
            if (guildId == null || channelId == null) {
                return allowedChannels.isEmpty();
            }
            final Set<String> denied = deniedChannels.getOrDefault(guildId, Set.of());
            if (denied.contains(channelId)) {
                return false;
            }
            final Set<String> allowed = allowedChannels.getOrDefault(guildId, Set.of());
            return allowed.isEmpty() || allowed.contains(channelId);
        }
    }
}
