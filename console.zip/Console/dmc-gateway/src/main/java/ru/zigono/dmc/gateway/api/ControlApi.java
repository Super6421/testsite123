package ru.zigono.dmc.gateway.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.command.CommandPolicyEngine;
import ru.zigono.dmc.common.command.CommandShortcuts;
import ru.zigono.dmc.common.command.NormalizedCommand;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.Permission;
import ru.zigono.dmc.common.perm.PermissionSet;
import ru.zigono.dmc.common.rate.RateLimiter;
import ru.zigono.dmc.common.target.TargetResolver;
import ru.zigono.dmc.gateway.EmergencySwitch;
import ru.zigono.dmc.gateway.auth.AuthorizationService;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.db.AuditRepository;
import ru.zigono.dmc.gateway.db.SecurityAuditRepository;
import ru.zigono.dmc.gateway.db.SecurityEvent;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.queue.QueueManager;
import ru.zigono.dmc.gateway.registry.PluginRegistry;
import ru.zigono.dmc.gateway.registry.ServerRuntimeState;
import ru.zigono.dmc.protocol.Message;
import ru.zigono.dmc.protocol.dto.CommandVisibility;
import ru.zigono.dmc.protocol.dto.ExecutionStatus;
import ru.zigono.dmc.protocol.dto.HistoryEntry;
import ru.zigono.dmc.protocol.dto.PolicySnapshot;
import ru.zigono.dmc.protocol.dto.ServerMetrics;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.dto.ServerStatus;
import ru.zigono.dmc.protocol.dto.TargetSelection;
import ru.zigono.dmc.protocol.dto.TargetsView;
import ru.zigono.dmc.protocol.dto.UserContext;
import ru.zigono.dmc.protocol.message.ControlMessages;
import ru.zigono.dmc.protocol.message.HandshakeMessages;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

/**
 * The authoritative control plane API used by the Discord bot. Every request is authorized here again, even
 * though the bot already ran the same pipeline for the user interface: no stage of the pipeline can be bypassed
 * by a modified or malicious client.
 *
 * @author Zigono
 */
public final class ControlApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(ControlApi.class);

    private final Supplier<GatewayConfig> config;
    private final AuthorizationService authorization;
    private final TargetResolver targetResolver;
    private final QueueManager queueManager;
    private final PluginRegistry registry;
    private final AuditRepository auditRepository;
    private final SecurityAuditRepository securityAuditRepository;
    private final RateLimiter rateLimiter;
    private final Metrics metrics;
    private final EmergencySwitch emergencySwitch;
    private final GatewayControlService controlService;
    private final ConfirmationRegistry confirmations = new ConfirmationRegistry();

    public ControlApi(Supplier<GatewayConfig> config, AuthorizationService authorization, QueueManager queueManager,
                      PluginRegistry registry, AuditRepository auditRepository,
                      SecurityAuditRepository securityAuditRepository, RateLimiter rateLimiter, Metrics metrics,
                      EmergencySwitch emergencySwitch, GatewayControlService controlService) {
        this.config = config;
        this.authorization = authorization;
        this.targetResolver = new TargetResolver(config.get().catalog());
        this.queueManager = queueManager;
        this.registry = registry;
        this.auditRepository = auditRepository;
        this.securityAuditRepository = securityAuditRepository;
        this.rateLimiter = rateLimiter;
        this.metrics = metrics;
        this.emergencySwitch = emergencySwitch;
        this.controlService = controlService;
    }

    public Message handle(Message request) {
        if (request instanceof ControlMessages.TargetsRequest targets) {
            return targets(targets);
        }
        if (request instanceof ControlMessages.ExecuteRequest execute) {
            return execute(execute);
        }
        if (request instanceof ControlMessages.StatusRequest status) {
            return status(status);
        }
        if (request instanceof ControlMessages.HistoryRequest history) {
            return history(history);
        }
        if (request instanceof ControlMessages.ReloadRequest reload) {
            return reload(reload);
        }
        if (request instanceof ControlMessages.EmergencyRequest emergency) {
            return emergency(emergency);
        }
        if (request instanceof ControlMessages.ConfigSnapshotRequest snapshot) {
            return snapshot(snapshot);
        }
        final HandshakeMessages.ErrorMessage error = request.correlate(new HandshakeMessages.ErrorMessage());
        error.code = ErrorCode.PROTOCOL_ERROR.name();
        error.detail = "unsupported control request " + request.getClass().getSimpleName();
        error.fatal = false;
        return error;
    }

    private ControlMessages.TargetsResponse targets(ControlMessages.TargetsRequest request) {
        final ControlMessages.TargetsResponse response = request.correlate(new ControlMessages.TargetsResponse());
        try {
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            if (!permissions.allows(Permission.READ) && !permissions.allows(Permission.SERVERS)) {
                throw new CommandException(ErrorCode.PERMISSION_DENIED, "missing " + Permission.READ);
            }
            response.view = authorization.view(request.user);
        } catch (CommandException e) {
            metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
            recordSecurity(SecurityEvent.Severity.WARNING, "CONTROL_DENIED", request.user, e.getMessage());
            response.view = new TargetsView(true, null, List.of(), List.of(), TargetsView.Capabilities.none(),
                    config.get().revision(), System.currentTimeMillis());
        }
        return response;
    }

    private ControlMessages.ConfigSnapshotResponse snapshot(ControlMessages.ConfigSnapshotRequest request) {
        final ControlMessages.ConfigSnapshotResponse response = request.correlate(new ControlMessages.ConfigSnapshotResponse());
        final GatewayConfig current = config.get();
        final CommandPolicyEngine policy = current.policy();
        final List<PolicySnapshot.RuleSnapshot> rules = new ArrayList<>();
        policy.rules().forEach(rule -> rules.add(new PolicySnapshot.RuleSnapshot(rule.pattern().raw(), rule.deny(),
                rule.permission(), rule.requireConfirmation())));
        response.policy = new PolicySnapshot(
                current.revision(),
                current.normalizer().maxLength(),
                current.root().stringList("security.blocked_sequences", List.of()),
                new ArrayList<>(policy.dangerousPatterns()),
                current.root().stringList("security.blocked_commands", List.of()),
                current.root().stringList("security.allowed_commands", List.of()),
                rules,
                current.confirmation().enabled(),
                (int) current.confirmation().timeout().toSeconds(),
                current.queue().maxSize(),
                emergencySwitch.enabled(),
                current.broadcast().responseMode(),
                current.responses().maxMessageLength(),
                current.responses().attachmentThreshold(),
                current.shortcuts().all().stream()
                        .filter(shortcut -> shortcut.kind() == CommandShortcuts.Kind.ALIAS)
                        .map(ControlApi::shortcutSnapshot).toList(),
                current.shortcuts().all().stream()
                        .filter(shortcut -> shortcut.kind() == CommandShortcuts.Kind.TEMPLATE)
                        .map(ControlApi::shortcutSnapshot).toList());
        return response;
    }

    private ControlMessages.ExecuteResponse execute(ControlMessages.ExecuteRequest request) {
        final long startedAt = System.currentTimeMillis();
        final ControlMessages.ExecuteResponse response = request.correlate(new ControlMessages.ExecuteResponse());
        final GatewayConfig current = config.get();
        response.command = request.command;
        response.dryRun = request.dryRun;
        response.responseMode = current.broadcast().responseMode();
        response.targetDescription = request.target == null ? "неизвестно" : request.target.describe();
        metrics.increment(Metrics.COMMANDS_TOTAL);
        final ru.zigono.dmc.gateway.db.AuditRecordBuilder audit = new ru.zigono.dmc.gateway.db.AuditRecordBuilder()
                .requestId(request.getRequestId())
                .user(request.user)
                .command(request.command)
                .target(response.targetDescription)
                .dryRun(request.dryRun)
                .createdEpochMs(startedAt);
        try {
            metrics.increment(request.dryRun ? "commands_dryrun_total" : "commands_received_total");
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            requirePermission(permissions, request.dryRun ? Permission.DRY_RUN : Permission.EXECUTE,
                    request.dryRun ? "dry run" : "executing commands");
            if (emergencySwitch.enabled() && !permissions.allows("console.emergency.*") && !permissions.allows("console.execute.emergency")) {
                throw new CommandException(ErrorCode.EMERGENCY_MODE, "аварийный режим активен");
            }
            final String expanded = expandShortcut(current, request.command, permissions);
            final NormalizedCommand normalized = current.normalizer().normalize(expanded);
            normalizedValidate(request, normalized);
            final TargetSelection selection = request.target == null ? TargetSelection.from(ru.zigono.dmc.common.target.TargetSpec.single("")) : request.target;
            final TargetResolver.Resolution resolution = targetResolver.resolve(selection.toSpec(), permissions);
            final CommandPolicyEngine.Decision decision = current.policy()
                    .evaluate(normalized, permissions, true);
            if (!decision.allowed()) {
                throw new CommandException(decision.error(), decision.reason());
            }
            checkRateLimit(current, request, normalized, resolution.servers());
            final boolean confirmationRequired = decision.requiresConfirmation() && current.confirmation().enabled()
                    && !request.dryRun;
            if (confirmationRequired) {
                final ConfirmationRegistry.Verdict verdict = confirmations.consume(request.confirmationId,
                        request.user, selection, normalized.normalized(), current.confirmation().timeout());
                if (!verdict.accepted()) {
                    response.errorCode = ErrorCode.CONFIRMATION_REQUIRED.name();
                    response.errorDetail = verdict.reason();
                    response.confirmationId = verdict.token();
                    response.confirmationExpiresAt = verdict.expiresAt();
                    response.durationMillis = System.currentTimeMillis() - startedAt;
                    metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
                    recordSecurity(SecurityEvent.Severity.WARNING, ErrorCode.CONFIRMATION_REQUIRED.name(),
                            request.user, verdict.reason());
                    auditCommand(audit, List.of(), List.of(), ErrorCode.CONFIRMATION_REQUIRED.name(),
                            ErrorCode.CONFIRMATION_REQUIRED.name(), verdict.reason());
                    return response;
                }
            }
            final CommandVisibility visibility = visibilityFor(current, normalized);
            final long timeout = current.queue().timeout().toMillis();
            final boolean dangerous = current.policy().isDangerous(normalized);
            if (dangerous) {
                recordSecurity(SecurityEvent.Severity.CRITICAL, "DANGEROUS_COMMAND", request.user,
                        "опасная команда '" + normalized.normalized() + "' на " + resolution.servers());
            }
            if (request.dryRun) {
                final boolean confirmationNeeded = decision.requiresConfirmation() && current.confirmation().enabled();
                response.dryRunChecks = List.of(
                        "права: ок",
                        "доступ к целям: ок " + resolution.servers(),
                        "политика: " + (confirmationNeeded ? "требуется подтверждение" : "разрешено"),
                        "чёрный список: ок",
                        "лимит частоты: ок",
                        "подтверждение: " + (confirmationNeeded ? "требуется" : "не требуется"));
                response.dryRunSummary = "команда была бы выполнена на "
                        + String.join(", ", resolution.servers())
                        + (confirmationNeeded ? " после подтверждения" : "");
                response.outcomes = queueManager.execute(new QueueManager.ExecutionRequest(request.getRequestId(),
                        resolution.servers(), normalized.normalized(), request.user, visibility,
                        true, timeout)).join();
                response.durationMillis = System.currentTimeMillis() - startedAt;
                metrics.increment("commands_dryrun_total");
                auditCommand(audit, resolution.servers(), response.outcomes, ExecutionStatus.DRY_RUN.name(), null, null);
                return response;
            }
            response.outcomes = queueManager.execute(new QueueManager.ExecutionRequest(request.getRequestId(),
                    resolution.servers(), normalized.normalized(), request.user, visibility,
                    false, timeout)).join();
            response.durationMillis = System.currentTimeMillis() - startedAt;
            final String status = aggregate(response.outcomes);
            if (anySuccess(response.outcomes)) {
                metrics.increment(Metrics.COMMANDS_SUCCESS_TOTAL);
            }
            if (!allSuccessful(response.outcomes)) {
                metrics.increment(Metrics.COMMANDS_FAILED_TOTAL);
            }
            auditCommand(audit, resolution.servers(), response.outcomes, status, null, null);
            return response;
        } catch (CommandException e) {
            response.errorCode = e.code().name();
            response.errorDetail = e.getMessage();
            response.durationMillis = System.currentTimeMillis() - startedAt;
            if (e.code() == ErrorCode.PERMISSION_DENIED || e.code() == ErrorCode.POLICY_DENIED
                    || e.code() == ErrorCode.CONFIRMATION_REQUIRED || e.code() == ErrorCode.EMERGENCY_MODE
                    || e.code() == ErrorCode.RATE_LIMIT || e.code() == ErrorCode.INVALID_COMMAND
                    || e.code() == ErrorCode.INVALID_TARGET) {
                metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
                recordSecurity(e.code() == ErrorCode.INVALID_COMMAND ? SecurityEvent.Severity.WARNING : SecurityEvent.Severity.WARNING,
                        e.code().name(), request.user, e.getMessage());
            } else {
                metrics.increment(Metrics.COMMANDS_FAILED_TOTAL);
            }
            auditCommand(audit, List.of(), List.of(), e.code().name(), e.code().name(), e.getMessage());
            return response;
        } catch (RuntimeException e) {
            LOGGER.error("Непредвиденная ошибка при выполнении управляющего запроса", e);
            metrics.increment(Metrics.COMMANDS_FAILED_TOTAL);
            response.errorCode = ErrorCode.INTERNAL_ERROR.name();
            response.errorDetail = e.getMessage();
            response.durationMillis = System.currentTimeMillis() - startedAt;
            auditCommand(audit, List.of(), List.of(), ErrorCode.INTERNAL_ERROR.name(), ErrorCode.INTERNAL_ERROR.name(),
                    String.valueOf(e.getMessage()));
            return response;
        }
    }

    private static PolicySnapshot.ShortcutSnapshot shortcutSnapshot(CommandShortcuts.Shortcut shortcut) {
        return new PolicySnapshot.ShortcutSnapshot(shortcut.name(), shortcut.command(), shortcut.permission(),
                shortcut.rules());
    }

    /**
     * Expands a configured Discord alias or template into the concrete Minecraft command.
     * <p>The first token selects the shortcut, the remaining tokens are bound to the declared placeholders: by
     * position for aliases and by {@code name=value} for templates. Every value passes
     * {@link ru.zigono.dmc.common.command.ValueValidator}, which is the command injection barrier, and the
     * {@code console.alias.&lt;name&gt;} / {@code console.template.&lt;name&gt;} permission of the shortcut is
     * enforced here so a user cannot bypass the ACL by using a shorthand.</p>
     *
     * @return the original command when it does not name a configured shortcut
     */
    private String expandShortcut(GatewayConfig current, String rawCommand, PermissionSet permissions) {
        if (rawCommand == null || rawCommand.isBlank()) {
            return rawCommand;
        }
        final String trimmed = rawCommand.strip();
        final String[] parts = trimmed.split("\\s+");
        final String head = parts[0].toLowerCase(java.util.Locale.ROOT);
        final CommandShortcuts shortcuts = current.shortcuts();
        final CommandShortcuts.Shortcut shortcut = shortcuts.alias(head)
                .or(() -> shortcuts.template(head)).orElse(null);
        if (shortcut == null) {
            return rawCommand;
        }
        if (!permissions.allows(shortcut.permission())) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED,
                    "нет права " + shortcut.permission() + " для сокращения '" + shortcut.name() + "'");
        }
        final java.util.List<String> arguments = new java.util.ArrayList<>(java.util.List.of(parts).subList(1, parts.length));
        final java.util.Map<String, String> values = new java.util.LinkedHashMap<>();
        final java.util.List<String> placeholders = new java.util.ArrayList<>(shortcut.rules().keySet());
        for (int index = 0; index < arguments.size(); index++) {
            final String argument = arguments.get(index);
            final int separator = argument.indexOf('=');
            if (separator > 0) {
                final String key = argument.substring(0, separator).toLowerCase(java.util.Locale.ROOT);
                if (!shortcut.rules().containsKey(key)) {
                    throw new CommandException(ErrorCode.INVALID_COMMAND,
                            "неизвестный параметр '" + key + "' для сокращения '" + shortcut.name() + "'");
                }
                values.put(key, argument.substring(separator + 1));
                continue;
            }
            if (index >= placeholders.size()) {
                throw new CommandException(ErrorCode.INVALID_COMMAND,
                        "слишком много аргументов для сокращения '" + shortcut.name() + "'");
            }
            values.putIfAbsent(placeholders.get(index), argument);
        }
        for (String placeholder : placeholders) {
            if (!values.containsKey(placeholder)) {
                throw new CommandException(ErrorCode.INVALID_COMMAND, "не задано значение параметра '"
                        + placeholder + "' сокращения '" + shortcut.name() + "'");
            }
        }
        return shortcuts.render(shortcut, values);
    }

    private void normalizedValidate(ControlMessages.ExecuteRequest request, NormalizedCommand normalized) {
        if (request.normalizedCommand != null && !request.normalizedCommand.isBlank()
                && !request.normalizedCommand.equals(normalized.normalized())) {
            throw new CommandException(ErrorCode.INVALID_COMMAND,
                    "нормализованная команда не совпадает с выполненной");
        }
    }

    private void checkRateLimit(GatewayConfig current, ControlMessages.ExecuteRequest request,
                                NormalizedCommand normalized, List<String> servers) {
        if (!rateLimiter.enabled()) {
            return;
        }
        final List<String> keys = new ArrayList<>();
        keys.add("user:" + request.user.userId());
        for (String roleId : request.user.roleIds()) {
            keys.add("role:" + roleId);
        }
        for (String serverId : servers) {
            keys.add("server:" + serverId);
        }
        keys.add("command:" + normalized.root());
        if (!servers.isEmpty()) {
            final String group = request.target == null ? null : request.target.group();
            if (group != null && !group.isBlank()) {
                keys.add("group:" + group.toLowerCase(java.util.Locale.ROOT));
            }
        }
        keys.add("global");
        final RateLimiter.Decision decision = rateLimiter.check(keys);
        if (!decision.allowed()) {
            metrics.increment(Metrics.RATE_LIMIT_HITS);
            throw new CommandException(ErrorCode.RATE_LIMIT,
                    "rate limit '" + decision.scope() + "' exceeded, retry after " + decision.retryAfterMillis() + " ms");
        }
    }

    private CommandVisibility visibilityFor(GatewayConfig current, NormalizedCommand normalized) {
        final ru.zigono.dmc.common.config.YamlConfig minecraft = current.root().section("minecraft");
        final ru.zigono.dmc.common.config.YamlConfig console = minecraft.section("discord_console_visibility");
        final boolean enabled = console.bool("enabled", true);
        final String permission = console.string("permission", "discordconsole.monitor");
        final String format = console.string("format", "&7[&9Discord&7] &f{user} &7executed &f{command}");
        final String resultFormat = console.string("result_format", "&7[&9Discord&7] &7result: &f{result}");
        final List<String> hidden = minecraft.stringList("visibility.hidden_commands", List.of());
        final String mode = minecraft.string("visibility.mode", "default");
        boolean showInGame = enabled && !hidden.contains(normalized.root());
        if ("permission".equalsIgnoreCase(mode)) {
            showInGame = showInGame && permission != null && !permission.isBlank();
        }
        return new CommandVisibility(true, showInGame, permission, format, resultFormat, null);
    }

    private void requirePermission(PermissionSet permissions, String node, String action) {
        if (!permissions.allows(node)) {
            throw new CommandException(ErrorCode.PERMISSION_DENIED, "нет права " + node + " для " + action);
        }
    }

    private ControlMessages.StatusResponse status(ControlMessages.StatusRequest request) {
        final ControlMessages.StatusResponse response = request.correlate(new ControlMessages.StatusResponse());
        final GatewayConfig current = config.get();
        response.gatewayId = current.gatewayId();
        response.configRevision = current.revision();
        response.uptimeSeconds = metrics.uptimeSeconds();
        try {
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            requirePermission(permissions, Permission.STATUS, "reading server status");
            final List<ControlMessages.ServerStatusEntry> entries = new ArrayList<>();
            for (ServerRuntimeState state : registry.states()) {
                if (!permissions.allows(Permission.server(state.serverId()))
                        && !permissions.allows(Permission.BROADCAST_ALL)) {
                    continue;
                }
                if (!request.serverIds.isEmpty() && !request.serverIds.contains(state.serverId())) {
                    continue;
                }
                entries.add(new ControlMessages.ServerStatusEntry(state.serverId(), state.name(), state.status().name(),
                        state.metrics(), state.errorDetail(), state.lastHeartbeatAt()));
            }
            response.servers = entries;
        } catch (CommandException e) {
            metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
            response.servers = List.of();
        }
        return response;
    }

    private ControlMessages.HistoryResponse history(ControlMessages.HistoryRequest request) {
        final ControlMessages.HistoryResponse response = request.correlate(new ControlMessages.HistoryResponse());
        try {
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            requirePermission(permissions, Permission.HISTORY, "чтения истории команд");
            final boolean all = permissions.allows("console.history.all");
            final String effectiveUser = all ? null : request.user.userId();
            final AuditRepository.HistoryQuery query = new AuditRepository.HistoryQuery(request.serverId, effectiveUser,
                    all ? request.username : request.user.username(), request.commandFragment, request.status,
                    request.fromMillis, request.toMillis, request.limit, request.offset);
            final List<HistoryEntry> entries = auditRepository.search(query);
            response.entries = entries;
            response.total = auditRepository.count(query);
            response.limit = request.limit;
            response.offset = request.offset;
        } catch (CommandException e) {
            metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
            response.entries = List.of();
            response.total = 0;
            recordSecurity(SecurityEvent.Severity.WARNING, "HISTORY_DENIED", request.user, e.getMessage());
        }
        return response;
    }

    private ControlMessages.ReloadResponse reload(ControlMessages.ReloadRequest request) {
        final ControlMessages.ReloadResponse response = request.correlate(new ControlMessages.ReloadResponse());
        try {
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            requirePermission(permissions, "console.admin.reload", "перезагрузки конфигурации");
            final GatewayControlService.ReloadResult result = controlService.reload();
            response.reloaded = result.reloaded();
            response.configRevision = result.revision();
            response.reloadedSections = result.sections();
            response.errorDetail = result.error();
            if (!result.reloaded()) {
                response.errorDetail = result.error();
            }
        } catch (CommandException e) {
            metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
            response.reloaded = false;
            response.errorDetail = e.getMessage();
            recordSecurity(SecurityEvent.Severity.CRITICAL, "RELOAD_DENIED", request.user, e.getMessage());
        }
        return response;
    }

    private ControlMessages.EmergencyResponse emergency(ControlMessages.EmergencyRequest request) {
        final ControlMessages.EmergencyResponse response = request.correlate(new ControlMessages.EmergencyResponse());
        try {
            authorization.checkContext(request.user);
            final PermissionSet permissions = authorization.permissionsOf(request.user);
            if (!permissions.allows("console.emergency.*") && !permissions.allows("console.emergency.toggle")
                    && !permissions.allows("console.admin.emergency")) {
                throw new CommandException(ErrorCode.PERMISSION_DENIED, "нет права console.emergency.*");
            }
            emergencySwitch.set(request.enabled);
            response.emergencyMode = emergencySwitch.enabled();
            recordSecurity(SecurityEvent.Severity.CRITICAL, request.enabled ? "EMERGENCY_ENABLED" : "EMERGENCY_DISABLED",
                    request.user, "аварийный режим переключён в " + request.enabled);
        } catch (CommandException e) {
            metrics.increment(Metrics.COMMANDS_DENIED_TOTAL);
            response.emergencyMode = emergencySwitch.enabled();
            response.errorDetail = e.getMessage();
        }
        return response;
    }

    private void auditCommand(ru.zigono.dmc.gateway.db.AuditRecordBuilder builder, List<String> servers,
                              List<ServerOutcome> outcomes, String status, String errorCode, String errorDetail) {
        try {
            if (outcomes.isEmpty()) {
                auditRepository.insert(builder.serverId(servers.isEmpty() ? null : String.join(",", servers))
                        .status(status).errorCode(errorCode).errorDetail(errorDetail).build());
                return;
            }
            final List<AuditRepository.AuditRecord> records = new ArrayList<>(outcomes.size());
            for (ServerOutcome outcome : outcomes) {
                records.add(builder.serverId(outcome.serverId())
                        .status(outcome.status().name())
                        .durationMs(outcome.durationMillis())
                        .response(String.join("\n", outcome.output()))
                        .errorCode(outcome.errorCode())
                        .errorDetail(outcome.errorDetail())
                        .build());
            }
            auditRepository.insertAll(records);
        } catch (RuntimeException e) {
            metrics.increment(Metrics.AUDIT_WRITE_FAILURES);
            LOGGER.error("Не удалось записать журнал аудита", e);
        }
    }

    private String aggregate(List<ServerOutcome> outcomes) {
        if (outcomes.isEmpty()) {
            return ExecutionStatus.FAILED.name();
        }
        if (allSuccessful(outcomes)) {
            return ExecutionStatus.SUCCESS.name();
        }
        if (anySuccess(outcomes)) {
            return "PARTIAL";
        }
        return outcomes.get(0).status().name();
    }

    private boolean allSuccessful(List<ServerOutcome> outcomes) {
        return !outcomes.isEmpty() && outcomes.stream().allMatch(outcome -> outcome.status().successful());
    }

    private boolean anySuccess(List<ServerOutcome> outcomes) {
        return outcomes.stream().anyMatch(outcome -> outcome.status().successful());
    }

    private void recordSecurity(SecurityEvent.Severity severity, String eventType, UserContext user, String detail) {
        try {
            securityAuditRepository.insert(new SecurityEvent(null, eventType, severity,
                    user == null ? null : user.userId(), user == null ? null : user.username(),
                    user == null ? null : user.guildId(), user == null ? null : user.channelId(),
                    null, null, null, detail, System.currentTimeMillis()));
        } catch (RuntimeException e) {
            metrics.increment(Metrics.AUDIT_WRITE_FAILURES);
            LOGGER.error("Не удалось записать аудит безопасности", e);
        }
    }

    public RateLimiter rateLimiter() {
        return rateLimiter;
    }

    public PluginRegistry registry() {
        return registry;
    }

    public Supplier<GatewayConfig> configSupplier() {
        return config;
    }
}