package ru.zigono.dmc.gateway;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.zigono.dmc.common.rate.InMemoryRateBackend;
import ru.zigono.dmc.common.rate.RateBackend;
import ru.zigono.dmc.common.rate.RateLimiter;
import ru.zigono.dmc.common.security.IpAllowlist;
import ru.zigono.dmc.common.util.Ids;
import ru.zigono.dmc.gateway.api.ControlApi;
import ru.zigono.dmc.gateway.api.GatewayControlService;
import ru.zigono.dmc.gateway.auth.AuthorizationService;
import ru.zigono.dmc.gateway.config.GatewayConfig;
import ru.zigono.dmc.gateway.db.AuditRepository;
import ru.zigono.dmc.gateway.db.Database;
import ru.zigono.dmc.gateway.db.RetentionService;
import ru.zigono.dmc.gateway.db.SecurityAuditRepository;
import ru.zigono.dmc.gateway.db.SecurityEvent;
import ru.zigono.dmc.gateway.db.ServerMetadataRepository;
import ru.zigono.dmc.gateway.db.StateRepository;
import ru.zigono.dmc.gateway.metrics.AdminHttpServer;
import ru.zigono.dmc.gateway.metrics.Metrics;
import ru.zigono.dmc.gateway.net.ClusterCommandDispatcher;
import ru.zigono.dmc.gateway.net.GatewayConnectionHandler;
import ru.zigono.dmc.gateway.net.PluginCommandDispatcher;
import ru.zigono.dmc.gateway.queue.QueueManager;
import ru.zigono.dmc.gateway.queue.QueuedCommand;
import ru.zigono.dmc.gateway.queue.RetryPolicy;
import ru.zigono.dmc.gateway.redis.RedisCoordinator;
import ru.zigono.dmc.gateway.redis.RedisRateBackend;
import ru.zigono.dmc.gateway.registry.PluginRegistry;
import ru.zigono.dmc.common.config.ConfigWatcher;
import ru.zigono.dmc.protocol.KeyResolver;
import ru.zigono.dmc.protocol.ProtocolException;
import ru.zigono.dmc.protocol.dto.ServerOutcome;
import ru.zigono.dmc.protocol.message.PluginMessages;
import ru.zigono.dmc.protocol.transport.TransportServer;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Gateway runtime: owns the secure listener, the ACL, the queues, the audit database, the metrics endpoint and
 * the optional Redis coordination.
 *
 * @author Zigono
 */
public final class Gateway implements AutoCloseable, GatewayControlService {

    private static final Logger LOGGER = LoggerFactory.getLogger(Gateway.class);

    private final Path configFile;
    private final AtomicReference<GatewayConfig> config = new AtomicReference<>();
    private final Metrics metrics = new Metrics();
    private final AtomicBoolean shuttingDown = new AtomicBoolean();
    private final String instanceId = Ids.ulid();

    private Database database;
    private AuditRepository auditRepository;
    private SecurityAuditRepository securityAuditRepository;
    private StateRepository stateRepository;
    private ServerMetadataRepository serverMetadataRepository;
    private AdminHttpServer adminServer;
    private RetentionService retentionService;
    private EmergencySwitch emergencySwitch;
    private RateLimiter rateLimiter;
    private RateBackend rateBackend;
    private RedisCoordinator redisCoordinator;
    private PluginRegistry registry;
    private PluginCommandDispatcher pluginDispatcher;
    private ClusterCommandDispatcher clusterDispatcher;
    private QueueManager queueManager;
    private AuthorizationService authorization;
    private ControlApi controlApi;
    private GatewayConnectionHandler handler;
    private TransportServer transportServer;
    private ScheduledExecutorService scheduler;
    private ConfigWatcher configWatcher;

    public Gateway(Path configFile) {
        this.configFile = configFile.toAbsolutePath();
    }

    public GatewayConfig config() {
        return config.get();
    }

    public Metrics metrics() {
        return metrics;
    }

    public void start() throws InterruptedException {
        final GatewayConfig loaded = GatewayConfig.load(configFile);
        config.set(loaded);
        LOGGER.info("Запускаю {} ({})", GatewayBuild.describe(), loaded.gatewayId());
        LOGGER.info("Конфигурация: {} (ревизия {}), режим {}", loaded.sourceFile(), loaded.revision(),
                loaded.catalog().singleServerMode() ? "один сервер" : "несколько серверов");

        database = Database.open(loaded.database());
        auditRepository = new AuditRepository(database);
        securityAuditRepository = new SecurityAuditRepository(database);
        stateRepository = new StateRepository(database);
        serverMetadataRepository = new ServerMetadataRepository(database);
        emergencySwitch = new EmergencySwitch(loaded.emergencyModeStartsEnabled(), stateRepository);

        if (loaded.redis().enabled()) {
            rateBackend = new RedisRateBackend(loaded.redis());
        } else {
            rateBackend = new InMemoryRateBackend();
        }
        rateLimiter = new RateLimiter(loaded.rateLimit(), rateBackend);

        registry = new PluginRegistry(loaded.catalog(), loaded.heartbeat(), this::onServerStale);
        pluginDispatcher = new PluginCommandDispatcher(registry, metrics);
        redisCoordinator = loaded.redis().enabled()
                ? new RedisCoordinator(loaded.redis(), instanceId, this::executeRemoteDispatch, (serverId, outcome) -> { })
                : null;
        clusterDispatcher = new ClusterCommandDispatcher(pluginDispatcher, redisCoordinator);
        queueManager = new QueueManager(loaded, new RetryPolicy(loaded.retry()), clusterDispatcher, metrics);
        authorization = new AuthorizationService(this::config, serverId -> registry.state(serverId).status());
        controlApi = new ControlApi(this::config, authorization, queueManager, registry, auditRepository,
                securityAuditRepository, rateLimiter, metrics, emergencySwitch, this);

        final IpAllowlist allowlist = IpAllowlist.of(loaded.root().stringList("network.allowed_ips", List.of()));
        handler = new GatewayConnectionHandler(this::config, registry, pluginDispatcher, queueManager, controlApi,
                metrics, securityAuditRepository, allowlist);
        transportServer = new TransportServer(loaded.transport(), keyResolver(loaded), handler, this::onViolation);
        transportServer.start();

        registerGauges();
        if (loaded.metrics().enabled()) {
            adminServer = new AdminHttpServer(loaded, metrics, this::live, this::ready);
            adminServer.start();
        }
        retentionService = new RetentionService(loaded.database(), auditRepository, securityAuditRepository);
        retentionService.start();

        scheduler = Executors.newScheduledThreadPool(2, runnable -> {
            final Thread thread = new Thread(runnable, "dmc-gateway-scheduler");
            thread.setDaemon(true);
            return thread;
        });
        scheduler.scheduleWithFixedDelay(this::heartbeatTick, 5, 5, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::persistServerMetadata, 15, 30, TimeUnit.SECONDS);

        configWatcher = new ConfigWatcher(List.of(configFile), Duration.ofSeconds(2), path -> reload());
        configWatcher.start();

        Runtime.getRuntime().addShutdownHook(new Thread(this::close, "dmc-gateway-shutdown"));
        LOGGER.info("Шлюз готов и слушает {}:{}", loaded.transport().host(), transportServer.port());
    }

    private KeyResolver keyResolver(GatewayConfig config) {
        final Map<String, byte[]> keys = new LinkedHashMap<>();
        keys.putAll(config.serverSecrets());
        keys.putAll(config.controlSecrets());
        return KeyResolver.of(keys);
    }

    private void registerGauges() {
        metrics.gauge(Metrics.CONNECTED_SERVERS, () -> registry.connectedCount());
        metrics.gauge(Metrics.OFFLINE_SERVERS, () -> registry.offlineCount());
        metrics.gauge(Metrics.QUEUE_SIZE, () -> queueManager == null ? 0 : queueManager.totalQueueSize());
        metrics.gauge("pending_dispatches", () -> pluginDispatcher == null ? 0 : pluginDispatcher.pendingCount());
        metrics.gauge("plugin_sessions", () -> handler == null ? 0 : handler.pluginSessionCount());
        metrics.gauge("emergency_mode", () -> emergencySwitch != null && emergencySwitch.enabled() ? 1 : 0);
    }

    private void heartbeatTick() {
        try {
            registry.tick();
        } catch (RuntimeException e) {
            LOGGER.error("Сбой монитора heartbeat", e);
        }
    }

    private void persistServerMetadata() {
        try {
            for (var state : registry.states()) {
                serverMetadataRepository.upsert(state.serverId(), state.name(), state.status().name(), state.metrics());
            }
        } catch (RuntimeException e) {
            LOGGER.warn("Не удалось сохранить метаданные сервера: {}", e.getMessage());
        }
    }

    private void onServerStale(PluginRegistry.StaleServer stale) {
        if (stale.status() == ru.zigono.dmc.protocol.dto.ServerStatus.OFFLINE) {
            LOGGER.warn("Minecraft-сервер '{}' больше не отвечает на heartbeat", stale.serverId());
            securityAudit(SecurityEvent.Severity.WARNING, "SERVER_OFFLINE", stale.serverId(),
                    "таймаут heartbeat для " + stale.serverId());
            queueManager.onServerDisconnected(stale.serverId(), "heartbeat timeout");
        } else {
            LOGGER.warn("Minecraft-сервер '{}' работает с ухудшением", stale.serverId());
        }
    }

    private void executeRemoteDispatch(PluginMessages.CommandDispatch dispatch) {
        LOGGER.debug("Выполняю удалённую отправку {} для {} из другого экземпляра шлюза", dispatch.getRequestId(),
                dispatch.serverId);
        if (redisCoordinator == null) {
            return;
        }
        if (registry.connection(dispatch.serverId).isEmpty()) {
            redisCoordinator.publishResult(dispatch.getRequestId(), dispatch.serverId,
                    ServerOutcome.failure(dispatch.serverId,
                            ru.zigono.dmc.protocol.dto.ExecutionStatus.OFFLINE, "SERVER_OFFLINE",
                            "на экземпляре, получившем перенаправленную команду, нет подключения плагина"));
            return;
        }
        final QueuedCommand command = new QueuedCommand(dispatch.getRequestId(), dispatch.serverId, dispatch.command,
                dispatch.issuer, dispatch.visibility, dispatch.timeoutMillis, false);
        queueManager.queue(dispatch.serverId).submit(command)
                .whenComplete((outcome, error) -> redisCoordinator.publishResult(dispatch.getRequestId(),
                        dispatch.serverId, outcome != null ? outcome
                                : ServerOutcome.failure(dispatch.serverId,
                                ru.zigono.dmc.protocol.dto.ExecutionStatus.FAILED, "INTERNAL_ERROR",
                                String.valueOf(error))));
    }

    private void onViolation(ProtocolException violation) {
        metrics.increment(Metrics.PROTOCOL_VIOLATIONS);
        if (violation.reason() == ProtocolException.Reason.REPLAY) {
            metrics.increment(Metrics.REPLAY_REJECTIONS);
        } else if (violation.reason() == ProtocolException.Reason.AUTHENTICATION) {
            metrics.increment(Metrics.AUTHENTICATION_FAILURES);
        }
        securityAudit(SecurityEvent.Severity.CRITICAL, violation.code().name(), null, violation.getMessage());
    }

    private void securityAudit(SecurityEvent.Severity severity, String type, String serverId, String detail) {
        try {
            if (securityAuditRepository != null) {
                securityAuditRepository.insert(new SecurityEvent(null, type, severity, null, null, null, null,
                        serverId, null, null, detail, System.currentTimeMillis()));
            }
        } catch (RuntimeException e) {
            LOGGER.error("Не удалось записать аудит безопасности", e);
        }
    }

    public boolean live() {
        return !shuttingDown.get();
    }

    public boolean ready() {
        if (shuttingDown.get() || transportServer == null) {
            return false;
        }
        if (database == null || !database.healthy()) {
            return false;
        }
        if (rateBackend instanceof RedisRateBackend redisBackend && !redisBackend.healthy()) {
            return false;
        }
        return true;
    }

    @Override
    public String configRevision() {
        return config.get().revision();
    }

    @Override
    public ReloadResult reload() {
        final List<String> sections = new ArrayList<>();
        try {
            final GatewayConfig previous = config.get();
            final GatewayConfig updated = GatewayConfig.load(configFile);
            if (updated.transport().port() != previous.transport().port()
                    || updated.transport().tlsEnabled() != previous.transport().tlsEnabled()) {
                LOGGER.warn("изменения network/tls требуют перезапуска и игнорируются горячей перезагрузкой");
            }
            config.set(updated);
            registry.ensureServers(updated.catalog());
            queueManager.applyConfig(updated);
            rateLimiter = new RateLimiter(updated.rateLimit(), rateBackend);
            controlApi = new ControlApi(this::config, authorization, queueManager, registry, auditRepository,
                    securityAuditRepository, rateLimiter, metrics, emergencySwitch, this);
            sections.add("permissions");
            sections.add("policies");
            sections.add("servers");
            sections.add("groups");
            sections.add("rate_limit");
            sections.add("security");
            sections.add("logging");
            sections.add("queue");
            sections.add("retry");
            sections.add("heartbeat");
            sections.add("broadcast");
            sections.add("confirmation");
            sections.add("responses");
            LOGGER.info("Конфигурация перезагружена, новая ревизия {}", updated.revision());
            return new ReloadResult(true, updated.revision(), sections, null);
        } catch (RuntimeException e) {
            LOGGER.error("Горячая перезагрузка не удалась, продолжает действовать прежняя конфигурация", e);
            return new ReloadResult(false, config.get().revision(), sections, String.valueOf(e.getMessage()));
        }
    }

    @Override
    public void close() {
        if (!shuttingDown.compareAndSet(false, true)) {
            return;
        }
        LOGGER.info("Начата остановка шлюза");
        if (configWatcher != null) {
            configWatcher.close();
        }
        if (scheduler != null) {
            scheduler.shutdownNow();
        }
        if (transportServer != null) {
            transportServer.close();
        }
        if (queueManager != null) {
            queueManager.close();
        }
        if (redisCoordinator != null) {
            redisCoordinator.close();
        }
        if (rateBackend != null) {
            rateBackend.close();
        }
        if (retentionService != null) {
            retentionService.close();
        }
        if (adminServer != null) {
            adminServer.close();
        }
        if (database != null) {
            database.close();
        }
        LOGGER.info("Остановка шлюза завершена");
    }

    public PluginRegistry registry() {
        return registry;
    }

    public QueueManager queueManager() {
        return queueManager;
    }

    public ControlApi controlApi() {
        return controlApi;
    }

    public TransportServer transportServer() {
        return transportServer;
    }

    public AuditRepository auditRepository() {
        return auditRepository;
    }

    public SecurityAuditRepository securityAuditRepository() {
        return securityAuditRepository;
    }

    public EmergencySwitch emergencySwitch() {
        return emergencySwitch;
    }

    public Database database() {
        return database;
    }
}
