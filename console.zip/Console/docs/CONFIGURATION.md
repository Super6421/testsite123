# Конфигурация

Автор: **Zigono** · версия 1.0.0

Полные примеры: `config/gateway.example.yml`, `config/bot.example.yml`, `config/plugin.example.yml`.
Переменные окружения: `.env.example`.

---

## 1. Общие правила

### 1.1. Формат

Все конфигурации — YAML в UTF-8. Файл шлюза загружается **строго**: неизвестные значения
enum-параметров, включённый сервер без секрета, отсутствие `control.clients`, неподдерживаемый
`protocol_version` или недопустимый `queue.on_disconnect` останавливают запуск с понятной ошибкой.

### 1.2. Подстановка переменных окружения

Поддерживаются `${VAR}` и `${VAR:default}`:

```yaml
token: ${DISCORD_TOKEN}                        # обязательна: без переменной запуск остановится
port: ${DMC_GATEWAY_PORT:8443}                 # значение по умолчанию, если переменной нет
dir: ${DMC_TLS_DIR:./tls}/gateway.p12          # подстановка внутри строки
prefix: ${REDIS_KEY_PREFIX:dmc:}               # двоеточие в значении по умолчанию допустимо
```

Подстановка выполняется **после** разбора YAML, поэтому секрет с символами YAML-синтаксиса не
может сломать документ. Храните секреты только в окружении: `.env` (для docker compose),
`EnvironmentFile=` в systemd или секреты оркестратора.

### 1.3. Длительности и целые числа

| Категория | Правило | Примеры |
|---|---|---|
| Ключи-длительности (`*_timeout`, `*_grace`, `reconnect.*`, `queue.timeout_seconds`, `queue.hold_timeout`, `heartbeat.*`, `confirmation.timeout_seconds`, `redis.timeout`, `rate_limit.*.interval`) | строка с единицей: `ms`, `s`, `m`, `h`, `d` или ISO-8601. Число **без** единицы = секунды | `120s`, `250ms`, `5m`, `2h`, `PT30S`, `30` (= 30s) |
| Целочисленные ключи (`retry.delay_ms`, `database.retention.interval_hours`, `rate_limit.*.interval_seconds`, `*.requests`, `*.port`, `security.max_command_length`, `queue.max_size`, `network.max_frame_bytes`, `responses.*`, `database.postgresql.pool_size`, `database.retention.days`) | только целое число, единицы не допускаются | `delay_ms: 1000`, `interval_hours: 6`, `interval_seconds: 10` |

> `retry.delay_ms` — **миллисекунды**, `database.retention.interval_hours` — **часы**,
> `rate_limit.*.interval_seconds` — **секунды**. Это целые числа: `delay_ms: 1s` приведёт к
> ошибке конфигурации.

### 1.4. Секреты

Значением любого секрета может быть:

```yaml
secret: ${DMC_SURVIVAL_SECRET}     # обычная строка -> UTF-8 байты (минимум 16 байт)
secret: "hex:9f86d081884c7d659a2feaa0c55ad015"
secret: "base64:q83vTIGwjH1pov6gr1LQFeY="
```

В **встроенном режиме** (`embedded.enabled: true`, см. §4.1) `security.server_secret` можно не
задавать: плагин сгенерирует 32 случайных байта при первом запуске, сохранит их в
`plugins/DiscordMinecraftConsole/embedded/server.secret` и передаст то же значение шлюзу, который
запускает сам. Так же генерируется секрет control-клиента (`embedded/control.secret`). Оба файла
доступны только владельцу процесса, где это поддерживает файловая система.

Секрет короче 16 байт отклоняется при загрузке. Секреты никогда не пишутся в логи: шлюз
редактирует значения `*secret*`, `*password*`, `*token*` в логах и исключениях, а в аудит
попадает команда, но не секрет.

---

## 2. Конфигурация шлюза (`config/gateway.yml`)

### 2.1. Общие параметры

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `protocol_version` | int | `1` | Версия протокола. Должна совпадать с версией сборки; иначе конфигурация отклоняется |
| `mode` | `single` \| `multi` | авто | Режим работы. Пусто — режим выводится автоматически (один включённый сервер ⇒ `single`). Принимается и как `gateway.mode` |
| `gateway.id` | string | `gateway-1` | Идентификатор экземпляра; у каждого экземпляра при кластеризации свой |
| `emergency.enabled` | bool | `false` | Стартовое состояние аварийного режима. Дальше состояние хранится в БД (`gateway_state`) и переживает перезапуск |

### 2.2. Серверы, группы, управляющие клиенты

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `servers.<id>.name` | string | `id` | Отображаемое имя |
| `servers.<id>.enabled` | bool | `true` | Выключенный сервер недоступен для команд |
| `servers.<id>.aliases` | list | `[]` | Дополнительные имена (нормализуются в нижний регистр, дубликаты — ошибка конфигурации) |
| `servers.<id>.secret` | secret | — | **Обязателен** для включённого сервера |
| `groups.<name>.servers` | list | — | Участники группы (id или alias). Группа не может быть пустой, неизвестный сервер — ошибка |
| `control.clients.<id>.secret` | secret | — | **Обязателен**; минимум один управляющий клиент (Discord-бот). Идентификатор — это `clientId` бота, роль подключения `control` |

### 2.3. Права Discord

| Ключ | Тип | Описание |
|---|---|---|
| `permissions.roles.<roleId>.allow` / `.deny` | list | Глобальные (не привязанные к гильдии) права роли |
| `permissions.users.<userId>.allow` / `.deny` | list | Персональные переопределения |
| `guilds.<guildId>.permissions.roles.<roleId>.allow` / `.deny` | list | Права роли внутри гильдии |
| `guilds.<guildId>.permissions.users.<userId>.allow` / `.deny` | list | Персональные права внутри гильдии |
| `guilds.<guildId>.channels.allowed` / `.denied` | list | Ограничения каналов: `denied` проверяется первым, пустой `allowed` = любой канал |
| `guilds.<guildId>.allowed_servers` | list | Зарезервировано; текущая сборка не ограничивает этим списком выдачу серверов (используйте `console.server.*`) |

Итоговые права пользователя = объединение всех подходящих назначений (глобальные роли,
персональные, роли гильдии, персональные в гильдии). `deny` всегда побеждает `allow`.
Синтаксис wildcard и полный список узлов — в `docs/PERMISSIONS.md`.

### 2.4. Политики команд и безопасность

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `command_policies` | list или map | `[]` | Правила вида `pattern`, `deny`, `permission`, `require_confirmation` |
| `command_policies[].pattern` | string | — | Паттерн по токенам: `*` (целый токен), `*`/`?` внутри токена; лишние аргументы допускаются |
| `command_policies[].deny` | bool | `false` | Запрет команды |
| `command_policies[].permission` | string | — | Явно требуемое право (иначе выводится `console.command.<root>.<arg1>`) |
| `command_policies[].require_confirmation` | bool | `false` | Обязательное подтверждение |
| `security.blocked_commands` | list | `[]` | Безусловный запрет (проверяется первым) |
| `security.allowed_commands` | list | `[]` | Если не пусто — режим whitelist: разрешены только совпадающие команды |
| `security.dangerous_commands` | list | `[]` | Требуют подтверждения инициатора |
| `security.blocked_sequences` | list | `["&&", "\|\|", ";", "$(", "\x", "\u0000"]` и обратный апостроф | Запрещённые последовательности (защита от chaining/injection); управляющие символы и переводы строк отклоняются всегда |
| `security.max_command_length` | int | `512` | Максимальная длина команды до нормализации и после неё |

Порядок проверок: нормализация → `blocked_commands` → whitelist → самое конкретное правило
`command_policies` → производное право → требование подтверждения. Порядок правил в файле не
влияет на результат: выбирается самое специфичное совпадение.

### 2.5. Rate limiting

Раздел целиком опционален: если `rate_limit` отсутствует, лимиты выключены.

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `rate_limit.enabled` | bool | `true` | Включает проверку лимитов |
| `rate_limit.per_user.requests` | int | `0` (= без лимита) | Лимит на `user:<id>` |
| `rate_limit.per_role.requests` | int | `0` | Лимит на каждый `role:<id>` пользователя |
| `rate_limit.per_server.requests` | int | `0` | Лимит на `server:<id>` |
| `rate_limit.per_command.requests` | int | `0` | Лимит на `command:<root>` |
| `rate_limit.per_group.requests` | int | `0` | Лимит на `group:<name>` (только для групповых целей) |
| `rate_limit.global.requests` | int | `0` | Общий лимит `global` |
| `*.interval_seconds` | int | `10` | Окно в секундах (целое число) |
| `*.interval` | duration | — | Альтернативная форма окна: `interval: 30s` |
| `rate_limit.servers.<id>` | обьект | — | Переопределение для конкретного сервера |
| `rate_limit.commands."<command root>"` | обьект | — | Переопределение для конкретной команды |
| `rate_limit.groups.<name>` | обьект | — | Переопределение для группы |

Для каждой команды проверяются **все** применимые ключи; превышение любого даёт `RATE_LIMIT` с
указанием области и времени до повторной попытки. При включённом Redis лимиты становятся
распределёнными (общими для всех экземпляров шлюза).

### 2.6. Очередь, retry, heartbeat

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `queue.enabled` | bool | `true` | Очередь на сервер (FIFO внутри сервера) |
| `queue.max_size` | int > 0 | `1000` | Максимум команд в очереди сервера; переполнение ⇒ `QUEUE_FULL` |
| `queue.timeout_seconds` | duration | `30` (сек) | Ожидание результата от сервера |
| `queue.on_disconnect` | `cancel` \| `hold` \| `retry` | `cancel` | Поведение при потере соединения с плагином |
| `queue.hold_timeout` | duration | `5m` | Через сколько `hold`-команды снимаются с удержания |
| `retry.enabled` | bool | `true` | Повторы разрешены |
| `retry.max_attempts` | int ≥ 1 | `3` | Максимум попыток |
| `retry.delay_ms` | int (мс) | `1000` | Пауза между попытками |
| `heartbeat.interval_seconds` | duration | `10` (сек) | Ожидаемый интервал heartbeat |
| `heartbeat.timeout_seconds` | duration | `30` (сек) | Молчание больше этого значения ⇒ `DEGRADED`, больше двух интервалов ⇒ `OFFLINE` |

Повтор выполняется **только** для ошибок, при которых команда гарантированно не была принята
плагином (нет подтверждения `COMMAND_ACCEPTED`). Команда, которую сервер принял, не повторяется
никогда — это исключает двойное выполнение опасных команд.

### 2.7. Массовое выполнение, ответы, подтверждения

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `broadcast.execution` | `parallel` \| `sequential` | `parallel` | Параллельно или по очереди по серверам |
| `broadcast.failure_policy` | `continue` \| `stop` | `continue` | Продолжать при сбое одного сервера или остановить рассылку |
| `broadcast.response_mode` | `per_server` \| `summary` \| `combined` | `per_server` | Формат ответа в Discord |
| `responses.max_message_length` | int | `1900` | Максимальная длина одного сообщения |
| `responses.large_output.mode` | `split` \| `attachment` | `split` | Как отдавать большой вывод |
| `responses.large_output.attachment_threshold` | int | `10000` | Порог переключения на вложение (символы) |
| `confirmation.enabled` | bool | `true` | Требовать подтверждение опасных команд |
| `confirmation.timeout_seconds` | duration | `30` (сек) | TTL подтверждения; подтверждает только инициатор |

### 2.8. База данных и retention

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `database.type` | `sqlite` \| `postgresql` | `sqlite` | Драйвер хранилища |
| `database.sqlite.file` | path | `data/dmc.db` | Путь относительно каталога конфигурации |
| `database.postgresql.host` | string | `localhost` | Хост PostgreSQL |
| `database.postgresql.port` | int | `5432` | Порт |
| `database.postgresql.database` | string | `dmc` | База |
| `database.postgresql.username` | string | `dmc` | Пользователь |
| `database.postgresql.password` | secret | — | Пароль (только из окружения) |
| `database.postgresql.pool_size` | int | `10` | Размер пула HikariCP |
| `database.retention.enabled` | bool | `true` | Включить очистку |
| `database.retention.days` | int | `90` | Срок хранения `audit_log` |
| `database.retention.security_days` | int | `365` | Срок хранения `security_audit`; `0` — не удалять |
| `database.retention.interval_hours` | int (часы) | `6` | Период прохода очистки (минимум 1 час) |

Миграции применяются автоматически при старте (`db/migration/{sqlite,postgres}/V1__init.sql`),
версии фиксируются в таблице `schema_migrations`. `security_audit` никогда не очищается через
команды Discord — только retention-политикой.

### 2.9. Redis и метрики

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `redis.enabled` | bool | `false` | Включает распределённый режим |
| `redis.uri` | string | `redis://127.0.0.1:6379` | URI подключения |
| `redis.password` | secret | — | Пароль |
| `redis.key_prefix` | string | `dmc:` | Префикс каналов `route:*` и `result:*` |
| `redis.timeout` | duration | `2` (сек) | Таймаут операций |
| `metrics.enabled` | bool | `true` | Поднять HTTP-эндпоинт |
| `metrics.host` | string | `127.0.0.1` | Адрес привязки (в контейнере — `0.0.0.0`) |
| `metrics.port` | int | `9100` | Порт |
| `metrics.path` | string | `/metrics` | Путь Prometheus-эндпоинта |
| `metrics.expose_internals` | bool | `false` | Зарезервировано: разбирается, но текущая сборка выводит все метрики независимо от значения |

Эндпоинты: `metrics.path` (Prometheus text), `/health`, `/health/live`, `/health/ready`
(JSON, `503` при недоступности).

### 2.10. Логирование

| Ключ | Тип | По умолчанию |
|---|---|---|
| `logging.commands` | bool | `true` |
| `logging.successful_commands` | bool | `true` |
| `logging.failed_commands` | bool | `true` |
| `logging.denied_commands` | bool | `true` |
| `logging.security_events` | bool | `true` |
| `logging.authentication` | bool | `true` |
| `logging.connections` | bool | `true` |
| `logging.errors` | bool | `true` |
| `logging.debug` | bool | `false` |
| `logging.format` | `json` \| `text` | `json` |

Каталог и уровень логов задаются переменными окружения `DMC_LOG_DIR` и `DMC_LOG_LEVEL`
(их читает `logback.xml` шлюза): файл `logs/gateway.log` с ротацией 32 МБ, 30 файлов, лимит 2 ГБ.
Каждое событие содержит `request_id` — correlation id проходит через бота, шлюз, плагин, аудит и
ответ в Discord.

### 2.11. Сеть и TLS

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `network.host` | string | `127.0.0.1` | Адрес прослушивания шлюза |
| `network.port` | int | `8443` | Порт протокола |
| `network.max_frame_bytes` | int | `1048576` | Максимальный размер кадра (защита от oversized payload) |
| `network.idle_timeout` | duration | `120` (сек) | Закрытие простаивающего соединения |
| `network.connect_timeout` | duration | `10` (сек) | Таймаут подключения (клиентская сторона) |
| `network.handshake_timeout` | duration | `15` (сек) | Таймаут handshake |
| `network.shutdown_grace` | duration | `10` (сек) | Время корректного закрытия |
| `network.worker_threads` | int | `0` (= max(2, CPU)) | Потоки Netty |
| `network.allowed_ips` | list | `[]` (проверка выключена) | IP и CIDR, например `10.0.0.0/24`, `fd00::/8`, `*` |
| `network.reconnect.initial_delay` | duration | `1` (сек) | Начальная задержка переподключения |
| `network.reconnect.max_delay` | duration | `60` (сек) | Максимальная задержка |
| `network.reconnect.multiplier` | double | `2.0` | Множитель экспоненциального backoff |
| `tls.enabled` | bool | `true` | TLS для протокола |
| `tls.allow_insecure_transport` | bool | `false` | Требуется `true`, если TLS выключен: незашифрованный транспорт возможен только явным решением |
| `tls.keystore` | path | — | PKCS12/JKS с ключом (для шлюза — `gateway.p12`) |
| `tls.keystore_password` | secret | — | Пароль keystore |
| `tls.key_password` | secret | — | Пароль ключа (если отличается) |
| `tls.truststore` | path | — | Truststore с CA |
| `tls.truststore_password` | secret | — | Пароль truststore |
| `tls.certificate` / `tls.private_key` / `tls.ca_certificate` | path | — | Альтернатива keystore: PEM-файлы |
| `tls.require_client_certificate` | bool | `false` | `true` ⇒ сервер требует клиентский сертификат (`REQUIRE`), иначе `OPTIONAL` |
| `tls.protocols` | list | `["TLSv1.3", "TLSv1.2"]` | Разрешённые версии TLS |

### 2.12. Aliases, templates, видимость в Minecraft

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `aliases.<name>.command` | string | — | Обязателен; шаблон с плейсхолдерами `{param}` |
| `aliases.<name>.permission` | string | `console.alias.<name>` | Право на использование alias |
| `aliases.<name>.parameters.<param>` | rule | `player`/`word` | Правило валидации: `player`, `word`, `integer`, `decimal`, `world`, `text`, `boolean` |
| `templates.<name>.command` | string | — | Обязателен |
| `templates.<name>.permission` | string | `console.template.<name>` | Право на использование template |
| `templates.<name>.parameters.<param>` | rule | `word` | Правило валидации |
| `minecraft.discord_console_visibility.enabled` | bool | `true` | Анонсировать команды Discord в Minecraft |
| `minecraft.discord_console_visibility.permission` | string | `discordconsole.monitor` | LuckPerms-право видимости |
| `minecraft.discord_console_visibility.format` | string | `&7[&9Discord&7] &f{user} &7executed &f{command}` | Формат анонса |
| `minecraft.discord_console_visibility.result_format` | string | `&7[&9Discord&7] &7result: &f{result}` | Формат строки результата |
| `minecraft.visibility.mode` | `default` \| `permission` | `default` | `permission` — показывать только владельцам права |
| `minecraft.visibility.hidden_commands` | list | `[]` | Команды, которые никогда не показываются игрокам |
| `minecraft.visibility.default` | bool | — | Из спецификации; текущая сборка не читает этот ключ — используйте `mode` |

Плейсхолдеры форматов: `{user}`, `{command}`, `{result}`, `{server}`, `{status}`. Значения
параметров alias/template строго валидируются регулярными выражениями, а не «подчищаются»:
невалидное значение отклоняется с `INVALID_COMMAND`.

---

## 3. Конфигурация Discord-бота (`config/bot.yml`)

Бот не является источником правды по правам: ACL, политика и лимиты живут в конфигурации шлюза.
Раздел `permissions` этого файла нужен боту, чтобы отрисовывать ровно то, что разрешит шлюз;
шлюз всё равно перепроверяет каждое решение.

### 3.1. Локализация и Discord

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `language` | `ru` \| `en` | `ru` | Локаль сообщений из `lang/<locale>.yml` |
| `language_directory` | path | `lang` | Каталог внешних языковых файлов (относительно каталога конфигурации) |
| `discord.token` | secret | — | **Обязателен**. Токен бота (только из окружения) |
| `discord.guilds` | list | `[]` | Пусто = все гильдии; иначе взаимодействия из других гильдий игнорируются |
| `discord.register_guild_commands` | bool | `true` | Регистрировать команды в гильдиях (команды регистрируются в гильдии только если она перечислена в `guilds`) |
| `discord.activity` | string | `Minecraft Console` | Текст активности бота |
| `discord.status` | `ONLINE` \| `IDLE` \| `DND` \| `INVISIBLE` | `ONLINE` | Статус бота |
| `discord.ready_timeout` | duration | `60` (сек) | Сколько ждать события готовности Discord при старте. Отказ входа (`FAILED_TO_LOGIN`) или истечение срока останавливают процесс с понятной ошибкой |

Бот записывает `bot.yml` и `lang/{en,ru}.yml` при первом старте и никогда не перезаписывает их. Если каталог
конфигурации недоступен для записи (например, смонтирован в контейнер только для чтения), бот продолжает
работать на языковых файлах, встроенных в jar, и пишет об этом предупреждение.

### 3.2. Каналы, права, гильдии

| Ключ | Тип | Описание |
|---|---|---|
| `channels.allowed` / `channels.denied` | list | Глобальные ограничения каналов |
| `guilds.<guildId>.channels.allowed` / `.denied` | list | Ограничения каналов гильдии. Непустой `allowed` гильдии **заменяет** глобальный список |
| `permissions.roles.<roleId>.allow` / `.deny` | list | Глобальные права ролей |
| `permissions.users.<userId>.allow` / `.deny` | list | Персональные права |
| `guilds.<guildId>.permissions.roles/users.<id>.allow/deny` | list | Права внутри гильдии |

`deny` побеждает `allow`; узлы и wildcard — как в `docs/PERMISSIONS.md`.

### 3.3. Подключение к шлюзу

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `control.client_id` | string | — | **Обязателен**; должен совпадать с ключом `control.clients.<id>` шлюза |
| `control.secret` | secret | — | **Обязателен**; секрет управляющего клиента |
| `control.request_timeout` | duration | `30` (сек) | Таймаут ожидания ответа шлюза |
| `control.handshake_timeout` | duration | `15` (сек) | Таймаут handshake |
| `control.ready_timeout` | duration | `20` (сек) | Ожидание готовности шлюза при старте |
| `control.reconnect_grace` | duration | `5` (сек) | Окно переподключения, в течение которого пользователю не показывается ошибка |
| `network.*` | — | как у шлюза | Адрес, порт, таймауты, `reconnect.*`, `worker_threads`, `max_frame_bytes` |
| `tls.*` | — | как у шлюза | Keystore (клиентский сертификат бота) и общий truststore |

### 3.4. Команды, ответы, интерфейс

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `security.max_command_length` | int | `512` | Максимальная длина команды |
| `security.blocked_sequences` | list | как у шлюза | Запрещённые последовательности |
| `command_policies` | list/map | `[]` | Правила политики (та же модель, что на шлюзе) |
| `aliases.<name>.command` / `.permission` / `.parameters` | — | — | Безопасные псевдонимы с валидацией параметров |
| `templates.<name>.command` / `.permission` / `.parameters` | — | — | Шаблоны команд с валидацией параметров |
| `responses.max_message_length` | int (200..2000) | `1900` | Максимальная длина сообщения |
| `responses.large_output.mode` | `split` \| `attachment` | `split` | Режим больших выводов |
| `responses.large_output.attachment_threshold` | int (≥ 100) | `10000` | Порог перехода на вложение |
| `responses.large_output.max_messages` | int (1..50) | `8` | Сколько сообщений можно разослать при `split` |
| `responses.embed_description_limit` | int (200..4096) | `3900` | Лимит описания embed |
| `confirmation.enabled` | bool | `true` | Подтверждение опасных команд |
| `confirmation.timeout_seconds` | duration | `30` (сек) | TTL подтверждения |
| `confirmation.max_pending` | int | `500` | Максимум ожидающих подтверждений |
| `ui.ephemeral` | bool | `true` | Ответы видны только автору |
| `ui.show_request_id` | bool | `false` | Показывать correlation id в ответах (включите только для отладки) |
| `ui.show_diagnostics` | bool | `false` | Показывать в embeds технические поля: длительность, ревизию конфигурации, режим, шлюз, аптайм, подробности ошибки и проверки dry-run |
| `ui.autocomplete_limit` | int (1..25) | `25` | Лимит подсказок автодополнения |
| `ui.history_page_size` | int (1..25) | `5` | Размер страницы истории |
| `ui.history_max_limit` | int (pageSize..100) | `25` | Максимум записей истории за запрос |
| `ui.panel_timeout_seconds` | duration | `10m` | Время жизни панели консоли |
| `ui.view_cache_seconds` | duration | `15` (сек) | Время жизни кэша представления целей (серверы и группы), которое бот получает у шлюза для автодополнения и панелей |
| `embeds.footer` | string | `Discord Minecraft Console · Zigono` | Футер всех embeds |
| `embeds.timestamp` | bool | `true` | Добавлять отметку времени |
| `embeds.color.<info\|success\|warning\|error\|audit\|neutral>` | hex RGB | `#5865F2`, `#57F287`, `#FEE75F`, `#ED4245`, `#EB459E`, `#99AAB5` | Палитра embeds |

### 3.5. Логи и аудит в Discord

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `logging.discord.enabled` | bool | `true` | Включить audit channel (требует непустой `channel_id`) |
| `logging.discord.channel_id` | string | — | Стартовый канал аудита: пользователь, цель, команда, статус, длительность, `request_id` |
| `logging.discord.include_output` | bool | `false` | Прикладывать вывод команды к записи аудита |
| `logging.discord.include_roles` | bool | `false` | Прикладывать роли пользователя |

Канал аудита выбирается прямо в Discord командой `/logs channel` (право `console.logs`): выбор
запоминается в `logs-channel.yml` рядом с `bot.yml` и переживает перезапуск, а `channel_id`
служит значением по умолчанию. Повторная команда в том же канале выключает журнал, в другом —
переносит его.

---

## 4. Конфигурация плагина (`plugins/DiscordMinecraftConsole/config.yml`)

### 4.1. Встроенный режим (`embedded`)

Режим по умолчанию в поставляемом `config.yml`: шлюз и Discord-бот работают внутри процесса
Minecraft-сервера, поэтому на панельном хостинге не нужно ничего, кроме jar плагина
(см. `docs/INSTALLATION.md` §2). Связь плагина, шлюза и бота идёт по loopback внутри машины,
наружу дополнительные порты не открываются.

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `embedded.enabled` | bool | `false` (в поставляемом `config.yml` — `true`) | Запускать шлюз и Discord-бота внутри плагина |
| `embedded.directory` | string | `embedded` | Каталог сгенерированных файлов внутри `plugins/DiscordMinecraftConsole/` |
| `embedded.gateway_id` | string | `dmc-embedded` | Id шлюза в логах и в `/discordconsole status` |
| `embedded.control_client_id` | string | `discord-console` | Id control-клиента (бота) в сгенерированной конфигурации шлюза |
| `embedded.discord.token` | string | `""` | Токен бота. Пусто или нерешённый плейсхолдер — бот не стартует, сервер работает дальше |
| `embedded.discord.guilds` | string или list | `""` | Идентификаторы гильдий: `"111, 222"` или список. Пусто — бот работает в любой гильдии, куда его пригласили |
| `embedded.discord.activity / status` | string | `Minecraft Console` / `ONLINE` | Активность и статус бота (`ONLINE`, `IDLE`, `DND`, `INVISIBLE`) |
| `embedded.discord.language` | string | язык плагина | Язык сообщений бота (`ru` или `en`) |
| `embedded.discord.audit_channel_id` | string | `""` | Канал аудита в Discord (кто что выполнил). Пусто — аудит только в базе, логах и в игре |
| `embedded.discord.channels.allowed / denied` | string или list | `""` | Каналы, где команды разрешены / запрещены: `"333, 444"` или список (deny всегда важнее) |
| `embedded.permissions` | map | `{}` | ACL: секции `roles` и `users`. Права пишутся строкой без скобок (`123: console.*`), несколько прав — через запятую; полная форма с `allow:`/`deny:` нужна только для запретов. Маски как у шлюза (§2.3) |
| `embedded.network.host / port` | string / int | `127.0.0.1` / `0` | Адрес и порт, на которых встроенный шлюз принимает другие серверы сети. Значения по умолчанию означают «только этот же процесс»; для сети указывайте доступный серверам адрес и постоянный порт (например `0.0.0.0` и `8443`) |
| `embedded.gateway_overrides` | map | `{}` | Правки сгенерированного `embedded/gateway.yml`; карты сливаются по ключам |
| `embedded.bot_overrides` | map | `{}` | Правки сгенерированного `embedded/bot.yml` (например `aliases`, `templates`, `responses`) |

Помимо секции `embedded` в том же `config.yml` объявляется сама сеть серверов — отдельные файлы для
неё не нужны:

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `mode` | `single` \| `multi` | авто | Режим шлюза. Если строку убрать, режим определяется по числу включённых серверов |
| `servers.<id>.name / description` | string | id / — | Имя и описание сервера в Discord |
| `servers.<id>.aliases` | string или list | `[]` | Псевдонимы для `/console`, например `smp, world` |
| `servers.<id>.enabled` | bool | `true` | Выключенный сервер остаётся в файле, но не принимает команды |
| `servers.<id>.secret` | secret | генерируется | Секрет сервера. Пусто — плагин создаёт `embedded/server-<id>.secret` и подсказывает значение для `security.server_secret` этого сервера |
| `groups.<имя>` | string или map | — | Именованный набор серверов: `all: "main, lobby"` или раздел с ключом `servers`. Используется опцией `group` у `/console` |

Сервер, внутри которого работает плагин, всегда присутствует в каталоге: его id, имя и описание берутся
из раздела `server`, а запись `servers.<его id>` только дополняет их (псевдонимы, включение, секрет).
Ошибки в каталоге (неизвестный сервер в группе, повторяющийся псевдоним, неверный `mode`) видны сразу
при запуске: каталог проверяется тем же кодом, который потом читает сгенерированный `gateway.yml`.

Пример целиком — `config/plugin-embedded.example.yml`.

Поставляемый `config.yml` уже заполнен рабочими значениями (токен бота, гильдия, канал, роль с полным
доступом) и не требует правок, кроме тех строк, которые описывают ваш Discord. Комментарии в файле —
на русском, язык сообщений — `ru`. Если файл перестанет быть корректным YAML, плагин сохранит его как
`config.yml.broken-<дата-время>` и запустится на стандартных значениях (см. `docs/INSTALLATION.md` §2.3).

Что делает плагин при старте в этом режиме:

1. читает `config.yml`, при необходимости создаёт `embedded/server.secret` и `embedded/control.secret`;
2. генерирует `embedded/gateway.yml` (каталог `servers` и `groups`, режим `mode`, адрес из
   `embedded.network`, TLS выключен, SQLite, метрики и Redis выключены, а также политика команд — список
   опасных команд всегда, остальные ключи `security.*` только если вы их задали) и `embedded/bot.yml`
   (токен, гильдии, ACL, каналы, аудит — из `config.yml`);
3. поднимает шлюз на `embedded.network.host:port` (по умолчанию `127.0.0.1:0` — свободный порт выбирает
   система) и подключает к нему плагин;
4. запускает Discord-бота в отдельном потоке, чтобы не блокировать главный поток сервера.

Файлы `gateway.yml` и `bot.yml` пересобираются из `config.yml` при каждом старте: правки в них
живут до следующего запуска. Всё, чего нет в `config.yml`, добавляйте через `embedded.gateway_overrides`
или `embedded.bot_overrides`.

Ограничения режима: метрик-эндпоинт не поднимается (состояние показывает `/discordconsole status`),
Redis недоступен. Сеть из нескольких серверов поддержана: перечислите их в `servers`/`groups` одного
`config.yml` и задайте `embedded.network` так, чтобы эти серверы могли подключиться к встроенному шлюзу
(общий открытый порт панели). Если общая база аудита и внешний шлюз удобнее — используйте
`embedded.enabled: false`.

### 4.2. Идентичность, нормализация, политика

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `language` | `ru` \| `en` | `en` | Язык сообщений плагина (`plugins/DiscordMinecraftConsole/lang/`) |
| `server.id` | string | — | **Обязателен**; должен совпадать с `servers.<id>` (или alias) шлюза |
| `server.name` | string | `id` | Отображаемое имя |
| `server.description` | string | `""` | Описание сервера |
| `security.server_secret` | secret | — | Обязателен для внешнего шлюза: должен совпадать с `servers.<id>.secret`. Во встроенном режиме (`embedded.enabled: true`) можно оставить пустым — секрет сгенерируется в `embedded/server.secret` |
| `security.max_command_length` | int | `512` | Максимальная длина команды |
| `security.blocked_sequences` | list | как у шлюза | Запрещённые последовательности |
| `security.blocked_commands` | list | `[]` | Безусловный запрет |
| `security.allowed_commands` | list | `[]` | Непустой список = whitelist |
| `security.dangerous_commands` | list | список опасных ванильных команд | Требуют подтверждения в Discord |
| `command_policies` | list/map | `[]` | Дополнительные правила политики |

Внешние языковые файлы — необязательное переопределение: при их отсутствии используются встроенные в jar
(`plugin-lang/*.yml` и общий каталог `lang/*.yml`).

### 4.3. Сеть и TLS

Секции `network` и `tls` описывают подключение к **внешнему** шлюзу. Во встроенном режиме они не
используются: плагин подключается к шлюзу своего же процесса по `127.0.0.1` со свободным портом, а TLS для
трафика, который не покидает машину, не нужен.

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `network.host` | string | `127.0.0.1` | Адрес шлюза |
| `network.port` | int | `8443` | Порт шлюза |
| `network.max_frame_bytes` | int | `1048576` | Максимальный размер кадра |
| `network.connect_timeout` / `handshake_timeout` / `idle_timeout` / `shutdown_grace` | duration | `10s` / `15s` / `120s` / `10s` | Таймауты |
| `network.reconnect.initial_delay` / `max_delay` / `multiplier` | duration / double | `1s` / `60s` / `2.0` | Параметры переподключения |
| `network.worker_threads` | int | `0` (= max(2, CPU)) | Потоки Netty |
| `tls.enabled` / `tls.allow_insecure_transport` | bool | `true` / `false` | TLS; отключение требует явного согласия |
| `tls.keystore` | path | `tls/client.p12` | Клиентский сертификат сервера (относительно каталога плагина) |
| `tls.keystore_password` / `tls.key_password` | secret | — | Пароли keystore и ключа |
| `tls.truststore` / `tls.truststore_password` | path / secret | `tls/truststore.p12` / — | Доверие к CA шлюза |
| `tls.certificate` / `tls.private_key` / `tls.ca_certificate` | path | `""` | Альтернатива keystore: PEM-файлы |
| `tls.require_client_certificate` | bool | `false` | (со стороны шлюза) требовать клиентский сертификат |
| `tls.protocols` | list | `["TLSv1.3", "TLSv1.2"]` | Разрешённые версии TLS |

### 4.4. Heartbeat, выполнение, захват вывода

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `heartbeat.interval_seconds` | duration | `10` (сек) | Период heartbeat |
| `heartbeat.timeout_seconds` | duration | `30` (сек) | Таймаут на стороне шлюза |
| `heartbeat.degraded_latency_ms` | double (мс) | `2500` | RTT, выше которого плагин сообщает `DEGRADED` |
| `execution.max_concurrent` | int ≥ 1 | `1` | Одновременных выполнений (держите `1` для точного захвата вывода) |
| `execution.queue_size` | int ≥ 1 | `64` | FIFO-очередь плагина; сверх лимита — отказ |
| `execution.queue_timeout_ms` | long (мс) | `5000` | Ожидание свободного слота выполнения |
| `execution.default_timeout_ms` | long (мс) | `30000` | Таймаут, если шлюз не прислал свой |
| `execution.poll_interval_ticks` | int | `1` | Период опроса сборщика вывода в тиках |
| `capture.enabled` | bool | `true` | Захват реального вывода консоли |
| `capture.quiet_period_ms` | long (мс) ≥ 0 | `250` | Тишина, после которой сбор вывода прекращается |
| `capture.max_wait_ms` | long (мс) > 0 | `10000` | Жёсткая остановка сбора |
| `capture.max_lines` | int | `200` | Максимум строк |
| `capture.max_chars` | int | `60000` | Максимум символов |
| `capture.max_line_length` | int | `2048` | Максимум символов в строке |

### 4.5. Видимость в игре и LuckPerms

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `minecraft.discord_console_visibility.enabled` | bool | `true` | Анонсировать активность Discord Console |
| `minecraft.discord_console_visibility.permission` | string | `discordconsole.monitor` | Право, используемое режимом `permission` |
| `minecraft.discord_console_visibility.format` | string | `&7[&9Discord&7] &f{user} &7executed: &f{command}` | Формат анонса (`&`-коды и MiniMessage) |
| `minecraft.visibility.mode` | `default` \| `permission` \| `nobody` | `default` | Кто видит анонсы в игре |
| `minecraft.visibility.default` | bool | `true` | `true` — видят все игроки (при `mode: default`) |
| `minecraft.visibility.hidden_commands` | list | `[login, token, password, auth, 2fa]` | Команды, никогда не показываемые в игре и в консоли |
| `minecraft.visibility.show_results` | bool | `true` | Показывать результат выполнения |
| `minecraft.visibility.result_format` | string | `&7[&9Discord&7] &7result: &f{result}` | Формат строки результата |
| `minecraft.visibility.server_format` | string | `&7[&9Discord&7] &7server: &f{server}` | Формат строки сервера |
| `minecraft.visibility.hidden_server_label` | string | `***` | Что показывать вместо имени сервера игрокам без права |
| `luckperms.enabled` | bool | `true` | Использовать LuckPerms API |
| `luckperms.monitor_permission` | string | `discordconsole.monitor` | Базовое право видимости |
| `luckperms.commands_permission` | string | `""` | Уточнение: видеть текст команды (пусто = отключено) |
| `luckperms.results_permission` | string | `""` | Уточнение: видеть результат (пусто = отключено) |
| `luckperms.servers_permission` | string | `""` | Уточнение: видеть имя сервера (пусто = отключено) |
| `luckperms.admin_permission` | string | `discordconsole.monitor.admin` | Обходит режим видимости (скрытые команды остаются скрытыми) |

Плейсхолдеры форматов: `{user}`, `{command}`, `{server}`, `{target}`, `{result}`, `{status}`,
`{duration}`.

### 4.6. Метрики и логи

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `metrics.enabled` | bool | `true` | Сбор метрик плагина |
| `metrics.log_interval_seconds` | duration | `300` (сек) | Периодичность агрегированной строки метрик в логе сервера |
| `logging.debug` | bool | `false` | Подробные логи плагина |
| `logging.command_echo` | bool | `true` | Писать «кто выполнил что» в консоль сервера |

Команды плагина (требуют `discordconsole.admin`, по умолчанию `op`):

```text
/discordconsole status        # состояние подключения, ревизия конфигурации
/discordconsole reload        # перечитать config.yml без перезапуска сервера
# aliases: /dmc, /dconsole
```

### 4.7. Персонал: выдача и снятие привилегий

Раздел `staff` добавляет в Discord две команды, которые меняют группы LuckPerms:

```text
/персонал-выдать ник:<ник> привилегия:<ключ> причина:<текст>
/персонал-снять  ник:<ник> привилегия:<ключ> причина:<текст>
```

| Ключ | Тип | По умолчанию | Описание |
|---|---|---|---|
| `staff.enabled` | bool | `true` | Включить команды персонала (нужен LuckPerms) |
| `staff.mode` | `add` \| `set` | `add` | `add` — привилегия добавляется к текущим группам; `set` — у игрока остаётся ровно эта привилегия |
| `staff.default_group` | string | `default` | Куда вернуть игрока, если в режиме `set` сняли его основную группу |
| `staff.commands.grant` | string | `персонал-выдать` | Имя слэш-команды выдачи |
| `staff.commands.remove` | string | `персонал-снять` | Имя слэш-команды снятия |
| `staff.ranks.<key>.name` | string | ключ | Подпись привилегии в Discord |
| `staff.ranks.<key>.group` | string | ключ | Группа LuckPerms |
| `staff.ranks.<key>.emoji` | string | — | Значок в списке привилегий |
| `staff.access.<roleId>` | строка или список | — | Какие привилегии выдаёт и снимает эта роль Discord; `*` — все настроенные |

Имена команд Discord допускают строчные буквы, цифры, дефис, подчёркивание (кириллица разрешена).
Пробелы и заглавные буквы Discord не принимает: если в конфиге такое имя, плагин подставит
`staff-grant` / `staff-remove` и напишет предупреждение в лог.

Права роли — одна строка на роль, без квадратных скобок:

```yaml
staff:
  access:
    111111111111111111: "helper, moderator, sr_moderator"
    222222222222222222: "helper, moderator, sr_moderator, administrator, sr_administrator"
    333333333333333333: "*"
```

Пример иерархии целиком — в комментарии перед разделом `staff` в `config.yml`. Группы обязаны
существовать в LuckPerms (`/lp creategroup helper`): если группы нет или игрок неизвестен
LuckPerms, бот ответит понятной причиной и ничего не изменит.

Канал журнала выдачи выбирается командой `/logs channel` (право `console.logs`) и запоминается в
`plugins/DiscordMinecraftConsole/logs-channel.yml`.

---
## 5. Горячая перезагрузка

- **Шлюз** следит за файлом конфигурации (проверка каждые 2 секунды) и применяет изменения без
  разрыва соединений: ACL, политики, серверы, группы, rate limit, security, logging, UI-настройки.
  Активные команды не прерываются. Изменения `network.*` и `tls.*` требуют перезапуска — шлюз
  пишет об этом предупреждение и оставляет старые значения.
- **Плагин** перечитывает `config.yml` командой перезагрузки Paper (`/reload confirm` или
  рестарт сервера); при изменении `network.*`/`tls.*` требуется перезапуск Minecraft-сервера.
- **Бот** перечитывает `bot.yml` и языковые файлы, как только меняется отпечаток файла (проверка каждые
  2 секунды): применяются локализация, права-фильтр, ответы, embeds и UI. Изменения `network.*`/`tls.*`
  переподключают управляющий канал к шлюзу, уже выполняющиеся команды не прерываются.
- **Встроенный режим**: при перезагрузке плагина `embedded/gateway.yml` и `embedded/bot.yml`
  пересобираются из `config.yml` и подхватываются штатными наблюдателями конфигурации (шлюз — за 2 секунды,
  бот — тоже), поэтому ACL, каналы и канал аудита применяются без перезапуска сервера. Смена
  `security.server_secret` требует перезапуска: запущенный слушатель работает с теми ключами, с которыми
  был поднят.
- Права и политики можно перезагрузить удалённо: запрос `RELOAD_REQUEST` от пользователя с правом
  `console.admin.reload`; ответ содержит новую ревизию конфигурации и список обновлённых разделов.