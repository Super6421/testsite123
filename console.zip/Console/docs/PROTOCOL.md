# Протокол

Автор: **Zigono** · версия протокола **1** (поддерживается 1..1)

Протокол реализован в модуле `dmc-protocol` и используется двумя видами клиентов:

- **control-клиент** — Discord-бот (роль `control`), запрашивает цели, статусы, историю, выполняет команды;
- **plugin-клиент** — плагин Paper (роль `plugin`) на каждом Minecraft-сервере, получает команды и
  отправляет heartbeat и реальные результаты выполнения.

---

## 1. Транспорт и кадрирование

| Уровень | Описание |
|---|---|
| TCP | соединение устанавливает клиент; шлюз слушает `network.host:network.port` |
| TLS | обязателен по умолчанию; TLS 1.3/1.2; аутентификация клиента по сертификату (`OPTIONAL`/`REQUIRE`); клиент проверяет имя хоста и цепочку CA |
| Кадрирование | 4-байтовый префикс длины (big-endian) + полезная нагрузка. Ограничение размера кадра — `network.max_frame_bytes` (по умолчанию 1048576) |
| Полезная нагрузка | компактный JSON (UTF-8) одного сообщения |
| Idle | соединение закрывается после `network.idle_timeout` без трафика (по умолчанию 120 секунд) |
| Порядок | сообщения обрабатываются в порядке получения; каждое сообщение подписывается отдельно |

Во **встроенном режиме** плагина (`embedded.enabled: true`) тот же протокол работает внутри одного
процесса: шлюз слушает `127.0.0.1:0` (свободный порт выбирает система), плагин и Discord-бот
подключаются к нему как обычные клиенты. TLS в этом случае выключен (`tls.enabled: false` вместе с
явным `allow_insecure_transport: true` в сгенерированной конфигурации), потому что трафик не покидает
машину; подпись сообщений, replay-защита, handshake и ACL работают ровно так же, как при внешнем шлюзе.
`network.port: 0` означает «занять любой свободный порт» и предназначен именно для этого режима.

Схема кадра:

```text
+----------------+--------------------------------------------+
| length: uint32 | JSON сообщения (длина = length байт)       |
+----------------+--------------------------------------------+
```

---

## 2. Envelope сообщения

Каждое сообщение (включая ответы) несёт конверт:

| Поле | Тип | Назначение |
|---|---|---|
| `type` | string | Тип сообщения (проводное имя, см. таблицу ниже). Добавляется Jackson по типу класса |
| `protocolVersion` | int | Версия протокола отправителя. Проверяется на приёмнике |
| `requestId` | string | Уникальный идентификатор запроса (ULID). Используется для корреляции ответа, аудита и replay-защиты |
| `clientId` | string | Идентичность отправителя (`discord-bot`, `survival`, …). Соединение жёстко привязывается к ней |
| `timestamp` | long | Время отправки, epoch millis |
| `nonce` | string | Случайный одноразовый идентификатор (защита от replay) |
| `signature` | string | HMAC-SHA256 в hex по канонической форме сообщения |
| `reply` | bool | `true` — это ответ на более ранний запрос, а не начало нового обмена. Входит в подпись |

Правила:

- при отправке кодек сам подставляет `requestId` (ULID), `timestamp` и `nonce`, если они пусты;
- ответ обязан нести тот же `requestId`, что и запрос (`Message.correlate`), иначе клиент его не
  сопоставит и запрос завершится по таймауту;
- ответ дополнительно помечается флагом `reply: true` (`Message.correlate`); флаг едет **внутри подписанного
  конверта**, поэтому replay-защита отличает настоящий ответ на запрос от попытки повторно использовать
  чужой `requestId`. Подделать флаг нельзя: любое изменение `reply` ломает подпись;
- `clientId` в ответе — идентичность отвечающей стороны; соединение не может отправлять сообщения
  от чужого имени (`identity mismatch` закрывает соединение).

---

## 3. Подпись

### 3.1. Каноническая форма

```text
canonical = compact JSON сообщения БЕЗ поля "signature"
signature = hex( HMAC-SHA256( secret, UTF-8(canonical) ) )
```

Подпись покрывает `type`, `protocolVersion`, `requestId`, `clientId`, `timestamp`, `nonce`, флаг `reply`
и все поля payload, поэтому изменение любого из них делает подпись недействительной.

### 3.2. Проверка

| Проверка | Результат при нарушении |
|---|---|
| JSON разбирается | `PROTOCOL_ERROR` (`malformed message`), соединение закрывается |
| `protocolVersion` совместим | `PROTOCOL_ERROR` (`unsupported protocol version`) |
| `clientId` присутствует | `AUTHENTICATION_FAILED` (`message without sender identity`) |
| `clientId` известен (`servers.<id>` или `control.clients.<id>`), совпадает с привязанной идентичностью соединения | `AUTHENTICATION_FAILED` (`unknown client id` / `identity mismatch`) |
| Подпись корректна (constant-time сравнение) | `AUTHENTICATION_FAILED` (`invalid signature`), метрика `dmc_authentication_failures` |
| `timestamp` в пределах окна; `nonce` не повторяется; `requestId` не повторяется, если сообщение не является ответом (`reply: false`) | `AUTHENTICATION_FAILED` (`replayed request id` / `replayed nonce` / `message timestamp outside the accepted window`), метрика `dmc_replay_rejections` |

Все нарушения регистрируются в `security_audit` с severity `CRITICAL`, после чего соединение
закрывается.

### 3.3. Replay-защита

| Параметр | Значение |
|---|---|
| Окно допустимого расхождения времени | **120 секунд** |
| Ёмкость таблицы запомненных идентификаторов | 200 000 записей на соединение/сторону, устаревшие вычищаются |
| Что запоминается | `clientId + nonce` — всегда; `clientId + requestId` — только для сообщений с `reply: false`. Ответы (`reply: true`) переиспользуют `requestId` запроса законно, поэтому для них проверяется только свежесть `nonce` |
| Часы | должны быть синхронизированы (NTP); расхождение больше 120 секунд ломает обмен |

---

## 4. Handshake и аутентификация

```text
Plugin / Bot                                        Gateway
     │                                                  │
     │  TCP + TLS (взаимная проверка сертификатов)      │
     │─────────────────────────────────────────────────▶│  IP allowlist
     │                                                  │
     │  HELLO { role, agentName, agentVersion,          │
     │          platform, serverId, capabilities }      │
     │─────────────────────────────────────────────────▶│  роль по clientId,
     │                                                  │  проверка serverId
     │  HELLO_ACK { gatewayId, gatewayVersion,          │
     │    min/maxSupportedProtocolVersion,              │
     │    heartbeatIntervalSeconds, challenge,          │
     │    configRevision, emergencyMode, serverTime }   │
     │◀─────────────────────────────────────────────────│
     │                                                  │
     │  AUTH { role, serverId, challenge, agentVersion } │
     │─────────────────────────────────────────────────▶│  сверка challenge,
     │                                                  │  секрет по clientId
     │  AUTH_RESULT { authenticated, sessionId,         │
     │    serverId, gatewayId, configRevision,          │
     │    heartbeatIntervalSeconds, message,            │
     │    errorCode, errorDetail, serverTime }          │
     │◀─────────────────────────────────────────────────│
     │                                                  │
     │  (plugin) HEARTBEAT / COMMAND_RESULT ...         │
     │  (bot)    TARGETS_REQUEST / EXECUTE_REQUEST ...  │
```

Требования handshake:

- до успешного `AUTH` никакие другие сообщения не обрабатываются (`CONNECTED` → `HELLO_RECEIVED`
  → `AUTHENTICATED`; при ошибке — `REJECTED` и закрытие соединения);
- роль должна соответствовать типу идентичности: сервер (`servers.<id>`) — только `plugin`,
  управляющий клиент — только `control`;
- плагин не может заявить чужой `serverId`;
- выключенный сервер (`enabled: false`) не проходит аутентификацию;
- после `AUTH` соединение привязывается к `clientId` (pinning);
- `challenge` — случайное значение из `HELLO_ACK`, проверяется на равенство; повторное использование
  challenge невозможно, потому что он генерируется на каждое соединение.

---

## 5. Выполнение команды

```text
Bot                                    Gateway                          Plugin
 │                                        │                                │
 │ EXECUTE_REQUEST { user, target,        │                                │
 │   command, normalizedCommand,          │                                │
 │   requiredPermission, dryRun,          │                                │
 │   confirmed, confirmationId,           │                                │
 │   issuedAt, timeoutMillis }            │                                │
 │───────────────────────────────────────▶│  контекст → права → цель →     │
 │                                        │  нормализация → политика →     │
 │                                        │  rate limit → подтверждение    │
 │                                        │  → очередь сервера             │
 │                                        │         COMMAND { serverId,    │
 │                                        │           command, issuer,     │
 │                                        │           visibility, attempt, │
 │                                        │           timeoutMillis }      │
 │                                        │───────────────────────────────▶│
 │                                        │         COMMAND_ACCEPTED {     │
 │                                        │           accepted, reason,    │
 │                                        │           acceptedAt,          │
 │                                        │           queuedMillis }       │
 │                                        │◀───────────────────────────────│
 │                                        │   → retry разрешён только если │
 │                                        │     accepted = false           │
 │                                        │         COMMAND_RESULT {       │
 │                                        │           outcome (реальный    │
 │                                        │           вывод консоли) }     │
 │                                        │◀───────────────────────────────│
 │ EXECUTE_RESPONSE { outcomes[],         │                                │
 │   durationMillis, targetDescription,   │                                │
 │   responseMode, errorCode,             │                                │
 │   confirmationId, confirmationExpiresAt,│                               │
 │   dryRun, dryRunSummary, dryRunChecks } │                               │
 │◀───────────────────────────────────────│                                │
```

Ключевые свойства:

- `COMMAND_ACCEPTED` — граница безопасности: команда, которую плагин подтвердил, никогда не
  повторяется автоматически (исключает двойное выполнение);
- при `dryRun: true` плагину ничего не отправляется: шлюз возвращает `outcomes` со статусом
  `DRY_RUN` и список выполненных проверок (`dryRunChecks`);
- при требовании подтверждения первый запрос возвращает `errorCode: CONFIRMATION_REQUIRED` и
  `confirmationId`; повторный запрос с тем же `confirmationId` и `confirmed: true` выполняется
  только тем же пользователем и до истечения `confirmationExpiresAt`;
- при рассылке в `outcomes` приходит по одному `ServerOutcome` на сервер
  (`broadcast.response_mode` влияет на формат отображения, не на состав данных).

---

## 6. Типы сообщений

### 6.1. Handshake и жизненный цикл

| Тип | Класс | Поля |
|---|---|---|
| `HELLO` | `HandshakeMessages.Hello` | `role`, `agentName`, `agentVersion`, `platform`, `serverId`, `capabilities[]` |
| `HELLO_ACK` | `HandshakeMessages.HelloAck` | `gatewayId`, `gatewayVersion`, `minSupportedProtocolVersion`, `maxSupportedProtocolVersion`, `heartbeatIntervalSeconds`, `challenge`, `configRevision`, `emergencyMode`, `serverTime` |
| `AUTH` | `HandshakeMessages.AuthRequest` | `role`, `serverId`, `challenge`, `agentVersion` |
| `AUTH_RESULT` | `HandshakeMessages.AuthResult` | `authenticated`, `errorCode`, `errorDetail`, `sessionId`, `serverId`, `gatewayId`, `configRevision`, `heartbeatIntervalSeconds`, `message`, `serverTime` |
| `PING` | `HandshakeMessages.Ping` | `sentAt`, `sequence` |
| `PONG` | `HandshakeMessages.Pong` | `sentAt`, `sequence`, `serverTime` |
| `SHUTDOWN` | `HandshakeMessages.ShutdownNotice` | `reason`, `graceSeconds`, `restarting` |
| `ERROR` | `HandshakeMessages.ErrorMessage` | `code`, `detail`, `arguments{}`, `fatal` |

### 6.2. Плагин → шлюз

| Тип | Класс | Поля |
|---|---|---|
| `HEARTBEAT` | `PluginMessages.Heartbeat` | `metrics` (`ServerMetrics`), `queuedCommands`, `lastCommandAt`, `status`, `sequence` |
| `COMMAND_ACCEPTED` | `PluginMessages.CommandAccepted` | `serverId`, `accepted`, `reason`, `acceptedAt`, `queuedMillis` |
| `COMMAND_RESULT` | `PluginMessages.CommandOutcomeMessage` | `serverId`, `command`, `outcome` (`ServerOutcome`) |

### 6.3. Шлюз → плагин

| Тип | Класс | Поля |
|---|---|---|
| `HEARTBEAT_ACK` | `PluginMessages.HeartbeatAck` | `heartbeatIntervalSeconds`, `serverTime`, `sequence` |
| `COMMAND` | `PluginMessages.CommandDispatch` | `serverId`, `command`, `targetDescription`, `issuer` (`UserContext`), `visibility` (`CommandVisibility`), `issuedAt`, `timeoutMillis`, `dryRun`, `attempt` |

### 6.4. Бот ↔ шлюз

| Тип | Класс | Поля |
|---|---|---|
| `TARGETS_REQUEST` / `TARGETS_RESPONSE` | `ControlMessages.TargetsRequest/Response` | запрос: `user`; ответ: `view` (`TargetsView`) |
| `CONFIG_SNAPSHOT_REQUEST` / `CONFIG_SNAPSHOT_RESPONSE` | `ControlMessages.ConfigSnapshotRequest/Response` | запрос: `user`; ответ: `policy` (`PolicySnapshot`) |
| `EXECUTE_REQUEST` / `EXECUTE_RESPONSE` | `ControlMessages.ExecuteRequest/Response` | запрос: `user`, `target`, `command`, `normalizedCommand`, `requiredPermission`, `dryRun`, `confirmed`, `confirmationId`, `issuedAt`, `timeoutMillis`; ответ: `targetDescription`, `command`, `dryRun`, `outcomes[]`, `durationMillis`, `errorCode`, `errorDetail`, `confirmationId`, `confirmationExpiresAt`, `responseMode`, `dryRunSummary`, `dryRunChecks[]` |
| `STATUS_REQUEST` / `STATUS_RESPONSE` | `ControlMessages.StatusRequest/Response` | запрос: `user`, `serverIds[]`; ответ: `servers[]` (`id`, `name`, `status`, `metrics`, `errorDetail`, `lastSeenMillis`), `gatewayId`, `configRevision`, `uptimeSeconds` |
| `HISTORY_REQUEST` / `HISTORY_RESPONSE` | `ControlMessages.HistoryRequest/Response` | запрос: `user`, `serverId`, `username`, `commandFragment`, `status`, `fromMillis`, `toMillis`, `limit`, `offset`; ответ: `entries[]` (`HistoryEntry`), `total`, `limit`, `offset` |
| `RELOAD_REQUEST` / `RELOAD_RESPONSE` | `ControlMessages.ReloadRequest/Response` | запрос: `user`; ответ: `reloaded`, `configRevision`, `reloadedSections[]`, `errorDetail` |
| `EMERGENCY_REQUEST` / `EMERGENCY_RESPONSE` | `ControlMessages.EmergencyRequest/Response` | запрос: `user`, `enabled`; ответ: `emergencyMode`, `errorDetail` |

### 6.5. Вложенные структуры

| Структура | Поля |
|---|---|
| `UserContext` | `userId`, `username`, `guildId`, `channelId`, `messageId`, `interactionId`, `roleIds[]`, `permissions[]`, `deniedPermissions[]` |
| `ServerMetrics` | `serverId`, `minecraftVersion`, `serverSoftware`, `pluginVersion`, `onlinePlayers`, `maxPlayers`, `tps`, `mspt`, `uptimeSeconds`, `usedMemoryBytes`, `maxMemoryBytes`, `cpuLoad`, `worldName`, `loadedChunks`, `collectedAt` |
| `ServerOutcome` | `serverId`, `status`, `output[]`, `durationMillis`, `errorCode`, `errorDetail`, `requestId`, `completedAt` |
| `HistoryEntry` | `requestId`, `userId`, `username`, `guildId`, `channelId`, `target`, `serverId`, `command`, `status`, `durationMillis`, `response`, `errorCode`, `dryRun`, `createdAt` |
| `TargetSelection` | `server`, `servers[]`, `group`, `all` |
| `CommandVisibility` | `showInConsole`, `showInGame`, `permission`, `format`, `resultFormat`, `announcement` |
| `TargetsView` | `singleServerMode`, `defaultServer`, `servers[]` (`id`, `name`, `status`, `enabled`), `groups[]` (`name`, `servers[]`), `capabilities` (`read`, `execute`, `dryRun`, `broadcast`, `broadcastAll`, `status`, `history`, `reload`, `emergency`), `configRevision`, `generatedAt` |
| `PolicySnapshot` | `revision`, `maxCommandLength`, `blockedSequences[]`, `dangerousPatterns[]`, `blockedPatterns[]`, `allowedPatterns[]`, `rules[]` (`pattern`, `deny`, `permission`, `requireConfirmation`), `confirmationEnabled`, `confirmationTimeoutSeconds`, `queueMaxSize`, `emergencyMode`, `responseMode`, `maxMessageLength`, `attachmentThreshold` |

---

## 7. Статусы и коды

### 7.1. `ServerStatus` — состояние соединения сервера

| Значение | Смысл |
|---|---|
| `CONNECTING` | Соединение установлено, аутентификация не завершена |
| `ONLINE` | Аутентифицирован, heartbeat приходит вовремя |
| `DEGRADED` | Молчание больше `heartbeat.timeout_seconds` (по умолчанию 30 с) |
| `OFFLINE` | Соединение закрыто или молчание больше двух интервалов (60 с) |
| `AUTH_FAILED` | Аутентификация отклонена |

### 7.2. `ExecutionStatus` — результат выполнения

| Значение | Смысл | Считается успехом |
|---|---|---|
| `SUCCESS` | Команда выполнена, получен реальный вывод | да |
| `DRY_RUN` | Проверки пройдены, выполнения не было | да |
| `FAILED` | Сервер вернул ошибку/команда не распознана | нет |
| `TIMEOUT` | Ответ не пришёл в отведённое время | нет |
| `OFFLINE` | Сервер недоступен | нет |
| `DENIED` | Отказ по правам или политике | нет |
| `QUEUE_FULL` | Очередь сервера заполнена | нет |
| `CANCELLED` | Команда отменена (например, политика `on_disconnect: cancel`) | нет |
| `UNKNOWN` | Состояние выполнения неизвестно (причина для запрета автоповтора) | нет |

### 7.3. `ErrorCode` — стандартизированные ошибки

| Код | Повторяемо автоматически | Сообщение пользователю (ru) |
|---|---|---|
| `PERMISSION_DENIED` | нет | У вас нет прав на это действие |
| `SERVER_OFFLINE` | да | Сервер `{0}` выключен, команда не выполнена |
| `TIMEOUT` | да | Сервер `{0}` не ответил вовремя |
| `INVALID_COMMAND` | нет | Команда отклонена: `{0}` |
| `INVALID_TARGET` | нет | Некорректная цель: `{0}` |
| `RATE_LIMIT` | да | Превышен лимит запросов (`{0}`). Повторите через `{1}` |
| `AUTHENTICATION_FAILED` | нет | Ошибка аутентификации |
| `QUEUE_FULL` | да | Очередь сервера `{0}` заполнена, команда не принята |
| `POLICY_DENIED` | нет | Политика команд запрещает выполнение: `{0}` |
| `CONFIRMATION_REQUIRED` | нет | Эта команда требует подтверждения |
| `EMERGENCY_MODE` | нет | Включён аварийный режим, обычные команды заблокированы |
| `NO_TARGETS` | нет | Нет доступных серверов для этой команды |
| `CONNECTION_LOST` | да | Соединение со шлюзом потеряно |
| `CONFIGURATION_ERROR` | нет | Ошибка конфигурации, обратитесь к администратору |
| `PROTOCOL_ERROR` | нет | Ошибка протокола между шлюзом и сервером |
| `DRY_RUN` | нет | Dry run: команда не выполнялась |
| `INTERNAL_ERROR` | да | Внутренняя ошибка, идентификатор запроса: `{0}` |

Пользователь всегда получает безопасное описание из `lang/<locale>.yml` (`error.<CODE>`);
детали и стектрейсы остаются только во внутренних логах.

---

## 8. Таймауты

| Таймаут | Источник | По умолчанию |
|---|---|---|
| Установка TCP/TLS соединения | `network.connect_timeout` | 10 c |
| Handshake | `network.handshake_timeout` | 15 c |
| Простой соединения | `network.idle_timeout` | 120 c |
| Ожидание результата из очереди сервера | `queue.timeout_seconds` | 30 c |
| Ожидание ответа бота на запрос | `gateway.request_timeout` (бот) / `timeoutMillis` сообщения | 60 c |
| Удержание команд при `on_disconnect: hold` | `queue.hold_timeout` | 5 мин |
| Переподключение клиента | `network.reconnect.*` | 1 c → 60 c, ×2 |

---

## 9. Версионирование и совместимость

| Понятие | Правило |
|---|---|
| Текущая версия | `ProtocolVersion.CURRENT = 1` |
| Минимальная поддерживаемая | `ProtocolVersion.MIN_SUPPORTED = 1` |
| Проверка | `protocolVersion.isCompatible(v)` ⇒ `v ∈ [MIN_SUPPORTED, CURRENT]` |
| Проверяется | на **каждом** сообщении, а также в `HELLO` при handshake |
| Несовместимость | `PROTOCOL_ERROR`, `AUTH_RESULT.authenticated = false`, соединение закрывается |
| Конфигурация | `protocol_version` в конфигурации шлюза должен быть равен версии сборки, иначе запуск отклоняется |
| Порядок обновления | шлюз можно обновлять независимо от плагинов и бота, пока версии попадают в поддерживаемый диапазон (см. `docs/UPGRADE.md`) |
| Расширение | новые поля JSON добавляются как необязательные: старые версии их игнорируют (`FAIL_ON_UNKNOWN_PROPERTIES` отключён, но дубли ключей запрещены) |

Политика изменения протокола:

1. **Обратно совместимое расширение** (новое необязательное поле, новый тип сообщения) — версия
   не меняется.
2. **Изменение семантики существующего поля или его обязательности** — увеличивается
   `CURRENT`, `MIN_SUPPORTED` остаётся, пока старая версия поддерживается.
3. **Удаление или несовместимое изменение** — увеличивается `CURRENT` и `MIN_SUPPORTED`;
   публикуется матрица совместимости в `docs/UPGRADE.md`.