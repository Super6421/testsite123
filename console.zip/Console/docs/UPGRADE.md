# Обновление версий

Автор: **Zigono**

Документ описывает политику версионирования, совместимость протокола и безопасную последовательность
обновления шлюза, бота и Minecraft-плагина, включая откат.

---

## 1. Версионирование

Проект использует семантическое версионирование `MAJOR.MINOR.PATCH` (текущая версия — `1.0.0`).

| Часть | Когда увеличивается | Что это значит для администратора |
|---|---|---|
| `MAJOR` | несовместимые изменения конфигурации, протокола или схемы БД | требуется чтение этого документа, возможна ручная правка конфигурации; старые клиенты могут не подключиться |
| `MINOR` | новые возможности, обратно совместимые | обновление безопасно, конфигурация расширяется необязательными ключами |
| `PATCH` | исправления | безопасно |

Дополнительно существует **версия протокола** (`ProtocolVersion`, сейчас `1`) — она независима от
версии продукта и определяет совместимость обмена между шлюзом, ботом и плагинами.

Версию сборки можно узнать командой:

```bash
java -jar dist/dmc-gateway-1.0.0.jar version
# Discord Minecraft Console Gateway 1.0.0 (protocol 1 (supported 1..1)) by Zigono
```

---

## 2. Матрица совместимости протокола

Проверка: `MIN_SUPPORTED ≤ версия партнёра ≤ CURRENT`. Проверяется в `HELLO` и **на каждом**
сообщении.

| Версия продукта | Версия протокола (CURRENT) | Поддерживаемые версии (MIN_SUPPORTED…) | Совместимо с |
|---|---|---|---|
| 1.0.0 | 1 | 1..1 | 1.0.0 (шлюз, бот, плагин) |

Правила:

- конфигурация шлюза содержит `protocol_version`, и он должен совпадать с версией сборки —
  иначе шлюз не запустится с `CONFIGURATION_ERROR`;
- при несовместимости партнёр получает `PROTOCOL_ERROR` и соединение закрывается
  (в логах — `unsupported protocol version N, this build speaks 1 (supported 1..1)`);
- обновление шлюза первым всегда безопаснее: старые клиенты продолжают работать, пока их версия
  попадает в поддерживаемый диапазон.

---

## 3. Схема базы данных и миграции

- Миграции лежат в `dmc-gateway/src/main/resources/db/migration/{sqlite,postgres}/V1__init.sql`
  и применяются автоматически при старте шлюза;
- применённые версии фиксируются в таблице `schema_migrations` (`version`, `applied_epoch_ms`);
- миграции идемпотентны (`CREATE TABLE IF NOT EXISTS`, `CREATE INDEX IF NOT EXISTS`) и
  выполняются **до** открытия слушателя: непрошедшая миграция не даст шлюзу стать `ready`;
- перед обновлением, которое содержит новую миграцию, сделайте бэкап (см. `docs/DEPLOYMENT.md`).

Проверка состояния:

```bash
psql "postgresql://dmc@db:5432/dmc" -c "select version, to_timestamp(applied_epoch_ms/1000) from schema_migrations order by version;"
sqlite3 /opt/dmc/data/dmc.db "select version, datetime(applied_epoch_ms/1000, 'unixepoch') from schema_migrations;"
```

Совместимость схемы: новые версии только добавляют таблицы, колонки и индексы; удаление и
переименование выполняется в рамках `MAJOR`-релиза с отдельной миграцией и предупреждением.

---

## 4. Пошаговое обновление

### 4.1. Подготовка

```bash
# 1. Бэкап БД
pg_dump "postgresql://dmc@db:5432/dmc" -Fc -f /backup/dmc-$(date +%F-%H%M).dump

# 2. Бэкап конфигурации и TLS
sudo tar czf /backup/dmc-config-$(date +%F).tgz -C /opt/dmc config tls

# 3. Зафиксируйте текущую версию и ревизию конфигурации
java -jar /opt/dmc/dmc-gateway-1.0.0.jar version
curl -s http://127.0.0.1:9100/health
```

Для отката достаточно старых jar-файлов и бэкапа конфигурации; откат БД нужен только при
переходе через `MAJOR` с несовместимой миграцией.

### 4.2. Шлюз (первым)

```bash
sudo systemctl stop dmc-gateway
sudo cp dist/dmc-gateway-1.1.0.jar /opt/dmc/
sudo cp config/gateway.example.yml /opt/dmc/config/gateway.yml.new   # сравнить и слить
sudo diff -u /opt/dmc/config/gateway.yml /opt/dmc/config/gateway.yml.new || true
sudo systemctl start dmc-gateway
curl -fsS http://127.0.0.1:9100/health/ready
sudo journalctl -u dmc-gateway -n 50 --no-pager
```

Что проверить в логах: версия и ревизия конфигурации при старте, отсутствие ошибок миграции,
восстановление соединений плагинов (`Minecraft server '…' authenticated`).

### 4.3. Бот

```bash
sudo systemctl stop dmc-bot
sudo cp dist/dmc-bot-1.1.0.jar /opt/dmc/
sudo cp config/bot.example.yml /opt/dmc/config/bot.yml.new   # слить новые ключи
sudo systemctl start dmc-bot
sudo journalctl -u dmc-bot -n 30 --no-pager
```

Slash-команды обновляются автоматически при старте. Если менялась локализация, при наличии
внешнего каталога `lang/` обновите и его.

### 4.4. Плагин Minecraft (по одному серверу)

```bash
# на Minecraft-сервере
cd /srv/minecraft
sudo cp plugins/DiscordMinecraftConsole/config.yml \
        plugins/DiscordMinecraftConsole/config.yml.bak
sudo cp ~/DiscordMinecraftConsole-1.1.0.jar plugins/
sudo rm plugins/DiscordMinecraftConsole-1.0.0.jar
# перезапуск сервера (не /reload: меняются классы и сетевые компоненты)
sudo systemctl restart minecraft-survival
```

После включения: плагин подключается к шлюзу, `/servers` показывает сервер `ONLINE`, тестовая
команда возвращает реальный вывод. Обновляйте серверы последовательно, чтобы не терять
управление всеми сразу.

### 4.5. Обновление только конфигурации (без смены версии)

Hot reload применяет изменения мгновенно и без разрыва соединений:

```bash
sudo vi /opt/dmc/config/gateway.yml
# шлюз замечает изменение в течение ~2 секунд
sudo journalctl -u dmc-gateway -n 20 --no-pager | grep -i reload
```

Что применяется на горячем reload: права, политики, серверы, группы, rate limit, security,
логирование, UI, сообщения, очередь, retry, heartbeat, broadcast, confirmation, responses.
Что **требует перезапуска**: `network.*`, `tls.*`, `database.*`, `redis.*`, `metrics.*`
(шлюз пишет предупреждение и оставляет прежние значения).

Права, политики и другие разделы можно перезагрузить удалённо запросом `RELOAD_REQUEST`
(`console.admin.reload`); ответ содержит новую ревизию и список обновлённых разделов.

### 4.6. Что меняется в выпуске 1.0.0

Обновление совместимо с прежними файлами конфигурации: старые формы записи продолжают читаться.
Меняются оформление и удобство настройки.

| Что | Было | Стало |
|---|---|---|
| Ответы в Discord | ASCII-иконки `[OK]`, технические поля (длительность, идентификатор запроса, ревизия конфигурации, шлюз, аптайм) | Эмодзи-статусы (✅ ❌ ⌛ ⛔ 🟡 …), карточка из заголовка, вывода и цели. Технические поля возвращаются `ui.show_diagnostics: true`, correlation id — `ui.show_request_id: true` |
| Футер embeds | `Discord Minecraft Console` | `Discord Minecraft Console · Zigono` (`embeds.footer`) |
| Права в `config.yml` плагина | `"123":` + `allow: [ "console.*" ]` | `123: console.*`; несколько прав — через запятую. Полная форма с `allow`/`deny` нужна только для запретов. Списки по-прежнему принимаются |
| Серверы | один сервер, остальное — только через внешний шлюз | разделы `servers`, `groups` и `mode` в том же `config.yml`; серверы сети подключаются к встроенному шлюзу по адресу из `embedded.network` |
| Журнал сервера | строка на каждое отклонённое взаимодействие, исключение JDA на каждое автодополнение, метрика на уровне INFO | одна строка на канал при отказе, автодополнение отклоняется без стектрейса, метрика плагина — DEBUG |
| Подписи полей embeds | служебные ключи `embed.field.user`, `embed.field.status` | переводы из `bot-lang` («Пользователь», «Цель», «Статус») |
| Команды персонала | — | `/персонал-выдать` и `/персонал-снять` меняют группы LuckPerms; что кому доступно — в `staff.access` |
| Журнал выдачи прав | — | `/logs channel` включает, выключает и переносит канал журнала; выбор хранится в `logs-channel.yml` |

Проверка после обновления: `/console list` возвращает реальный вывод, `/servers` показывает серверы
сети, а в консоли сервера нет строк `uncaught exception` и повторяющихся отказов по каналу.

---

## 5. Откат

| Что откатываем | Как |
|---|---|
| Шлюз | `sudo systemctl stop dmc-gateway`, вернуть прежний jar и конфигурацию, `sudo systemctl start dmc-gateway`, проверить `/health/ready` |
| Бот | то же для `dmc-bot`; достаточно вернуть прежний jar |
| Плагин | вернуть прежний jar в `plugins/`, удалить новый, перезапустить локальный Minecraft-сервер |
| Миграции | автоматического отката нет (миграции только добавляют объекты). При необходимости восстановите БД из дампа: `pg_restore -d … --clean --if-exists /backup/dmc-….dump` |
| Конфигурация | `sudo tar xzf /backup/dmc-config-….tgz -C /opt/dmc` и hot reload/перезапуск |

Правило совместимости при откате: если новая версия увеличивала `MIN_SUPPORTED`, откат шлюза на
старую версию требует одновременного отката клиентов, версия которых стала несовместимой.
Для версии 1.0.0 (`MIN_SUPPORTED = CURRENT = 1`) расхождения нет.

---

## 6. Регрессионная проверка после обновления

```bash
# 1. Версии
java -jar /opt/dmc/dmc-gateway-1.1.0.jar version

# 2. Готовность и метрики
curl -fsS http://127.0.0.1:9100/health
curl -fsS http://127.0.0.1:9100/metrics | grep -E 'dmc_(connected_servers|offline_servers)'

# 3. Аудит пишется
psql "postgresql://dmc@db:5432/dmc" -c "select count(*) from audit_log where created_epoch_ms > (extract(epoch from now())*1000 - 600000);"
```

В Discord:

1. `/servers` — все серверы доступны, метрики обновляются;
2. `/console dryrun command:list` — все проверки пройдены, выполнения нет;
3. `/console command:list` — реальный вывод из Minecraft;
4. опасная команда (например, `whitelist list`) — требование подтверждения;
5. `/console-history` — записи о только что выполненных командах, включая `request_id`.

---

## 7. Автоматизация

`.github/workflows/ci.yml` собирает и тестирует каждое изменение и публикует артефакты
(`dist/*.jar`). Для релизов рекомендуется:

1. собрать `mvn -B -ntp clean verify`;
2. проверить `dist/` и обновить версию в `pom.xml` (`MAJOR.MINOR.PATCH`);
3. при изменении протокола обновить таблицу совместимости в этом документе и в `docs/PROTOCOL.md`;
4. при изменении конфигурации — обновить `config/*.example.yml` и `docs/CONFIGURATION.md`;
5. приложить артефакты сборки к релизу и указать автора — **Zigono**.