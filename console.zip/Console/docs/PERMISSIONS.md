# Права и доступ

Автор: **Zigono** · версия 1.0.0

Модель доступа состоит из двух независимых слоёв:

1. **Discord ACL (шлюз)** — кто и на каком сервере может выполнять какие команды. Источник правды:
   `permissions` и `guilds.<id>.permissions` в конфигурации шлюза.
2. **LuckPerms (плагин Minecraft)** — кто из игроков видит активность Discord Console в игре.
   Этот слой **не** даёт прав на выполнение команд, он управляет только отображением.

---

## 1. Узлы прав Discord

### 1.1. Базовые узлы

| Узел | Что разрешает |
|---|---|
| `console.read` | Видеть панель консоли (доступ к UI) |
| `console.status` | `/servers` — состояние серверов |
| `console.servers` | Видеть список доступных серверов в UI |
| `console.history` | `/console-history` — история **своих** команд |
| `console.history.all` | История всех пользователей (фильтр по пользователю) |
| `console.logs` | `/logs channel` — включить, выключить или перенести журнал выдачи прав |
| `console.execute` | Выполнять команды |
| `console.dryrun` | `/console dryrun` (проверка без выполнения) |
| `console.broadcast` | Отправлять команду более чем на один сервер (группа или список серверов) |
| `console.broadcast.all` | Цель `all` — все серверы |
| `console.admin.reload` | Удалённая перезагрузка конфигурации шлюза |
| `console.admin.*` | Полный административный набор (`console.admin.reload`, `console.admin.emergency`) |

### 1.2. Параметризованные узлы

| Шаблон узла | Пример | Когда проверяется |
|---|---|---|
| `console.server.<serverId>` | `console.server.survival` | Доступ к конкретному серверу. Проверяется для каждого сервера из цели |
| `console.group.<groupName>` | `console.group.survival-network` | Доступ к группе серверов (имя в нижнем регистре) |
| `console.command.<root>` | `console.command.cmi` | Право на корень команды (производное) |
| `console.command.<root>.<arg1>` | `console.command.cmi.heal` | Наиболее специфичное производное право команды |
| `console.alias.<name>` | `console.alias.heal` | Использование alias |
| `console.template.<name>` | `console.template.give` | Использование template |
| `console.emergency.*` | `console.emergency.toggle` | Работа в аварийном режиме / переключение режима |
| `console.execute.emergency` | — | Альтернативный узел, разрешающий выполнение при включённом аварийном режиме |

### 1.3. Как выводится право команды

Команда сначала нормализуется, затем из неё выводится узел:

```text
cmi heal Zigono   ->  console.command.cmi.heal
list              ->  console.command.list
tps               ->  console.command.tps
```

Правила преобразования второго токена: строчные буквы, цифры, `_` и `-` сохраняются, `.` и `:`
заменяются на `_`, остальные символы отбрасываются. Если в команде нет второго токена, узел
ограничивается корнем (`console.command.<root>`).

Право можно переопределить в `command_policies` (`permission: "console.command.ban"`), тогда
проверяется именно указанный узел.

---

## 2. Wildcard, allow и deny

### 2.1. Синтаксис wildcard

| Шаблон | Совпадает с |
|---|---|
| `*` | абсолютно любым узлом |
| `console.*` | `console.read`, `console.execute`, `console.command.cmi.heal`, … |
| `console.server.*` | `console.server.survival`, `console.server.lobby`, … |
| `console.command.cmi.*` | `console.command.cmi.heal`, `console.command.cmi.fly`, … |
| `console.command.cmi.heal` | только с этим узлом |
| `console.server.survival.*` | `console.server.survival` и всё ниже (`…survival.admin`) |

Правила сопоставления: `*` сам по себе совпадает со всем; `prefix.*` совпадает как с самим
`prefix`, так и с любым узлом, начинающимся на `prefix.`; иначе требуется точное совпадение.
Частичные wildcard внутри узла (например `console.*.heal`) не поддерживаются. Все узлы
приводятся к нижнему регистру.

> Права `console.server.survival` **недостаточно** для массовой рассылки: нужен ещё
> `console.broadcast` (а для цели `all` — `console.broadcast.all`). Это защищает от превращения
> одиночной команды в массовую.

### 2.2. Приоритет deny

`deny` побеждает всегда и не зависит от конкретности `allow`:

```yaml
permissions:
  roles:
    "234567890123456789":
      allow:
        - "console.*"
      deny:
        - "console.command.stop"      # запрещено несмотря на console.*
        - "console.admin.*"           # административные действия закрыты
```

Проверка узла: если узел совпал с любым `deny` — отказ; иначе, если совпал с любым `allow` —
разрешение; иначе отказ.

### 2.3. Объединение назначений

Итоговые права пользователя — объединение всех применимых наборов:

```text
permissions.roles.<роль>               (все роли пользователя)
+ permissions.users.<пользователь>
+ guilds.<гильдия>.permissions.roles.<роль>
+ guilds.<гильдия>.permissions.users.<пользователь>
```

Списки `allow` складываются, списки `deny` тоже складываются; после объединения применяется
правило «deny побеждает». Роли одной гильдии никогда не дают прав в другой: идентификаторы ролей
уникальны внутри гильдии и разрешаются только в её контексте.

### 2.4. Ограничения контекста

| Условие | Результат |
|---|---|
| Гильдия не указана, а в конфигурации заданы `channels.allowed` | `PERMISSION_DENIED`: команды из личных сообщений запрещены |
| Канал в `guilds.<id>.channels.denied` | `PERMISSION_DENIED` |
| Канал не входит в непустой `guilds.<id>.channels.allowed` | `PERMISSION_DENIED` |
| Пустой `channels.allowed` | Разрешены все каналы гильдии, кроме `denied` |

### 2.5. Защита от обхода ACL

- Команда **сначала** нормализуется (убираются ведущие `/`, схлопываются пробелы, отклоняются
  управляющие и форматные символы, `&&`, `||`, `;`, backtick, `$(`, `\x`), и только потом
  проверяется политика и производное право — обход через `;/`, переводы строк, zero-width символы
  или `$()` невозможен.
- Alias и template разворачиваются системой: пользователь подставляет значения, которые
  валидируются регулярными выражениями (`player`, `word`, `integer`, `decimal`, `world`, `text`,
  `boolean`), а не «санитайзятся».
- Вложенные команды, `execute`, `op`, `deop`, `stop`, `restart` закрываются правилами политики.
- Бот передаёт шлюзу уже нормализованную команду в поле `normalizedCommand`; если она не совпадает
  с тем, что шлюз получил в `command`, запрос отклоняется (`INVALID_COMMAND`) — подменённый клиент
  не может «донармить» команду в обход проверок.
- Права вычисляются и проверяются **на шлюзе** заново для каждого запроса; права, переданные
  ботом в `UserContext`, только дополняют конфигурацию и не могут отменить `deny` из неё.

---

## 3. Примеры назначений

Права пишутся строкой без скобок; несколько прав перечисляются через запятую, точку с запятой,
вертикальную черту или пробел. Список (в том числе блочный, через `-`) тоже принимается — это удобно
для длинных наборов.

```yaml
permissions:
  roles:
    # Полный доступ
    123456789012345678: console.*

    # Дежурный администратор: выполнение и наблюдение без админ-функций
    234567890123456789:
      allow: console.read, console.status, console.servers, console.history, console.execute, console.server.survival, console.server.lobby, console.command.*
      deny: console.command.stop, console.command.op, console.admin.*, console.emergency.*

    # Модератор одного сервера и одного плагина команд
    345678901234567890:
      allow: console.read, console.status, console.servers, console.execute, console.broadcast, console.server.skyblock, console.group.survival-network, console.command.cmi.heal, console.command.cmi.fly

    # Наблюдатель
    456789012345678901:
      allow: console.read, console.status, console.servers
      deny: console.execute

  users:
    # Персональное исключение: пользователь не может выполнять команды,
    # даже если роль даёт console.*
    987654321098765432:
      deny: console.execute, console.broadcast.all
```

Проверка того, что видит конкретный пользователь: команда `/servers` (список серверов) и
панель `/console` — в них отображаются только разрешённые цели; `Capabilities` из `TargetsView`
показывает доступные режимы (`execute`, `dryRun`, `broadcast`, `broadcastAll`, `status`,
`history`, `reload`, `emergency`).

---

## 4. LuckPerms: видимость Discord Console в Minecraft

Плагин использует LuckPerms как **отдельный слой контроля отображения**: права Discord управляют
выполнением команд, права LuckPerms — тем, кто из игроков видит в игре, что команда была
инициирована через Discord Console.

### 4.1. Узлы прав (объявлены в `plugin.yml`)

| Узел | По умолчанию | Назначение |
|---|---|---|
| `discordconsole.monitor` | `op` | Базовое право: видеть активность Discord Console в игре |
| `discordconsole.monitor.commands` | `op` | Уточнение: видеть текст выполняемой команды |
| `discordconsole.monitor.results` | `op` | Уточнение: видеть результат выполнения |
| `discordconsole.monitor.servers` | `op` | Уточнение: видеть имя сервера |
| `discordconsole.monitor.admin` | `op` | Всегда видеть активность, независимо от режима видимости |
| `discordconsole.admin` | `op` | Команды `/discordconsole status` и `/discordconsole reload` |

Как работают уточнения: права `commands`/`results`/`servers` берутся из
`luckperms.commands_permission`, `luckperms.results_permission`, `luckperms.servers_permission`.
**Пустое значение отключает уточнение** — тогда достаточно базового права `monitor_permission`.
Если уточнение задано, игрок без него видит анонс, но без соответствующей части (текста команды,
результата или имени сервера); вместо имени сервера показывается `hidden_server_label` (по
умолчанию `***`).

### 4.2. Выдача прав

```text
# Базовый мониторинг для администраторов
/lp group admin permission set discordconsole.monitor true
/lp group admin permission set discordconsole.monitor.commands true
/lp group admin permission set discordconsole.monitor.results true
/lp group admin permission set discordconsole.monitor.servers true

# Модераторы видят только факт выполнения (настраивается через уточнения выше)
/lp group moderator permission set discordconsole.monitor true

# Полный доступ, включая /discordconsole status|reload
/lp group admin permission set discordconsole.admin true
/lp user Zigono permission set discordconsole.monitor.admin true

# Проверка
/lp user Zigono permission check discordconsole.monitor
```

### 4.3. Настройка видимости

```yaml
minecraft:
  discord_console_visibility:
    enabled: true
    permission: "discordconsole.monitor"        # право для режима permission
    format: "&7[&9Discord&7] &f{user} &7executed: &f{command}"
  visibility:
    mode: default        # default | permission | nobody
    default: true        # true: видят все игроки при mode: default
    show_results: true
    result_format: "&7[&9Discord&7] &7result: &f{result}"
    server_format: "&7[&9Discord&7] &7server: &f{server}"
    hidden_server_label: "***"
    hidden_commands:     # никогда не показываются ни в игре, ни в консоли
      - "login"
      - "token"
      - "password"
      - "auth"
      - "2fa"

luckperms:
  enabled: true
  monitor_permission: "discordconsole.monitor"
  commands_permission: ""
  results_permission: ""
  servers_permission: ""
  admin_permission: "discordconsole.monitor.admin"
```

Режимы `mode`:

| Режим | Кто видит анонс в игре |
|---|---|
| `default` | Все игроки при `default: true`; при `default: false` — только владельцы `monitor_permission` |
| `permission` | Только владельцы права `minecraft.discord_console_visibility.permission` |
| `nobody` | Никто в игре; анонс идёт только в консоль сервера |

Правила:

- `luckperms.admin_permission` обходит режим и флаг `default` — владелец права видит всё, но
  команды из `hidden_commands` остаются скрытыми для всех;
- `format`, `result_format` и `server_format` поддерживают legacy-коды `&` и теги MiniMessage;
- плейсхолдеры: `{user}`, `{command}`, `{server}`, `{target}`, `{result}`, `{status}`, `{duration}`;
- плагин **только читает** права через LuckPerms API: он ничего не выдаёт и не изменяет;
- если LuckPerms не установлен или `luckperms.enabled: false`, плагин продолжает выполнять команды,
  а видимость определяется режимом `mode` (права считаются отсутствующими, `admin_permission`
  никому не выдан).

### 4.4. Команды плагина

```text
/discordconsole status     # состояние подключения к шлюзу, ревизия конфигурации
/discordconsole reload     # перечитать config.yml
/dmc status                # алиасы: /dmc, /dconsole
```

Требуется `discordconsole.admin` (`default: op`). Сообщение при отказе:
«You do not have permission to use the Discord Minecraft Console plugin.»

---
## 5. Быстрая диагностика прав

| Симптом | Что проверить |
|---|---|
| Пользователь не видит сервер в селекторе | `console.server.<id>` или `console.broadcast.all`; также `console.servers`/`console.read` |
| Пользователя нет в `/servers`, хотя право есть | Ограничения каналов `guilds.<id>.channels.*` |
| Отказ при рассылке | Нужны `console.broadcast` (и `console.broadcast.all` для цели `all`) |
| Отказ на конкретной команде | Производное право `console.command.<root>.<arg1>` или правило `command_policies` |
| Отказ только для одной роли | Проверьте `deny` — он приоритетнее любого `allow` |
| Игрок не видит анонсы | `mode: permission` без выданного `discordconsole.monitor`, либо команда в `hidden_commands` |
| История показывает только свои записи | Нужен `console.history.all`, чтобы видеть чужие |

Систематическая проверка: `/console dryrun` — он проверяет права, цель, политику, лимиты и
требование подтверждения, не выполняя команду.