# Установка

Автор: **Zigono** · версия 1.0.0 · протокол 1

Документ описывает два варианта установки:

| Вариант | Что ставится | Когда подходит |
|---|---|---|
| **Всё внутри плагина** (§2) | один jar плагина | сервер куплен на панельном хостинге (Pterodactyl), отдельные процессы и порты недоступны |
| **Три компонента** (§3–§8) | шлюз, Discord-бот, плагин | свой VPS/сервер, несколько Minecraft-серверов, общая база аудита и метрики |

Оба варианта используют один и тот же протокол, права и политики команд: различия только в том, где работают
шлюз и бот.

---

## 1. Требования

| Компонент | Требование | Обязательность |
|---|---|---|
| Java | **JDK 21** (сборка и запуск; `maven.compiler.release=21`) | обязательно |
| Maven | 3.9+ (или готовые jar-файлы из `dist/`) | для сборки |
| Minecraft-сервер | **Paper 1.21.1** | обязательно |
| PostgreSQL | 13+ | рекомендуется в production |
| SQLite | встроен в шлюз (`sqlite-jdbc`) | для быстрого старта |
| Redis | 6+ | только для нескольких экземпляров шлюза |
| Discord | приложение и бот с включёнными slash-командами | обязательно |
| LuckPerms | любой актуальный релиз | для видимости Discord Console в игре |
| ОС | Linux x86_64/arm64 или Windows | любая с JDK 21 |

Сетевые порты:

| Порт | Назначение | Кому доступен |
|---|---|---|
| `8443/tcp` | протокол шлюза (бот и плагины) | бот и Minecraft-серверы |
| `9100/tcp` | `/metrics`, `/health`, `/health/live`, `/health/ready` | только мониторинг/локально |

Порт метрик **не должен** быть доступен из интернета: он отдаёт внутреннее состояние шлюза.

---

## 2. Всё внутри плагина (панельный хостинг, Pterodactyl)

Вариант для случая, когда сервер куплен на панельном хостинге: запустить второй процесс или открыть второй
порт нельзя, а устанавливать что-либо кроме плагина негде. Шлюз и Discord-бот работают внутри того же
процесса, что и Minecraft, поэтому устанавливается ровно один файл — `dist/DiscordMinecraftConsole-1.0.0.jar`.

Свойства этого режима:

- наружу открыт только порт Minecraft, дополнительных портов и TLS-материала нет;
- связь плагина, шлюза и бота идёт по loopback (`127.0.0.1`) внутри машины, свободный порт выбирает система;
- база аудита — SQLite в `plugins/DiscordMinecraftConsole/embedded/data/gateway.db`;
- секреты внутренней связи и конфигурация шлюза с ботом генерируются автоматически при старте;
- один сервер Minecraft = один Discord-бот и одна гильдия: чужие серверы не смешиваются.

### 2.1. Шаги установки

1. Убедитесь, что в панели выбран образ с **Java 21** (например `ghcr.io/pterodactyl/yolks:java_21`) и
   серверная сборка **Paper 1.21.1**.
2. Загрузите `dist/DiscordMinecraftConsole-1.0.0.jar` в каталог `plugins/` сервера — файловым менеджером
   панели (Upload) или по SFTP. Файл занимает около 22 МБ и содержит всё необходимое: шлюз, Discord-бота и их
   библиотеки.
3. Перезапустите сервер. Плагин создаст `plugins/DiscordMinecraftConsole/config.yml`, служебный каталог
   `embedded` и поднимет шлюз на `127.0.0.1` (свободный порт выбирает система). В консоли появятся строки:

```text
Встроенный режим включён: шлюз DiscordMinecraftConsole работает внутри этого сервера на 127.0.0.1:49321 (служебные файлы — .../plugins/DiscordMinecraftConsole/embedded)
Discord-бот запущен и работает как Console#5252
```

4. Конфигурация **уже заполнена и работает сразу**: в `config.yml` указаны токен бота, гильдия, канал и роль
   с полным доступом. Меняйте только те строки, которые относятся к вашему Discord:

```yaml
embedded:
  enabled: true
  discord:
    token: "ТОКЕН_БОТА"        # Discord Developer Portal -> Bot -> Reset Token
    guilds: "ID_ГИЛЬДИИ"       # гильдии, в которых работает бот (через запятую)
    channels:
      allowed: "ID_КАНАЛА"     # каналы, в которых разрешены команды
    audit_channel_id: "ID_КАНАЛА_ЛОГОВ"  # канал логов: кто что выполнил
  permissions:
    roles:
      ID_РОЛИ: console.*       # роль с полным доступом; права — строкой, без скобок
```

   Права выдаются ролям и пользователям Discord по id (см. `docs/PERMISSIONS.md`). Токен можно не хранить в
   файле, а задать переменной окружения `DISCORD_TOKEN` в переменных панели.
5. Пригласите бота в гильдию со scopes `bot` и `applications.commands`
   (**OAuth2 → URL Generator**), иначе slash-команды не появятся.
6. Перезапустите сервер. В Discord появятся команды `/console`, `/console-history`, `/servers`.
7. Проверка: `/console list` в Discord возвращает реальный вывод консоли, `/discordconsole status` в консоли
   сервера (или в игре с правом `discordconsole.admin`) показывает loopback-порт и состояние бота.

### 2.2. Что появляется на диске

```text
plugins/DiscordMinecraftConsole/
├── config.yml        # единственный файл, который правит администратор
├── lang/             # ru.yml, en.yml — тексты плагина
└── embedded/         # служебный каталог режима
    ├── gateway.yml   # генерируется из config.yml при каждом старте
    ├── bot.yml       # генерируется из config.yml при каждом старте
    ├── server.secret # секрет сервера, если он не задан в config.yml
    ├── control.secret# секрет control-клиента (бота)
    └── data/gateway.db
```

`gateway.yml` и `bot.yml` не нужно (и не рекомендуется) править руками: они пересобираются из `config.yml`.
Если нужен параметр, которого нет в `config.yml`, добавьте его через `embedded.gateway_overrides` или
`embedded.bot_overrides` — см. `docs/CONFIGURATION.md` §4.1.

### 2.3. Почему файл такой короткий и что делать, если YAML сломался

Остальные настройки — лимиты выполнения, захват вывода, политика команд, LuckPerms, метрики, видимость в
игре — в `config.yml` не нужны: в плагине действуют безопасные значения по умолчанию (подтверждение для
`stop`, `reload`, `op`, `ban` и других опасных команд, скрытие `login`, `password`, `token` в игровом
чате, запрет опасных последовательностей вроде `&&` и `;`). Добавляйте их в файл только для тонкой
настройки — описание есть в `docs/CONFIGURATION.md` §4.2–§4.6.

Если файл перестал быть корректным YAML или содержит недопустимые значения, плагин **не отключается**: он
пишет в консоль строку с ошибкой (там указаны строка и столбец), сохраняет прежний файл как
`config.yml.broken-<дата-время>` и запускается на стандартных значениях. Перенесите свои правки из сохранённого
файла в новый `config.yml` и перезапустите сервер.

Если в консоли панели вместо русских букв видны `?`, добавьте переменную окружения `LANG=C.UTF-8` в
переменных сервера — это локаль контейнера, а не настройка плагина.

### 2.4. Переход на внешний шлюз позже

Поставьте `embedded.enabled: false`, задайте `security.server_secret`, `network` и `tls` — плагин станет
обычным клиентом `dmc-gateway` (см. §7). Обратно — так же: `enabled: true` возвращает всё внутрь плагина.

---

## 3. Сборка

```bash
git clone https://github.com/zigono/discord-minecraft-console.git
cd discord-minecraft-console
mvn -B clean package
```

После сборки в каталоге `dist/` появятся:

```text
dist/dmc-gateway-1.0.0.jar               # шлюз (fat jar)
dist/dmc-bot-1.0.0.jar                   # Discord-бот (fat jar)
dist/DiscordMinecraftConsole-1.0.0.jar   # плагин Paper
```

Полезные варианты:

```bash
mvn -B clean package -DskipTests          # без тестов
mvn -B -pl dmc-gateway -am package        # только шлюз (с зависимыми модулями)
mvn -B clean verify                       # сборка + все тесты (как в CI)
```

Проверка сборки:

```bash
java -jar dist/dmc-gateway-1.0.0.jar version
# Discord Minecraft Console Gateway 1.0.0 (protocol 1 (supported 1..1)) by Zigono
```

---

## 4. TLS-материал

Шлюз, бот и плагины общаются только по TLS с взаимной аутентификацией по сертификатам и
дополнительной HMAC-подписью каждого сообщения. Сертификаты генерируются встроенной командой.

```bash
java -jar dist/dmc-gateway-1.0.0.jar certs \
  --out tls \
  --hosts localhost,10.0.0.5,mc-gateway.example.com \
  --clients discord-bot,lobby,survival,skyblock \
  --password "$TLS_KEYSTORE_PASSWORD" \
  --days 825
```

Параметры команды:

| Флаг | Значение по умолчанию | Описание |
|---|---|---|
| `--out` | `tls` | каталог для материала |
| `--hosts` | `localhost` | список через запятую: DNS-имена и IP, попадающие в SAN сертификата шлюза |
| `--clients` | пусто | идентификаторы клиентов, для каждого выпускается отдельный сертификат |
| `--password` | `changeit` | пароль всех PKCS12-хранилищ |
| `--days` | `825` | срок действия сертификатов шлюза и клиентов (CA — в 5 раз дольше) |

Результат:

```text
tls/
├── ca.crt              # корневой сертификат CA (PEM, для проверки)
├── ca.p12              # CA вместе с ключом (храните в тайне!)
├── gateway.crt         # сертификат шлюза (PEM)
├── gateway.key         # закрытый ключ шлюза (PEM)
├── gateway.p12         # keystore шлюза (alias: gateway)
├── truststore.p12      # truststore с CA (alias: ca) — нужен и шлюзу, и клиентам
├── client-discord-bot.p12
├── client-lobby.p12
├── client-survival.p12
└── client-skyblock.p12
```

Как разложить материал:

| Файл | Кому |
|---|---|
| `gateway.p12`, `truststore.p12` | шлюзу (`tls.keystore`, `tls.truststore`) |
| `client-discord-bot.p12`, `truststore.p12` | боту |
| `client-<serverId>.p12`, `truststore.p12` | соответствующему Minecraft-серверу |

Правила:

- `tls.keystore_password` и `tls.truststore_password` — пароль из `--password`;
- `--hosts` **обязательно** должен содержать адрес, по которому клиенты подключаются к шлюзу:
  клиентская сторона проверяет имя хоста;
- идентификаторы клиентов (`--clients`) должны совпадать с ключами `servers.<id>` и
  `control.clients.<id>` в конфигурации шлюза;
- файлы `*.p12`, `*.key`, `*.pem` исключены из git (`.gitignore`) — не коммитьте их.

---

## 5. Установка шлюза

### 4.1. Размещение

```bash
sudo useradd --system --home /opt/dmc --shell /usr/sbin/nologin dmc
sudo mkdir -p /opt/dmc/{config,tls,data,logs}
sudo cp dist/dmc-gateway-1.0.0.jar /opt/dmc/
sudo cp config/gateway.example.yml /opt/dmc/config/gateway.yml
sudo cp -r tls/* /opt/dmc/tls/
sudo chown -R dmc:dmc /opt/dmc
sudo chmod 600 /opt/dmc/tls/*.p12 /opt/dmc/tls/*.key
```

### 4.2. Переменные окружения

```bash
sudo mkdir -p /etc/dmc
sudo cp .env.example /etc/dmc/dmc.env     # заполните реальными значениями
sudo chmod 600 /etc/dmc/dmc.env
```

Обязательный минимум: `DMC_GATEWAY_ID`, `DMC_CONTROL_SECRET`, секрет каждого сервера
(`DMC_SURVIVAL_SECRET`, …), `TLS_KEYSTORE_PASSWORD`, `TLS_TRUSTSTORE_PASSWORD`, а для PostgreSQL —
`POSTGRES_*`. Секреты должны быть не короче **16 байт**; можно использовать форму `hex:<hex>` или
`base64:<base64>`.

### 4.3. Первый запуск

```bash
sudo -u dmc env $(grep -v '^#' /etc/dmc/dmc.env | xargs) \
  java -jar /opt/dmc/dmc-gateway-1.0.0.jar run --config /opt/dmc/config/gateway.yml
```

Шлюз при старте:

1. загружает и строго проверяет конфигурацию (неизвестный `protocol_version`, включённый сервер без
   секрета, пустой `control.clients`, неверный `queue.on_disconnect` — остановка с понятной ошибкой);
2. поднимает соединение с базой и применяет миграции;
3. открывает слушатель `network.host:network.port`;
4. включает `/metrics` и `/health/*`, если `metrics.enabled: true`;
5. запускает мониторинг heartbeat, retention и наблюдение за файлом конфигурации (hot reload).

Проверка работоспособности:

```bash
curl -s http://127.0.0.1:9100/health/ready   # {"status":"UP","live":true,"ready":true,...}
curl -s http://127.0.0.1:9100/metrics | head
```

Для постоянной работы используйте systemd-юнит из `docs/DEPLOYMENT.md`.

---

## 6. Установка Discord-бота

1. Создайте приложение на https://discord.com/developers/applications и получите токен бота.
2. Пригласите бота в гильдию с правами `applications.commands` и `bot` (минимально: отправка
   сообщений; подсказки автодополнения не требуют отдельного намерения).
3. Подготовьте конфигурацию:

```bash
cp config/bot.example.yml config/bot.yml
```

4. Убедитесь, что `control.client_id` совпадает с ключом `control.clients.<id>` в конфигурации
   шлюза, а `control.secret` — с тем же секретом. Токен задайте через `DISCORD_TOKEN`.
5. Запустите бота:

```bash
DISCORD_TOKEN=... DMC_CONTROL_SECRET=... java -jar dist/dmc-bot-1.0.0.jar --config config/bot.yml
```

Бот регистрирует slash-команды `/console`, `/console-history`, `/servers`. Если в
`discord.guilds` перечислены гильдии, команды регистрируются внутри них
(`discord.register_guild_commands: true`) — это удобно при первом запуске, поскольку глобальная
регистрация команд кэшируется Discord.

---

## 7. Установка плагина

1. Скопируйте `dist/DiscordMinecraftConsole-1.0.0.jar` в каталог `plugins/` Paper-сервера.
2. Перезапустите сервер: плагин создаст `plugins/DiscordMinecraftConsole/config.yml` и каталог `lang/`.
3. Заполните конфигурацию:

```yaml
language: ru
server:
  id: "${DMC_SERVER_ID:survival}"          # должен совпадать с servers.<id> на шлюзе
  name: "Survival"
security:
  server_secret: "${DMC_SERVER_SECRET}"    # = servers.survival.secret
network:
  host: "10.0.0.10"                        # адрес шлюза
  port: 8443
tls:
  enabled: true
  keystore: "tls/client.p12"
  keystore_password: "${TLS_KEYSTORE_PASSWORD:}"
  truststore: "tls/truststore.p12"
  truststore_password: "${TLS_TRUSTSTORE_PASSWORD:}"
```

4. Положите TLS-материал в `plugins/DiscordMinecraftConsole/tls/`:

```text
plugins/DiscordMinecraftConsole/
├── config.yml
├── lang/            ru.yml, en.yml
└── tls/
    ├── client.p12       # client-<serverId>.p12 из команды certs
    └── truststore.p12   # общий truststore
```

Если хотите оставить оригинальные имена (`client-survival.p12`), укажите их в `tls.keystore`.

5. Перезапустите Minecraft-сервер и проверьте подключение:

```text
/discordconsole status      # состояние подключения к шлюзу (право discordconsole.admin)
```

В консоли сервера при подключении появляется сообщение об установленной сессии; сервер становится
виден в `/servers` как `ONLINE` с TPS, MSPT, памятью и версиями, а `/console` возвращает реальный
вывод серверной консоли.

Права LuckPerms для видимости активности Discord Console выдаются отдельно — см.
`docs/PERMISSIONS.md`.

Для команд персонала (`/персонал-выдать`, `/персонал-снять`) сервер должен работать с LuckPerms:
привилегии — это группы LuckPerms, а иерархия ролей Discord настраивается в разделе `staff`
файла `config.yml` (см. `docs/CONFIGURATION.md`, §4.7).

---

## 8. Checklist первого запуска

- [ ] **Вариант «всё внутри плагина»:** `plugins/DiscordMinecraftConsole/embedded/gateway.yml` и `bot.yml`
      созданы, а в логе есть строки `Встроенный режим включён: шлюз ...` и `Discord-бот запущен и работает как ...`.
- [ ] **Вариант «всё внутри плагина»:** `/console list` в Discord возвращает реальный вывод сервера.
- [ ] **Вариант «три компонента»:** `mvn -B clean package` завершился, `dist/` содержит три jar-файла.
- [ ] `java -jar dist/dmc-gateway-1.0.0.jar version` печатает версию и автора.
- [ ] сгенерирован TLS-материал, `--hosts` содержит адрес подключения клиентов.
- [ ] `.env` заполнен, секреты ≥ 16 байт, права на файл `600`.
- [ ] `config/gateway.yml` прошёл загрузку (шлюз стартовал без `CONFIGURATION_ERROR`).
- [ ] `curl /health/ready` возвращает `UP`.
- [ ] бот подключился к шлюзу (в логах шлюза есть аутентификация control-клиента).
- [ ] каждый Minecraft-сервер виден в `/servers` как `ONLINE`.
- [ ] `/discordconsole status` на сервере показывает установленное соединение.
- [ ] `/console` на тестовом сервере возвращает реальный вывод (например, `list`).
- [ ] отказ в правах проверен: пользователь без `console.execute` получает понятный отказ.
- [ ] опасная команда требует подтверждения, подтверждает только инициатор.
- [ ] `/console dryrun` показывает проверки и не выполняет команду.
- [ ] записи появились в аудите (`audit_log`), критические события — в `security_audit`.
- [ ] `/metrics` отдаёт `dmc_commands_total` и растёт при выполнении команд.

Дальше: `docs/CONFIGURATION.md` — тонкая настройка, `docs/PERMISSIONS.md` — права,
`docs/DEPLOYMENT.md` — продакшен-развёртывание.