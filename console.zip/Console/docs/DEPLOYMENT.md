# Развёртывание в production

Автор: **Zigono** · версия 1.0.0

Документ описывает запуск шлюза и бота под systemd, подготовку PostgreSQL и Redis, сетевые
правила, мониторинг, масштабирование, резервное копирование и безопасное обновление.

---

## 1. Топология

### 1.1. Один хост (минимум для production)

```text
                Internet
                   │
                   │ Discord Gateway (исходящие соединения)
                   ▼
   ┌──────────────────────────────┐      ┌──────────────────────┐
   │  Discord Bot (systemd)       │      │  Minecraft серверы   │
   │  исходящее TLS к шлюзу       │      │  плагин Paper 1.21.1 │
   └───────────┬──────────────────┘      └──────────┬───────────┘
               │ 8443/tcp                           │ 8443/tcp (исходящее)
               ▼                                    ▼
   ┌────────────────────────────────────────────────────────────┐
   │  Secure Gateway (systemd, непривилегированный пользователь) │
   │  :8443 протокол · :9100 метрики, /health/*                  │
   └───────────┬───────────────────────────────┬────────────────┘
               │ TCP 5432                      │ TCP 6379 (опционально)
               ▼                               ▼
        ┌─────────────┐                ┌─────────────┐
        │ PostgreSQL  │                │   Redis     │
        └─────────────┘                └─────────────┘
```

### 1.2. Горизонтальное масштабирование (§60)

```text
                     ┌── Gateway 1 ──┐
Discord ── Bot ──────┼── Gateway 2 ──┼──── Minecraft серверы
                     └── Gateway 3 ──┘
                              │
                        ┌─────┴─────┐
                        │   Redis   │  распределённый rate limit,
                        └───────────┘  маршрутизация команд к владельцу соединения
```

Правила масштабирования:

- **бот — один процесс** (или несколько с одинаковым `control.clients.discord-bot`, если Discord
  это допускает): команды идут в шлюз, который умеет маршрутизировать их дальше;
- у каждого экземпляра шлюза свой `gateway.id` и **свой TLS-сертификат** (клиенты подключаются к
  конкретному адресу, балансировщик перед плагинами не нужен: плагины идут на один адрес);
- все экземпляры используют **одну БД** и **один Redis** с одинаковым `redis.key_prefix`;
- Redis обязателен: без него экземпляр, к которому не подключён плагин сервера, не сможет
  выполнить команду (получит `SERVER_OFFLINE`), а rate limit будет локальным;
- Minecraft-сервер подключается к одному экземпляру; переподключение после сбоя автоматически
  переводит сервер на другой экземпляр (соединение устанавливает клиент).

---

### 1.3. Панельный хостинг (Pterodactyl): шлюз и бот внутри плагина

Когда Minecraft-сервер куплен на панельном хостинге, отдельный хост под шлюз и бот недоступен: ни второй
контейнер, ни второй порт, ни systemd. Для этого случая есть встроенный режим плагина
(`embedded.enabled: true`, см. `docs/CONFIGURATION.md` §4.1 и `docs/INSTALLATION.md` §2): тот же шлюз и
тот же бот запускаются внутри процесса Minecraft-сервера.

| Свойство | Значение |
|---|---|
| Что устанавливается | один jar в `plugins/` |
| Порты | только порт Minecraft; шлюз слушает `127.0.0.1` на свободном порту внутри контейнера |
| TLS | не нужен: трафик не покидает машину, конфигурация генерируется с `allow_insecure_transport: true` на loopback |
| База аудита | SQLite `plugins/DiscordMinecraftConsole/embedded/data/gateway.db` |
| Метрики | эндпоинт не поднимается, состояние видно в `/discordconsole status` |
| Изоляция | один сервер = один бот и одна гильдия; чужие серверы не видны |
| systemd/firewall/Redis | не нужны |

Поставляемый `plugins/DiscordMinecraftConsole/config.yml` уже заполнен рабочими значениями — токен бота,
гильдия, роль с полным доступом и канал консоли, — поэтому при первом запуске достаточно положить jar в
`plugins/` и перезапустить сервер. Если YAML окажется повреждён (табы вместо пробелов, сбитые отступы),
плагин **не отключается**: прежний файл сохраняется рядом как `config.yml.broken-<дата-время>`, а на его место
пишется стандартный — см. `docs/TROUBLESHOOTING.md` §14. Если в консоли панели вместо русских букв видны
«кракозябры», добавьте серверу переменную `LANG=C.UTF-8`.

Ограничение: это режим «один сервер — один бот». Как только серверов становится несколько и нужна общая
база аудита, права между серверами и эндпоинт метрик — переходите на топологию из §1.1, поставив в
конфигурации плагина `embedded.enabled: false` (см. `docs/UPGRADE.md` §4.4).

Бэкап в этом режиме — это `plugins/DiscordMinecraftConsole/` целиком: конфигурация, сгенерированные файлы,
секреты и SQLite-база в одном каталоге.

---

## 2. Подготовка PostgreSQL

```sql
CREATE ROLE dmc LOGIN PASSWORD 'strong-password';
CREATE DATABASE dmc OWNER dmc ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C' TEMPLATE template0;
\c dmc
GRANT ALL ON SCHEMA public TO dmc;
```

Требования:

- PostgreSQL 13+; при нескольких экземплярах шлюза — обязателен;
- `database.postgresql.pool_size` × число экземпляров шлюза не должно превышать `max_connections`;
- миграции применяются шлюзом автоматически, отдельный пользователь-мигратор не требуется;
- проверка: `psql "postgresql://dmc@db:5432/dmc" -c "select version from schema_migrations;"`.

Переключение SQLite → PostgreSQL: задайте `database.type: postgresql`, параметры подключения,
перезапустите шлюз (миграции создадут схему). Историческую часть `audit_log` из SQLite можно
перенести вручную через `COPY`, если она нужна в новой базе.

---

## 3. Подготовка Redis (опционально)

```conf
# /etc/redis/redis.conf (фрагмент)
bind 10.0.0.10
requirepass strong-redis-password
appendonly yes
maxmemory-policy noeviction
```

```yaml
redis:
  enabled: true
  uri: redis://10.0.0.10:6379
  password: ${REDIS_PASSWORD}
  key_prefix: dmc:
  timeout: 2s
```

Redis используется только для координации и распределённого rate limit: потеря Redis переводит
probe `/health/ready` в `DOWN` (экземпляр перестаёт быть «готовым»), но не приводит к выполнению
команд в обход лимитов — шлюз не считает себя готовым, пока Redis недоступен.

---

## 4. systemd: шлюз

`/etc/systemd/system/dmc-gateway.service`:

```ini
[Unit]
Description=Discord Minecraft Console Gateway (author: Zigono)
Documentation=https://github.com/zigono/discord-minecraft-console
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
Type=simple
User=dmc
Group=dmc
WorkingDirectory=/opt/dmc
EnvironmentFile=/etc/dmc/dmc.env
ExecStart=/usr/bin/java -XX:MaxRAMPercentage=75 -XX:+ExitOnOutOfMemoryError \
          -Dfile.encoding=UTF-8 \
          -jar /opt/dmc/dmc-gateway-1.0.0.jar run --config /opt/dmc/config/gateway.yml
SuccessExitStatus=143
Restart=on-failure
RestartSec=5s
TimeoutStopSec=60s

# Ограничения безопасности
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/dmc/data /opt/dmc/logs
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

## 5. systemd: бот

`/etc/systemd/system/dmc-bot.service`:

```ini
[Unit]
Description=Discord Minecraft Console Bot (author: Zigono)
After=network-online.target dmc-gateway.service
Wants=dmc-gateway.service

[Service]
Type=simple
User=dmc
Group=dmc
WorkingDirectory=/opt/dmc
EnvironmentFile=/etc/dmc/dmc.env
ExecStart=/usr/bin/java -XX:MaxRAMPercentage=60 -XX:+ExitOnOutOfMemoryError \
          -Dfile.encoding=UTF-8 \
          -jar /opt/dmc/dmc-bot-1.0.0.jar --config /opt/dmc/config/bot.yml
Restart=always
RestartSec=10s
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/dmc/logs

[Install]
WantedBy=multi-user.target
```

Управление:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now dmc-gateway dmc-bot
sudo journalctl -u dmc-gateway -f
sudo systemctl reload-or-restart dmc-gateway   # конфигурация также подхватывается hot reload
```

Перезапуск бота не влияет на Minecraft-серверы: их соединения идут к шлюзу.

---

## 6. Сеть, firewall и reverse proxy

```bash
# Доступ к протоколу только с адресов бота и Minecraft-серверов
sudo ufw allow from 10.0.0.0/24 to any port 8443 proto tcp
sudo ufw deny 8443/tcp
# Метрики — только из сети мониторинга
sudo ufw allow from 10.0.10.0/24 to any port 9100 proto tcp
sudo ufw deny 9100/tcp
```

Дополнительно на уровне шлюза:

```yaml
network:
  allowed_ips:
    - "10.0.0.0/24"     # Minecraft-серверы
    - "10.0.1.5"        # хост бота
    - "192.168.1.0/24"
```

Проксирование:

- **Плагины не должны ходить через HTTP-прокси**: это raw TLS-протокол, а не HTTPS.
- Если между клиентами и шлюзом стоит L4-балансировщик (HAProxy/NLB/F5), используйте режим
  `tcp`/`ssl passthrough` (SNI, без терминации TLS) — иначе ломается проверка имени хоста и
  привязка сертификатов.
- Для `/metrics` и `/health/*` можно поставить reverse proxy с базовой аутентификацией или
  ограничением по IP; сам эндпоинт аутентификации не имеет.
- Ограничьте частоту новых TCP-соединений на периметре (например, `limit_conn` в nginx для
  health-трафика) — протокол предполагает долгоживущие соединения.

---

## 7. Мониторинг

Эндпоинты:

| Путь | Назначение | Коды |
|---|---|---|
| `/metrics` | Prometheus text exposition | 200 |
| `/health` | Итоговое состояние (`live` + `ready`), uptime | 200 / 503 |
| `/health/live` | Процесс жив (не в shutdown) | 200 / 503 |
| `/health/ready` | Готов принимать команды: слушатель поднят, БД доступна, Redis (если включён) здоров | 200 / 503 |

Метрики (префикс `dmc_`):

| Метрика | Тип | Смысл |
|---|---|---|
| `dmc_commands_total` | counter | Всего запросов на выполнение |
| `dmc_commands_success_total` | counter | Успешные выполнения |
| `dmc_commands_failed_total` | counter | Неуспешные выполнения |
| `dmc_commands_denied_total` | counter | Отказы (права, политика, лимит, подтверждение) |
| `dmc_commands_received_total`, `dmc_commands_dryrun_total` | counter | Разделение по типу запроса |
| `dmc_command_latency` | summary | Гистограмма (5…10000 мс), `_count`, `_sum`, `_max` |
| `dmc_connected_servers` | gauge | Серверы в состоянии ONLINE/DEGRADED |
| `dmc_offline_servers` | gauge | Недоступные серверы |
| `dmc_queue_size` | gauge | Суммарная длина очередей |
| `dmc_pending_dispatches` | gauge | Ожидающие результаты выполнения |
| `dmc_plugin_sessions` | gauge | Активные сессии плагинов |
| `dmc_emergency_mode` | gauge | Аварийный режим включён (1/0) |
| `dmc_rate_limit_hits` | counter | Срабатывания лимитов |
| `dmc_authentication_failures` | counter | Неудачные аутентификации |
| `dmc_replay_rejections` | counter | Отклонённые replay |
| `dmc_protocol_violations` | counter | Нарушения протокола |
| `dmc_rejected_connections_total` | counter | Соединения, отклонённые allowlist |
| `dmc_audit_write_failures` | counter | Ошибки записи аудита (тревожный сигнал) |
| `dmc_uptime_seconds` | gauge | Аптайм процесса |

Пример `prometheus.yml`:

```yaml
scrape_configs:
  - job_name: dmc-gateway
    metrics_path: /metrics
    static_configs:
      - targets: [ "10.0.0.10:9100" ]
```

Рекомендуемые алерты: `up == 0`; `dmc_audit_write_failures > 0`; `dmc_emergency_mode == 1`;
`dmc_connected_servers < ожидаемого`; рост `dmc_authentication_failures` или
`dmc_protocol_violations`; `dmc_queue_size` у предела `queue.max_size`;
`rate(dmc_commands_denied_total[5m])` выше обычного.

Логи: JSON (или text) в `logs/gateway.log` с ротацией; каждая запись содержит `request_id`,
который связывает действие в Discord, шлюз, Minecraft и аудит.

---

## 8. Резервное копирование и retention

PostgreSQL:

```bash
# Ежедневный дамп с сжатием
pg_dump "postgresql://dmc@10.0.0.11:5432/dmc" -Fc -f /backup/dmc-$(date +%F).dump

# Восстановление
pg_restore -d "postgresql://dmc@10.0.0.11:5432/dmc" --clean --if-exists /backup/dmc-2026-09-15.dump
```

SQLite:

```bash
sqlite3 /opt/dmc/data/dmc.db "VACUUM INTO '/backup/dmc-$(date +%F).db'"
```

Retention:

```yaml
database:
  retention:
    enabled: true
    days: 90             # audit_log
    security_days: 365   # security_audit (0 = хранить вечно)
    interval_hours: 6    # целое число часов, минимум 1
```

Рекомендации: держите бэкапы вне хоста шлюза, проверяйте восстановление раз в квартал,
для security audit используйте срок, соответствующий политике вашей организации, и не удаляйте
её ручными запросами.

Плановая проверка целостности данных:

```sql
-- Ошибки записи аудита
SELECT count(*) FROM audit_log WHERE status = 'INTERNAL_ERROR';
-- Отказы и нарушения протокола за сутки
SELECT event_type, severity, count(*) FROM security_audit
WHERE created_epoch_ms > (extract(epoch from now()) * 1000 - 86400000)
GROUP BY 1, 2 ORDER BY 3 DESC;
```

---

## 9. Безопасность развёртывания

- шлюз и бот работают от отдельного системного пользователя, без root (`NoNewPrivileges`,
  `ProtectSystem=strict`);
- конфигурация и TLS-материал доступны только этому пользователю (`chmod 600`, владелец `dmc`);
- секреты — в `EnvironmentFile`/секретах оркестратора, не в unit-файлах с правами `644`;
- файл конфигурации шлюза (`gateway.yml`) может быть доступен для записи только администраторам:
  hot reload применяет изменения немедленно;
- `/metrics` и `/health/*` не публикуйте в интернет;
- включите `tls.require_client_certificate: true`, если хотите требовать клиентский сертификат в
  дополнение к HMAC-подписи;
- версия Java и ОС должны получать обновления безопасности; образ содержит `ca-certificates`.

---

## 10. Порядок остановки и обновления

Graceful shutdown шлюза (по `SIGTERM` или `systemctl stop`):

1. прекращается приём новых команд (`/health/ready` → `DOWN`, `live` → `false`);
2. активные команды завершаются или корректно отменяются;
3. очередь обрабатывается по политике `queue.on_disconnect`;
4. закрываются соединения (клиентам отправляется `SHUTDOWN` при graceful shutdown);
5. останавливается retention и HTTP-эндпоинт;
6. закрываются Redis-соединения и БД.

Безопасный порядок обновления компонентов (подробности — `docs/UPGRADE.md`):

```bash
# 1. Шлюз (сначала он: он принимает новые и старые версии клиентов)
sudo systemctl stop dmc-gateway
sudo cp dist/dmc-gateway-1.0.0.jar /opt/dmc/
sudo cp -r dist/dmc-gateway-1.0.0.jar.new /opt/dmc/   # при обновлении версии
sudo systemctl start dmc-gateway
curl -fsS http://127.0.0.1:9100/health/ready

# 2. Бот
sudo systemctl restart dmc-bot

# 3. Плагины Minecraft (по одному, в окно обслуживания)
#    заменить jar в plugins/, перезапустить сервер, проверить /servers
```

---

## 11. Проверка развёртывания

```bash
systemctl status dmc-gateway dmc-bot
curl -fsS http://127.0.0.1:9100/health
curl -fsS http://127.0.0.1:9100/metrics | grep -E 'dmc_(connected_servers|offline_servers|queue_size)'
journalctl -u dmc-gateway --since '15 min ago' | grep -i -E 'auth|violation|error'
psql "postgresql://dmc@10.0.0.11:5432/dmc" -c "select count(*) from audit_log where created_epoch_ms > (extract(epoch from now())*1000 - 3600000);"
```

В Discord: `/servers` должен показать все серверы `ONLINE`, `/console dryrun` — пройти все проверки,
`/console` — вернуть реальный вывод серверной консоли.