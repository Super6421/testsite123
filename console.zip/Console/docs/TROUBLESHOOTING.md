# Диагностика неполадок

Автор: **Zigono** · версия 1.0.0

Формат: **симптом → причина → решение**. Все команды приведены для Linux; пути соответствуют
развёртыванию из `docs/DEPLOYMENT.md`.

Первое, что стоит собрать при любой проблеме:

```bash
java -jar /opt/dmc/dmc-gateway-1.0.0.jar version
curl -s http://127.0.0.1:9100/health ; echo
curl -s http://127.0.0.1:9100/metrics | grep -E 'dmc_(authentication_failures|protocol_violations|replay_rejections|connected_servers|queue_size)'
sudo journalctl -u dmc-gateway -n 100 --no-pager
sudo journalctl -u dmc-bot -n 100 --no-pager
```

---

## 1. Плагин не подключается к шлюзу

| Симптом | Причина | Решение |
|---|---|---|
| В логах плагина `Connection refused` / `timeout` | Шлюз не слушает адрес/порт, неверный `network.host`/`port` | `ss -lntp \| grep 8443`; сравните `network.host`/`network.port` в конфигурации плагина с `network.port` шлюза; проверьте firewall |
| Шлюз закрывает соединение сразу после подключения, в `security_audit` событие `IP_NOT_ALLOWED` | Адрес сервера не входит в `network.allowed_ips` | Добавьте адрес/CIDR в allowlist или уберите ограничение: `network.allowed_ips: []` |
| Плагин подключается, но не появляется в `/servers` | Не завершена аутентификация: неверный `server.id` или секрет | `SELECT event_type, detail FROM security_audit ORDER BY id DESC LIMIT 20;` — событие `AUTHENTICATION_FAILED` с пояснением; сверьте `server.id` с ключом `servers.<id>` и секрет с `servers.<id>.secret` |
| В логе шлюза `unknown client id 'survival'` | Такого сервера нет в конфигурации шлюза | Добавьте `servers.survival` (с `secret`) и перезагрузите конфигурацию |
| В логе `server 'survival' is disabled` | `servers.survival.enabled: false` | Включите сервер |
| В логе `plugin identity 'x' may not claim server 'y'` | В конфигурации плагина `server.id` и `server.name`/`serverId` расходятся | Приведите `server.id` к ключу конфигурации шлюза |
| Плагин работает, шлюз не видит heartbeat | Плагин не в главном потоке/нестартовал scheduler | Проверьте лог плагина на исключения при регистрации задач |

---

## 2. `AUTH_FAILED`

| Симптом | Причина | Решение |
|---|---|---|
| В `/servers` статус `AUTH_FAILED` | Секрет клиента не совпадает с конфигурацией шлюза | Сверьте `servers.<id>.secret` и секрет в конфигурации плагина; после смены секрета перезапустите обе стороны |
| `authentication challenge mismatch` | Соединение используется повторно/подменено, либо клиент неверно реализует handshake | Перезапустите плагин; проверьте, что между клиентом и шлюзом нет TLS-терминирующего балансировщика |
| `invalid signature on COMMAND_RESULT` | У клиента другой секрет либо сообщение изменено посредником | Проверьте секреты; убедитесь, что никто не модифицирует трафик (см. `dmc_authentication_failures`) |
| `message timestamp outside the accepted window` | Расхождение часов больше 120 секунд | Включите/исправьте NTP на шлюзе и на серверах Minecraft |
| `message without nonce/request id` | Клиент собран из другого кода/очень старая версия | Обновите плагин/бота до текущей версии |
| Бот получает `AUTHENTICATION_FAILED` | `control.clients.<id>` отсутствует или секрет другой | Сверьте `control.client_id` бота с ключом в конфигурации шлюза |

---

## 3. Ошибки TLS handshake

| Симптом | Причина | Решение |
|---|---|---|
| `PKIX path building failed` / `unable to find valid certification path` | Клиент не доверяет CA: неверный `truststore` | Разложите `truststore.p12` на клиент, проверьте `tls.truststore` и `tls.truststore_password` |
| `No subject alternative DNS name matching … found` | В сертификате шлюза нет имени/адреса, по которому подключается клиент | Перегенерируйте сертификат с нужным `--hosts` и разложите заново |
| `SSLHandshakeException: Received fatal alert: certificate_required` | Включён `tls.require_client_certificate: true`, а у клиента нет сертификата | Установите `client-<id>.p12` на клиенте или отключите требование |
| `unsupported protocol` / handshake с TLS 1.0-1.1 | `tls.protocols` ограничивает 1.2/1.3 | Обновите клиент/Java или расширьте список протоколов |
| `keystore password was incorrect` | Неверный `tls.keystore_password`/`key_password` | Проверьте пароль: `openssl pkcs12 -in gateway.p12 -noout -passin pass:...` |
| Клиент видит сертификат другого узла | Между клиентом и шлюзом стоит TLS-терминирующий прокси | Настройте passthrough (L4) или используйте корректный сертификат на прокси |

Диагностика:

```bash
openssl s_client -connect gateway.example.com:8443 -servername gateway.example.com -showcerts </dev/null
openssl pkcs12 -in tls/gateway.p12 -nokeys -clcerts | openssl x509 -noout -subject -dates -ext subjectAltName
```

---

## 4. Нарушения протокола и replay

| Симптом | Причина | Решение |
|---|---|---|
| Рост `dmc_protocol_violations`, в аудите `PROTOCOL_VIOLATION` | Несовместимая версия протокола, повреждённый кадр, обращение не по протоколу | Проверьте версии всех компонентов (`version`), убедитесь, что на порт 8443 не ходит посторонний клиент |
| `unsupported protocol version N` | Обновили один компонент, не обновив другой | См. `docs/UPGRADE.md`; шлюз обновляется первым |
| `message without sender identity` / `identity mismatch` | Клиент отправляет сообщения от чужого имени или соединение переиспользуется | Перезапустите клиент; проверьте, что один `clientId` не используется двумя серверами |
| Рост `dmc_replay_rejections` | Расхождение часов, повторное использование `requestId`/`nonce`, либо попытка replay | Проверьте NTP; если часовой пояс в порядке — считайте это инцидентом безопасности и разберите записи `security_audit` |
| `malformed message` | Обрезанный/некорректный JSON, часто после «оптимизаций» прокси или MTU | Убедитесь, что прокси работает в режиме passthrough и не буферизует/переписывает поток |

---

## 5. Очередь заполнена, лимиты и подтверждения

| Симптом | Причина | Решение |
|---|---|---|
| `QUEUE_FULL` | `queue.max_size` достигнут: сервер не успевает обрабатывать команды | Проверьте `dmc_queue_size`, `dmc_pending_dispatches`; уменьшите частоту команд или увеличьте `queue.max_size`/`queue.timeout_seconds` |
| `RATE_LIMIT` | Сработал лимит (`per_user`, `per_role`, `per_server`, `per_command`, `per_group` или `global`) | Сообщение указывает область и время до повтора; метрика `dmc_rate_limit_hits`; при необходимости скорректируйте `rate_limit.*` |
| Лимит срабатывает «непонятно почему» при нескольких шлюзах | Redis выключен ⇒ лимиты локальные для каждого экземпляра | Включите `redis.enabled: true` и общий `redis.key_prefix` |
| `CONFIRMATION_REQUIRED` при каждой попытке | Подтверждение истекло (`confirmation.timeout_seconds`) или нажимает другой пользователь | Подтверждать должен инициатор и в течение TTL; проверьте часы на хосте бота |
| `EMERGENCY_MODE` | Включён аварийный режим | Переключите состояние пользователем с `console.emergency.*`; проверьте `dmc_emergency_mode` и таблицу `gateway_state` |
| Команда в `hold` не выполняется | Плагин не переподключился за `queue.hold_timeout` | Проверьте соединение плагина; при частых обрывах используйте `on_disconnect: cancel`, чтобы не копить команды |
| Команда выполнилась дважды | Неверная настройка повторов вне системы (внешние скрипты) | Система не повторяет принятые команды: `COMMAND_ACCEPTED` отключает retry. Проверьте, не отправляет ли команду что-то ещё |

---

## 6. Права: пользователь не видит серверы

| Симптом | Причина | Решение |
|---|---|---|
| Пустой список в `/console` | Нет ни `console.server.<id>`, ни `console.broadcast.all` | Назначьте права роли: см. `docs/PERMISSIONS.md` |
| Видны не все серверы | Часть серверов закрыта `deny` или отсутствием прав | `/console dryrun` покажет отказ; проверьте `permissions.roles.<roleId>.deny` |
| «Вам недоступен ни один сервер» при наличии прав | Ограничения каналов или гильдии | `guilds.<guildId>.channels.allowed/denied`, `console.read`/`console.servers` |
| Отказ только в одном канале | Канал в `channels.denied` | Уберите канал из списка или используйте разрешённый |
| Права изменили, но эффекта нет | Конфигурация не перезагружена | Ждите hot reload (~2 с) или используйте `console.admin.reload` |
| Пользователь с ролью в другой гильдии не имеет прав | Изоляция гильдий: роли действуют только в своей гильдии | Назначьте права в `guilds.<guildId>.permissions.roles.<roleId>` |

Проверка `deny`-приоритета: если пользователь имеет `console.*` и `console.execute` в `deny`,
выполнение запрещено — это ожидаемое поведение.

---

## 7. LuckPerms: узлы не видны

| Симптом | Причина | Решение |
|---|---|---|
| Игрок не видит анонсы Discord Console | Нет `discordconsole.monitor`, либо `minecraft.visibility.mode: permission` | Выдайте право: `/lp user <ник> permission set discordconsole.monitor true`; проверьте `/lp user <ник> permission check discordconsole.monitor` |
| Право выдано, но не действует | LuckPerms не загрузился или плагин включён без интеграции | Проверьте `/plugins` (LuckPerms активен) и `luckperms.enabled: true` в конфигурации плагина |
| Анонс виден, но без текста команды, результата или имени сервера | Включены уточнения `luckperms.commands_permission` / `results_permission` / `servers_permission`, а право не выдано | Выдайте узел из настройки (например `/lp group admin permission set discordconsole.monitor.commands true`) либо оставьте соответствующее уточнение пустым, чтобы базового `monitor_permission` было достаточно |
| Анонс виден всем, хотя ожидался только для администраторов | Режим видимости `mode: default` вместе с `visibility.default: true` | Переключите `minecraft.visibility.mode: permission` (или `nobody`) и проверьте `default` |
| Команда вообще не анонсируется | Команда в `hidden_commands` или `discord_console_visibility.enabled: false` | Уберите команду из списка или включите отображение |
| Игрок видит чужие команды другого сервера | Анонс идёт в общий канал сервера | Используйте `discordconsole.monitor.servers` для детализации; анонсы приходят только на сервер, выполнивший команду |
| Права LuckPerms выданы, но текст в формате «сырой» (`&7`) | Формат не поддерживает legacy-цвета в вашей версии клиента | Используйте `&`-коды (плагин конвертирует их) или MiniMessage-совместимый формат в `format` |

---

## 8. PostgreSQL

| Симптом | Причина | Решение |
|---|---|---|
| Шлюз не стартует: `Не удалось применить миграции базы данных` (перед ней в логе — строки HikariCP) | Неверные параметры подключения, БД недоступна | `psql "postgresql://dmc@host:5432/dmc" -c 'select 1'`; проверьте `database.postgresql.*` и `PGPASSWORD` |
| `password authentication failed for user "dmc"` | Неверный пароль или `pg_hba.conf` | Проверьте пароль в окружении; для удалённого доступа нужна строка `host dmc dmc <cidr> scram-sha-256` |
| `too many connections` | `pool_size` × число экземпляров больше лимита | Уменьшите `database.postgresql.pool_size` или увеличьте `max_connections` |
| `/health/ready` возвращает `DOWN` | `database.healthy()` = false | Проверьте доступность БД и логи HikariCP (уровень INFO в `logback.xml` шлюза) |
| `dmc_audit_write_failures` растёт | Запись аудита падает (диск, права, блокировки) | Смотрите `journalctl -u dmc-gateway \| grep -i audit`; проверьте свободное место и права таблиц |

---

## 9. Redis

| Симптом | Причина | Решение |
|---|---|---|
| `/health/ready` = `DOWN`, в логе `Межэкземплярная координация … Redis` | Redis недоступен, а `redis.enabled: true` | Восстановите Redis или отключите `redis.enabled` (лимиты станут локальными) |
| `NOAUTH Authentication required` | Не задан `redis.password` | Укажите пароль; проверьте `redis-cli -a … ping` |
| Команда уходит «в пустоту» при нескольких шлюзах | Разные `redis.key_prefix` у экземпляров | Приведите `key_prefix` к одному значению |
| Команды выполняются, но результат не приходит | Экземпляр, владеющий соединением сервера, недоступен | Проверьте `pending_dispatches`/`dmc_pending_dispatches` на всех экземплярах; сервер переподключится к живому экземпляру |

---

## 10. Миграции БД

| Симптом | Причина | Решение |
|---|---|---|
| Шлюз не стартует: ошибка миграции | Недостаточно прав у пользователя БД или расхождение схемы | Проверьте права (`GRANT ALL ON SCHEMA public`), затем `select * from schema_migrations;` |
| `syntax error at or near …` на PostgreSQL | База создана не под PostgreSQL-диалект (например, дамп из SQLite) или старая версия PostgreSQL | Создайте чистую базу (`TEMPLATE template0`) и дайте шлюзу применить миграции |
| `database is locked` (SQLite) | Одновременный доступ другого процесса/копирование файла | Не запускайте два шлюза на одном SQLite-файле; для резервной копии используйте `VACUUM INTO`, а не копирование «на живую» |
| Таблицы не создаются | Указан `database.type: sqlite`, а проверяете PostgreSQL (или наоборот) | Сверьте `database.type` с фактической базой, в которую подключаетесь |
| нужно откатить миграцию | Автоматического отката нет | Восстановите БД из дампа и запустите прежнюю версию шлюза |

---

## 11. Высокая задержка выполнения

| Симптом | Причина | Решение |
|---|---|---|
| `dmc_command_latency` растёт, команды выполняются медленно | Очередь сервера забита, медленный плагин, перегрузка Minecraft | Проверьте `dmc_queue_size`, TPS/MSPT в `/servers`, `execution.max_concurrent` |
| Задержка только при рассылке | `broadcast.execution: sequential` | Переключите на `parallel` (или наоборот, если важна предсказуемость) |
| Высокая задержка между шлюзом и сервером | Сетевые задержки, TLS-прокси, geodistributed хосты | Разместите шлюз рядом с Minecraft-серверами; проверьте `dmc_plugin_sessions` и латентность в метриках плагина |
| Команды ждут часами | Включён `hold` и удержанные команды накапливаются | Проверьте `queue.on_disconnect`; при нестабильных серверах предпочтителен `cancel` |
| Ответ приходит мгновенно, но пустой | Плагин не захватил вывод | См. следующий раздел |

---

## 12. Нет вывода консоли (пустой ответ)

| Симптом | Причина | Решение |
|---|---|---|
| Статус `SUCCESS`, но `Сервер не вернул вывода` | `capture.enabled: false` или вывод не успел появиться | Включите `capture.enabled: true`, увеличьте `capture.quiet_period_ms`/`capture.max_wait_ms` |
| Вывод обрезан | `capture.max_lines` слишком мал, либо сработал порог вложения | Увеличьте `capture.max_lines`/`capture.max_chars`; при больших выводах используйте `responses.large_output.mode: attachment` |
| Вывод есть в консоли сервера, но не в Discord | Слишком маленькие `capture.max_lines`/`capture.max_chars` или короткий `capture.quiet_period_ms` | Увеличьте лимиты захвата |
| Команда не распознана, `FAILED` | Опечатка/несуществующая команда; политика не при чём | Проверьте команду в консоли сервера вручную; сообщение плагина `command.unknown` |
| Вывод дублируется в игре | Включены и анонс, и показ результата, и эхо в консоль | Отключите `minecraft.visibility.show_results` или `logging.command_echo` |

---

## 13. Прочие проблемы

| Симптом | Причина | Решение |
|---|---|---|
| `Configuration file not found` | Неверный путь `--config` | Укажите абсолютный путь: `run --config /opt/dmc/config/gateway.yml` |
| `Environment variable X referenced by … is not set` | Секрет не проброшен | Добавьте переменную в `EnvironmentFile`/`.env`; для необязательных значений используйте `${VAR:default}` |
| `secret for X must be at least 16 bytes long` | Слишком короткий секрет | `openssl rand -hex 32` |
| `secret for X must be at least 16 bytes` при проверке `hex:` | В `hex:` меньше 32 hex-символов | Сгенерируйте 32+ hex-символа |
| `protocol_version N is not supported by gateway build` | Конфигурация от другой версии | Приведите `protocol_version` к версии сборки |
| `queue.on_disconnect must be one of …` | Опечатка в значении | Допустимо: `cancel`, `hold`, `retry` |
| `rate_limit.X.requests must not be negative` | Отрицательное значение | Исправьте на 0 (без лимита) или положительное число |
| Hot reload не применил изменения | Изменён раздел `network`/`tls`/`database`/`redis`/`metrics` | Требуется перезапуск; в логе есть предупреждение |
| Шлюз не останавливается по `systemctl stop` | Активная команда/ожидание очереди | `TimeoutStopSec=60s` в unit-файле; проверьте логи graceful shutdown |
| Бот не регистрирует slash-команды | Глобальная регистрация кэшируется Discord | Используйте `discord.test_guild_id` для мгновенной проверки или подождите до часа |
| «Ошибка конфигурации, обратитесь к администратору» в Discord | `CONFIGURATION_ERROR` (внутренняя причина не показывается пользователю) | Смотрите лог шлюза/бота по `request_id` из ответа |

---

## 14. Встроенный режим: бот, Discord, loopback

| Симптом | Причина | Решение |
|---|---|---|
| В логе `Discord-бот не запущен: впишите токен ...` | не задан токен либо плейсхолдер не подставился | вписать `embedded.discord.token` в `config.yml` или задать переменную окружения `DISCORD_TOKEN`; перезапустить сервер |
| `Discord-бот не запустился: ... status is FAILED_TO_LOGIN` | токен отозван, скопирован с лишними символами или сменён пароль приложения | `Bot` → `Reset Token` в Discord Developer Portal, вставить новый токен |
| Бот онлайн, но slash-команд нет | бот приглашён без `applications.commands` | перепригласить по OAuth2-ссылке с нужными scope; команды регистрируются при старте |
| `No compatible encryption modes` или ошибки TLS в логе | для loopback-режима TLS не нужен, но он включён в `tls.enabled` | во встроенном режиме `tls` игнорируется; проверьте, что `embedded.enabled: true`, а не `false` |
| `Встроенный режим включён: шлюз ... работает внутри этого сервера на 127.0.0.1:0` | порт 0 = «выбрать свободный»; в этой строке должен быть реальный номер | если номер 0 — плагин не смог поднять слушатель, смотрите предыдущие строки лога |
| В логе `Некорректный YAML в .../config.yml` или `Значение конфигурации ... в ...` | файл конфигурации повреждён: табы вместо пробелов, сбитые отступы, лишние символы, недопустимое значение | плагин **не отключается**: прежний файл сохраняется рядом как `config.yml.broken-<дата-время>`, а на его место пишется стандартный `config.yml`; перенесите свои значения обратно и перезапустите сервер |
| Плагин отключился с `Discord Minecraft Console отключён` | не удалось прочитать сам файл конфигурации (нет прав, файл занят) или не сохранить его копию | в логе `config.yml` указан явно: проверьте права на каталог `plugins/DiscordMinecraftConsole/`, исправьте YAML вручную |
| Соединение есть, но команды не приходят | у пользователя нет прав в ACL `embedded.permissions` | выдать роль/пользователю `console.read`, `console.status`, `console.execute` (см. `docs/PERMISSIONS.md`) |
| Команды идут, но нельзя управлять каналом | `embedded.discord.channels.denied` или режим каналов бота | убрать канал из deny-списка, перезапустить сервер |
| Не хочется держать бота в гильдии постоянно | бот виден всем участникам | ограничить гильдию через `embedded.discord.guilds` и выдавать права только доверенным ролям |
| В логе одна строка `Команды консоли отклонены: ... Пользователь ...` | кто-то вызвал команду в канале, которого нет в `embedded.discord.channels.allowed` | это не ошибка: отказ виден пользователю в Discord. Повторные попытки в том же канале пишутся только в debug-журнал, чтобы не засорять консоль сервера |
| В логе `uncaught exception ... CommandAutoCompleteInteractionEvent` на каждое нажатие клавиши | старая сборка: автодополнение не умело отклоняться без исключения | обновите jar плагина: начиная с 1.0.0 отказ автодополнения не пишет стектрейс |
| В логе каждые 5 минут строка `команд=... успешно=...` | это метрика плагина (`metrics.log_interval_seconds`) | она пишется на уровне DEBUG; счётчики всегда доступны по `/discordconsole status`, а интервал меняется в `config.yml` |
| В логе видно `В config.yml объявлены другие серверы (...), но embedded.network оставлен по умолчанию` | серверы сети объявлены, но шлюз слушает только loopback на случайном порту | задайте `embedded.network.host` (например `0.0.0.0`) и постоянный `port`, откройте порт в панели и перезапустите сервер |
| Нужно посмотреть, что сгенерировалось | файлы лежат в `embedded/` | `gateway.yml` и `bot.yml` пересобираются из `config.yml` при старте |
| Вместо русских букв в логе «кракозябры» | консоль панели читает вывод в неверной кодировке | запускать JVM с `-Dfile.encoding=UTF-8`, а в переменные сервера Pterodactyl добавить `LANG=C.UTF-8` |
| Ответ `группа ... не найдена в LuckPerms` | в `staff.ranks` указана группа, которой нет на сервере | создать её (`/lp creategroup helper`) или исправить `group` в разделе `staff` |
| Ответ `игрок ... не известен LuckPerms` | игрок ещё не заходил на сервер или профиль не загружен | попросить игрока зайти и повторить команду |
| `/logs channel` не включает журнал | канал недоступен боту (нет прав на просмотр или отправку) | выдать боту доступ к каналу и повторить команду |
| Повторная `/logs channel` выключает журнал | так задумано: команда работает как переключатель | чтобы перенести журнал, укажите другой канал |
| В карточках видно `embed.field.user`, `embed.field.status` | старая сборка: имена полей не переводились | обновите jar: подписи берутся из `bot-lang` |

Диагностика: `/discordconsole status` показывает loopback-порт, состояние бота и последнюю ошибку
шлюза; `logging.debug: true` в `config.yml` включает подробный лог.

## 15. Что приложить к обращению за помощью

1. `java -jar dmc-gateway-1.0.0.jar version` (и версии бота/плагина);
2. вывод `/health` и релевантные метрики (`dmc_*`);
3. `request_id` проблемной операции;
4. строки из `gateway.log` с этим `request_id` (файл JSON — можно приложить фрагмент);
5. строку из `audit_log`/`security_audit` по этому `request_id`;
6. версию Paper и список плагинов;
7. ревизию конфигурации шлюза (`revision` из лога старта или `/health`).

Секреты, токены и пароли в обращение не включайте: текст команды из аудита может их содержать,
поэтому прикладывайте только нужные фрагменты.