package ru.zigono.dmc.common.staff;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Иерархия выдачи привилегий должна описываться конфигурацией без скобок и без правок кода: администратор
 * пишет, какая роль Discord какие привилегии выдаёт, и получает ровно это поведение.
 *
 * @author Zigono
 */
class StaffConfigTest {

    @Test
    void readsRanksInEverySupportedForm() {
        final StaffConfig config = StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                  ranks:
                    helper:
                      name: "Хелпер"
                      group: "helper"
                      emoji: "🟢"
                    moderator: "Модератор"
                    director:
                """, "test.yml", false));

        assertEquals(3, config.ranks().size());
        final StaffConfig.Rank helper = config.rank("Helper").orElseThrow();
        assertEquals("helper", helper.group());
        assertEquals("🟢 Хелпер", helper.display());
        final StaffConfig.Rank moderator = config.rank("moderator").orElseThrow();
        assertEquals("moderator", moderator.group());
        assertEquals("Модератор", moderator.display());
        final StaffConfig.Rank director = config.rank("director").orElseThrow();
        assertEquals("director", director.group());
        assertEquals("director", director.display());
    }

    @Test
    void accessAcceptsStringsAndLists() {
        final StaffConfig config = StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                  ranks:
                    helper: "Хелпер"
                    moderator: "Модератор"
                    admin: "Администратор"
                  access:
                    111: "helper, moderator"
                    222: [ "helper", "moderator" ]
                    333: "helper moderator;admin|"
                    444: "*"
                """, "test.yml", false));

        assertTrue(config.allows(List.of("111"), "helper"));
        assertTrue(config.allows(List.of("222"), "moderator"));
        assertTrue(config.allows(List.of("333"), "admin"));
        assertFalse(config.allows(List.of("111"), "admin"));
        assertTrue(config.allows(List.of("444"), "admin"));
        assertFalse(config.allows(List.of(), "helper"));
    }

    @Test
    void accessAllowsOnlyTheConfiguredRanksOfEachRole() {
        final StaffConfig config = StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                  ranks:
                    helper: "Хелпер"
                    moderator: "Модератор"
                    sr_moderator: "Ст. модератор"
                    administrator: "Администратор"
                    sr_administrator: "Ст. администратор"
                    chief_administrator: "Гл. администратор"
                    supervisor: "Супервайзер"
                    director: "Директор"
                  access:
                    1001: "helper, moderator, sr_moderator"
                    1002: "helper, moderator, sr_moderator, administrator, sr_administrator"
                    1003: "helper, moderator, sr_moderator, administrator, sr_administrator, chief_administrator"
                    1004: "*"
                """, "test.yml", false));

        assertTrue(config.allows(List.of("1001"), "sr_moderator"));
        assertFalse(config.allows(List.of("1001"), "administrator"));
        assertTrue(config.allows(List.of("1002"), "sr_administrator"));
        assertFalse(config.allows(List.of("1002"), "chief_administrator"));
        assertTrue(config.allows(List.of("1003"), "chief_administrator"));
        assertFalse(config.allows(List.of("1003"), "supervisor"));
        assertTrue(config.allows(List.of("1004"), "director"));
        assertTrue(config.allows(List.of("1004"), "supervisor"));

        // Роль-модератор и роль-директор у одного пользователя: привилегии складываются.
        assertTrue(config.allows(List.of("1001", "1004"), "director"));
        assertEquals(8, config.allowedRanks(List.of("1004")).size());
        assertEquals(3, config.allowedRanks(List.of("1001")).size());
    }

    @Test
    void rejectsUnknownRanksAndEmptyConfiguration() {
        final ConfigException unknown = assertThrows(ConfigException.class, () -> StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                  ranks:
                    helper: "Хелпер"
                  access:
                    111: "helper, moderator"
                """, "test.yml", false)));
        assertTrue(unknown.getMessage().contains("moderator"), unknown.getMessage());

        final ConfigException empty = assertThrows(ConfigException.class, () -> StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                """, "test.yml", false)));
        assertTrue(empty.getMessage().contains("staff.ranks"), empty.getMessage());
    }

    @Test
    void staysDisabledWithoutASectionAndKeepsCommandNames() {
        assertFalse(StaffConfig.from(YamlConfig.empty("test.yml")).enabled());
        assertFalse(StaffConfig.disabled().enabled());

        final StaffConfig custom = StaffConfig.from(YamlConfig.parse(
                """
                staff:
                  enabled: true
                  commands:
                    grant: "staff-grant"
                    remove: "staff-remove"
                  ranks:
                    helper: "Хелпер"
                """, "test.yml", false));
        assertEquals("staff-grant", custom.grantCommand());
        assertEquals("staff-remove", custom.removeCommand());
        assertEquals(StaffConfig.DEFAULT_GRANT_COMMAND, StaffConfig.disabled().grantCommand());
    }
}