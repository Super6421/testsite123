package ru.zigono.dmc.common.command;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Aliases and templates with their parameter validation rules.
 *
 * @author Zigono
 */
class CommandShortcutsTest {

    private final CommandShortcuts shortcuts = CommandShortcuts.from(YamlConfig.parse("""
            aliases:
              heal:
                command: "cmi heal {player}"
                permission: "console.alias.heal"
              tp:
                command: "minecraft:tp {player} {x} {y}"
                parameters:
                  x: integer
                  y: integer
            templates:
              announce:
                command: "cmi announce {text}"
                permission: "console.template.announce"
                parameters:
                  text: text
            """, "aliases.yml", false), CommandNormalizer.withDefaults());

    @Test
    @DisplayName("alias renders a validated command")
    void rendersAlias() {
        final CommandShortcuts.Shortcut heal = shortcuts.alias("heal").orElseThrow();
        assertEquals("cmi heal Zigono", shortcuts.render(heal, Map.of("player", "Zigono")));
        assertTrue(shortcuts.permits(heal, java.util.List.of("console.alias.heal")));
    }

    @Test
    @DisplayName("invalid parameter values are rejected")
    void rejectsInvalidValues() {
        final CommandShortcuts.Shortcut heal = shortcuts.alias("heal").orElseThrow();
        assertEquals(ErrorCode.INVALID_COMMAND,
                assertThrows(CommandException.class, () -> shortcuts.render(heal, Map.of("player", "Zigono; stop"))).code());
        assertEquals(ErrorCode.INVALID_COMMAND,
                assertThrows(CommandException.class, () -> shortcuts.render(heal, Map.of())).code());

        final CommandShortcuts.Shortcut tp = shortcuts.alias("tp").orElseThrow();
        assertEquals(ErrorCode.INVALID_COMMAND,
                assertThrows(CommandException.class, () -> shortcuts.render(tp, Map.of("y", "1", "player", "Zigono", "x", "stop"))).code());
        assertEquals("minecraft:tp Zigono 10 64", shortcuts.render(tp, Map.of("player", "Zigono", "x", "10", "y", "64")));
    }

    @Test
    @DisplayName("declared but unused parameters are rejected at load time")
    void rejectsUnusedParameters() {
        assertEquals(ConfigException.class, assertThrows(ConfigException.class, () -> CommandShortcuts.from(
                YamlConfig.parse("""
                        templates:
                          broken:
                            command: "say hello"
                            parameters:
                              missing: word
                        """, "aliases.yml", false), CommandNormalizer.withDefaults())).getClass());
    }

    private static void assertTrue(boolean condition) {
        org.junit.jupiter.api.Assertions.assertTrue(condition);
    }
}