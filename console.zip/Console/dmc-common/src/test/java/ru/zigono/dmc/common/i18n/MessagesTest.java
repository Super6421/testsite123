package ru.zigono.dmc.common.i18n;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Localized catalogs: fallback language, overrides and safe formatting.
 *
 * @author Zigono
 */
class MessagesTest {

    @Test
    @DisplayName("english messages are bundled and formatted")
    void englishDefaults() {
        final Messages messages = Messages.load("en", null);
        assertEquals("en", messages.language());
        assertEquals("You do not have permission to do that.", messages.format("error.PERMISSION_DENIED"));
        assertTrue(messages.format("error.SERVER_OFFLINE", "Survival").contains("Survival"));
    }

    @Test
    @DisplayName("russian messages are bundled")
    void russian() {
        final Messages messages = Messages.load("ru", null);
        assertNotEquals("You do not have permission to do that.", messages.format("error.PERMISSION_DENIED"));
        assertTrue(messages.has("panel.title"));
    }

    @Test
    @DisplayName("unknown keys fall back to the key itself")
    void unknownKey() {
        final Messages messages = Messages.load("en", null);
        assertEquals("does.not.exist", messages.format("does.not.exist"));
    }
}