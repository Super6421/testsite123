package ru.zigono.dmc.common.command;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Normalization, validation and blocking of raw console commands.
 *
 * @author Zigono
 */
class CommandNormalizerTest {

    private final CommandNormalizer normalizer = CommandNormalizer.withDefaults();

    @Test
    @DisplayName("leading slash, extra spaces and non breaking spaces are normalized")
    void normalizesWhitespace() {
        final NormalizedCommand command = normalizer.normalize("  /cmi\u00A0  heal    Zigono ");
        assertEquals("cmi heal Zigono", command.normalized());
        assertEquals("cmi", command.root());
        assertEquals("heal Zigono", command.arguments());
        assertEquals(3, command.tokens().size());
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "cmi heal Zigono\nstop",
            "cmi heal\r\nstop",
            "stop\u0000",
            "stop\u001b[31m",
            "cmi heal Zigono; stop",
            "cmi heal Zigono && stop",
            "cmi heal $(whoami)",
            "stop\u2028stop",
            "stop\u200B"})
    @DisplayName("injection attempts are rejected")
    void rejectsInjection(String raw) {
        final CommandException exception = assertThrows(CommandException.class, () -> normalizer.normalize(raw));
        assertEquals(ErrorCode.INVALID_COMMAND, exception.code());
    }

    @Test
    @DisplayName("empty commands are rejected")
    void rejectsEmpty() {
        assertEquals(ErrorCode.INVALID_COMMAND, assertThrows(CommandException.class, () -> normalizer.normalize("   "))
                .code());
        assertEquals(ErrorCode.INVALID_COMMAND, assertThrows(CommandException.class, () -> normalizer.normalize(null))
                .code());
    }

    @Test
    @DisplayName("oversized commands are rejected")
    void rejectsOversized() {
        final String command = "say " + "a".repeat(600);
        assertEquals(ErrorCode.INVALID_COMMAND, assertThrows(CommandException.class, () -> normalizer.normalize(command))
                .code());
    }

    @Test
    @DisplayName("malformed UTF-16 input is rejected")
    void rejectsUnpairedSurrogate() {
        final String malformed = "say \uD800";
        assertEquals(ErrorCode.INVALID_COMMAND,
                assertThrows(CommandException.class, () -> normalizer.normalize(malformed)).code());
    }
}