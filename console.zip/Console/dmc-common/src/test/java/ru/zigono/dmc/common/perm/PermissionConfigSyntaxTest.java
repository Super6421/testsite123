package ru.zigono.dmc.common.perm;

import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Права в конфигурации можно писать тремя способами: строкой без скобок, строкой с разделителями и списком.
 * Все три формы должны давать один и тот же набор прав, потому что именно первая форма попадает в config.yml.
 *
 * @author Zigono
 */
class PermissionConfigSyntaxTest {

    @Test
    void acceptsTheShortFormWithoutBrackets() {
        final PermissionConfig config = PermissionConfig.from(YamlConfig.parse(
                """
                permissions:
                  roles:
                    123456789012345678: console.*
                  users:
                    987654321098765432: console.read, console.status
                """, "test.yml", false), Set.of());

        final PermissionSet role = config.resolve(null, List.of("123456789012345678"), "1");
        assertTrue(role.allows("console.execute"));
        final PermissionSet user = config.resolve(null, List.of(), "987654321098765432");
        assertTrue(user.allows("console.read"));
        assertTrue(user.allows("console.status"));
        assertFalse(user.allows("console.admin.reload"));
    }

    @Test
    void acceptsListsAndEverySeparator() {
        final PermissionConfig config = PermissionConfig.from(YamlConfig.parse(
                """
                permissions:
                  users:
                    1:
                      allow: "console.read console.status"
                    2:
                      allow: [ "console.read", "console.status" ]
                    3:
                      allow: "console.read;console.status|console.history"
                """, "test.yml", false), Set.of());

        for (String id : List.of("1", "2", "3")) {
            final PermissionSet set = config.resolve(null, List.of(), id);
            assertTrue(set.allows("console.read"), id);
            assertTrue(set.allows("console.status"), id);
        }
        assertTrue(config.resolve(null, List.of(), "3").allows("console.history"));
    }

    @Test
    void understandsCommandsLuckPermsPermissionsServersAndGroups() {
        final PermissionConfig config = PermissionConfig.from(YamlConfig.parse(
                """
                permissions:
                  roles:
                    1: "console.read, kick, mute %player%, /tempban"
                    2: "essentials.heal, perm:worldedit.wand"
                    3: "server:survival, group:all, server:*"
                    4:
                      allow: console.execute
                      deny: kick
                """, "test.yml", false), Set.of());

        final PermissionSet commands = config.resolve(null, List.of("1"), "0");
        assertTrue(commands.allows("console.read"), "права консоли читаются как раньше");
        assertTrue(commands.allows("console.command.kick.steve"), "запись kick разрешает команду с аргументом");
        assertTrue(commands.allows("console.command.mute.steve"), "аргументы внутри записи не мешают");
        assertTrue(commands.allows("console.command.tempban.steve"), "слэш и cmd: — та же самая запись");
        assertFalse(commands.allows("console.command.ban.steve"), "чужая команда не разрешена");

        final PermissionSet permissions = config.resolve(null, List.of("2"), "0");
        assertTrue(permissions.allows("essentials.heal"), "право LuckPerms выдаётся как есть");
        assertTrue(permissions.allows("console.command.heal.steve"), "и разрешает команду в своём конце");
        assertTrue(permissions.allows("console.command.wand.steve"), "явная форма perm: работает так же");

        final PermissionSet targets = config.resolve(null, List.of("3"), "0");
        assertTrue(targets.allows("console.server.survival"));
        assertTrue(targets.allows("console.server.lobby"), "server:* — все серверы сети");
        assertTrue(targets.allows("console.group.all"));

        final PermissionSet denied = config.resolve(null, List.of("4"), "0");
        assertTrue(denied.allows("console.execute"));
        assertTrue(denied.denies("console.command.kick.steve"), "запрет команды действует и с аргументами");
    }
}
