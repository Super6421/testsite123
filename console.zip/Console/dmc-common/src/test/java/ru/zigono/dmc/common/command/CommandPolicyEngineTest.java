package ru.zigono.dmc.common.command;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.PermissionSet;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Command policies: explicit denies, required permissions and confirmations.
 *
 * @author Zigono
 */
class CommandPolicyEngineTest {

    private static final YamlConfig CONFIG = YamlConfig.parse("""
            security:
              dangerous_commands:
                - "stop"
                - "restart"
                - "op"
                - "deop"
                - "reload"
              blocked_commands:
                - "ban *"
              allowed_commands: []
            command_policies:
              - pattern: "cmi heal"
                permission: "console.command.cmi.heal"
              - pattern: "op *"
                deny: true
            """, "policy.yml", false);

    private final CommandPolicyEngine engine = CommandPolicyEngine.from(CONFIG);
    private final CommandNormalizer normalizer = CommandNormalizer.withDefaults();

    @Test
    @DisplayName("permission derives from the command path")
    void derivesPermission() {
        final NormalizedCommand command = normalizer.normalize("cmi heal Zigono");
        final CommandPolicyEngine.Decision decision = engine.evaluate(command,
                PermissionSet.of(List.of("console.command.cmi.*")), false);
        assertTrue(decision.allowed());
        assertEquals("console.command.cmi.heal", decision.requiredPermission());
        assertFalse(decision.requiresConfirmation());
    }

    @Test
    @DisplayName("missing permission denies execution")
    void deniesWithoutPermission() {
        final NormalizedCommand command = normalizer.normalize("cmi god Zigono");
        final CommandPolicyEngine.Decision decision = engine.evaluate(command,
                PermissionSet.of(List.of("console.execute")), false);
        assertFalse(decision.allowed());
        assertEquals(ErrorCode.PERMISSION_DENIED, decision.error());
    }

    @Test
    @DisplayName("explicit deny rule blocks the command")
    void denyRuleWins() {
        final NormalizedCommand command = normalizer.normalize("op Zigono");
        final CommandPolicyEngine.Decision decision = engine.evaluate(command, PermissionSet.of(List.of("*")), true);
        assertFalse(decision.allowed());
        assertEquals(ErrorCode.POLICY_DENIED, decision.error());
    }

    @Test
    @DisplayName("blocked commands are always rejected")
    void blockedCommands() {
        final NormalizedCommand command = normalizer.normalize("ban Zigono");
        final CommandPolicyEngine.Decision decision = engine.evaluate(command, PermissionSet.of(List.of("*")), true);
        assertFalse(decision.allowed());
        assertEquals(ErrorCode.POLICY_DENIED, decision.error());
    }

    @Test
    @DisplayName("dangerous commands require confirmation")
    void dangerousRequiresConfirmation() {
        final NormalizedCommand command = normalizer.normalize("stop");
        final CommandPolicyEngine.Decision pending = engine.evaluate(command, PermissionSet.of(List.of("*")), false);
        assertFalse(pending.allowed());
        assertEquals(ErrorCode.CONFIRMATION_REQUIRED, pending.error());

        final CommandPolicyEngine.Decision confirmed = engine.evaluate(command, PermissionSet.of(List.of("*")), true);
        assertTrue(confirmed.allowed());
        assertTrue(confirmed.requiresConfirmation());
    }

    @Test
    @DisplayName("wildcards allow a command family")
    void wildcardFamily() {
        assertTrue(engine.evaluate(normalizer.normalize("cmi fly Zigono"), PermissionSet.of(List.of("console.command.*")),
                true).allowed());
        assertTrue(engine.evaluate(normalizer.normalize("cmi fly Zigono"), PermissionSet.of(List.of("*")), true).allowed());
        assertFalse(engine.evaluate(normalizer.normalize("cmi fly Zigono"),
                PermissionSet.of(List.of("console.command.essentials.*")), true).allowed());
    }
}