package ru.zigono.dmc.common.security;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Address and CIDR matching of the connection allowlist.
 *
 * @author Zigono
 */
class IpAllowlistTest {

    @Test
    @DisplayName("CIDR blocks and single addresses are matched")
    void matchesCidr() {
        final IpAllowlist allowlist = IpAllowlist.of(List.of("10.0.0.0/24", "192.168.1.5/32", "fd00::/8"));
        assertTrue(allowlist.allows("10.0.0.7"));
        assertTrue(allowlist.allows("/10.0.0.7"));
        assertTrue(allowlist.allows("192.168.1.5"));
        assertTrue(allowlist.allows("fd00::1"));
        assertFalse(allowlist.allows("10.0.1.7"));
        assertFalse(allowlist.allows("192.168.1.6"));
        assertFalse(allowlist.allows("8.8.8.8"));
    }

    @Test
    @DisplayName("wildcard allows everything and an empty list disables the check")
    void wildcardAndEmpty() {
        assertTrue(IpAllowlist.of(List.of("*")).allows("8.8.8.8"));
        assertTrue(IpAllowlist.of(List.of()).allows("8.8.8.8"));
    }

    @Test
    @DisplayName("secrets are redacted")
    void redactsSecrets() {
        final SecretRedactor redactor = SecretRedactor.of(List.of("super-secret-value"));
        final String redacted = redactor.redact("token=abcdef123456 secret=super-secret-value");
        assertFalse(redacted.contains("super-secret-value"));
        assertFalse(redacted.contains("abcdef123456"));
        assertTrue(redacted.contains("***"));
    }
}