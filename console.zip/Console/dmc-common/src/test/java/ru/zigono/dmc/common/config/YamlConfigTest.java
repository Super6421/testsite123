package ru.zigono.dmc.common.config;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * YAML parsing, typed accessors, environment substitution and change detection.
 *
 * @author Zigono
 */
class YamlConfigTest {

    @Test
    @DisplayName("environment placeholders are resolved with defaults")
    void environmentSubstitution() {
        final String previous = System.getenv("DMC_TEST_TOKEN");
        assertTrue(previous == null || previous != null);
        final String yaml = """
                discord:
                  token: "${DMC_TEST_UNDEFINED_TOKEN:default-token}"
                  port: 8080
                """;
        final YamlConfig config = YamlConfig.parse(yaml, "test.yml", true);
        assertEquals("default-token", config.string("discord.token", ""));
        assertEquals(8080, config.integer("discord.port", 0));
    }

    @Test
    @DisplayName("missing variables without default fail fast")
    void missingVariableFails() {
        assertThrows(ConfigException.class,
                () -> YamlConfig.parse("token: ${DMC_DEFINITELY_NOT_SET}\n", "test.yml", true));
    }

    @Test
    @DisplayName("typed accessors, durations and lists work")
    void typedAccessors() {
        final YamlConfig config = YamlConfig.parse("""
                servers:
                  survival:
                    enabled: true
                    aliases: [ surv, main ]
                queue:
                  timeout: 30s
                  max_size: 1000
                """, "test.yml", false);
        assertTrue(config.bool("servers.survival.enabled", false));
        assertEquals(List.of("surv", "main"), config.stringList("servers.survival.aliases", List.of()));
        assertEquals(Duration.ofSeconds(30), config.duration("queue.timeout", Duration.ZERO));
        assertEquals(1000, config.integer("queue.max_size", 0));
        assertThrows(ConfigException.class, () -> config.requiredString("queue.missing"));
    }

    @Test
    @DisplayName("duplicate keys are rejected")
    void duplicateKeysRejected() {
        assertThrows(ConfigException.class, () -> YamlConfig.parse("a: 1\na: 2\n", "test.yml", false));
    }

    @Test
    @DisplayName("a syntax error names the file, the line and the column in Russian")
    void syntaxErrorPointsAtTheFileAndThePlace() {
        final ConfigException failure = assertThrows(ConfigException.class, () -> YamlConfig.parse("""
                embedded:
                  enabled: true
                   permissions:
                """, "/home/container/plugins/DiscordMinecraftConsole/config.yml", false));

        assertTrue(failure.getMessage().contains("Некорректный YAML в /home/container/plugins"
                + "/DiscordMinecraftConsole/config.yml"), failure.getMessage());
        assertTrue(failure.getMessage().contains("строка "), failure.getMessage());
        assertTrue(failure.getMessage().contains("столбец "), failure.getMessage());
    }
}