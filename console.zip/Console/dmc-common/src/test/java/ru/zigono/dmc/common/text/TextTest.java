package ru.zigono.dmc.common.text;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Text helpers used by the user facing output.
 *
 * @author Zigono
 */
class TextTest {

    @Test
    @DisplayName("legacy and ANSI formatting is removed")
    void stripsFormatting() {
        assertEquals("Hello Zigono", Text.stripFormatting("\u001B[31m\u00A7aHello &lZigono"));
    }

    @Test
    @DisplayName("long output is split without losing content")
    void splits() {
        final List<String> chunks = Text.split("a".repeat(25), 10);
        assertEquals(List.of("aaaaaaaaaa", "aaaaaaaaaa", "aaaaa"), chunks);
        final List<String> lines = Text.split("line one\nline two\nline three", 18);
        assertEquals(List.of("line one\nline two", "line three"), lines);
    }

    @Test
    @DisplayName("surrogate pairs are never split")
    void neverSplitsSurrogates() {
        final String text = "\uD83D\uDE00".repeat(10);
        final List<String> chunks = Text.split(text, 5);
        for (String chunk : chunks) {
            assertTrue(chunk.length() % 2 == 0);
        }
        assertEquals(text, String.join("", chunks));
    }

    @Test
    @DisplayName("control characters are removed for Discord")
    void sanitizes() {
        assertEquals("safe", Text.sanitizeForDiscord("sa\u0000fe"));
        assertEquals("abc...", Text.truncate("abcdefghij", 6));
    }
}