package ru.zigono.dmc.common.rate;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Rate limits per user, role, server, command and globally.
 *
 * @author Zigono
 */
class RateLimiterTest {

    private static RateLimiter limiter(String yaml) {
        return new RateLimiter(RateLimitSettings.from(YamlConfig.parse(yaml, "rate.yml", false)),
                new InMemoryRateBackend());
    }

    @Test
    @DisplayName("per user quota is enforced and reported")
    void perUserQuota() {
        final RateLimiter limiter = limiter("""
                rate_limit:
                  enabled: true
                  per_user:
                    requests: 2
                    interval_seconds: 60
                """);
        assertTrue(limiter.check(List.of("user:1")).allowed());
        assertTrue(limiter.check(List.of("user:1")).allowed());
        final RateLimiter.Decision denied = limiter.check(List.of("user:1"));
        assertFalse(denied.allowed());
        assertEquals("user", denied.scope());
        assertTrue(denied.retryAfterMillis() > 0);
        assertTrue(limiter.check(List.of("user:2")).allowed());
    }

    @Test
    @DisplayName("server and command overrides are applied")
    void overrides() {
        final RateLimiter limiter = limiter("""
                rate_limit:
                  enabled: true
                  per_server:
                    requests: 10
                    interval_seconds: 10
                  per_command:
                    requests: 1
                    interval_seconds: 600
                  servers:
                    survival:
                      requests: 1
                      interval_seconds: 600
                """);
        assertTrue(limiter.check(List.of("server:survival")).allowed());
        assertFalse(limiter.check(List.of("server:survival")).allowed());
        assertTrue(limiter.check(List.of("server:lobby")).allowed());

        assertTrue(limiter.check(List.of("command:cmi heal")).allowed());
        assertFalse(limiter.check(List.of("command:cmi heal")).allowed());
    }

    @Test
    @DisplayName("global quota spans all keys")
    void globalQuota() {
        final RateLimiter limiter = limiter("""
                rate_limit:
                  enabled: true
                  global:
                    requests: 3
                    interval_seconds: 60
                """);
        assertTrue(limiter.check(List.of("global")).allowed());
        assertTrue(limiter.check(List.of("global")).allowed());
        assertTrue(limiter.check(List.of("global")).allowed());
        assertFalse(limiter.check(List.of("global")).allowed());
    }

    @Test
    @DisplayName("disabled rate limiting allows everything")
    void disabled() {
        final RateLimiter limiter = limiter("""
                rate_limit:
                  enabled: false
                  per_user:
                    requests: 1
                    interval_seconds: 60
                """);
        assertTrue(limiter.check(List.of("user:1")).allowed());
        assertTrue(limiter.check(List.of("user:1")).allowed());
    }
}