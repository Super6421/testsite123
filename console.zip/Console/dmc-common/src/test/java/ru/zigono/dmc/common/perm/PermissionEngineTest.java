package ru.zigono.dmc.common.perm;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Wildcard permissions, deny precedence and guild isolation.
 *
 * @author Zigono
 */
class PermissionEngineTest {

    @Test
    @DisplayName("wildcards match the declared subtree only")
    void wildcardMatching() {
        assertTrue(Permissions.matches("*", "console.execute"));
        assertTrue(Permissions.matches("console.*", "console.execute"));
        assertTrue(Permissions.matches("console.server.*", "console.server.survival"));
        assertTrue(Permissions.matches("console.command.cmi.*", "console.command.cmi.heal"));
        assertFalse(Permissions.matches("console.command.cmi.*", "console.command.essentials.heal"));
        assertFalse(Permissions.matches("console.execute", "console.execute.all"));
        assertTrue(Permissions.matches("console.command.cmi.heal", "console.command.cmi.heal"));
        assertFalse(Permissions.matches("console.server.survival", "console.server.lobby"));
    }

    @Test
    @DisplayName("deny wins over any allow pattern")
    void denyHasPriority() {
        final PermissionSet set = PermissionSet.of(List.of("*"), List.of("console.command.stop"));
        assertTrue(set.allows("console.execute"));
        assertFalse(set.allows("console.command.stop"));
        assertTrue(set.allows("console.command.reload"));
    }

    @Test
    @DisplayName("role, guild and user assignments are merged")
    void resolvesAssignments() {
        final YamlConfig config = YamlConfig.parse("""
                permissions:
                  roles:
                    "100":
                      allow: [ "console.read", "console.server.survival" ]
                    "200":
                      allow: [ "console.command.cmi.*" ]
                      deny: [ "console.command.cmi.god" ]
                  users:
                    "900":
                      allow: [ "console.broadcast.all" ]
                guilds:
                  "111111":
                    permissions:
                      roles:
                        "300":
                          allow: [ "console.server.lobby" ]
                """, "test.yml", false);
        final PermissionConfig permissionConfig = PermissionConfig.from(config, Set.of("111111", "222222"));

        final PermissionSet member = permissionConfig.resolve("111111", List.of("100", "200", "300"), "555");
        assertTrue(member.allows("console.read"));
        assertTrue(member.allows("console.server.survival"));
        assertTrue(member.allows("console.server.lobby"));
        assertTrue(member.allows("console.command.cmi.heal"));
        assertFalse(member.allows("console.command.cmi.god"));
        assertFalse(member.allows("console.broadcast.all"));

        final PermissionSet owner = permissionConfig.resolve("111111", List.of(), "900");
        assertTrue(owner.allows("console.broadcast.all"));

        final PermissionSet foreignGuild = permissionConfig.resolve("222222", List.of("300"), "555");
        assertFalse(foreignGuild.allows("console.server.lobby"));
    }

    @Test
    @DisplayName("permission sets are immutable value objects")
    void mergeDoesNotMutate() {
        final PermissionSet base = PermissionSet.of(List.of("console.read"));
        final PermissionSet merged = base.merge(PermissionSet.of(List.of("console.execute")));
        assertEquals(1, base.allow().size());
        assertEquals(2, merged.allow().size());
        assertFalse(base.allows("console.execute"));
        assertTrue(merged.allows("console.execute"));
    }
}