package ru.zigono.dmc.common.staff;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Раздел {@code staff} конфигурации: привилегии, которые можно выдавать и снимать прямо из Discord, и
 * иерархия — какая роль Discord какие привилегии выдаёт.
 * <pre>
 * staff:
 *   enabled: true
 *   mode: add
 *   default_group: default
 *   commands:
 *     grant: "персонал-выдать"
 *     remove: "персонал-снять"
 *   ranks:
 *     helper:
 *       name: "Хелпер"
 *       group: "helper"
 *       emoji: "🟢"
 *     moderator: "Модератор"
 *   access:
 *     "1390285875169988638": "*"
 *     "123456789012345678": "helper, moderator"
 * </pre>
 * Значения, состоящие из нескольких элементов, принимаются и строкой (через запятую, точку с запятой,
 * вертикальную черту или пробел), и списком: квадратные скобки не нужны нигде. Привилегию в {@code ranks}
 * можно записать тремя способами — полным словарём, одной строкой с подписью или пустой строкой, тогда и
 * подпись, и группа LuckPerms совпадают с ключом.
 * <p>Иерархия задаётся только в {@code access}: роль получает ровно те привилегии, которые перечислены в её
 * строке. Так «главный администратор выдаёт хелпера, модератора и старшего модератора» описывается одной
 * строкой конфигурации, а не порядком рангов в коде.</p>
 *
 * @author Zigono
 */
public record StaffConfig(boolean enabled, String grantCommand, String removeCommand, Mode mode, String defaultGroup,
                          List<Rank> ranks, Map<String, Access> access) {

    /** Значение {@code access}, которое означает «все настроенные привилегии». */
    public static final String ALL = "*";

    /** Команда выдачи по умолчанию. */
    public static final String DEFAULT_GRANT_COMMAND = "персонал-выдать";

    /** Команда снятия по умолчанию. */
    public static final String DEFAULT_REMOVE_COMMAND = "персонал-снять";

    /** Группа, в которую возвращается игрок, когда привилегию снимают в режиме {@link Mode#SET}. */
    public static final String DEFAULT_GROUP = "default";

    public StaffConfig {
        grantCommand = text(grantCommand, DEFAULT_GRANT_COMMAND);
        removeCommand = text(removeCommand, DEFAULT_REMOVE_COMMAND);
        mode = mode == null ? Mode.ADD : mode;
        defaultGroup = text(defaultGroup, DEFAULT_GROUP);
        ranks = List.copyOf(ranks == null ? List.of() : ranks);
        access = Map.copyOf(access == null ? Map.of() : access);
    }

    /**
     * Как привилегия применяется к игроку в LuckPerms.
     * <p>{@link #ADD} ничего не отнимает: у игрока остаются и другие группы. {@link #SET} выдаёт ровно эту
     * привилегию, поэтому подходит для иерархии персонала, где у игрока одна ступень.</p>
     */
    public enum Mode {
        ADD("add"),
        SET("set");

        private final String id;

        Mode(String id) {
            this.id = id;
        }

        public String id() {
            return id;
        }

        /** @return режим по его значению из конфигурации, {@code null} когда значение неизвестно */
        public static Mode byId(String value) {
            if (value == null) {
                return null;
            }
            for (Mode mode : values()) {
                if (mode.id.equals(value.trim().toLowerCase(Locale.ROOT))) {
                    return mode;
                }
            }
            return null;
        }
    }

    /** Одна привилегия: ключ для конфигурации, подпись для Discord и группа LuckPerms. */
    public record Rank(String key, String name, String group, String emoji) {

        public Rank {
            key = text(key, "");
            name = text(name, key);
            group = text(group, key);
            emoji = emoji == null ? "" : emoji.trim();
        }

        /** @return подпись для Discord, например {@code 🟢 Хелпер} */
        public String display() {
            return emoji.isEmpty() ? name : emoji + " " + name;
        }
    }

    /** Что разрешено одной роли Discord. */
    public record Access(String roleId, Set<String> ranks) {

        public Access {
            ranks = Set.copyOf(ranks == null ? Set.of() : ranks);
        }

        /** @return {@code true}, когда роль может выдавать любую настроенную привилегию */
        public boolean all() {
            return ranks.contains(ALL);
        }

        public boolean allows(String rankKey) {
            if (rankKey == null || rankKey.isBlank()) {
                return false;
            }
            return all() || ranks.contains(rankKey.trim().toLowerCase(Locale.ROOT));
        }
    }

    /** @return настройки персонала из полного документа конфигурации */
    public static StaffConfig from(YamlConfig root) {
        final YamlConfig section = root.section("staff");
        final boolean enabled = section.bool("enabled", false);
        final YamlConfig commands = section.sectionOrEmpty("commands");
        final List<Rank> ranks = parseRanks(section.sectionOrEmpty("ranks"));
        final Map<String, Access> access = parseAccess(section.sectionOrEmpty("access"), ranks);
        final String modeName = section.string("mode", Mode.ADD.id()).trim();
        final Mode mode = Mode.byId(modeName);
        if (mode == null) {
            throw new ConfigException("staff.mode должен быть add (добавлять и убирать группу, не трогая "
                    + "остальные) или set (выдавать ровно эту привилегию), но было '" + modeName + "'");
        }
        if (enabled && ranks.isEmpty()) {
            throw new ConfigException("staff.enabled: true, но раздел staff.ranks пуст — выдавать нечего. "
                    + "Добавьте хотя бы одну привилегию, например:" + System.lineSeparator()
                    + "  staff:" + System.lineSeparator()
                    + "    ranks:" + System.lineSeparator()
                    + "      helper:" + System.lineSeparator()
                    + "        name: \"Хелпер\"" + System.lineSeparator()
                    + "        group: \"helper\"");
        }
        return new StaffConfig(enabled, commands.string("grant", DEFAULT_GRANT_COMMAND),
                commands.string("remove", DEFAULT_REMOVE_COMMAND), mode,
                section.string("default_group", DEFAULT_GROUP), ranks, access);
    }

    /** @return выключенные настройки персонала */
    public static StaffConfig disabled() {
        return new StaffConfig(false, DEFAULT_GRANT_COMMAND, DEFAULT_REMOVE_COMMAND, Mode.ADD, DEFAULT_GROUP,
                List.of(), Map.of());
    }

    /** @return привилегия по её ключу, без учёта регистра */
    public Optional<Rank> rank(String key) {
        if (key == null || key.isBlank()) {
            return Optional.empty();
        }
        final String normalized = key.trim().toLowerCase(Locale.ROOT);
        for (Rank rank : ranks) {
            if (rank.key().toLowerCase(Locale.ROOT).equals(normalized)) {
                return Optional.of(rank);
            }
        }
        return Optional.empty();
    }

    /** @return {@code true}, когда хотя бы одна из ролей пользователя может выдавать эту привилегию */
    public boolean allows(Collection<String> roleIds, String rankKey) {
        if (roleIds == null || roleIds.isEmpty() || rankKey == null || rankKey.isBlank()) {
            return false;
        }
        for (String roleId : roleIds) {
            final Access granted = roleId == null ? null : access.get(roleId.trim());
            if (granted != null && granted.allows(rankKey)) {
                return true;
            }
        }
        return false;
    }

    /** @return привилегии, доступные хотя бы одной из ролей, в порядке объявления в конфигурации */
    public List<Rank> allowedRanks(Collection<String> roleIds) {
        final List<Rank> result = new ArrayList<>();
        for (Rank rank : ranks) {
            if (allows(roleIds, rank.key())) {
                result.add(rank);
            }
        }
        return List.copyOf(result);
    }

    /** @return {@code true}, когда привилегии не настроены */
    public boolean isEmpty() {
        return ranks.isEmpty();
    }

    /** @return ключи привилегий через запятую: для сообщений об ошибке */
    public String rankKeys() {
        final List<String> keys = new ArrayList<>(ranks.size());
        for (Rank rank : ranks) {
            keys.add(rank.key());
        }
        return String.join(", ", keys);
    }

    private static List<Rank> parseRanks(YamlConfig section) {
        final List<Rank> result = new ArrayList<>();
        for (String key : section.keys("")) {
            final String normalized = key == null ? "" : key.trim();
            if (normalized.isEmpty()) {
                continue;
            }
            final Object raw = section.raw(key);
            String group = normalized;
            String name = normalized;
            String emoji = "";
            if (raw instanceof Map<?, ?>) {
                final YamlConfig entry = section.section(key);
                group = text(entry.string("group", normalized), normalized);
                name = text(entry.string("name", normalized), normalized);
                emoji = entry.string("emoji", "");
            } else if (raw != null) {
                final String scalar = String.valueOf(raw).trim();
                if (!scalar.isEmpty()) {
                    name = scalar;
                }
            }
            result.add(new Rank(normalized, name, group, emoji));
        }
        return result;
    }

    private static Map<String, Access> parseAccess(YamlConfig section, List<Rank> ranks) {
        final Set<String> known = new LinkedHashSet<>();
        for (Rank rank : ranks) {
            known.add(rank.key().toLowerCase(Locale.ROOT));
        }
        final Map<String, Access> result = new LinkedHashMap<>();
        final List<String> unknown = new ArrayList<>();
        for (String key : section.keys("")) {
            final String roleId = key == null ? "" : key.trim();
            if (roleId.isEmpty()) {
                continue;
            }
            final Set<String> nodes = nodes(section.raw(key));
            for (String node : nodes) {
                if (!ALL.equals(node) && !known.contains(node)) {
                    unknown.add("staff.access." + roleId + " -> " + node);
                }
            }
            result.put(roleId, new Access(roleId, nodes));
        }
        if (!unknown.isEmpty()) {
            throw new ConfigException("В staff.access указаны привилегии, которых нет в staff.ranks: "
                    + String.join(", ", unknown) + ". Доступные ключи привилегий: "
                    + (known.isEmpty() ? "нет" : String.join(", ", known)));
        }
        return result;
    }

    /** Одно значение или список: и строка с разделителями, и список YAML дают один и тот же набор. */
    private static Set<String> nodes(Object raw) {
        final Set<String> result = new LinkedHashSet<>();
        if (raw == null) {
            return result;
        }
        if (raw instanceof Collection<?> collection) {
            for (Object element : collection) {
                addNode(result, element);
            }
            return result;
        }
        for (String part : String.valueOf(raw).split("[,;|\\s]+")) {
            addNode(result, part);
        }
        return result;
    }

    private static void addNode(Set<String> target, Object raw) {
        if (raw == null) {
            return;
        }
        final String node = String.valueOf(raw).trim().toLowerCase(Locale.ROOT);
        if (!node.isEmpty() && !"null".equals(node)) {
            target.add(node);
        }
    }

    private static String text(String value, String fallback) {
        if (value != null && !value.isBlank()) {
            return value.trim();
        }
        return fallback == null ? "" : fallback;
    }
}