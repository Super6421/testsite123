package ru.zigono.dmc.common.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.IThrowableProxy;
import ch.qos.logback.classic.spi.ThrowableProxyUtil;
import ch.qos.logback.core.encoder.EncoderBase;
import ru.zigono.dmc.common.security.SecretRedactor;
import ru.zigono.dmc.common.util.Json;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Structured JSON log encoder shared by the long running processes (gateway and Discord bot).
 * <p>Secrets are redacted before anything is written, so tokens, shared secrets and signatures never end up in
 * the log files. Keeping a single implementation means every component applies exactly the same redaction
 * rules and no component can silently log a secret because its own copy was never updated.</p>
 *
 * @author Zigono
 */
public final class JsonLogEncoder extends EncoderBase<ILoggingEvent> {

    private static final int MAX_MESSAGE_LENGTH = 8192;

    private static final String NEWLINE = System.lineSeparator();

    private volatile SecretRedactor redactor = SecretRedactor.empty();

    /**
     * Registers additional literal secrets that must never be logged.
     */
    public void setSecrets(List<String> secrets) {
        this.redactor = SecretRedactor.of(secrets);
    }

    @Override
    public byte[] encode(ILoggingEvent event) {
        final Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("timestamp", Instant.ofEpochMilli(event.getTimeStamp()).toString());
        entry.put("level", event.getLevel().toString());
        entry.put("logger", event.getLoggerName());
        entry.put("thread", event.getThreadName());
        entry.put("message", redact(truncate(event.getFormattedMessage())));
        if (event.getMDCPropertyMap() != null && !event.getMDCPropertyMap().isEmpty()) {
            entry.put("context", new LinkedHashMap<>(event.getMDCPropertyMap()));
        }
        final IThrowableProxy throwable = event.getThrowableProxy();
        if (throwable != null) {
            entry.put("exception", throwable.getClassName());
            entry.put("stacktrace", redact(truncate(ThrowableProxyUtil.asString(throwable))));
        }
        final String json = Json.write(entry);
        return (json + NEWLINE).getBytes(StandardCharsets.UTF_8);
    }

    private String redact(String value) {
        return redactor.redact(value);
    }

    private String truncate(String value) {
        if (value == null) {
            return "";
        }
        return value.length() <= MAX_MESSAGE_LENGTH ? value : value.substring(0, MAX_MESSAGE_LENGTH) + "...";
    }

    @Override
    public byte[] headerBytes() {
        return null;
    }

    @Override
    public byte[] footerBytes() {
        return null;
    }
}