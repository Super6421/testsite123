package ru.zigono.dmc.common.security;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Removes secrets from log lines, error messages and audit records. Configured secret values are redacted
 * verbatim; additionally common key/value patterns such as {@code token=...} or {@code "secret": "..."} are
 * masked so secrets never reach a log file, a stack trace or Discord.
 *
 * @author Zigono
 */
public final class SecretRedactor {

    private static final Pattern KEY_VALUE = Pattern.compile(
            "(?i)((?:token|secret|password|passphrase|api[_-]?key|authorization|signature|hmac|credential)"
                    + "[\"'\\s:=]{1,6})([A-Za-z0-9_\\-./+=]{6,})");
    private static final String MASK = "***";

    private final List<String> secrets;

    private SecretRedactor(List<String> secrets) {
        this.secrets = secrets;
    }

    public static SecretRedactor of(List<String> secrets) {
        final List<String> filtered = new ArrayList<>();
        for (String secret : secrets) {
            if (secret != null && secret.length() >= 4) {
                filtered.add(secret);
            }
        }
        filtered.sort((left, right) -> Integer.compare(right.length(), left.length()));
        return new SecretRedactor(List.copyOf(filtered));
    }

    public static SecretRedactor empty() {
        return new SecretRedactor(List.of());
    }

    public String redact(String value) {
        if (value == null || value.isEmpty()) {
            return value;
        }
        String result = value;
        for (String secret : secrets) {
            if (result.contains(secret)) {
                result = result.replace(secret, MASK);
            }
        }
        final Matcher matcher = KEY_VALUE.matcher(result);
        final StringBuilder out = new StringBuilder(result.length());
        while (matcher.find()) {
            matcher.appendReplacement(out, Matcher.quoteReplacement(matcher.group(1) + MASK));
        }
        matcher.appendTail(out);
        return out.toString();
    }
}