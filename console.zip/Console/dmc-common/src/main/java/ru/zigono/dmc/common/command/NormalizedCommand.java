package ru.zigono.dmc.common.command;

import java.util.List;

/**
 * Result of command normalization: the exact string that will be executed, its tokens and the root command.
 *
 * @author Zigono
 */
public record NormalizedCommand(String original, String normalized, String root, List<String> tokens) {

    public NormalizedCommand {
        tokens = List.copyOf(tokens);
    }

    /**
     * @return the command without its root token, or an empty string when there are no arguments
     */
    public String arguments() {
        if (tokens.size() <= 1) {
            return "";
        }
        return String.join(" ", tokens.subList(1, tokens.size()));
    }

    public int length() {
        return normalized.length();
    }

    @Override
    public String toString() {
        return normalized;
    }
}