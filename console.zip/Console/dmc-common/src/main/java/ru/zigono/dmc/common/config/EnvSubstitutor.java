package ru.zigono.dmc.common.config;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Replaces {@code ${VAR}} and {@code ${VAR:default}} placeholders with values of environment variables.
 * Substitution happens after YAML parsing so secrets containing YAML syntax cannot break the document.
 *
 * @author Zigono
 */
public final class EnvSubstitutor {

    private EnvSubstitutor() {
    }

    public static Object apply(Object value, Map<String, String> environment, String source, boolean strict) {
        if (value instanceof String string) {
            return substitute(string, environment, source, strict);
        }
        if (value instanceof Map<?, ?> map) {
            final Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()),
                        apply(entry.getValue(), environment, source, strict));
            }
            return result;
        }
        if (value instanceof List<?> list) {
            final java.util.List<Object> result = new java.util.ArrayList<>(list.size());
            for (Object element : list) {
                result.add(apply(element, environment, source, strict));
            }
            return result;
        }
        return value;
    }

    public static String substitute(String text, Map<String, String> environment, String source, boolean strict) {
        if (text.indexOf('$') < 0) {
            return text;
        }
        final StringBuilder out = new StringBuilder(text.length());
        int index = 0;
        while (index < text.length()) {
            final int start = text.indexOf("${", index);
            if (start < 0) {
                out.append(text, index, text.length());
                break;
            }
            final int end = text.indexOf('}', start + 2);
            if (end < 0) {
                throw new ConfigException("Незакрытый плейсхолдер переменной окружения в " + source + ": " + text);
            }
            out.append(text, index, start);
            final String expression = text.substring(start + 2, end);
            final int separator = expression.indexOf(':');
            final String name = (separator < 0 ? expression : expression.substring(0, separator)).trim();
            final String fallback = separator < 0 ? null : expression.substring(separator + 1);
            if (name.isEmpty()) {
                throw new ConfigException("Пустой плейсхолдер переменной окружения в " + source);
            }
            final String resolved = environment.get(name);
            if (resolved != null) {
                out.append(resolved);
            } else if (fallback != null) {
                out.append(fallback);
            } else if (strict) {
                throw new ConfigException("Переменная окружения " + name + " используется в " + source + " и не задана");
            } else {
                out.append(text, start, end + 1);
            }
            index = end + 1;
        }
        return out.toString();
    }
}