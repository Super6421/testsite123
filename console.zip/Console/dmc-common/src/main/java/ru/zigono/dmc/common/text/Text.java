package ru.zigono.dmc.common.text;

import java.util.ArrayList;
import java.util.List;

/**
 * Text helpers used when Minecraft output is rendered inside Discord and vice versa.
 *
 * @author Zigono
 */
public final class Text {

    private Text() {
    }

    /**
     * Removes legacy Minecraft color codes ({@code §} and {@code &}) and ANSI escape sequences.
     */
    public static String stripFormatting(String value) {
        if (value == null) {
            return "";
        }
        final StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            final char character = value.charAt(i);
            if (character == '\u00A7' || character == '&') {
                if (i + 1 < value.length() && isFormatCode(value.charAt(i + 1))) {
                    i++;
                    continue;
                }
                if (character == '\u00A7' && i + 7 < value.length() && value.charAt(i + 1) == 'x') {
                    i += 7;
                    continue;
                }
            }
            if (character == '\u001B') {
                i = skipAnsi(value, i);
                continue;
            }
            out.append(character);
        }
        return out.toString();
    }

    private static int skipAnsi(String value, int start) {
        int index = start + 1;
        if (index < value.length() && value.charAt(index) == '[') {
            while (index < value.length() && value.charAt(index) != 'm') {
                index++;
            }
        }
        return index;
    }

    private static boolean isFormatCode(char character) {
        final char lower = Character.toLowerCase(character);
        return (lower >= '0' && lower <= '9') || (lower >= 'a' && lower <= 'f') || lower == 'k' || lower == 'l'
                || lower == 'm' || lower == 'n' || lower == 'o' || lower == 'r' || lower == 'x';
    }

    /**
     * Splits text so every chunk fits into {@code maxLength} characters, preferring line boundaries and never
     * cutting a surrogate pair.
     */
    public static List<String> split(String value, int maxLength) {
        final List<String> result = new ArrayList<>();
        if (value == null || value.isEmpty()) {
            return result;
        }
        if (maxLength <= 0) {
            result.add(value);
            return result;
        }
        final String normalized = value.replace("\r\n", "\n").replace('\r', '\n');
        final StringBuilder current = new StringBuilder();
        for (String line : normalized.split("\n", -1)) {
            if (line.length() > maxLength) {
                if (!current.isEmpty()) {
                    result.add(current.toString());
                    current.setLength(0);
                }
                result.addAll(hardSplit(line, maxLength));
                continue;
            }
            if (current.length() + line.length() + (current.isEmpty() ? 0 : 1) > maxLength) {
                result.add(current.toString());
                current.setLength(0);
            }
            if (!current.isEmpty()) {
                current.append('\n');
            }
            current.append(line);
        }
        if (!current.isEmpty()) {
            result.add(current.toString());
        }
        return result;
    }

    private static List<String> hardSplit(String value, int maxLength) {
        final List<String> result = new ArrayList<>();
        int index = 0;
        while (index < value.length()) {
            int end = Math.min(index + maxLength, value.length());
            if (end < value.length() && Character.isHighSurrogate(value.charAt(end - 1))) {
                end--;
            }
            if (end <= index) {
                end = Math.min(index + maxLength, value.length());
            }
            result.add(value.substring(index, end));
            index = end;
        }
        return result;
    }

    public static String truncate(String value, int maxLength) {
        if (value == null) {
            return "";
        }
        if (value.length() <= maxLength) {
            return value;
        }
        final int end = maxLength <= 3 ? maxLength
                : (Character.isHighSurrogate(value.charAt(maxLength - 1)) ? maxLength - 1 : maxLength - 3);
        return value.substring(0, Math.max(0, end)) + (maxLength > 3 ? "..." : "");
    }

    /**
     * Makes text safe for Discord: removes control characters that break markdown rendering.
     */
    public static String sanitizeForDiscord(String value) {
        if (value == null) {
            return "";
        }
        final StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            final char character = value.charAt(i);
            if (character == '\n' || character == '\t') {
                out.append(character);
                continue;
            }
            if (Character.isISOControl(character) || character == '\u2028' || character == '\u2029'
                    || character == '\uFEFF') {
                continue;
            }
            out.append(character);
        }
        return out.toString();
    }
}