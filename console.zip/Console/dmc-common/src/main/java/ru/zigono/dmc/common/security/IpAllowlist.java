package ru.zigono.dmc.common.security;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * IP and CIDR allowlist used by the gateway to reject connections before any protocol handling happens.
 * Accepts single addresses ({@code 10.0.0.5}), CIDR blocks ({@code 10.0.0.0/24}, {@code fd00::/8}) and {@code *}
 * for "allow everything". An empty list means the check is disabled.
 *
 * @author Zigono
 */
public final class IpAllowlist {

    private final List<CidrBlock> blocks;
    private final boolean allowAll;

    private IpAllowlist(List<CidrBlock> blocks, boolean allowAll) {
        this.blocks = blocks;
        this.allowAll = allowAll;
    }

    public static IpAllowlist of(List<String> entries) {
        final List<CidrBlock> blocks = new ArrayList<>();
        boolean allowAll = false;
        for (String entry : entries) {
            if (entry == null || entry.isBlank()) {
                continue;
            }
            final String trimmed = entry.trim();
            if (trimmed.equals("*")) {
                allowAll = true;
                continue;
            }
            blocks.add(CidrBlock.parse(trimmed));
        }
        return new IpAllowlist(List.copyOf(blocks), allowAll);
    }

    public static IpAllowlist allowAll() {
        return new IpAllowlist(List.of(), true);
    }

    public boolean isEmpty() {
        return blocks.isEmpty() && !allowAll;
    }

    public boolean allows(InetAddress address) {
        if (allowAll) {
            return true;
        }
        if (blocks.isEmpty()) {
            return true;
        }
        if (address == null) {
            return false;
        }
        for (CidrBlock block : blocks) {
            if (block.contains(address)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param host textual host name or address, possibly with a leading slash as produced by socket APIs
     */
    public boolean allows(String host) {
        if (isEmpty()) {
            return true;
        }
        if (host == null) {
            return false;
        }
        final String cleaned = host.startsWith("/") ? host.substring(1) : host;
        final int bracket = cleaned.indexOf(']');
        final String withoutPort = bracket > 0 ? cleaned.substring(0, bracket + 1)
                : (cleaned.contains(":") && cleaned.indexOf(':') == cleaned.lastIndexOf(':') && cleaned.contains(".")
                ? cleaned.substring(0, cleaned.indexOf(':')) : cleaned);
        final String address = withoutPort.startsWith("[") && withoutPort.endsWith("]")
                ? withoutPort.substring(1, withoutPort.length() - 1) : withoutPort;
        try {
            return allows(InetAddress.getByName(address));
        } catch (UnknownHostException e) {
            return false;
        }
    }

    /**
     * A single CIDR block.
     *
     * @author Zigono
     */
    public static final class CidrBlock {

        private final byte[] network;
        private final int prefixLength;

        private CidrBlock(byte[] network, int prefixLength) {
            this.network = network;
            this.prefixLength = prefixLength;
        }

        public static CidrBlock parse(String value) {
            final int slash = value.indexOf('/');
            final String addressPart = slash < 0 ? value : value.substring(0, slash);
            final byte[] address;
            try {
                address = InetAddress.getByName(addressPart).getAddress();
            } catch (UnknownHostException e) {
                throw new IllegalArgumentException("Некорректный адрес в allowlist: " + value);
            }
            final int prefix = slash < 0 ? address.length * 8 : Integer.parseInt(value.substring(slash + 1).trim());
            if (prefix < 0 || prefix > address.length * 8) {
                throw new IllegalArgumentException("Некорректный префикс CIDR в allowlist: " + value);
            }
            return new CidrBlock(address, prefix);
        }

        public boolean contains(InetAddress address) {
            final byte[] candidate = address.getAddress();
            if (candidate.length != network.length) {
                return false;
            }
            int remaining = prefixLength;
            for (int i = 0; i < candidate.length && remaining > 0; i++) {
                final int bits = Math.min(8, remaining);
                final int mask = (0xFF << (8 - bits)) & 0xFF;
                if ((candidate[i] & mask) != (network[i] & mask)) {
                    return false;
                }
                remaining -= bits;
            }
            return true;
        }
    }
}