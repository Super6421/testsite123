package ru.zigono.dmc.common.i18n;

import ru.zigono.dmc.common.config.YamlConfig;

import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Localized user facing messages. Language files live in {@code lang/<locale>.yml} and can be overridden by a
 * file of the same name next to the component configuration.
 *
 * @author Zigono
 */
public final class Messages {

    public static final String FALLBACK_LANGUAGE = "en";

    private final String language;
    private final Map<String, String> fallback;
    private final Map<String, String> entries;

    private Messages(String language, Map<String, String> fallback, Map<String, String> entries) {
        this.language = language;
        this.fallback = fallback;
        this.entries = entries;
    }

    public static Messages load(String language, Path externalDirectory) {
        return load(language, externalDirectory, null);
    }

    /**
     * Loads the catalog of one component: the shared {@code lang/<locale>.yml}, then the catalog shipped inside
     * the component jar and finally the external files, which win.
     *
     * @param language          requested locale
     * @param externalDirectory directory with administrator overrides, {@code null} or absent is allowed
     * @param bundledDirectory  resource directory of the catalog bundled in the jar (for example
     *                          {@code bot-lang}), {@code null} when the component has no own catalog
     */
    public static Messages load(String language, Path externalDirectory, String bundledDirectory) {
        final String locale = (language == null || language.isBlank() ? FALLBACK_LANGUAGE : language)
                .trim().toLowerCase(Locale.ROOT);
        final Map<String, String> fallback = flatten(YamlConfig.loadResource("lang/" + FALLBACK_LANGUAGE + ".yml", false));
        final Map<String, String> selected = new LinkedHashMap<>(fallback);
        if (!locale.equals(FALLBACK_LANGUAGE)) {
            selected.putAll(flatten(YamlConfig.loadResource("lang/" + locale + ".yml", false)));
        }
        if (bundledDirectory != null) {
            selected.putAll(flatten(YamlConfig.loadOptionalResource(bundledDirectory + "/" + FALLBACK_LANGUAGE
                    + ".yml", false)));
            if (!locale.equals(FALLBACK_LANGUAGE)) {
                selected.putAll(flatten(YamlConfig.loadOptionalResource(bundledDirectory + "/" + locale + ".yml", false)));
            }
        }
        if (externalDirectory != null) {
            selected.putAll(flatten(YamlConfig.loadOptional(externalDirectory.resolve(FALLBACK_LANGUAGE + ".yml"), false)));
            if (!locale.equals(FALLBACK_LANGUAGE)) {
                selected.putAll(flatten(YamlConfig.loadOptional(externalDirectory.resolve(locale + ".yml"), false)));
            }
        }
        return new Messages(locale, Map.copyOf(fallback), Map.copyOf(selected));
    }

    public static Messages of(Map<String, String> entries) {
        return new Messages(FALLBACK_LANGUAGE, Map.copyOf(entries), Map.copyOf(entries));
    }

    public String language() {
        return language;
    }

    public Map<String, String> entries() {
        return entries;
    }

    public boolean has(String key) {
        return entries.containsKey(key) || fallback.containsKey(key);
    }

    public String raw(String key) {
        final String value = entries.get(key);
        if (value != null) {
            return value;
        }
        return fallback.getOrDefault(key, key);
    }

    /**
     * Formats a message using {@link MessageFormat}. Missing keys return the key itself so a broken language file
     * never hides an action, and never throws at runtime.
     */
    public String format(String key, Object... arguments) {
        final String pattern = raw(key);
        if (arguments == null || arguments.length == 0) {
            return pattern;
        }
        try {
            return new MessageFormat(pattern, Locale.forLanguageTag(language)).format(arguments);
        } catch (IllegalArgumentException e) {
            return pattern + " " + java.util.Arrays.toString(arguments);
        }
    }

    public String formatOrDefault(String key, String fallbackPattern, Object... arguments) {
        if (!has(key)) {
            return arguments == null || arguments.length == 0 ? fallbackPattern
                    : new MessageFormat(fallbackPattern, Locale.forLanguageTag(language)).format(arguments);
        }
        return format(key, arguments);
    }

    private static Map<String, String> flatten(YamlConfig config) {
        final Map<String, String> result = new LinkedHashMap<>();
        flatten("", config.asMap(), result);
        return result;
    }

    private static void flatten(String prefix, Map<String, Object> values, Map<String, String> target) {
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            final String key = prefix.isEmpty() ? entry.getKey() : prefix + "." + entry.getKey();
            final Object value = entry.getValue();
            if (value instanceof Map<?, ?> map) {
                final Map<String, Object> nested = new LinkedHashMap<>();
                map.forEach((k, v) -> nested.put(Objects.toString(k), v));
                flatten(key, nested, target);
            } else if (value instanceof java.util.List<?> list) {
                final StringBuilder joined = new StringBuilder();
                for (int i = 0; i < list.size(); i++) {
                    if (i > 0) {
                        joined.append('\n');
                    }
                    joined.append(list.get(i));
                }
                target.put(key, joined.toString());
            } else if (value != null) {
                target.put(key, String.valueOf(value));
            }
        }
    }
}