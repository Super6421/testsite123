package ru.zigono.dmc.common.errors;

import java.util.Map;

/**
 * An exception that carries a stable error code plus a safe description. Internal details are never
 * shown to Discord users and are logged separately.
 *
 * @author Zigono
 */
public class CommandException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final ErrorCode code;
    private final transient Map<String, String> arguments;

    public CommandException(ErrorCode code, String internalDetail) {
        this(code, internalDetail, Map.of(), null);
    }

    public CommandException(ErrorCode code, String internalDetail, Throwable cause) {
        this(code, internalDetail, Map.of(), cause);
    }

    public CommandException(ErrorCode code, String internalDetail, Map<String, String> arguments) {
        this(code, internalDetail, arguments, null);
    }

    public CommandException(ErrorCode code, String internalDetail, Map<String, String> arguments, Throwable cause) {
        super(internalDetail == null ? code.name() : internalDetail, cause);
        this.code = code;
        this.arguments = arguments == null ? Map.of() : Map.copyOf(arguments);
    }

    public ErrorCode code() {
        return code;
    }

    public Map<String, String> arguments() {
        return arguments;
    }
}