package ru.zigono.dmc.common.command;

import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Normalizes user supplied Minecraft commands and rejects anything that could turn a single command into
 * several commands or otherwise break the console contract.
 * <p>Rejected: control characters, newlines, carriage returns, line/paragraph separators, BOM, unpaired
 * surrogates, configured injection sequences and oversized input.</p>
 *
 * @author Zigono
 */
public final class CommandNormalizer {

    public static final int DEFAULT_MAX_LENGTH = 512;
    public static final List<String> DEFAULT_BLOCKED_SEQUENCES = List.of("&&", "||", ";", "`", "$(", "\\x", "\u0000");

    private static final char NON_BREAKING_SPACE = '\u00A0';
    private static final char LINE_SEPARATOR = '\u2028';
    private static final char PARAGRAPH_SEPARATOR = '\u2029';
    private static final char BYTE_ORDER_MARK = '\uFEFF';

    private final int maxLength;
    private final List<String> blockedSequences;

    public CommandNormalizer(int maxLength, List<String> blockedSequences) {
        if (maxLength <= 0) {
            throw new IllegalArgumentException("maxLength должен быть положительным");
        }
        this.maxLength = maxLength;
        this.blockedSequences = List.copyOf(blockedSequences);
    }

    public static CommandNormalizer withDefaults() {
        return new CommandNormalizer(DEFAULT_MAX_LENGTH, DEFAULT_BLOCKED_SEQUENCES);
    }

    public int maxLength() {
        return maxLength;
    }

    public NormalizedCommand normalize(String raw) {
        if (raw == null) {
            throw new CommandException(ErrorCode.INVALID_COMMAND, "команда не задана (null)");
        }
        final String trimmed = raw.strip();
        if (trimmed.isEmpty()) {
            throw new CommandException(ErrorCode.INVALID_COMMAND, "команда пуста");
        }
        if (trimmed.length() > maxLength) {
            throw new CommandException(ErrorCode.INVALID_COMMAND,
                    "длина команды " + trimmed.length() + " превышает заданный максимум " + maxLength);
        }
        final String unicode = Normalizer.normalize(trimmed, Normalizer.Form.NFC);
        rejectUnsafeCharacters(unicode);
        String candidate = unicode.replace(NON_BREAKING_SPACE, ' ');
        candidate = collapse(candidate);
        while (candidate.startsWith("/")) {
            candidate = candidate.substring(1).stripLeading();
        }
        if (candidate.isEmpty()) {
            throw new CommandException(ErrorCode.INVALID_COMMAND, "после нормализации команда пуста");
        }
        if (candidate.length() > maxLength) {
            throw new CommandException(ErrorCode.INVALID_COMMAND,
                    "длина команды " + candidate.length() + " превышает заданный максимум " + maxLength);
        }
        final String lower = candidate.toLowerCase(Locale.ROOT);
        for (String sequence : blockedSequences) {
            if (!sequence.isEmpty() && lower.contains(sequence.toLowerCase(Locale.ROOT))) {
                throw new CommandException(ErrorCode.INVALID_COMMAND,
                        "команда содержит запрещённую последовательность '" + sequence + "'");
            }
        }
        final List<String> tokens = new ArrayList<>(List.of(candidate.split(" ")));
        tokens.removeIf(String::isEmpty);
        if (tokens.isEmpty()) {
            throw new CommandException(ErrorCode.INVALID_COMMAND, "в команде нет слов");
        }
        return new NormalizedCommand(raw, candidate, tokens.get(0).toLowerCase(Locale.ROOT), tokens);
    }

    private void rejectUnsafeCharacters(String value) {
        for (int i = 0; i < value.length(); i++) {
            final char character = value.charAt(i);
            if (Character.isISOControl(character)) {
                throw new CommandException(ErrorCode.INVALID_COMMAND,
                        "command contains a control character (U+" + Integer.toHexString(character).toUpperCase(Locale.ROOT) + ")");
            }
            if (Character.getType(character) == Character.FORMAT || character == LINE_SEPARATOR
                    || character == PARAGRAPH_SEPARATOR || character == BYTE_ORDER_MARK) {
                throw new CommandException(ErrorCode.INVALID_COMMAND,
                        "command contains a forbidden format character");
            }
            if (Character.isSurrogate(character)) {
                final boolean validPair = Character.isHighSurrogate(character)
                        ? i + 1 < value.length() && Character.isLowSurrogate(value.charAt(i + 1))
                        : i > 0 && Character.isHighSurrogate(value.charAt(i - 1));
                if (!validPair) {
                    throw new CommandException(ErrorCode.INVALID_COMMAND, "command contains malformed UTF-16 input");
                }
            }
        }
    }

    private static String collapse(String value) {
        final StringBuilder out = new StringBuilder(value.length());
        boolean previousSpace = false;
        for (int i = 0; i < value.length(); i++) {
            final char character = value.charAt(i);
            if (character == ' ' || character == '\t') {
                if (!previousSpace) {
                    out.append(' ');
                }
                previousSpace = true;
            } else {
                out.append(character);
                previousSpace = false;
            }
        }
        return out.toString().strip();
    }
}