package ru.zigono.dmc.common.command;

import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.Permissions;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Safe Discord aliases and templates. Both are declared in configuration, translated into a concrete Minecraft
 * command and validated before anything is sent to a server.
 * <pre>
 * aliases:
 *   heal:
 *     command: "cmi heal {player}"
 *     permission: "console.alias.heal"
 * templates:
 *   broadcast:
 *     command: "broadcast {text}"
 *     permission: "console.template.broadcast"
 *     parameters:
 *       text: text
 * </pre>
 *
 * @author Zigono
 */
public final class CommandShortcuts {

    private static final Pattern PLACEHOLDER = Pattern.compile("\\{([A-Za-z0-9_]+)}");
    private static final Set<String> PLAYER_PARAMETER_NAMES = Set.of("player", "target", "player1", "player2", "victim");

    private final Map<String, Shortcut> aliases;
    private final Map<String, Shortcut> templates;
    private final CommandNormalizer normalizer;

    private CommandShortcuts(Map<String, Shortcut> aliases, Map<String, Shortcut> templates, CommandNormalizer normalizer) {
        this.aliases = aliases;
        this.templates = templates;
        this.normalizer = normalizer;
    }

    public record Shortcut(String name, String command, String permission, Map<String, String> rules, Kind kind) {

        /**
         * The rules keep the order in which the placeholders appear in the command, because positional
         * arguments are assigned to placeholders in that order.
         */
        public Shortcut {
            rules = java.util.Collections.unmodifiableMap(new LinkedHashMap<>(rules));
        }

        public Set<String> placeholders() {
            return rules.keySet();
        }
    }

    public enum Kind {
        ALIAS,
        TEMPLATE
    }

    public static CommandShortcuts from(YamlConfig root, CommandNormalizer normalizer) {
        return new CommandShortcuts(
                parse(root.section("aliases"), Kind.ALIAS, normalizer),
                parse(root.section("templates"), Kind.TEMPLATE, normalizer),
                normalizer);
    }

    private static Map<String, Shortcut> parse(YamlConfig section, Kind kind, CommandNormalizer normalizer) {
        final Map<String, Shortcut> result = new LinkedHashMap<>();
        for (String name : section.keys("")) {
            final YamlConfig entry = section.section(name);
            if (entry.isEmpty()) {
                continue;
            }
            final String normalizedName = name.toLowerCase(Locale.ROOT);
            final String command = entry.string("command", "").trim();
            if (command.isEmpty()) {
                throw new ru.zigono.dmc.common.config.ConfigException(
                        kind.name().toLowerCase(Locale.ROOT) + " '" + name + "' должна задавать команду");
            }
            normalizer.normalize(command.replaceAll("\\{[A-Za-z0-9_]+}", "value"));
            final Map<String, String> rules = new LinkedHashMap<>();
            final YamlConfig parameters = entry.section("parameters");
            for (String placeholder : placeholdersOf(command)) {
                final String rule = parameters.string(placeholder, defaultRule(placeholder));
                if (!ValueValidator.RULES.contains(rule)) {
                    throw new ru.zigono.dmc.common.config.ConfigException("Неизвестное правило проверки '" + rule
                            + "' для параметра '" + placeholder + "' команды " + kind.name().toLowerCase(Locale.ROOT) + " '" + name + "'");
                }
                rules.put(placeholder, rule);
            }
            for (String declared : parameters.keys("")) {
                if (!rules.containsKey(declared)) {
                    throw new ru.zigono.dmc.common.config.ConfigException("Параметр '" + declared + "' команды "
                            + kind.name().toLowerCase(Locale.ROOT) + " '" + name + "' не используется в шаблоне команды");
                }
            }
            final String permission = entry.string("permission",
                    kind == Kind.ALIAS ? "console.alias." + normalizedName : "console.template." + normalizedName);
            result.put(normalizedName, new Shortcut(normalizedName, command, permission, rules, kind));
        }
        return result;
    }

    private static String defaultRule(String placeholder) {
        return PLAYER_PARAMETER_NAMES.contains(placeholder.toLowerCase(Locale.ROOT)) ? "player" : "word";
    }

    private static Set<String> placeholdersOf(String command) {
        final Set<String> result = new LinkedHashSet<>();
        final Matcher matcher = PLACEHOLDER.matcher(command);
        while (matcher.find()) {
            result.add(matcher.group(1));
        }
        return result;
    }

    public Optional<Shortcut> alias(String name) {
        return name == null ? Optional.empty() : Optional.ofNullable(aliases.get(name.toLowerCase(Locale.ROOT)));
    }

    public Optional<Shortcut> template(String name) {
        return name == null ? Optional.empty() : Optional.ofNullable(templates.get(name.toLowerCase(Locale.ROOT)));
    }

    public Set<String> aliasNames() {
        return aliases.keySet();
    }

    public Set<String> templateNames() {
        return templates.keySet();
    }

    public List<Shortcut> all() {
        final List<Shortcut> result = new java.util.ArrayList<>(aliases.values());
        result.addAll(templates.values());
        return List.copyOf(result);
    }

    /**
     * Renders the shortcut into a concrete command after validating every provided value.
     */
    public String render(Shortcut shortcut, Map<String, String> values) {
        final Map<String, String> validated = new LinkedHashMap<>();
        for (Map.Entry<String, String> rule : shortcut.rules().entrySet()) {
            validated.put(rule.getKey(), ValueValidator.validate(rule.getValue(), rule.getKey(), values.get(rule.getKey())));
        }
        final StringBuilder out = new StringBuilder();
        final Matcher matcher = PLACEHOLDER.matcher(shortcut.command());
        while (matcher.find()) {
            final String value = validated.get(matcher.group(1));
            if (value == null) {
                throw new CommandException(ErrorCode.INVALID_COMMAND, "Unresolved placeholder " + matcher.group());
            }
            matcher.appendReplacement(out, Matcher.quoteReplacement(value));
        }
        matcher.appendTail(out);
        final NormalizedCommand normalized = normalizer.normalize(out.toString());
        return normalized.normalized();
    }

    /**
     * @return {@code true} when the user is allowed to use the alias or template
     */
    public boolean permits(Shortcut shortcut, java.util.Collection<String> grantedPermissions) {
        return Permissions.has(grantedPermissions, shortcut.permission());
    }
}