package ru.zigono.dmc.common.rate;

/**
 * Storage for rate limit counters. The default implementation is in-memory; the gateway can plug in a
 * Redis backed implementation for horizontal scaling so limits are shared by all gateway instances.
 *
 * @author Zigono
 */
public interface RateBackend {

    /**
     * Attempts to consume one unit of the quota for the given key.
     *
     * @return {@code true} when the request is allowed
     */
    boolean tryAcquire(String key, int limit, long windowMillis);

    /**
     * @return milliseconds until the next request for the key may be allowed, {@code 0} when currently allowed
     */
    long retryAfterMillis(String key, int limit, long windowMillis);

    void reset(String key);

    default void close() {
    }
}