package ru.zigono.dmc.common.config;

import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import ru.zigono.dmc.common.util.Durations;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/**
 * Read-only view over a YAML document with typed accessors, environment variable substitution and
 * change tracking for hot reload.
 *
 * @author Zigono
 */
public final class YamlConfig {

    private final Map<String, Object> root;
    private final String source;
    private final String fingerprint;

    private YamlConfig(Map<String, Object> root, String source, String fingerprint) {
        this.root = root;
        this.source = source;
        this.fingerprint = fingerprint;
    }

    public static YamlConfig load(Path path) {
        return load(path, true);
    }

    public static YamlConfig load(Path path, boolean strictEnvironment) {
        Objects.requireNonNull(path, "path");
        if (!Files.isRegularFile(path)) {
            throw new ConfigException("Файл конфигурации не найден: " + path.toAbsolutePath());
        }
        try {
            final String text = Files.readString(path, StandardCharsets.UTF_8);
            return parse(text, path.toAbsolutePath().toString(), strictEnvironment);
        } catch (IOException e) {
            throw new ConfigException("Не удалось прочитать файл конфигурации " + path.toAbsolutePath(), e);
        }
    }

    public static YamlConfig loadResource(String resourcePath, boolean strictEnvironment) {
        try (InputStream stream = YamlConfig.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (stream == null) {
                throw new ConfigException("Встроенный ресурс конфигурации не найден: " + resourcePath);
            }
            return parse(new String(stream.readAllBytes(), StandardCharsets.UTF_8), "classpath:" + resourcePath,
                    strictEnvironment);
        } catch (IOException e) {
            throw new ConfigException("Не удалось прочитать встроенный ресурс конфигурации " + resourcePath, e);
        }
    }

    /**
     * Reads a bundled resource and returns an empty document when it is absent, so a component can merge a
     * catalog that another jar may or may not ship.
     */
    public static YamlConfig loadOptionalResource(String resourcePath, boolean strictEnvironment) {
        try (InputStream stream = YamlConfig.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (stream == null) {
                return empty("classpath:" + resourcePath);
            }
            return parse(new String(stream.readAllBytes(), StandardCharsets.UTF_8), "classpath:" + resourcePath,
                    strictEnvironment);
        } catch (IOException e) {
            throw new ConfigException("Не удалось прочитать встроенный ресурс конфигурации " + resourcePath, e);
        }
    }


    public static YamlConfig parse(String text, String source, boolean strictEnvironment) {
        final LoaderOptions options = new LoaderOptions();
        options.setAllowDuplicateKeys(false);
        options.setMaxAliasesForCollections(64);
        options.setCodePointLimit(4 * 1024 * 1024);
        final Object loaded;
        try {
            loaded = new Yaml(new SafeConstructor(options)).load(text);
        } catch (RuntimeException e) {
            throw new ConfigException("Некорректный YAML в " + source + ": " + describe(e), e);
        }
        final Map<String, Object> normalized = new LinkedHashMap<>();
        if (loaded != null) {
            if (!(loaded instanceof Map<?, ?> map)) {
                throw new ConfigException("Корень конфигурации " + source + " должен быть словарём (mapping)");
            }
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                normalized.put(String.valueOf(entry.getKey()), normalize(entry.getValue()));
            }
        }
        if (strictEnvironment) {
            final Map<String, Object> substituted = new LinkedHashMap<>();
            for (Map.Entry<String, Object> entry : normalized.entrySet()) {
                substituted.put(entry.getKey(),
                        EnvSubstitutor.apply(entry.getValue(), System.getenv(), source, true));
            }
            return of(substituted, source);
        }
        return of(normalized, source);
    }

    public static YamlConfig of(Map<String, Object> values, String source) {
        final Map<String, Object> copy = new LinkedHashMap<>();
        values.forEach((key, value) -> copy.put(String.valueOf(key), normalize(value)));
        final String fingerprint = ru.zigono.dmc.common.util.Hashing.sha256Hex(
                ru.zigono.dmc.common.util.Json.write(copy));
        return new YamlConfig(copy, source, fingerprint);
    }

    public static YamlConfig empty(String source) {
        return of(new LinkedHashMap<>(), source);
    }

    private static Object normalize(Object value) {
        if (value instanceof Map<?, ?> map) {
            final Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), normalize(entry.getValue()));
            }
            return result;
        }
        if (value instanceof List<?> list) {
            final List<Object> result = new ArrayList<>(list.size());
            for (Object element : list) {
                result.add(normalize(element));
            }
            return result;
        }
        return value;
    }

    public String source() {
        return source;
    }

    /**
     * @return a stable hash of the configuration content, used to detect changes for hot reload.
     */
    public String fingerprint() {
        return fingerprint;
    }

    public Map<String, Object> asMap() {
        return root;
    }

    public boolean isEmpty() {
        return root.isEmpty();
    }

    public boolean has(String path) {
        return lookup(path) != null;
    }

    public Object raw(String path) {
        return lookup(path);
    }

    public String requiredString(String path) {
        final String value = optionalString(path).orElseThrow(
                () -> new ConfigException("Отсутствует обязательное значение конфигурации: " + path + " в " + source));
        if (value.isBlank()) {
            throw new ConfigException("Значение конфигурации " + path + " в " + source + " не может быть пустым");
        }
        return value;
    }

    public Optional<String> optionalString(String path) {
        final Object value = lookup(path);
        if (value == null) {
            return Optional.empty();
        }
        final String text = String.valueOf(value);
        return Optional.of(text);
    }

    public String string(String path, String fallback) {
        final Object value = lookup(path);
        return value == null ? fallback : String.valueOf(value);
    }

    public int integer(String path, int fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof Number number) {
            return number.intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            throw new ConfigException("Значение конфигурации " + path + " в " + source + " должен быть целым числом");
        }
    }

    public long longValue(String path, long fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof Number number) {
            return number.longValue();
        }
        try {
            return Long.parseLong(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            throw new ConfigException("Значение конфигурации " + path + " в " + source + " должен быть числом");
        }
    }

    public double doubleValue(String path, double fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof Number number) {
            return number.doubleValue();
        }
        try {
            return Double.parseDouble(String.valueOf(value).trim());
        } catch (NumberFormatException e) {
            throw new ConfigException("Значение конфигурации " + path + " в " + source + " должен быть числом");
        }
    }

    public boolean bool(String path, boolean fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof Boolean bool) {
            return bool;
        }
        final String text = String.valueOf(value).trim().toLowerCase(Locale.ROOT);
        return switch (text) {
            case "true", "yes", "on", "1" -> true;
            case "false", "no", "off", "0" -> false;
            default -> throw new ConfigException("Значение конфигурации " + path + " в " + source + " должен быть логическим значением");
        };
    }

    public Duration duration(String path, Duration fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof Number number) {
            return Duration.ofSeconds(number.longValue());
        }
        return Durations.parse(String.valueOf(value));
    }

    public List<String> stringList(String path, List<String> fallback) {
        final Object value = lookup(path);
        if (value == null) {
            return fallback;
        }
        if (value instanceof List<?> list) {
            final List<String> result = new ArrayList<>(list.size());
            for (Object element : list) {
                result.add(String.valueOf(element));
            }
            return result;
        }
        return List.of(String.valueOf(value));
    }

    public List<Map<String, Object>> mapList(String path) {
        final Object value = lookup(path);
        if (!(value instanceof List<?> list)) {
            return List.of();
        }
        final List<Map<String, Object>> result = new ArrayList<>(list.size());
        for (Object element : list) {
            if (element instanceof Map<?, ?> map) {
                final Map<String, Object> entry = new LinkedHashMap<>();
                map.forEach((key, item) -> entry.put(String.valueOf(key), item));
                result.add(entry);
            }
        }
        return result;
    }

    public Map<String, Object> map(String path) {
        final Object value = lookup(path);
        if (!(value instanceof Map<?, ?> map)) {
            return Map.of();
        }
        final Map<String, Object> result = new LinkedHashMap<>();
        map.forEach((key, item) -> result.put(String.valueOf(key), item));
        return result;
    }

    /**
     * @return the configuration keys under the given path, in declaration order
     */
    public Set<String> keys(String path) {
        return new LinkedHashSet<>(map(path).keySet());
    }

    public YamlConfig section(String path) {
        final Object value = lookup(path);
        if (value == null) {
            return YamlConfig.empty(source + "#" + path);
        }
        if (!(value instanceof Map<?, ?> map)) {
            throw new ConfigException("Раздел конфигурации " + path + " в " + source + " должен быть словарём (mapping)");
        }
        final Map<String, Object> result = new LinkedHashMap<>();
        map.forEach((key, item) -> result.put(String.valueOf(key), normalize(item)));
        return of(result, source + "#" + path);
    }

    /**
     * Fails fast when any of the given paths is missing. Used to validate a configuration at startup.
     */
    /**
     * @return the section when it exists and is a mapping, an empty configuration otherwise
     */
    public YamlConfig sectionOrEmpty(String path) {
        final Object value = lookup(path);
        return value instanceof Map<?, ?> ? section(path) : empty(source + "#" + path);
    }

    public void require(Collection<String> paths) {
        final List<String> missing = new ArrayList<>();
        for (String path : paths) {
            if (!has(path)) {
                missing.add(path);
            }
        }
        if (!missing.isEmpty()) {
            throw new ConfigException("В конфигурации " + source + " — отсутствуют обязательные ключи: " + String.join(", ", missing));
        }
    }

    public void requireEnum(String path, String value, Collection<String> allowed) {
        if (!allowed.contains(value)) {
            throw new ConfigException("Значение конфигурации " + path + " в " + source + " должен быть одним из " + allowed
                    + " но было '" + value + "'");
        }
    }

    /**
     * SnakeYAML сообщает место ошибки как {@code in 'string', line 42, column 3}, потому что документ
     * разбирается из строки. Администратору эти слова ничего не говорят: заменяем их на понятные
     * {@code строка 42, столбец 3}, чтобы файл и место правки были видны сразу.
     */
    private static String describe(RuntimeException failure) {
        final String message = failure.getMessage();
        if (message == null || message.isBlank()) {
            return failure.getClass().getSimpleName();
        }
        return message.replace("\n in 'string', line ", "\n строка ")
                .replace(" in 'string', line ", " строка ")
                .replace(", column ", ", столбец ");
    }

    private Object lookup(String path) {
        if (path == null || path.isEmpty()) {
            return root;
        }
        Object current = root;
        int index = 0;
        while (index <= path.length()) {
            final int dot = path.indexOf('.', index);
            final String segment = dot < 0 ? path.substring(index) : path.substring(index, dot);
            if (!(current instanceof Map<?, ?> map)) {
                return null;
            }
            current = map.get(segment);
            if (current == null) {
                return null;
            }
            if (dot < 0) {
                return current;
            }
            index = dot + 1;
        }
        return current;
    }

    @Override
    public String toString() {
        return "YamlConfig[" + source + "]";
    }

    /**
     * Reads a file, returning an empty configuration when it does not exist. Used for optional configuration
     * fragments such as {@code permissions.yml}.
     */
    public static YamlConfig loadOptional(Path path, boolean strictEnvironment) {
        if (!Files.isRegularFile(path)) {
            return empty(path.toString());
        }
        try {
            return parse(Files.readString(path, StandardCharsets.UTF_8), path.toAbsolutePath().toString(), strictEnvironment);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
