package ru.zigono.dmc.common.rate;

import java.util.List;
import java.util.Locale;

/**
 * Multi scope rate limiter. Callers pass every applicable key, for example
 * {@code user:123}, {@code role:456}, {@code server:survival}, {@code command:cmi heal}, {@code global};
 * the limiter evaluates them in order and fails on the first exceeded quota.
 *
 * @author Zigono
 */
public final class RateLimiter {

    private final RateLimitSettings settings;
    private final RateBackend backend;

    public RateLimiter(RateLimitSettings settings, RateBackend backend) {
        this.settings = settings;
        this.backend = backend;
    }

    public record Decision(boolean allowed, String scope, String key, long retryAfterMillis) {

        public static Decision permitted() {
            return new Decision(true, null, null, 0L);
        }
    }

    public boolean enabled() {
        return settings.enabled();
    }

    public RateLimitSettings settings() {
        return settings;
    }

    /**
     * @param keys fully qualified keys such as {@code user:1} or {@code server:survival}
     */
    public Decision check(List<String> keys) {
        if (!settings.enabled() || keys.isEmpty()) {
            return Decision.permitted();
        }
        final long now = System.currentTimeMillis();
        for (String key : keys) {
            final int separator = key.indexOf(':');
            final String scope = (separator < 0 ? key : key.substring(0, separator)).toLowerCase(Locale.ROOT);
            final String identity = separator < 0 ? "" : key.substring(separator + 1);
            final RateLimitSettings.Rule rule = settings.ruleFor(scope, identity);
            if (rule.unlimited()) {
                continue;
            }
            if (!backend.tryAcquire(key, rule.requests(), rule.intervalMillis())) {
                final long retryAfter = backend.retryAfterMillis(key, rule.requests(), rule.intervalMillis());
                return new Decision(false, scope, key, Math.max(retryAfter, 1000L));
            }
        }
        return Decision.permitted();
    }

    public void reset(String key) {
        backend.reset(key);
    }

    public void close() {
        backend.close();
    }
}