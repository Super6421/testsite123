package ru.zigono.dmc.common.util;

import ru.zigono.dmc.common.config.ConfigException;

import java.time.Duration;
import java.util.Locale;

/**
 * Parses human readable durations such as {@code 500ms}, {@code 30s}, {@code 5m}, {@code 2h}, {@code 7d}
 * as well as ISO-8601 durations.
 *
 * @author Zigono
 */
public final class Durations {

    private Durations() {
    }

    public static Duration parse(String raw) {
        if (raw == null) {
            throw new ConfigException("Значение длительности не может быть null");
        }
        final String value = raw.trim();
        if (value.isEmpty()) {
            throw new ConfigException("Значение длительности не может быть пустым");
        }
        if (value.startsWith("P") || value.startsWith("p")) {
            try {
                return Duration.parse(value.toUpperCase(Locale.ROOT));
            } catch (RuntimeException e) {
                throw new ConfigException("Некорректная длительность ISO-8601: " + raw);
            }
        }
        final int split = firstNonDigit(value);
        final String numberPart = split < 0 ? value : value.substring(0, split);
        final String unitPart = split < 0 ? "s" : value.substring(split).trim().toLowerCase(Locale.ROOT);
        final long amount;
        try {
            amount = Long.parseLong(numberPart.trim());
        } catch (NumberFormatException e) {
            throw new ConfigException("Некорректная длительность: " + raw);
        }
        if (amount < 0) {
            throw new ConfigException("Длительность не может быть отрицательной: " + raw);
        }
        return switch (unitPart) {
            case "ms", "millis", "milliseconds" -> Duration.ofMillis(amount);
            case "s", "sec", "secs", "second", "seconds", "" -> Duration.ofSeconds(amount);
            case "m", "min", "mins", "minute", "minutes" -> Duration.ofMinutes(amount);
            case "h", "hour", "hours" -> Duration.ofHours(amount);
            case "d", "day", "days" -> Duration.ofDays(amount);
            default -> throw new ConfigException("Неизвестная единица длительности: " + raw);
        };
    }

    public static Duration parseOrDefault(String raw, Duration fallback) {
        return raw == null || raw.isBlank() ? fallback : parse(raw);
    }

    public static String format(Duration duration) {
        final long millis = duration.toMillis();
        if (millis % 86_400_000L == 0 && millis >= 86_400_000L) {
            return (millis / 86_400_000L) + "d";
        }
        if (millis % 3_600_000L == 0 && millis >= 3_600_000L) {
            return (millis / 3_600_000L) + "h";
        }
        if (millis % 60_000L == 0 && millis >= 60_000L) {
            return (millis / 60_000L) + "m";
        }
        if (millis % 1000L == 0 && millis >= 1000L) {
            return (millis / 1000L) + "s";
        }
        return millis + "ms";
    }

    private static int firstNonDigit(String value) {
        for (int i = 0; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) {
                return i;
            }
        }
        return -1;
    }
}