package ru.zigono.dmc.common.perm;

import java.util.Collection;
import java.util.Locale;

/**
 * Wildcard permission matching.
 * <p>Supported shapes: {@code *}, {@code console.*}, {@code console.server.*}, {@code console.command.cmi.*},
 * {@code console.command.cmi.heal}. A wildcard matches the node itself and everything below it.</p>
 *
 * @author Zigono
 */
public final class Permissions {

    public static final String GLOBAL_WILDCARD = "*";

    private Permissions() {
    }

    public static String normalize(String node) {
        return node == null ? "" : node.trim().toLowerCase(Locale.ROOT);
    }

    public static boolean matches(String pattern, String node) {
        final String normalizedPattern = normalize(pattern);
        final String normalizedNode = normalize(node);
        if (normalizedPattern.isEmpty() || normalizedNode.isEmpty()) {
            return false;
        }
        if (GLOBAL_WILDCARD.equals(normalizedPattern)) {
            return true;
        }
        if (normalizedPattern.equals(normalizedNode)) {
            return true;
        }
        if (normalizedPattern.endsWith(".*")) {
            final String prefix = normalizedPattern.substring(0, normalizedPattern.length() - 2);
            return normalizedNode.equals(prefix) || normalizedNode.startsWith(prefix + ".");
        }
        if (GLOBAL_WILDCARD.equals(normalizedNode)) {
            return false;
        }
        return false;
    }

    /**
     * @param granted collection of permission patterns held by the subject
     * @param node    the requested permission node
     * @return {@code true} if at least one granted pattern matches the requested node
     */
    public static boolean has(Collection<String> granted, String node) {
        if (granted == null || granted.isEmpty()) {
            return false;
        }
        for (String pattern : granted) {
            if (matches(pattern, node)) {
                return true;
            }
        }
        return false;
    }

    public static boolean hasAny(Collection<String> granted, Collection<String> nodes) {
        for (String node : nodes) {
            if (has(granted, node)) {
                return true;
            }
        }
        return false;
    }
}