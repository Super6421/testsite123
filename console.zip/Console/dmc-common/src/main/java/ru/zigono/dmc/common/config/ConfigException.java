package ru.zigono.dmc.common.config;

/**
 * Thrown when a configuration file is missing, malformed or incomplete.
 *
 * @author Zigono
 */
public class ConfigException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ConfigException(String message) {
        super(message);
    }

    public ConfigException(String message, Throwable cause) {
        super(message, cause);
    }
}