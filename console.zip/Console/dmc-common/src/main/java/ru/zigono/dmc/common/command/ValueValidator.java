package ru.zigono.dmc.common.command;

import ru.zigono.dmc.common.errors.CommandException;
import ru.zigono.dmc.common.errors.ErrorCode;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Strict validation of parameters that are substituted into aliases and templates.
 * Values are never silently repaired: an invalid value is rejected with {@link ErrorCode#INVALID_COMMAND}.
 *
 * @author Zigono
 */
public final class ValueValidator {

    private static final Pattern PLAYER_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final Pattern WORD = Pattern.compile("^[A-Za-z0-9_.\\-]{1,64}$");
    private static final Pattern INTEGER = Pattern.compile("^-?\\d{1,18}$");
    private static final Pattern DECIMAL = Pattern.compile("^-?\\d{1,15}(\\.\\d{1,6})?$");
    private static final Pattern WORLD_NAME = Pattern.compile("^[A-Za-z0-9_./\\-]{1,64}$");

    public static final Set<String> RULES = Set.of("player", "word", "integer", "decimal", "world", "text", "boolean");

    private ValueValidator() {
    }

    public static String validate(String rule, String name, String value) {
        final String effectiveRule = rule == null || rule.isBlank() ? "word" : rule.toLowerCase(Locale.ROOT);
        if (value == null) {
            throw new CommandException(ErrorCode.INVALID_COMMAND, "Не задано значение параметра '" + name + "'");
        }
        final String candidate = value.strip();
        final boolean valid = switch (effectiveRule) {
            case "player" -> PLAYER_NAME.matcher(candidate).matches();
            case "word" -> WORD.matcher(candidate).matches();
            case "integer" -> INTEGER.matcher(candidate).matches();
            case "decimal" -> DECIMAL.matcher(candidate).matches();
            case "world" -> WORLD_NAME.matcher(candidate).matches();
            case "boolean" -> candidate.equalsIgnoreCase("true") || candidate.equalsIgnoreCase("false");
            case "text" -> !candidate.isEmpty() && candidate.length() <= 256 && candidate.chars()
                    .noneMatch(character -> Character.isISOControl(character));
            default -> throw new IllegalArgumentException("Неизвестное правило проверки: " + rule);
        };
        if (!valid) {
            throw new CommandException(ErrorCode.INVALID_COMMAND,
                    "Parameter '" + name + "' не соответствует '" + effectiveRule + "' rule");
        }
        return candidate;
    }

    /**
     * Validates every provided value against its rule.
     *
     * @param rules  parameter name to rule mapping
     * @param values parameter name to raw value mapping
     * @return the validated values
     */
    public static Map<String, String> validateAll(Map<String, String> rules, Map<String, String> values) {
        final java.util.LinkedHashMap<String, String> result = new java.util.LinkedHashMap<>();
        rules.forEach((name, rule) -> result.put(name, validate(rule, name, values.get(name))));
        return Map.copyOf(result);
    }
}