package ru.zigono.dmc.common.perm;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Effective permissions of a subject: a set of granted patterns and a set of denied patterns.
 * Deny always wins, independently of how specific the granted pattern is.
 *
 * @author Zigono
 */
public final class PermissionSet {

    private static final PermissionSet EMPTY = new PermissionSet(Set.of(), Set.of());

    private final Set<String> allow;
    private final Set<String> deny;

    private PermissionSet(Set<String> allow, Set<String> deny) {
        this.allow = allow;
        this.deny = deny;
    }

    public static PermissionSet of(Collection<String> allow, Collection<String> deny) {
        final Set<String> normalizedAllow = new LinkedHashSet<>();
        if (allow != null) {
            allow.forEach(node -> {
                final String normalized = Permissions.normalize(node);
                if (!normalized.isEmpty()) {
                    normalizedAllow.add(normalized);
                }
            });
        }
        final Set<String> normalizedDeny = new LinkedHashSet<>();
        if (deny != null) {
            deny.forEach(node -> {
                final String normalized = Permissions.normalize(node);
                if (!normalized.isEmpty()) {
                    normalizedDeny.add(normalized);
                }
            });
        }
        if (normalizedAllow.isEmpty() && normalizedDeny.isEmpty()) {
            return EMPTY;
        }
        return new PermissionSet(Set.copyOf(normalizedAllow), Set.copyOf(normalizedDeny));
    }

    public static PermissionSet empty() {
        return EMPTY;
    }

    public static PermissionSet of(Collection<String> allow) {
        return of(allow, Set.of());
    }

    public PermissionSet merge(PermissionSet other) {
        if (other == null || other.isEmpty()) {
            return this;
        }
        final Set<String> mergedAllow = new LinkedHashSet<>(allow);
        mergedAllow.addAll(other.allow);
        final Set<String> mergedDeny = new LinkedHashSet<>(deny);
        mergedDeny.addAll(other.deny);
        return of(mergedAllow, mergedDeny);
    }

    public boolean denies(String node) {
        return Permissions.has(deny, node);
    }

    public boolean allows(String node) {
        if (denies(node)) {
            return false;
        }
        return Permissions.has(allow, node);
    }

    public boolean allowsAll(Collection<String> nodes) {
        for (String node : nodes) {
            if (!allows(node)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return allow.isEmpty() && deny.isEmpty();
    }

    public Set<String> allow() {
        return allow;
    }

    public Set<String> deny() {
        return deny;
    }

    @Override
    public String toString() {
        return "PermissionSet[allow=" + allow.size() + ", deny=" + deny.size() + "]";
    }
}