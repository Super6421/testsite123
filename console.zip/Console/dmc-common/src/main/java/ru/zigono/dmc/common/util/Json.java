package ru.zigono.dmc.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;

/**
 * Shared Jackson configuration used by the protocol, the bot and the gateway.
 *
 * @author Zigono
 */
public final class Json {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .enable(DeserializationFeature.FAIL_ON_READING_DUP_TREE_KEY);

    private Json() {
    }

    public static ObjectMapper mapper() {
        return MAPPER;
    }

    public static byte[] writeBytes(Object value) {
        try {
            return MAPPER.writeValueAsBytes(value);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Не удалось сериализовать " + value.getClass().getName(), e);
        }
    }

    public static String write(Object value) {
        try {
            return MAPPER.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Не удалось сериализовать " + value.getClass().getName(), e);
        }
    }

    public static <T> T read(byte[] data, Class<T> type) throws IOException {
        return MAPPER.readValue(data, type);
    }

    public static <T> T read(String data, Class<T> type) {
        try {
            return MAPPER.readValue(data, type);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Не удалось десериализовать " + type.getName(), e);
        }
    }

    public static JsonNode tree(byte[] data) throws IOException {
        return MAPPER.readTree(data);
    }

    public static JsonNode tree(String data) throws IOException {
        return MAPPER.readTree(data);
    }

    public static String compact(JsonNode node) {
        return node.toString();
    }

    public static byte[] utf8(String value) {
        return value.getBytes(StandardCharsets.UTF_8);
    }

    public static String utf8(byte[] value) {
        return new String(value, StandardCharsets.UTF_8);
    }

    public static UncheckedIOException wrap(IOException e) {
        return new UncheckedIOException(e);
    }
}