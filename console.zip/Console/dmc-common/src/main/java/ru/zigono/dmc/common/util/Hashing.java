package ru.zigono.dmc.common.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.util.HexFormat;

/**
 * Hashing and message authentication helpers.
 *
 * @author Zigono
 */
public final class Hashing {

    public static final String HMAC_ALGORITHM = "HmacSHA256";
    private static final HexFormat HEX = HexFormat.of();

    private Hashing() {
    }

    public static byte[] hmacSha256(byte[] key, byte[] data) {
        try {
            final Mac mac = Mac.getInstance(HMAC_ALGORITHM);
            mac.init(new SecretKeySpec(key, HMAC_ALGORITHM));
            return mac.doFinal(data);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("HMAC-SHA256 недоступен", e);
        }
    }

    public static String hmacSha256Hex(byte[] key, String data) {
        return hex(hmacSha256(key, data.getBytes(StandardCharsets.UTF_8)));
    }

    public static String sha256Hex(String data) {
        try {
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return hex(digest.digest(data.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    public static String sha256Hex(byte[] data) {
        try {
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return hex(digest.digest(data));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    public static String hex(byte[] data) {
        return HEX.formatHex(data);
    }

    public static byte[] fromHex(String hex) {
        return HEX.parseHex(hex);
    }

    /**
     * Compares two byte arrays in constant time so signature checks do not leak information.
     */
    public static boolean constantTimeEquals(byte[] left, byte[] right) {
        return MessageDigest.isEqual(left, right);
    }

    public static boolean constantTimeEquals(String left, String right) {
        if (left == null || right == null) {
            return false;
        }
        return MessageDigest.isEqual(left.getBytes(StandardCharsets.UTF_8), right.getBytes(StandardCharsets.UTF_8));
    }
}