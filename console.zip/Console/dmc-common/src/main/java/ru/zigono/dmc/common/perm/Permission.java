package ru.zigono.dmc.common.perm;

/**
 * All permission nodes understood by the system.
 *
 * @author Zigono
 */
public final class Permission {

    public static final String READ = "console.read";
    public static final String STATUS = "console.status";
    public static final String SERVERS = "console.servers";
    public static final String HISTORY = "console.history";
    public static final String EXECUTE = "console.execute";
    public static final String DRY_RUN = "console.dryrun";
    public static final String BROADCAST = "console.broadcast";
    public static final String BROADCAST_ALL = "console.broadcast.all";

    private Permission() {
    }

    public static String server(String serverId) {
        return "console.server." + serverId;
    }

    public static String group(String groupName) {
        return "console.group." + groupName;
    }

    public static String command(String commandRoot) {
        return "console.command." + commandRoot;
    }

    public static String alias(String aliasName) {
        return "console.alias." + aliasName;
    }

    public static String template(String templateName) {
        return "console.template." + templateName;
    }
}