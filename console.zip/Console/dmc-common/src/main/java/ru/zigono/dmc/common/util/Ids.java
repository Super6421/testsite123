package ru.zigono.dmc.common.util;

import java.security.SecureRandom;

/**
 * Time-ordered identifier and nonce generation.
 *
 * @author Zigono
 */
public final class Ids {

    private static final char[] CROCKFORD = "0123456789ABCDEFGHJKMNPQRSTVWXYZ".toCharArray();
    private static final SecureRandom RANDOM = new SecureRandom();

    private Ids() {
    }

    /**
     * Generates a ULID: 48 bit timestamp followed by 80 bit randomness, encoded with Crockford base32.
     *
     * @return a 26 character, lexicographically sortable identifier
     */
    public static String ulid() {
        final byte[] random = new byte[10];
        RANDOM.nextBytes(random);
        final char[] out = new char[26];
        long time = System.currentTimeMillis();
        for (int i = 9; i >= 0; i--) {
            out[i] = CROCKFORD[(int) (time & 0x1F)];
            time >>>= 5;
        }
        int bitBuffer = 0;
        int bitCount = 0;
        int index = 10;
        for (byte b : random) {
            bitBuffer = (bitBuffer << 8) | (b & 0xFF);
            bitCount += 8;
            while (bitCount >= 5) {
                bitCount -= 5;
                out[index++] = CROCKFORD[(bitBuffer >> bitCount) & 0x1F];
            }
        }
        if (bitCount > 0) {
            out[index] = CROCKFORD[(bitBuffer << (5 - bitCount)) & 0x1F];
        }
        return new String(out);
    }

    /**
     * Generates a cryptographically strong nonce encoded as lowercase hexadecimal.
     *
     * @param bytes entropy size in bytes
     * @return hex encoded nonce
     */
    public static String nonce(int bytes) {
        if (bytes < 8 || bytes > 64) {
            throw new IllegalArgumentException("размер nonce должен быть от 8 до 64 байт");
        }
        final byte[] buffer = new byte[bytes];
        RANDOM.nextBytes(buffer);
        return Hashing.hex(buffer);
    }
}