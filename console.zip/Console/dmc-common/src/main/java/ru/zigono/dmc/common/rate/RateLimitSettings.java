package ru.zigono.dmc.common.rate;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Rate limit configuration. Limits can be declared per user, role, server, command, group and globally, with
 * optional per server and per command overrides.
 * <pre>
 * rate_limit:
 *   enabled: true
 *   per_user:    { requests: 10,  interval_seconds: 10 }
 *   per_role:    { requests: 100, interval_seconds: 10 }
 *   per_server:  { requests: 50,  interval_seconds: 10 }
 *   per_command: { requests: 20,  interval_seconds: 10 }
 *   per_group:   { requests: 50,  interval_seconds: 10 }
 *   global:      { requests: 500, interval_seconds: 10 }
 *   servers:
 *     survival:  { requests: 5, interval_seconds: 10 }
 *   commands:
 *     "cmi heal": { requests: 3, interval_seconds: 60 }
 * </pre>
 *
 * @author Zigono
 */
public record RateLimitSettings(boolean enabled, Rule perUser, Rule perRole, Rule perServer, Rule perCommand,
                                Rule perGroup, Rule global, Map<String, Rule> serverOverrides,
                                Map<String, Rule> commandOverrides, Map<String, Rule> groupOverrides) {

    public static final String USER_SCOPE = "user";
    public static final String ROLE_SCOPE = "role";
    public static final String SERVER_SCOPE = "server";
    public static final String COMMAND_SCOPE = "command";
    public static final String GROUP_SCOPE = "group";
    public static final String GLOBAL_SCOPE = "global";

    /**
     * @param requests       number of allowed requests inside the interval
     * @param intervalMillis length of the sliding window in milliseconds
     */
    public record Rule(int requests, long intervalMillis) {
        public static final Rule UNLIMITED = new Rule(0, 0);

        public boolean unlimited() {
            return requests <= 0 || intervalMillis <= 0;
        }
    }

    public static RateLimitSettings disabled() {
        return new RateLimitSettings(false, Rule.UNLIMITED, Rule.UNLIMITED, Rule.UNLIMITED, Rule.UNLIMITED,
                Rule.UNLIMITED, Rule.UNLIMITED, Map.of(), Map.of(), Map.of());
    }

    public static RateLimitSettings from(YamlConfig root) {
        final YamlConfig section = root.section("rate_limit");
        if (section.isEmpty()) {
            return disabled();
        }
        final boolean enabled = section.bool("enabled", true);
        return new RateLimitSettings(
                enabled,
                rule(section, "per_user"),
                rule(section, "per_role"),
                rule(section, "per_server"),
                rule(section, "per_command"),
                rule(section, "per_group"),
                rule(section, "global"),
                overrides(section.section("servers")),
                overrides(section.section("commands")),
                overrides(section.section("groups")));
    }

    private static Map<String, Rule> overrides(YamlConfig section) {
        final Map<String, Rule> result = new LinkedHashMap<>();
        for (String key : section.keys("")) {
            result.put(key, rule(section, key));
        }
        return Map.copyOf(result);
    }

    private static Rule rule(YamlConfig section, String path) {
        if (section.section(path).isEmpty()) {
            return Rule.UNLIMITED;
        }
        final int requests = section.integer(path + ".requests", 0);
        if (requests < 0) {
            throw new ConfigException("rate_limit." + path + ".requests не может быть отрицательным");
        }
        long intervalMillis;
        if (section.has(path + ".interval")) {
            intervalMillis = section.duration(path + ".interval", java.time.Duration.ofSeconds(10)).toMillis();
        } else {
            intervalMillis = section.integer(path + ".interval_seconds", 10) * 1000L;
        }
        if (intervalMillis <= 0) {
            throw new ConfigException("rate_limit." + path + ".interval_seconds должен быть положительным");
        }
        return new Rule(requests, intervalMillis);
    }

    /**
     * @param scope one of {@code user}, {@code role}, {@code server}, {@code command}, {@code group}, {@code global}
     * @param key   the scope specific key, e.g. the server id
     */
    public Rule ruleFor(String scope, String key) {
        return switch (scope) {
            case USER_SCOPE -> perUser;
            case ROLE_SCOPE -> perRole;
            case SERVER_SCOPE -> serverOverrides.getOrDefault(key, perServer);
            case COMMAND_SCOPE -> commandOverrides.getOrDefault(key, perCommand);
            case GROUP_SCOPE -> groupOverrides.getOrDefault(key, perGroup);
            case GLOBAL_SCOPE -> global;
            default -> Rule.UNLIMITED;
        };
    }
}