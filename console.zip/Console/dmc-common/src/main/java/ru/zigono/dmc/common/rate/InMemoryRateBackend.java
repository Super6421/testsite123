package ru.zigono.dmc.common.rate;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Sliding window rate limit backend kept in process memory. Bounded by the configured limit so a hostile
 * caller cannot grow the window beyond the quota size.
 *
 * @author Zigono
 */
public final class InMemoryRateBackend implements RateBackend {

    private final ConcurrentMap<String, Window> windows = new ConcurrentHashMap<>();
    private final int maxTrackedKeys;

    public InMemoryRateBackend(int maxTrackedKeys) {
        this.maxTrackedKeys = maxTrackedKeys;
    }

    public InMemoryRateBackend() {
        this(20_000);
    }

    private static final class Window {
        private final Deque<Long> timestamps = new ArrayDeque<>();
        private long lastAccess;

        synchronized boolean acquire(long now, int limit, long windowMillis) {
            lastAccess = now;
            prune(now - windowMillis);
            if (timestamps.size() >= limit) {
                return false;
            }
            timestamps.addLast(now);
            return true;
        }

        synchronized long retryAfter(long now, int limit, long windowMillis) {
            lastAccess = now;
            prune(now - windowMillis);
            if (timestamps.size() < limit) {
                return 0L;
            }
            final Long oldest = timestamps.peekFirst();
            return oldest == null ? 0L : Math.max(0L, oldest + windowMillis - now);
        }

        synchronized void reset() {
            timestamps.clear();
        }

        private void prune(long threshold) {
            while (!timestamps.isEmpty() && timestamps.peekFirst() <= threshold) {
                timestamps.pollFirst();
            }
        }
    }

    @Override
    public boolean tryAcquire(String key, int limit, long windowMillis) {
        if (limit <= 0 || windowMillis <= 0) {
            return true;
        }
        pruneStale();
        return window(key).acquire(System.currentTimeMillis(), limit, windowMillis);
    }

    @Override
    public long retryAfterMillis(String key, int limit, long windowMillis) {
        if (limit <= 0 || windowMillis <= 0) {
            return 0L;
        }
        return window(key).retryAfter(System.currentTimeMillis(), limit, windowMillis);
    }

    @Override
    public void reset(String key) {
        final Window window = windows.remove(key);
        if (window != null) {
            window.reset();
        }
    }

    private Window window(String key) {
        return windows.computeIfAbsent(key, ignored -> new Window());
    }

    private void pruneStale() {
        if (windows.size() <= maxTrackedKeys) {
            return;
        }
        final long threshold = System.currentTimeMillis() - 3_600_000L;
        final Iterator<java.util.Map.Entry<String, Window>> iterator = windows.entrySet().iterator();
        while (iterator.hasNext() && windows.size() > maxTrackedKeys / 2) {
            final java.util.Map.Entry<String, Window> entry = iterator.next();
            if (entry.getValue().lastAccess < threshold) {
                iterator.remove();
            }
        }
    }
}