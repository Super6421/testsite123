package ru.zigono.dmc.common.text;

import java.util.Map;

/**
 * Renders {@code {placeholder}} style templates used by configuration driven messages and embeds.
 *
 * @author Zigono
 */
public final class Template {

    private Template() {
    }

    public static String render(String template, Map<String, String> values) {
        if (template == null) {
            return "";
        }
        final StringBuilder out = new StringBuilder(template.length());
        int index = 0;
        while (index < template.length()) {
            final int start = template.indexOf('{', index);
            if (start < 0) {
                out.append(template, index, template.length());
                break;
            }
            final int end = template.indexOf('}', start + 1);
            if (end < 0) {
                out.append(template, index, template.length());
                break;
            }
            final String key = template.substring(start + 1, end);
            final String replacement = values.get(key);
            out.append(template, index, start);
            out.append(replacement == null ? "" : replacement);
            index = end + 1;
        }
        return out.toString();
    }
}