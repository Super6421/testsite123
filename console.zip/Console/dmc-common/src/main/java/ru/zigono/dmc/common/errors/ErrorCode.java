package ru.zigono.dmc.common.errors;

/**
 * Standardized error codes shared by the bot, the gateway and the plugin.
 * The user facing description of an error is resolved from the language files by the key
 * {@code error.<CODE>}.
 *
 * @author Zigono
 */
public enum ErrorCode {

    PERMISSION_DENIED(false),
    SERVER_OFFLINE(true),
    TIMEOUT(true),
    INVALID_COMMAND(false),
    INVALID_TARGET(false),
    RATE_LIMIT(true),
    AUTHENTICATION_FAILED(false),
    QUEUE_FULL(true),
    POLICY_DENIED(false),
    CONFIRMATION_REQUIRED(false),
    EMERGENCY_MODE(false),
    NO_TARGETS(false),
    CONNECTION_LOST(true),
    CONFIGURATION_ERROR(false),
    PROTOCOL_ERROR(false),
    DRY_RUN(false),
    INTERNAL_ERROR(true);

    private final boolean retryable;

    ErrorCode(boolean retryable) {
        this.retryable = retryable;
    }

    /**
     * @return {@code true} when a retry may succeed without repeating a side effect on the Minecraft server.
     */
    public boolean retryable() {
        return retryable;
    }

    public String messageKey() {
        return "error." + name();
    }
}