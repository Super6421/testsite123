package ru.zigono.dmc.common.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * Polls one or more configuration files and triggers a hot reload callback when their content changes.
 * The callback is executed on a single dedicated thread, so reloads can never run concurrently.
 *
 * @author Zigono
 */
public final class ConfigWatcher implements AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigWatcher.class);

    private final java.util.List<Path> files;
    private final java.util.Map<Path, String> fingerprints = new java.util.concurrent.ConcurrentHashMap<>();
    private final Consumer<Path> onChange;
    private final Duration window;
    private final ScheduledExecutorService scheduler;
    private final AtomicBoolean running = new AtomicBoolean();
    private ScheduledFuture<?> task;

    public ConfigWatcher(java.util.List<Path> files, Duration window, Consumer<Path> onChange) {
        this.files = java.util.List.copyOf(files);
        this.onChange = Objects.requireNonNull(onChange, "onChange");
        this.scheduler = Executors.newSingleThreadScheduledExecutor(runnable -> {
            final Thread thread = new Thread(runnable, "dmc-config-watcher");
            thread.setDaemon(true);
            return thread;
        });
        this.window = window;
    }

    public void start() {
        if (!running.compareAndSet(false, true)) {
            return;
        }
        for (Path file : files) {
            fingerprints.put(file, fingerprint(file));
        }
        final long millis = Math.max(250L, window.toMillis());
        task = scheduler.scheduleWithFixedDelay(this::poll, millis, millis, TimeUnit.MILLISECONDS);
        LOGGER.info("Слежу за изменениями {} файл(ов) конфигурации каждые {} мс", files.size(), millis);
    }

    private void poll() {
        if (!running.get()) {
            return;
        }
        for (Path file : files) {
            final String current = fingerprint(file);
            final String previous = fingerprints.put(file, current);
            if (!Objects.equals(previous, current)) {
                LOGGER.info("Обнаружено изменение конфигурации {}", file);
                try {
                    onChange.accept(file);
                } catch (RuntimeException e) {
                    LOGGER.error("Горячая перезагрузка, вызванная {}, не удалась", file, e);
                }
            }
        }
    }

    private String fingerprint(Path file) {
        try {
            if (!Files.isRegularFile(file)) {
                return "missing";
            }
            final MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(Files.readAllBytes(file)));
        } catch (IOException | NoSuchAlgorithmException e) {
            return "unreadable:" + e.getClass().getSimpleName();
        }
    }

    @Override
    public void close() {
        running.set(false);
        if (task != null) {
            task.cancel(false);
        }
        scheduler.shutdownNow();
    }
}