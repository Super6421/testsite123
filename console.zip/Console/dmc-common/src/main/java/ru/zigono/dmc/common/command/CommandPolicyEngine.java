package ru.zigono.dmc.common.command;

import ru.zigono.dmc.common.config.ConfigException;
import ru.zigono.dmc.common.config.YamlConfig;
import ru.zigono.dmc.common.errors.ErrorCode;
import ru.zigono.dmc.common.perm.Permission;
import ru.zigono.dmc.common.perm.PermissionSet;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Command Policy Engine. Runs after normalization and before anything is sent to the gateway.
 * <p>Checks, in order: blocked commands, whitelist mode, explicit command policies, the derived
 * {@code console.command.<root>} permission and finally the dangerous command confirmation requirement.</p>
 *
 * @author Zigono
 */
public final class CommandPolicyEngine {

    private final List<PolicyRule> rules;
    private final List<TokenPattern> blocked;
    private final List<TokenPattern> allowed;
    private final List<TokenPattern> dangerous;

    private CommandPolicyEngine(List<PolicyRule> rules, List<TokenPattern> blocked, List<TokenPattern> allowed,
                                List<TokenPattern> dangerous) {
        this.rules = rules;
        this.blocked = blocked;
        this.allowed = allowed;
        this.dangerous = dangerous;
    }

    /**
     * A single policy rule. {@code deny} rules win over everything else.
     */
    public record PolicyRule(TokenPattern pattern, boolean deny, String permission, boolean requireConfirmation) {
    }

    /**
     * Decision of the policy engine. {@code allowed} is {@code true} only when the command may be dispatched.
     */
    public record Decision(boolean allowed, boolean requiresConfirmation, String requiredPermission, ErrorCode error,
                           String reason) {

        public static Decision allow(String requiredPermission, boolean requiresConfirmation) {
            return new Decision(true, requiresConfirmation, requiredPermission, null, "allowed");
        }

        public static Decision deny(ErrorCode error, String reason) {
            return new Decision(false, false, null, error, reason);
        }
    }

    public static CommandPolicyEngine from(YamlConfig root) {
        final YamlConfig security = root.section("security");
        final List<TokenPattern> blocked = TokenPattern.listOf(security.stringList("blocked_commands", List.of()));
        final List<TokenPattern> allowed = TokenPattern.listOf(security.stringList("allowed_commands", List.of()));
        final List<TokenPattern> dangerous = TokenPattern.listOf(security.stringList("dangerous_commands", List.of()));
        return new CommandPolicyEngine(parseRules(root), blocked, allowed, dangerous);
    }

    private static List<PolicyRule> parseRules(YamlConfig root) {
        final List<PolicyRule> result = new ArrayList<>();
        final List<java.util.Map<String, Object>> list = root.mapList("command_policies");
        final YamlConfig section = root.sectionOrEmpty("command_policies");
        if (!list.isEmpty()) {
            for (java.util.Map<String, Object> entry : list) {
                final String pattern = entry.get("pattern") == null ? null : String.valueOf(entry.get("pattern"));
                if (pattern == null || pattern.isBlank()) {
                    throw new ConfigException("Каждая запись command_policies должна задавать pattern");
                }
                result.add(rule(pattern, entry));
            }
            return result;
        }
        for (String pattern : section.keys("")) {
            final YamlConfig entry = section.section(pattern);
            result.add(rule(pattern, entry.asMap()));
        }
        return result;
    }

    private static PolicyRule rule(String pattern, java.util.Map<String, Object> entry) {
        final YamlConfig config = YamlConfig.of(entry, "command_policies." + pattern);
        final boolean deny = config.bool("deny", false);
        final boolean requireConfirmation = config.bool("require_confirmation", false);
        final String permission = config.string("permission", null);
        return new PolicyRule(TokenPattern.of(pattern), deny, permission, requireConfirmation);
    }

    /**
     * @param command     normalized command
     * @param permissions effective permissions of the requesting user
     * @param confirmed   whether the user already confirmed a dangerous command
     */
    public Decision evaluate(NormalizedCommand command, PermissionSet permissions, boolean confirmed) {
        for (TokenPattern pattern : blocked) {
            if (pattern.matches(command.tokens())) {
                return Decision.deny(ErrorCode.POLICY_DENIED, "команда заблокирована политикой: " + pattern.raw());
            }
        }
        if (!allowed.isEmpty()) {
            final boolean matched = allowed.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
            if (!matched) {
                return Decision.deny(ErrorCode.POLICY_DENIED, "команды нет в белом списке политики");
            }
        }
        PolicyRule matched = null;
        for (PolicyRule rule : rules) {
            if (rule.pattern().matches(command.tokens())
                    && (matched == null || rule.pattern().specificity() > matched.pattern().specificity())) {
                matched = rule;
            }
        }
        if (matched != null && matched.deny()) {
            return Decision.deny(ErrorCode.POLICY_DENIED, "команда запрещена политикой: " + matched.pattern().raw());
        }
        final String rulePermission = matched == null ? null : matched.permission();
        final String requiredPermission = rulePermission == null ? qualified(command) : rulePermission;
        if (!permissions.allows(requiredPermission)) {
            return Decision.deny(ErrorCode.PERMISSION_DENIED,
                    "missing permission " + requiredPermission + " для команды '" + command.normalized() + "'");
        }
        final boolean dangerousCommand = dangerous.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
        final boolean requiresConfirmation = dangerousCommand || (matched != null && matched.requireConfirmation());
        if (requiresConfirmation && !confirmed) {
            return Decision.deny(ErrorCode.CONFIRMATION_REQUIRED, "command requires confirmation");
        }
        return Decision.allow(requiredPermission, requiresConfirmation);
    }

    /**
     * @return the most specific permission node derived from the command, e.g. {@code cmi heal} becomes
     * {@code console.command.cmi.heal}
     */
    public static String qualified(NormalizedCommand command) {
        final StringBuilder node = new StringBuilder("console.command.");
        node.append(command.root());
        if (command.tokens().size() > 1) {
            node.append('.').append(sanitizeNode(command.tokens().get(1)));
        }
        return node.toString();
    }

    private static String sanitizeNode(String token) {
        final StringBuilder out = new StringBuilder(token.length());
        for (int i = 0; i < token.length(); i++) {
            final char character = Character.toLowerCase(token.charAt(i));
            if ((character >= 'a' && character <= 'z') || (character >= '0' && character <= '9')
                    || character == '_' || character == '-') {
                out.append(character);
            } else if (character == '.' || character == ':') {
                out.append('_');
            }
        }
        return out.isEmpty() ? "_" : out.toString();
    }

    public boolean isDangerous(NormalizedCommand command) {
        return dangerous.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
    }

    public boolean isBlocked(NormalizedCommand command) {
        return blocked.stream().anyMatch(pattern -> pattern.matches(command.tokens()));
    }

    public Set<String> dangerousPatterns() {
        final Set<String> result = new LinkedHashSet<>();
        dangerous.forEach(pattern -> result.add(pattern.raw()));
        return Set.copyOf(result);
    }

    public List<PolicyRule> rules() {
        return List.copyOf(rules);
    }

    /**
     * Token wise command pattern. A {@code *} token matches exactly one arbitrary token, {@code *} and {@code ?}
     * inside a token match within that token, and the command may carry additional trailing arguments.
     *
     * @author Zigono
     */
    public static final class TokenPattern {

        private final String raw;
        private final List<Pattern> tokens;

        private TokenPattern(String raw, List<Pattern> tokens) {
            this.raw = raw;
            this.tokens = tokens;
        }

        public static TokenPattern of(String raw) {
            final String normalized = raw.trim().toLowerCase(Locale.ROOT);
            if (normalized.isEmpty()) {
                throw new ConfigException("Шаблон команды не может быть пустым");
            }
            final List<Pattern> compiled = new ArrayList<>();
            for (String token : normalized.split("\\s+")) {
                if (token.equals("*")) {
                    compiled.add(Pattern.compile(".+"));
                } else {
                    compiled.add(Pattern.compile(globToRegex(token)));
                }
            }
            return new TokenPattern(normalized, List.copyOf(compiled));
        }

        public static List<TokenPattern> listOf(List<String> patterns) {
            final List<TokenPattern> result = new ArrayList<>(patterns.size());
            for (String pattern : patterns) {
                if (pattern != null && !pattern.isBlank()) {
                    result.add(of(pattern));
                }
            }
            return List.copyOf(result);
        }

        private static String globToRegex(String token) {
            final StringBuilder regex = new StringBuilder("^");
            for (int i = 0; i < token.length(); i++) {
                final char character = token.charAt(i);
                switch (character) {
                    case '*' -> regex.append(".*");
                    case '?' -> regex.append('.');
                    case '.', '(', ')', '[', ']', '{', '}', '+', '^', '$', '|', '\\' -> regex.append('\\').append(character);
                    default -> regex.append(character);
                }
            }
            return regex.append(".*$").toString();
        }

        public boolean matches(List<String> commandTokens) {
            if (commandTokens.size() < tokens.size()) {
                return false;
            }
            for (int i = 0; i < tokens.size(); i++) {
                if (!tokens.get(i).matcher(commandTokens.get(i).toLowerCase(Locale.ROOT)).matches()) {
                    return false;
                }
            }
            return true;
        }

        public int specificity() {
            return tokens.size();
        }

        public String raw() {
            return raw;
        }

        @Override
        public String toString() {
            return raw;
        }
    }
}
