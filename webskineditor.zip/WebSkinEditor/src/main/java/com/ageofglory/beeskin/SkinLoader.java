package com.ageofglory.beeskin;

import org.bukkit.entity.Player;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.lang.reflect.Method;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import javax.imageio.ImageIO;

/** Loads the player's current texture once for the editor; all network work is async. */
final class SkinLoader {
  private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
  static void loadAsync(BeeSkinPlugin plugin, TokenStore.Session session, Player player) {
    String textureUrl = textureUrlFromSkinsRestorer(player);
    if (textureUrl == null) {
      try { var skin = player.getPlayerProfile().getTextures().getSkin(); if (skin != null) textureUrl = skin.toString(); } catch (Throwable ignored) { }
    }
    if (textureUrl == null || textureUrl.isBlank()) return;
    try {
      HttpRequest request = HttpRequest.newBuilder(URI.create(textureUrl)).timeout(Duration.ofSeconds(8)).header("User-Agent", "BeeSkin/1.0 AgeOfGlory").GET().build();
      HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofByteArray()).thenAccept(response -> {
        if (response.statusCode() != 200) return;
        try {
          BufferedImage image = ImageIO.read(new ByteArrayInputStream(response.body()));
          if (image != null && image.getWidth() == 64 && image.getHeight() == 64) session.png = response.body();
        } catch (Exception ignored) { }
      }).exceptionally(error -> { plugin.getLogger().fine("Current skin download failed: " + error.getMessage()); return null; });
    } catch (Exception error) { plugin.getLogger().fine("Current skin URL is invalid: " + error.getMessage()); }
  }

  private static String textureUrlFromSkinsRestorer(Player player) {
    try {
      if (player.getServer().getPluginManager().getPlugin("SkinsRestorer") == null) return null;
      Object api = Class.forName("net.skinsrestorer.api.SkinsRestorerProvider").getMethod("get").invoke(null);
      Object storage = api.getClass().getMethod("getPlayerStorage").invoke(api);
      Object result = storage.getClass().getMethod("getSkinForPlayer", java.util.UUID.class, String.class).invoke(storage, player.getUniqueId(), player.getName());
      if (!(result instanceof java.util.Optional<?> optional) || optional.isEmpty()) return null;
      Object property = optional.get();
      Class<?> utils = Class.forName("net.skinsrestorer.api.PropertyUtils");
      Method textureMethod = null;
      for (Method method : utils.getMethods()) {
        if (method.getName().equals("getSkinTextureUrl") && method.getParameterCount() == 1 && method.getParameterTypes()[0].isAssignableFrom(property.getClass())) { textureMethod = method; break; }
      }
      if (textureMethod == null) return null;
      Object url = textureMethod.invoke(null, property);
      return url == null ? null : url.toString();
    } catch (Throwable ignored) { return null; }
  }
}
