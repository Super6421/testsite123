package com.ageofglory.beeskin;

import org.bukkit.entity.Player;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TokenStore {
    public static final class Session { public final String token; public final UUID playerId; public final String playerName; public final long expiresAt; public volatile byte[] png; Session(String token, UUID playerId, String playerName, long expiresAt) { this.token=token; this.playerId=playerId; this.playerName=playerName; this.expiresAt=expiresAt; } boolean valid() { return Instant.now().toEpochMilli() < expiresAt; } }
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();
    private final long ttl;
    public TokenStore(int minutes) { ttl = Math.max(1, minutes) * 60_000L; }
    public Session issue(Player player) { cleanup(); String token = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes(32)); Session s = new Session(token, player.getUniqueId(), player.getName(), Instant.now().toEpochMilli() + ttl); sessions.put(token, s); return s; }
    public Session find(String token) { Session s = sessions.get(token); return s != null && s.valid() ? s : null; }
    public Session findByPlayer(UUID id) { for (Session s : sessions.values()) if (s.playerId.equals(id) && s.valid()) return s; return null; }
    private byte[] randomBytes(int n) { byte[] b = new byte[n]; random.nextBytes(b); return b; }
    private void cleanup() { sessions.entrySet().removeIf(e -> !e.getValue().valid()); }
}
