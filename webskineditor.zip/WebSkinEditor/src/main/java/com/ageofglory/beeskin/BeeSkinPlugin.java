package com.ageofglory.beeskin;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.Objects;

public final class BeeSkinPlugin extends JavaPlugin {
    private EditorServer editorServer;
    private TokenStore tokenStore;

    @Override public void onEnable() {
        saveDefaultConfig();
        tokenStore = new TokenStore(getConfig().getInt("token-minutes", 15));
        editorServer = new EditorServer(this, tokenStore);
        try { editorServer.start(); }
        catch (Exception ex) { getLogger().severe("BeeSkin web server failed: " + ex.getMessage()); getServer().getPluginManager().disablePlugin(this); return; }
        PluginCommand command = Objects.requireNonNull(getCommand("skineditor"));
        command.setExecutor(new EditorCommand(this, tokenStore));
        getLogger().info("BeeSkin enabled for AgeOfGlory on port " + editorServer.port());
    }

    @Override public void onDisable() { if (editorServer != null) editorServer.stop(); }
    public String publicUrl(String token) {
        String configured = getConfig().getString("public-url", "").trim();
        if (!configured.isEmpty()) return configured.replaceAll("/$", "") + "/?token=" + token;
        return "http://" + (getConfig().getString("bind-address", "0.0.0.0").equals("0.0.0.0") ? "127.0.0.1" : getConfig().getString("bind-address")) + ":" + editorServer.port() + "/?token=" + token;
    }
}
