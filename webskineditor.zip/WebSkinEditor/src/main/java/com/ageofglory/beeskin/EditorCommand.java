package com.ageofglory.beeskin;

import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public final class EditorCommand implements CommandExecutor {
    private final BeeSkinPlugin plugin; private final TokenStore tokens;
    public EditorCommand(BeeSkinPlugin plugin, TokenStore tokens) { this.plugin = plugin; this.tokens = tokens; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Only players can open BeeSkin."); return true; }
        if (!p.hasPermission("beeskin.use")) { p.sendMessage(ChatColor.RED + "Нет прав."); return true; }
        var session = tokens.issue(p);
        SkinLoader.loadAsync(plugin, session, p);
        p.sendMessage(ChatColor.GOLD + "BeeSkin " + ChatColor.YELLOW + "для AgeOfGlory");
        p.sendMessage(ChatColor.WHITE + "Открой редактор: " + ChatColor.AQUA + plugin.publicUrl(session.token));
        p.sendMessage(ChatColor.GRAY + "Ссылка действует 15 минут и одноразово привязана к твоему аккаунту.");
        return true;
    }
}
