package com.ageofglory.beeskin;

import com.sun.net.httpserver.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.util.Base64;
import java.util.regex.Pattern;

public final class EditorServer {
    private final BeeSkinPlugin plugin; private final TokenStore tokens; private HttpServer server;
    public EditorServer(BeeSkinPlugin plugin, TokenStore tokens) { this.plugin = plugin; this.tokens = tokens; }
    public void start() throws IOException {
        InetSocketAddress address = new InetSocketAddress(plugin.getConfig().getString("bind-address", "0.0.0.0"), plugin.getConfig().getInt("port", 8765));
        server = HttpServer.create(address, 0); server.createContext("/", this::handle); server.setExecutor(null); server.start();
    }
    public int port() { return server == null ? plugin.getConfig().getInt("port", 8765) : server.getAddress().getPort(); }
    public void stop() { if (server != null) server.stop(0); }
    private void handle(HttpExchange ex) throws IOException {
        try {
            addCors(ex); String path = ex.getRequestURI().getPath(); String method = ex.getRequestMethod(); boolean head = "HEAD".equalsIgnoreCase(method);
            if (("GET".equalsIgnoreCase(method) || head) && (path.equals("/") || path.equals("/index.html"))) { send(ex, 200, "text/html; charset=utf-8", resource("web/index.html"), head); return; }
            if (("GET".equalsIgnoreCase(method) || head) && path.startsWith("/web/")) { send(ex, 200, mime(path), resource(path.substring(1)), head); return; }
            if (("GET".equalsIgnoreCase(method) || head) && path.equals("/api/session")) { session(ex); return; }
            if (("GET".equalsIgnoreCase(method) || head) && path.equals("/api/skin.png")) { skinPng(ex, head); return; }
            if ("POST".equals(ex.getRequestMethod()) && path.equals("/api/apply")) { apply(ex); return; }
            send(ex, 404, "application/json", "{\"error\":\"not_found\"}");
        } catch (Exception e) { plugin.getLogger().warning("BeeSkin HTTP: " + e.getMessage()); send(ex, 500, "application/json", "{\"error\":\"server_error\"}"); }
    }
    private void session(HttpExchange ex) throws IOException {
        TokenStore.Session s = tokens.find(query(ex, "token")); if (s == null) { send(ex, 401, "application/json", "{\"error\":\"invalid_token\"}"); return; }
        send(ex, 200, "application/json", "{\"player\":\"" + esc(s.playerName) + "\",\"expiresAt\":" + s.expiresAt + ",\"skinReady\":" + (s.png != null) + "}");
    }
    private void skinPng(HttpExchange ex, boolean head) throws IOException { String key = query(ex, "token"); TokenStore.Session s = tokens.find(key); if (s == null) { try { s = tokens.findByPlayer(java.util.UUID.fromString(key)); } catch (IllegalArgumentException ignored) {} } if (s == null || s.png == null) { send(ex, 404, "text/plain", "not found", head); return; } ex.getResponseHeaders().set("Content-Type", "image/png"); ex.getResponseHeaders().set("Cache-Control", "no-store"); ex.sendResponseHeaders(200, head ? -1 : s.png.length); if (!head) try (OutputStream o = ex.getResponseBody()) { o.write(s.png); } else ex.close(); }
    private void apply(HttpExchange ex) throws IOException {
        String token = query(ex, "token"); TokenStore.Session s = tokens.find(token); if (s == null) { send(ex, 401, "application/json", "{\"error\":\"invalid_token\"}"); return; }
        int maxBody = plugin.getConfig().getInt("max-upload-bytes", 1048576) * 2; String length = ex.getRequestHeaders().getFirst("Content-Length"); if (length != null) { try { if (Long.parseLong(length) > maxBody) { send(ex, 413, "application/json", "{\"error\":\"request_too_large\"}"); return; } } catch (NumberFormatException ignored) { } }
        String body = new String(readLimited(ex.getRequestBody(), maxBody), StandardCharsets.UTF_8); String png = jsonValue(body, "png");
        if (png == null || !png.startsWith("data:image/png;base64,")) { send(ex, 400, "application/json", "{\"error\":\"png_required\"}"); return; }
        byte[] bytes; try { bytes = Base64.getDecoder().decode(png.substring(png.indexOf(',') + 1)); } catch (IllegalArgumentException badBase64) { send(ex, 400, "application/json", "{\"error\":\"invalid_png\"}"); return; }
        if (bytes.length > plugin.getConfig().getInt("max-upload-bytes", 1048576)) { send(ex, 413, "application/json", "{\"error\":\"file_too_large\"}"); return; }
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes)); if (image == null || image.getWidth() != 64 || image.getHeight() != 64) { send(ex, 400, "application/json", "{\"error\":\"skin_must_be_64x64\"}"); return; }
        // One-shot, main-thread bridge. SkinsRestorer is intentionally optional at compile time.
        s.png = bytes; Bukkit.getScheduler().runTask(plugin, () -> SkinApplier.apply(plugin, s.playerId, bytes));
        send(ex, 200, "application/json", "{\"ok\":true,\"message\":\"Скин отправлен на применение\"}");
    }
    private static byte[] readLimited(InputStream input, int max) throws IOException { java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(Math.min(max, 8192)); byte[] buffer = new byte[8192]; int total=0, read; while ((read=input.read(buffer))!=-1) { total += read; if (total > max) throw new IOException("request too large"); out.write(buffer,0,read); } return out.toByteArray(); }
    private String resource(String path) throws IOException { try (InputStream in = plugin.getResource(path)) { if (in == null) throw new FileNotFoundException(path); return new String(in.readAllBytes(), StandardCharsets.UTF_8); } }
    private static String jsonValue(String body, String key) { var m = Pattern.compile("\\\"" + key + "\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").matcher(body); return m.find() ? m.group(1) : null; }
    private static String query(HttpExchange e, String k) { String q=e.getRequestURI().getRawQuery(); if(q==null)return ""; for(String p:q.split("&")){String[] a=p.split("=",2);if(a.length==2&&a[0].equals(k))try{return URLDecoder.decode(a[1],"UTF-8");}catch(Exception ignored){}} return ""; }
    private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    private static String mime(String p) { return p.endsWith(".js") ? "application/javascript" : p.endsWith(".css") ? "text/css" : "text/plain"; }
    private static void addCors(HttpExchange e) { e.getResponseHeaders().add("Access-Control-Allow-Origin", "*"); }
    private static void send(HttpExchange e,int code,String type,String text)throws IOException{send(e,code,type,text,"HEAD".equalsIgnoreCase(e.getRequestMethod()));}
    private static void send(HttpExchange e,int code,String type,String text,boolean head)throws IOException{byte[] b=text.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type",type);e.sendResponseHeaders(code,head ? -1 : b.length);if(!head)try(OutputStream o=e.getResponseBody()){o.write(b);}else e.close();}
}
