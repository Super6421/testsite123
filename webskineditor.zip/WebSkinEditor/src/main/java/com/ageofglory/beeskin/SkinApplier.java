package com.ageofglory.beeskin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.lang.reflect.Method;
import java.nio.file.*;
import java.util.UUID;

/** Runtime-only SkinsRestorer bridge. No SR or MineSkin jar is bundled into BeeSkin. */
final class SkinApplier {
  static void apply(BeeSkinPlugin plugin, UUID uuid, byte[] png) {
    try {
      Path dir = plugin.getDataFolder().toPath().resolve("pending"); Files.createDirectories(dir);
      Files.write(dir.resolve(uuid + ".png"), png, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    } catch (Exception e) { plugin.getLogger().warning("Skin file save failed: " + e.getMessage()); return; }
    Player initial = Bukkit.getPlayer(uuid);
    if (initial == null) return;
    if (Bukkit.getPluginManager().getPlugin("SkinsRestorer") == null) { initial.sendMessage("§eBeeSkin: установите SkinsRestorer для применения скина."); return; }
    // MineSkin generation is a network operation, so it must not block the Paper main thread.
    Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> generateAndApply(plugin, uuid, png));
  }

  private static void generateAndApply(BeeSkinPlugin plugin, UUID uuid, byte[] png) {
    try {
      Object api = Class.forName("net.skinsrestorer.api.SkinsRestorerProvider").getMethod("get").invoke(null);
      Object mine = api.getClass().getMethod("getMineSkinAPI").invoke(api);
      Class<?> variant = Class.forName("net.skinsrestorer.api.property.SkinVariant");
      Object classic = Enum.valueOf((Class<Enum>) variant.asSubclass(Enum.class), "CLASSIC");
      Method gen = null;
      for (Method method : mine.getClass().getMethods()) {
        if (method.getName().equals("genSkin") && method.getParameterCount() == 2 && method.getParameterTypes()[0] == byte[].class) { gen = method; break; }
      }
      if (gen == null) throw new NoSuchMethodException("SkinsRestorer MineSkinAPI.genSkin(byte[], SkinVariant)");
      Object response = gen.invoke(mine, png, classic);
      Object property = response.getClass().getMethod("getProperty").invoke(response);
      final Object finalApi = api; final Object finalProperty = property;
      Bukkit.getScheduler().runTask(plugin, () -> {
        try {
          Player player = Bukkit.getPlayer(uuid); if (player == null) return;
          Object applier = finalApi.getClass().getMethod("getSkinApplier", Class.class).invoke(finalApi, Player.class);
          Method apply = null;
          for (Method method : applier.getClass().getMethods()) if (method.getName().equals("applySkin") && method.getParameterCount() == 2) { apply = method; break; }
          if (apply == null) throw new NoSuchMethodException("SkinsRestorer SkinApplier.applySkin(Player, SkinProperty)");
          apply.invoke(applier, player, finalProperty);
          player.sendMessage("§aBeeSkin: скин применён на сервере без перезахода.");
        } catch (Throwable e) { report(plugin, uuid, e); }
      });
    } catch (Throwable e) { report(plugin, uuid, e); }
  }

  private static void report(BeeSkinPlugin plugin, UUID uuid, Throwable error) {
    Throwable root = error; while (root.getCause() != null) root = root.getCause();
    final String detail = root.getClass().getSimpleName() + ": " + String.valueOf(root.getMessage());
    plugin.getLogger().warning("SkinsRestorer apply failed: " + detail);
    Bukkit.getScheduler().runTask(plugin, () -> { Player p = Bukkit.getPlayer(uuid); if (p != null) p.sendMessage("§cBeeSkin: SkinsRestorer не смог обработать текстуру: " + detail); });
  }
}
